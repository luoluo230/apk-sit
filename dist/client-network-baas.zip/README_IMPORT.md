﻿# 瀹㈡埛绔綉缁滄ā鍧楋細baas

| 瀛楁 | 鍊?|
|------|-----|
| 閰嶅鏈嶅姟绔?| casual_baas_server |
| Unity 瀵煎叆鐩綍 | Assets/Modules/BaasNetwork |
| 绋嬪簭闆?| MAClient.Network.Baas |
| Bootstrap | /api/public/client-bootstrap |

---

## 鍓嶆彁

- Unity 2022.3+ / Unity 6锛堜笌 maclient 涓€鑷达級
- **鍩虹宸ョ▼**浠呬繚鐣?`ClientNetworkModuleGate`锛坄MAClient.Network.Abstractions`锛夛紝**涓嶈**棰勭疆鏈ā鍧椾唬鐮?- 鏈嶅姟绔凡鎸?`SERVER_DEPLOY_GUIDE.md` 閮ㄧ讲骞?health 姝ｅ父

---

## 姝ラ 1 鈥?瑙ｅ帇

```powershell
Expand-Archive -Path client-network-baas-*.zip -DestinationPath E:\tmp\baas-module -Force
```

瑙ｅ帇鍚庢牴鐩綍涓?`ClientNetworkModule/`锛屽唴鍚?`manifest.json`銆乣Runtime/`銆乣stubs/`銆?
---

## 姝ラ 2 鈥?瀵煎叆 Unity 宸ョ▼

鍦?**apk-site** 浠撳簱鏍圭洰褰曟墽琛岋細

```powershell
powershell -ExecutionPolicy Bypass -File scripts\Import-ClientNetworkModule.ps1 
  -Module baas 
  -MaclientRoot E:\maclient 
  -SourceDir E:\tmp\baas-module\ClientNetworkModule
```

鑴氭湰浼氾細

1. 澶嶅埗 `Runtime/` 鍒?`Assets/Modules/BaasNetwork/Runtime/`
2. 鍐欏叆 `MAClient.Network.Baas.asmdef`
3. 鍚屾 `stubs/Runtime/ClientNetworkModuleGate.cs` 鍒?Abstractions锛堣嫢缂哄け锛?4. 鏇存柊 `Assets/StreamingAssets/client_network_modules.json`

---

## 姝ラ 3 鈥?Unity 缂栬瘧楠岃瘉

1. 鎵撳紑 Unity Hub 鈫?鎵撳紑 maclient 宸ョ▼
2. 绛夊緟鑴氭湰缂栬瘧瀹屾垚锛圕onsole 鏃?error锛?3. 纭绋嬪簭闆?`MAClient.Network.Baas` 瀛樺湪
4. 杩愯鏃?`ClientNetworkModuleGate.HasBaasModule` 涓?true

---

## 姝ラ 4 鈥?Bootstrap 鑱旇皟

1. 鍦?HotUpdateConfig / 椤圭洰閰嶇疆濉叆 Portal 涓嬪彂鐨?`game_id` / `game_key`
2. 鍚姩娓告垙鎴?PlayMode 娴嬭瘯鎷夊彇 `/api/public/client-bootstrap`
3. 楠岃瘉缃戠粶娉ㄥ叆锛堟嫇鎵戯細`gateway_ws`锛汢aaS锛歚public_api_base`锛?
---

## 姝ラ 5 鈥?鍗歌浇妯″潡锛堟仮澶嶅共鍑€鍩虹嚎锛?
```powershell
powershell -ExecutionPolicy Bypass -File scripts\Import-ClientNetworkModule.ps1 
  -Module baas -MaclientRoot E:\maclient -Remove
```

---

## 鍖呭唴鏂囦欢璇存槑

| 璺緞 | 璇存槑 |
|------|------|
| `Runtime/` | 妯″潡杩愯鏃?C# |
| `Runtime/PortalHttp.cs` | 鍏变韩 HTTP GET锛坆ootstrap锛?|
| `stubs/` | 鍩虹嚎 Gate锛屽鍏ユ椂鍚堝苟鍒?Abstractions |
| `manifest.json` | 妯″潡鍏冩暟鎹?|
| `SERVER_DEPLOY_GUIDE.md` | 閰嶅鏈嶅姟绔€愭閮ㄧ讲鏁欑▼ |
| `Tests/PlayMode/` | 锛坆aas锛夊彲閫?PlayMode E2E |

---

## 娉ㄦ剰

- **鍚屼竴浜у搧**閫氬父鍙鍏?**topology** 鎴?**baas** 涔嬩竴锛涘弻鏍堥渶鏄庣‘鏋舵瀯璇勫
- 鎷撴墤鍖呰嫢鍚?`maclient/` 瀛愮洰褰曪紝Import 浼氶澶栧悎骞?GameServer 缃戠粶鏍堜笌鍗忚璧勪骇
- 璇︾粏鏈嶅姟绔儴缃茶 `SERVER_DEPLOY_GUIDE.md`
