﻿# Client Network Module: baas
Pairs with: casual_baas_server
Import target: Assets/Modules/BaasNetwork

1. Unzip to a temp folder.
2. Run Import-ClientNetworkModule.ps1 -Module baas -SourceDir <unzipped>
3. Unity will compile assembly MAClient.Network.Baas.
