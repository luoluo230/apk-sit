# 中重度拓扑服务器架构 — 部署包

生成时间: 2026-08-19T09:48:05Z

## 快速开始

1. 解压到 apk-site 仓库根目录（与 portals/、scripts/ 同级合并）。
2. 安装 Python 依赖后启动 Portal：
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\Start-DevStack.ps1 -SkipGameServer
   ```
3. 同步客户端拓扑网络模块：
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\Sync-DevStackClientConfig.ps1 -Mode topology
   ```
4. Portal 管理入口：服务器管理 → 中重度服务器

## 环境变量

- `PORTAL_SERVER_FRAMEWORKS=topology`
- Bootstrap: `/api/public/client-bootstrap`
- 客户端包: `packages/client_network/topology`

详细逐步教程（必读）：

- `docs/runbooks/topology_server_deploy_step_by_step.md`

速查 Runbook 见 docs/runbooks/ 与 docs/design_specs/。
