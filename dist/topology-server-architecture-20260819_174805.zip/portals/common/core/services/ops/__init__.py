"""Ops platform services."""
