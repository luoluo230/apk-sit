# -*- coding: utf-8 -*-
"""Route dependency injection — direct ops submodule imports (Plan P1-01 Step 6)."""

from __future__ import annotations

from services.ops import cross_bind

cross_bind.wire_all()

# Facade-only: auth + page render
from services.ops.helpers import (  # noqa: E402
    _allow_gm_execute,
    _allow_ops_execute,
    _allow_ops_view,
    _ops_csrf_token,
    _render_local_template,
    _render_ops_page,
    _render_page,
    _render_standalone_page,
    _session_username,
)

from services.ops import (  # noqa: E402
    agent_registry,
    cluster_importer,
    diagnostics,
    runtime_orchestrator,
    runtime_service,
    shared_bootstrap,
    storage,
    topology_contracts,
    topology_registry,
    topology_service,
)

for _mod in (
    shared_bootstrap,
    storage,
    topology_service,
    runtime_service,
    cluster_importer,
    topology_contracts,
    topology_registry,
    agent_registry,
    runtime_orchestrator,
    diagnostics,
):
    for _name, _val in vars(_mod).items():
        if _name.startswith("__"):
            continue
        globals()[_name] = _val

del _mod, _name, _val, cross_bind
