# 轻度 BaaS 服务器架构 — 部署包

生成时间: 2026-08-19T09:48:06Z

## 快速开始

1. 解压到 apk-site 仓库根目录（与 portals/、scripts/ 同级合并）。
2. 一键启动独立 BaaS：
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\Start-BaaSStack.ps1 -Background
   ```
3. 可选 PostgreSQL：添加 `-UsePostgres`
4. 同步客户端 BaaS 模块：
   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\Sync-DevStackClientConfig.ps1 -Mode baas
   ```
5. 默认地址：http://127.0.0.1:5004/admin/baas

## 环境变量

- `PORTAL_SERVER_FRAMEWORKS=baas`
- Bootstrap: `/api/public/client-bootstrap`
- 客户端包: `packages/client_network/baas`

详细逐步教程（必读）：

- `docs/runbooks/baas_server_deploy_step_by_step.md`

速查 Runbook 见 docs/runbooks/ 与 docs/design_specs/。
