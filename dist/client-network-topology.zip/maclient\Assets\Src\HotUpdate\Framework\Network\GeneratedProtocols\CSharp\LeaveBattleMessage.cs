﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 离开战斗会话请求
/// </summary>
public class LeaveBattle_c2s
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 离开原因(主动/断线/超时等)
    /// </summary>
    public string Reason { get; set; }
    /// <summary>
    /// 客户端时间戳
    /// </summary>
    public long ClientTime { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 离开战斗会话响应
/// </summary>
public class LeaveBattle_s2c
{
    /// <summary>
    /// 是否离开成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 结果说明
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 最终结果(可空)
    /// </summary>
    public BattleResultType FinalResult { get; set; }
    /// <summary>
    /// 最终锚点(可空)
    /// </summary>
    public BattleTimelineAnchor Anchor { get; set; }
}

