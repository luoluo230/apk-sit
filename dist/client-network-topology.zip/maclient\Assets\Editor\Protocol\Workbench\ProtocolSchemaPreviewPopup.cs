using UnityEditor;
using UnityEngine;

public sealed class ProtocolSchemaPreviewPopup : EditorWindow
{
    private string _title;
    private string _content;
    private Vector2 _scroll;

    public static void Open(string title, string content)
    {
        var window = CreateInstance<ProtocolSchemaPreviewPopup>();
        window.titleContent = new GUIContent("Protocol Preview");
        window._title = title;
        window._content = content;
        window.minSize = new Vector2(640f, 520f);
        window.ShowUtility();
    }

    private void OnGUI()
    {
        GUILayout.Label(_title ?? "Protocol Preview", EditorStyles.boldLabel);
        _scroll = EditorGUILayout.BeginScrollView(_scroll);
        EditorGUILayout.TextArea(_content ?? string.Empty, GUILayout.ExpandHeight(true));
        EditorGUILayout.EndScrollView();
    }
}
