using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;

public sealed class ProtocolSkillAiRepairService
{
    private readonly string _repoRoot;
    private readonly IProtocolSkillAiInvoker _invoker;

    public ProtocolSkillAiRepairService(string repoRoot, IProtocolSkillAiInvoker invoker)
    {
        _repoRoot = repoRoot;
        _invoker = invoker;
    }

    public ProtocolSkillAiResponse RepairIfNeeded(ProtocolSkillGenerationPlan plan, ProtocolSkillAiRequest originalRequest, ProtocolSkillAiResponse response, Action<string> log)
    {
        if (plan == null || response == null || !response.Success || !plan.Options.AutoRepairAfterAi || plan.Options.AiRepairRounds <= 0) return response;
        Dictionary<string, string> backups = BackupFiles(response.Files);
        try
        {
            ProtocolSkillAiResponse current = response;
            for (int round = 0; round < plan.Options.AiRepairRounds; round++)
            {
                WriteFiles(current.Files);
                string compileLog = RunUnityBatchCompile(out bool compileOk);
                if (compileOk)
                {
                    log?.Invoke("AI generated code compile check passed.");
                    ReadBackFiles(current.Files);
                    return current;
                }

                string errors = ExtractCompileErrors(compileLog);
                log?.Invoke("AI generated code compile failed. Repair round " + (round + 1) + ":\n" + errors);
                var repairRequest = new ProtocolSkillAiRequest
                {
                    PlanId = originalRequest.PlanId,
                    PromptMarkdown = originalRequest.PromptMarkdown,
                    PromptJson = originalRequest.PromptJson,
                    CompileErrorFeedback = errors,
                    PreviousAiOutput = RenderFilesForPrompt(current.Files)
                };
                repairRequest.Contexts.AddRange(originalRequest.Contexts);
                ProtocolSkillAiResponse repaired = _invoker.Invoke(repairRequest);
                if (!repaired.Success)
                {
                    current.Warnings.Add("AI repair failed: " + repaired.Message);
                    return current;
                }
                current = repaired;
            }
            return current;
        }
        finally
        {
            RestoreFiles(backups);
            AssetDatabase.Refresh();
        }
    }

    private Dictionary<string, string> BackupFiles(IEnumerable<ProtocolSkillPlanFile> files)
    {
        var backups = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (ProtocolSkillPlanFile file in files)
        {
            string path = ToAbsolutePath(file.Path);
            backups[path] = File.Exists(path) ? File.ReadAllText(path, Encoding.UTF8) : null;
        }
        return backups;
    }

    private void WriteFiles(IEnumerable<ProtocolSkillPlanFile> files)
    {
        foreach (ProtocolSkillPlanFile file in files)
        {
            string path = ToAbsolutePath(file.Path);
            Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
            File.WriteAllText(path, file.Content ?? string.Empty, new UTF8Encoding(false));
        }
        AssetDatabase.Refresh();
    }

    private void ReadBackFiles(IEnumerable<ProtocolSkillPlanFile> files)
    {
        foreach (ProtocolSkillPlanFile file in files)
        {
            string path = ToAbsolutePath(file.Path);
            if (File.Exists(path)) file.Content = File.ReadAllText(path, Encoding.UTF8);
        }
    }

    private void RestoreFiles(Dictionary<string, string> backups)
    {
        foreach (KeyValuePair<string, string> pair in backups)
        {
            if (pair.Value == null) { if (File.Exists(pair.Key)) File.Delete(pair.Key); }
            else
            {
                Directory.CreateDirectory(Path.GetDirectoryName(pair.Key) ?? string.Empty);
                File.WriteAllText(pair.Key, pair.Value, new UTF8Encoding(false));
            }
        }
    }

    private string RunUnityBatchCompile(out bool compileOk)
    {
        string logPath = Path.Combine(_repoRoot, "Temp", "protocol-skill-ai-compile.log");
        Directory.CreateDirectory(Path.GetDirectoryName(logPath) ?? string.Empty);
        var startInfo = new ProcessStartInfo
        {
            FileName = EditorApplication.applicationPath,
            Arguments = "-batchmode -quit -projectPath \"" + _repoRoot + "\" -logFile \"" + logPath + "\"",
            UseShellExecute = false,
            CreateNoWindow = true
        };
        using (Process process = Process.Start(startInfo))
        {
            process?.WaitForExit(240000);
        }
        string log = File.Exists(logPath) ? File.ReadAllText(logPath, Encoding.UTF8) : string.Empty;
        compileOk = log.IndexOf("error CS", StringComparison.OrdinalIgnoreCase) < 0
            && log.IndexOf("Compilation failed", StringComparison.OrdinalIgnoreCase) < 0
            && log.IndexOf("Multiple Unity instances", StringComparison.OrdinalIgnoreCase) < 0;
        return log;
    }

    private static string ExtractCompileErrors(string log)
    {
        if (string.IsNullOrWhiteSpace(log)) return "No compile log was produced.";
        return string.Join("\n", log.Replace("\r\n", "\n").Split('\n').Where(line =>
            line.IndexOf("error CS", StringComparison.OrdinalIgnoreCase) >= 0
            || line.IndexOf("Compilation failed", StringComparison.OrdinalIgnoreCase) >= 0
            || line.IndexOf("Multiple Unity instances", StringComparison.OrdinalIgnoreCase) >= 0
            || line.IndexOf("Assets/", StringComparison.OrdinalIgnoreCase) >= 0).Take(120));
    }

    private static string RenderFilesForPrompt(IEnumerable<ProtocolSkillPlanFile> files)
    {
        var builder = new StringBuilder();
        foreach (ProtocolSkillPlanFile file in files)
        {
            builder.AppendLine("## " + file.Path);
            builder.AppendLine("```");
            builder.AppendLine(file.Content ?? string.Empty);
            builder.AppendLine("```");
        }
        return builder.ToString();
    }

    private string ToAbsolutePath(string path)
    {
        return Path.IsPathRooted(path) ? path : Path.GetFullPath(Path.Combine(_repoRoot, path));
    }
}
