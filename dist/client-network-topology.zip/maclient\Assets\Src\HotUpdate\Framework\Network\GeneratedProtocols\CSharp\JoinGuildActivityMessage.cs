﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 加入公会活动
/// </summary>
public class JoinGuildActivity_c2s
{
    /// <summary>
    /// 活动 ID
    /// </summary>
    public string ActivityId { get; set; }
}

/// <summary>
/// 加入公会活动结果
/// </summary>
public class JoinGuildActivity_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

