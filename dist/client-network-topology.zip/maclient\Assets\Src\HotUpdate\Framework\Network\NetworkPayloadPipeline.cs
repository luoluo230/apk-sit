using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using Newtonsoft.Json;

public interface INetworkSerializer
{
    string Name { get; }
    string Serialize(object payload);
    object Deserialize(string payload, Type targetType);
}

public interface INetworkCompressionProvider
{
    byte[] Compress(byte[] input);
    byte[] Decompress(byte[] input);
}

public interface INetworkCryptoProvider
{
    byte[] Encrypt(byte[] input);
    byte[] Decrypt(byte[] input);
}

internal sealed class NetworkJsonSerializer : INetworkSerializer
{
    public string Name => "json";
    public string Serialize(object payload) => JsonConvert.SerializeObject(payload);
    public object Deserialize(string payload, Type targetType) => JsonConvert.DeserializeObject(payload, targetType);
}

internal sealed class NetworkBinaryJsonSerializer : INetworkSerializer
{
    public string Name => "binary";
    public string Serialize(object payload)
    {
        string json = JsonConvert.SerializeObject(payload);
        return Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
    }

    public object Deserialize(string payload, Type targetType)
    {
        byte[] bytes = Convert.FromBase64String(payload);
        string json = Encoding.UTF8.GetString(bytes);
        return JsonConvert.DeserializeObject(json, targetType);
    }
}

internal sealed class NetworkProtobufLikeSerializer : INetworkSerializer
{
    public string Name => "protobuflike";
    public string Serialize(object payload)
    {
        string json = JsonConvert.SerializeObject(payload);
        byte[] bytes = Encoding.UTF8.GetBytes(json);
        return Convert.ToBase64String(bytes);
    }

    public object Deserialize(string payload, Type targetType)
    {
        byte[] bytes = Convert.FromBase64String(payload);
        string json = Encoding.UTF8.GetString(bytes);
        return JsonConvert.DeserializeObject(json, targetType);
    }
}

internal sealed class GZipNetworkCompressionProvider : INetworkCompressionProvider
{
    public byte[] Compress(byte[] input)
    {
        using (var output = new MemoryStream())
        {
            using (var gzip = new GZipStream(output, CompressionLevel.Fastest, true))
            {
                gzip.Write(input, 0, input.Length);
            }
            return output.ToArray();
        }
    }

    public byte[] Decompress(byte[] input)
    {
        using (var source = new MemoryStream(input))
        using (var gzip = new GZipStream(source, CompressionMode.Decompress))
        using (var output = new MemoryStream())
        {
            gzip.CopyTo(output);
            return output.ToArray();
        }
    }
}

internal sealed class XorNetworkCryptoProvider : INetworkCryptoProvider
{
    private readonly byte[] _key;

    public XorNetworkCryptoProvider(string key)
    {
        _key = Encoding.UTF8.GetBytes(string.IsNullOrWhiteSpace(key) ? "MAClient.NetworkKey" : key);
    }

    public byte[] Encrypt(byte[] input) => Xor(input);
    public byte[] Decrypt(byte[] input) => Xor(input);

    private byte[] Xor(byte[] input)
    {
        var output = new byte[input.Length];
        for (int i = 0; i < input.Length; i++)
        {
            output[i] = (byte)(input[i] ^ _key[i % _key.Length]);
        }
        return output;
    }
}

internal sealed class NetworkPayloadEnvelope
{
    public string Serializer;
    public bool Compressed;
    public bool Encrypted;
    public string PayloadBase64;
}

public static class NetworkPayloadPipeline
{
    private static readonly Dictionary<string, INetworkSerializer> Serializers = new Dictionary<string, INetworkSerializer>(StringComparer.OrdinalIgnoreCase);

    private static INetworkCompressionProvider _compressionProvider = new GZipNetworkCompressionProvider();
    private static INetworkCryptoProvider _cryptoProvider = new XorNetworkCryptoProvider("MAClient.NetworkKey");

    private static string _activeSerializerName = "json";
    private static bool _compressionEnabled;
    private static bool _encryptionEnabled;

    static NetworkPayloadPipeline()
    {
        RegisterSerializer(new NetworkJsonSerializer());
        RegisterSerializer(new NetworkBinaryJsonSerializer());
        RegisterSerializer(new NetworkProtobufLikeSerializer());
    }

    public static void RegisterSerializer(INetworkSerializer serializer)
    {
        if (serializer == null || string.IsNullOrWhiteSpace(serializer.Name))
        {
            return;
        }

        Serializers[serializer.Name] = serializer;
    }

    /// <summary>
    /// 判断指定序列化器是否已注册。
    /// </summary>
    public static bool HasSerializer(string serializerName)
    {
        string key = string.IsNullOrWhiteSpace(serializerName) ? "json" : serializerName;
        return Serializers.ContainsKey(key);
    }

    public static void Configure(string serializerName, bool enableCompression, bool enableEncryption, INetworkCompressionProvider compressionProvider = null, INetworkCryptoProvider cryptoProvider = null)
    {
        if (!string.IsNullOrWhiteSpace(serializerName))
        {
            _activeSerializerName = serializerName;
        }

        _compressionEnabled = enableCompression;
        _encryptionEnabled = enableEncryption;

        if (compressionProvider != null)
        {
            _compressionProvider = compressionProvider;
        }

        if (cryptoProvider != null)
        {
            _cryptoProvider = cryptoProvider;
        }
    }

    public static string Encode(object payload)
    {
        var serializer = ResolveSerializer(_activeSerializerName);
        string serialized = serializer.Serialize(payload);
        if (!_compressionEnabled && !_encryptionEnabled && string.Equals(serializer.Name, "json", StringComparison.OrdinalIgnoreCase))
        {
            return serialized;
        }

        byte[] bytes = Encoding.UTF8.GetBytes(serialized);

        if (_compressionEnabled)
        {
            bytes = _compressionProvider.Compress(bytes);
        }

        if (_encryptionEnabled)
        {
            bytes = _cryptoProvider.Encrypt(bytes);
        }

        var envelope = new NetworkPayloadEnvelope
        {
            Serializer = serializer.Name,
            Compressed = _compressionEnabled,
            Encrypted = _encryptionEnabled,
            PayloadBase64 = Convert.ToBase64String(bytes)
        };

        return JsonConvert.SerializeObject(envelope);
    }

    public static object Decode(string rawPayload, Type targetType)
    {
        if (string.IsNullOrWhiteSpace(rawPayload))
        {
            return null;
        }

        NetworkPayloadEnvelope envelope = null;
        try
        {
            envelope = JsonConvert.DeserializeObject<NetworkPayloadEnvelope>(rawPayload);
        }
        catch
        {
        }

        if (envelope == null || string.IsNullOrWhiteSpace(envelope.PayloadBase64))
        {
            return JsonConvert.DeserializeObject(rawPayload, targetType);
        }

        byte[] bytes = Convert.FromBase64String(envelope.PayloadBase64);
        if (envelope.Encrypted)
        {
            bytes = _cryptoProvider.Decrypt(bytes);
        }

        if (envelope.Compressed)
        {
            bytes = _compressionProvider.Decompress(bytes);
        }

        string serialized = Encoding.UTF8.GetString(bytes);
        var serializer = ResolveSerializer(envelope.Serializer);
        return serializer.Deserialize(serialized, targetType);
    }

    private static INetworkSerializer ResolveSerializer(string serializerName)
    {
        string key = string.IsNullOrWhiteSpace(serializerName) ? "json" : serializerName;
        if (!Serializers.TryGetValue(key, out var serializer))
        {
            throw new InvalidOperationException("NETWORK_SERIALIZER_NOT_FOUND:" + key);
        }
        return serializer;
    }
}
