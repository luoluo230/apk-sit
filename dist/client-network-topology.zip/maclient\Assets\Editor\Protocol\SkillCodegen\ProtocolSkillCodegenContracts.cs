using System;
using System.Collections.Generic;

/// <summary>
/// M09-07A Protocol Skill Codegen 的目标端。
/// Client 生成客户端调用封装，Server 生成服务端 handler/service/repository 骨架，Both 同时生成双端。
/// </summary>
public enum ProtocolSkillTarget
{
    Client,
    Server,
    Both
}

/// <summary>
/// AI Skill 支持的业务代码生成能力。
/// 每个 Skill 都对应一套明确输入、输出文件、生成约束和校验规则。
/// </summary>
[Flags]
public enum ProtocolSkillKind
{
    None = 0,
    ClientApiWrapper = 1 << 0,
    ClientUseCase = 1 << 1,
    ClientPresenterBinding = 1 << 2,
    ServerHandler = 1 << 3,
    ServerService = 1 << 4,
    ServerRepository = 1 << 5,
    ServerRouteRegistration = 1 << 6,
    MockAndTest = 1 << 7,
    Migration = 1 << 8,
    All = ClientApiWrapper | ClientUseCase | ClientPresenterBinding | ServerHandler | ServerService | ServerRepository | ServerRouteRegistration | MockAndTest | Migration
}

/// <summary>
/// 生成代码风格。
/// 项目早期可用 Callback，后续如果接 UniTask/Task，可按选项生成不同 API。
/// </summary>
public enum ProtocolSkillCodeStyle
{
    Callback,
    TaskAsync,
    UniTask,
    Coroutine
}

public enum ProtocolSkillServerLanguage
{
    CSharp,
    TypeScriptNodeJs,
    Python,
    Java,
    Go,
    Kotlin
}

public enum ProtocolSkillBusinessDomain
{
    Common,
    Login,
    Profile,
    Inventory,
    Hero,
    Battle,
    Social,
    Guild,
    Mail,
    Shop,
    Activity
}

/// <summary>
/// 生成深度。
/// Minimal 只生成薄封装，Standard 生成推荐业务骨架，FullSample 额外生成示例、mock 和测试。
/// </summary>
public enum ProtocolSkillGenerationDepth
{
    Minimal,
    Standard,
    FullSample
}

/// <summary>
/// 数据库代码生成策略。
/// 数据库代码风险较高，因此默认只生成 schema 建议，避免把临时字段或敏感字段直接落库。
/// </summary>
public enum ProtocolSkillDatabaseStrategy
{
    None,
    SuggestSchemaOnly,
    GenerateModelAndRepository,
    GenerateModelRepositoryAndMigration
}

/// <summary>
/// Skill Codegen 的一次生成选项。
/// 这些选项会同时写入 context/plan，保证 AI 或本地模板生成过程可追踪、可复现。
/// </summary>
public sealed class ProtocolSkillCodegenOptions
{
    public ProtocolSkillTarget Target = ProtocolSkillTarget.Client;
    public ProtocolSkillKind Skills = ProtocolSkillKind.ClientApiWrapper | ProtocolSkillKind.MockAndTest;
    public ProtocolSkillCodeStyle CodeStyle = ProtocolSkillCodeStyle.Callback;
    public ProtocolSkillServerLanguage ServerLanguage = ProtocolSkillServerLanguage.CSharp;
    public ProtocolSkillGenerationDepth Depth = ProtocolSkillGenerationDepth.Standard;
    public ProtocolSkillDatabaseStrategy DatabaseStrategy = ProtocolSkillDatabaseStrategy.SuggestSchemaOnly;
    public bool IncludeSelectedOnly = true;
    public bool DryRun = true;
    public bool PreserveManualBlocks = true;
    public bool GenerateSkillContext = true;
    public bool GeneratePlanMarkdown = true;
    public bool GenerateAiPromptPayload = true;
    public bool EnableDomainSkillTemplates = true;
    public bool EnableCodebaseRetrieval = true;
    public bool EnableBusinessConstraintTemplate = true;
    public bool AutoRepairAfterAi = true;
    public int AiRepairRounds = 1;
    public string BusinessRequirementSupplement = string.Empty;
    public string ClientOutputRoot = "Assets/Src/HotUpdate/Business/GeneratedProtocolSkills/Client";
    public string ServerOutputRoot = "game-server/shared/ProtocolSkills/Generated";
    public string ServerHandlerRoot = "game-server/shared/ProtocolSkills/Generated/Handlers";
    public string ServerServiceRoot = "game-server/shared/ProtocolSkills/Generated/Services";
    public string ServerRepositoryRoot = "game-server/shared/ProtocolSkills/Generated/Repositories";
    public string ServerDbModelRoot = "game-server/shared/ProtocolSkills/Generated/DbModels";
    public string ServerMigrationRoot = "game-server/shared/ProtocolSkills/Generated/Migrations";
    public string ServerRouteRoot = "game-server/shared/ProtocolSkills/Generated/Routing";
    public string ContextOutputRoot = "protocols/generated/skill-codegen/context";
    public string PlanOutputRoot = "protocols/generated/skill-codegen/plans";
    public string ClientNamespace = "HotUpdate.Business.ProtocolSkills";
    public string ServerNamespace = "GameServer.ProtocolSkills";
    public string NetworkFacadeType = "NetworkFacade";
    public string RequestSendMethod = "Send";
    public string DbAccessPattern = "Repository";
    public string AiEndpoint = "https://api.deepseek.com/v1/chat/completions";
    public string AiModel = "deepseek-reasoner";
    public float AiTemperature = 0.2f;
    public int AiTimeoutSeconds = 600;
    public int AiMaxTokens = 8192;
}

/// <summary>
/// AI Skill 使用的协议上下文。
/// 该上下文会被导出为 JSON/Markdown，供本地模板或真正 AI 调用读取。
/// </summary>
public sealed class ProtocolSkillContext
{
    public string ProtocolName;
    public string Module;
    public string RequestName;
    public string ResponseName;
    public int RequestMessageId;
    public int ResponseMessageId;
    public string Comment;
    public string Status;
    public string SinceVersion;
    public string ClientDtoPath;
    public string ServerDtoPath;
    public string ClientProtocolIdsPath;
    public string ServerProtocolIdsPath;
    public string ClientDictionaryPath;
    public string ServerDictionaryPath;
    public string NetworkFacadeType;
    public string NetworkSendMethod;
    public string NetworkCallPattern;
    public string ServerHandlerRoot;
    public string ServerServiceRoot;
    public string ServerRepositoryRoot;
    public string ServerDbModelRoot;
    public string ServerMigrationRoot;
    public string ServerRouteRoot;
    public string DatabaseAccessPattern;
    public string ServerArchitectureSummary;
    public string DetectedDbFramework;
    public string DetectedDbContextType;
    public string DetectedLoggerPattern;
    public string DetectedErrorCodeType;
    public string DetectedTransactionPattern;
    public string ClientLanguage;
    public string ServerLanguage;
    public string BusinessDomain;
    public string DomainPromptTemplatePath;
    public string BusinessConstraintSummary;
    public string RetrievedCodeSummary;
    public readonly List<string> ClientReferencePaths = new List<string>();
    public readonly List<string> ServerReferencePaths = new List<string>();
    public readonly List<ProtocolSchemaField> RequestFields = new List<ProtocolSchemaField>();
    public readonly List<ProtocolSchemaField> ResponseFields = new List<ProtocolSchemaField>();
    public readonly List<string> Dependencies = new List<string>();
}

/// <summary>
/// 一条待写入文件的生成计划。
/// Apply 前先展示计划，避免 AI 或模板直接覆盖业务代码。
/// </summary>
public sealed class ProtocolSkillPlanFile
{
    public string Path;
    public string Action;
    public string Skill;
    public string Reason;
    public string Content;
}

/// <summary>
/// 一次 Skill 生成计划。
/// 计划中同时包含风险提示、上下文路径和待写入文件，方便审查与回滚。
/// </summary>
public sealed class ProtocolSkillGenerationPlan
{
    public string PlanId;
    public string GeneratedAtUtc;
    public ProtocolSkillCodegenOptions Options;
    public readonly List<ProtocolSkillContext> Contexts = new List<ProtocolSkillContext>();
    public readonly List<ProtocolSkillPlanFile> Files = new List<ProtocolSkillPlanFile>();
    public readonly List<string> Risks = new List<string>();
    public readonly List<string> ContextFiles = new List<string>();
}

/// <summary>
/// Skill 定义。
/// 目前先使用本地模板生成，后续接 AI 时可把 PromptTemplatePath 和 ProtocolSkillContext 一起发送给 AI。
/// </summary>
public sealed class ProtocolSkillDefinition
{
    public ProtocolSkillKind Kind;
    public ProtocolSkillTarget Target;
    public string DisplayName;
    public string Description;
    public string PromptTemplatePath;
    public bool WritesRuntimeCode;
    public bool RequiresDatabaseReview;
}

/// <summary>
/// 预留给真实 AI API 的 Skill 调用请求。
/// 当前版本先导出 AI Prompt Payload；后续拿到 API 后，只需要实现 IAiSkillInvoker 并把 payload 发给服务即可。
/// </summary>
public sealed class ProtocolSkillAiRequest
{
    public string PlanId;
    public string PromptMarkdown;
    public string PromptJson;
    public string CompileErrorFeedback;
    public string PreviousAiOutput;
    public readonly List<ProtocolSkillContext> Contexts = new List<ProtocolSkillContext>();
}

/// <summary>
/// AI Skill 调用返回。
/// 返回内容仍然建议走 ProtocolSkillGenerationPlan 审查后再写入，避免 AI 直接覆盖项目代码。
/// </summary>
public sealed class ProtocolSkillAiResponse
{
    public bool Success;
    public string Message;
    public string RawResponseJson;
    public string RawAssistantContent;
    public readonly List<ProtocolSkillPlanFile> Files = new List<ProtocolSkillPlanFile>();
    public readonly List<string> Warnings = new List<string>();
}

/// <summary>
/// AI Skill 调用接口。
/// 用户后续提供 OpenAI、私有网关或公司内部 AI API 后，实现该接口即可接入工作台。
/// </summary>
public interface IProtocolSkillAiInvoker
{
    ProtocolSkillAiResponse Invoke(ProtocolSkillAiRequest request);
}
