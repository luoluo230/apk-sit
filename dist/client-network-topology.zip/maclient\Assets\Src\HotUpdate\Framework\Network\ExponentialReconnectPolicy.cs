using UnityEngine;

/// <summary>
/// 指数退避重连策略。
/// 每次重连按 2 的指数增长等待时长，并受最大值限制。
/// </summary>
public sealed class ExponentialReconnectPolicy : IReconnectPolicy
{
    /// <summary>
    /// 计算本次重连等待时长。
    /// </summary>
    public float GetDelaySeconds(int attempt, float baseDelaySeconds, float maxDelaySeconds)
    {
        if (attempt <= 0)
        {
            return Mathf.Max(0f, baseDelaySeconds);
        }

        float delay = baseDelaySeconds * Mathf.Pow(2f, attempt);
        return Mathf.Min(delay, maxDelaySeconds);
    }
}
