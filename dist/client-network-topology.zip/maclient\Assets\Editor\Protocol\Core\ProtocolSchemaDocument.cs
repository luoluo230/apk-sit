using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

public enum ProtocolSchemaEntryKind
{
    All,
    Message,
    Class,
    Enum,
    Unknown
}

public sealed class ProtocolSchemaEntry
{
    public string Name { get; set; }
    public string Json { get; set; }
    public ProtocolSchemaEntryKind Kind { get; set; }
    public int MessageId { get; set; }
}

public sealed class ProtocolSchemaValidationResult
{
    public readonly List<string> Errors = new List<string>();
    public readonly List<string> Warnings = new List<string>();
    public bool IsValid => Errors.Count == 0;
}

/// <summary>
/// Lightweight protocol document model for protocols.json.
/// The editor keeps the top-level protocol entries editable without depending on Newtonsoft.Json.
/// </summary>
public sealed class ProtocolSchemaDocument
{
    private static readonly Regex NameRegex = new Regex("^[A-Za-z][A-Za-z0-9_]*$", RegexOptions.Compiled);

    public string SourcePath { get; private set; }
    public readonly List<ProtocolSchemaEntry> Entries = new List<ProtocolSchemaEntry>();
    public readonly List<string> ParseErrors = new List<string>();

    public static ProtocolSchemaDocument Load(string sourcePath)
    {
        var document = new ProtocolSchemaDocument { SourcePath = sourcePath };
        if (!File.Exists(sourcePath))
        {
            document.ParseErrors.Add("Protocol source file does not exist: " + sourcePath);
            return document;
        }

        if (!ProtocolJson.TryParse(File.ReadAllText(sourcePath, Encoding.UTF8), out ProtocolJsonValue value, out string error) || !(value is ProtocolJsonObject root))
        {
            document.ParseErrors.Add("Protocol source JSON parse failed: " + error);
            return document;
        }

        foreach (KeyValuePair<string, ProtocolJsonValue> pair in root.Properties)
        {
            string json = pair.Value?.ToJson(4) ?? "{}";
            document.Entries.Add(new ProtocolSchemaEntry
            {
                Name = pair.Key,
                Json = json,
                Kind = DetectKind(json),
                MessageId = ExtractMessageId(json)
            });
        }

        return document;
    }

    public ProtocolSchemaEntry Find(string name)
    {
        return Entries.FirstOrDefault(entry => string.Equals(entry.Name, name, StringComparison.Ordinal));
    }

    public ProtocolSchemaValidationResult Validate()
    {
        var result = new ProtocolSchemaValidationResult();
        result.Errors.AddRange(ParseErrors);
        if (Entries.Count == 0)
        {
            result.Errors.Add("No protocol entries were found.");
            return result;
        }

        foreach (ProtocolSchemaEntry entry in Entries)
        {
            ValidateEntry(entry, result);
        }

        foreach (IGrouping<int, ProtocolSchemaEntry> group in Entries.Where(e => e.Kind == ProtocolSchemaEntryKind.Message && e.MessageId > 0).GroupBy(e => e.MessageId))
        {
            if (group.Count() > 1)
            {
                result.Errors.Add("Duplicate MessageID " + group.Key + ": " + string.Join(", ", group.Select(e => e.Name)));
            }
        }

        return result;
    }

    public ProtocolSchemaValidationResult ValidateRawEntry(string entryName, string rawJson)
    {
        var result = new ProtocolSchemaValidationResult();
        if (!NameRegex.IsMatch(entryName ?? string.Empty))
        {
            result.Errors.Add("Protocol name must start with a letter and contain only letters, numbers and underscore.");
        }

        if (!ProtocolJson.TryParse(rawJson, out ProtocolJsonValue value, out string error) || !(value is ProtocolJsonObject))
        {
            result.Errors.Add("Protocol entry JSON must be a valid object. " + error);
            return result;
        }

        ValidateEntry(new ProtocolSchemaEntry
        {
            Name = entryName,
            Json = value.ToJson(4),
            Kind = DetectKind(rawJson),
            MessageId = ExtractMessageId(rawJson)
        }, result);
        return result;
    }

    public void Add(ProtocolSchemaEntry entry)
    {
        entry.Json = NormalizeEntryJson(entry.Json);
        entry.Kind = DetectKind(entry.Json);
        entry.MessageId = ExtractMessageId(entry.Json);
        Entries.Add(entry);
    }

    public void Replace(string oldName, ProtocolSchemaEntry replacement)
    {
        int index = Entries.FindIndex(entry => string.Equals(entry.Name, oldName, StringComparison.Ordinal));
        replacement.Json = NormalizeEntryJson(replacement.Json);
        replacement.Kind = DetectKind(replacement.Json);
        replacement.MessageId = ExtractMessageId(replacement.Json);
        if (index < 0) Entries.Add(replacement);
        else Entries[index] = replacement;
    }

    public bool Remove(string name)
    {
        int index = Entries.FindIndex(entry => string.Equals(entry.Name, name, StringComparison.Ordinal));
        if (index < 0) return false;
        Entries.RemoveAt(index);
        return true;
    }

    public void Save()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(SourcePath) ?? string.Empty);
        var root = new ProtocolJsonObject();
        foreach (ProtocolSchemaEntry entry in Entries)
        {
            if (ProtocolJson.TryParse(entry.Json, out ProtocolJsonValue value, out _))
            {
                root.Properties[entry.Name] = value;
            }
        }

        File.WriteAllText(SourcePath, root.ToJson(0), new UTF8Encoding(false));
    }

    public static ProtocolSchemaEntry CreateTemplate(string name, ProtocolSchemaEntryKind kind, int messageId)
    {
        switch (kind)
        {
            case ProtocolSchemaEntryKind.Class:
                return new ProtocolSchemaEntry
                {
                    Name = name,
                    Kind = ProtocolSchemaEntryKind.Class,
                    Json = "{\n    \"Type\": \"Class\",\n    \"Comment\": \"New data class\",\n    \"Fields\": {\n        \"Example\": { \"Type\": \"string\", \"Comment\": \"Example field\" }\n    }\n}"
                };
            case ProtocolSchemaEntryKind.Enum:
                return new ProtocolSchemaEntry
                {
                    Name = name,
                    Kind = ProtocolSchemaEntryKind.Enum,
                    Json = "{\n    \"Type\": \"Enum\",\n    \"Comment\": \"New enum\",\n    \"Values\": [\"None\", \"ValueA\", \"ValueB\"]\n}"
                };
            default:
                return new ProtocolSchemaEntry
                {
                    Name = name,
                    Kind = ProtocolSchemaEntryKind.Message,
                    MessageId = Math.Max(1, messageId),
                    Json = "{\n    \"MessageID\": " + Math.Max(1, messageId) + ",\n    \"Comment\": \"New protocol\",\n    \"Data\": {\n        \"Example\": { \"Type\": \"string\", \"Comment\": \"Example field\" }\n    }\n}"
                };
        }
    }

    public static ProtocolSchemaEntryKind DetectKind(string rawJson)
    {
        if (!ProtocolJson.TryParse(rawJson, out ProtocolJsonValue value, out _) || !(value is ProtocolJsonObject obj))
        {
            return ProtocolSchemaEntryKind.Unknown;
        }

        if (obj.Get("MessageID") is ProtocolJsonNumber) return ProtocolSchemaEntryKind.Message;
        string type = obj.GetString("Type", string.Empty);
        if (string.Equals(type, "Class", StringComparison.OrdinalIgnoreCase)) return ProtocolSchemaEntryKind.Class;
        if (string.Equals(type, "Enum", StringComparison.OrdinalIgnoreCase)) return ProtocolSchemaEntryKind.Enum;
        return ProtocolSchemaEntryKind.Unknown;
    }

    public static int ExtractMessageId(string rawJson)
    {
        return ProtocolJson.TryParse(rawJson, out ProtocolJsonValue value, out _) && value is ProtocolJsonObject obj
            ? obj.GetInt("MessageID")
            : 0;
    }

    private static string NormalizeEntryJson(string rawJson)
    {
        return ProtocolJson.TryParse(rawJson, out ProtocolJsonValue value, out _) ? value.ToJson(4) : rawJson ?? "{}";
    }

    private static void ValidateEntry(ProtocolSchemaEntry entry, ProtocolSchemaValidationResult result)
    {
        if (!NameRegex.IsMatch(entry.Name ?? string.Empty))
        {
            result.Errors.Add("Invalid protocol name: " + entry.Name);
        }

        if (!ProtocolJson.TryParse(entry.Json, out ProtocolJsonValue value, out string error) || !(value is ProtocolJsonObject obj))
        {
            result.Errors.Add(entry.Name + " JSON is invalid: " + error);
            return;
        }

        if (entry.Kind == ProtocolSchemaEntryKind.Message)
        {
            if (entry.MessageId <= 0) result.Errors.Add(entry.Name + " is missing a valid MessageID.");
            if (!entry.Name.EndsWith("_c2s", StringComparison.Ordinal) && !entry.Name.EndsWith("_s2c", StringComparison.Ordinal))
            {
                result.Warnings.Add(entry.Name + " should use _c2s or _s2c suffix.");
            }

            if (!(obj.Get("Data") is ProtocolJsonObject)) result.Warnings.Add(entry.Name + " has no Data object.");
        }
        else if (entry.Kind == ProtocolSchemaEntryKind.Class)
        {
            if (!(obj.Get("Fields") is ProtocolJsonObject)) result.Errors.Add(entry.Name + " class is missing Fields.");
        }
        else if (entry.Kind == ProtocolSchemaEntryKind.Enum)
        {
            if (!(obj.Get("Values") is ProtocolJsonArray)) result.Errors.Add(entry.Name + " enum is missing Values.");
        }
        else
        {
            result.Errors.Add(entry.Name + " type cannot be detected. Use MessageID or Type=Class/Enum.");
        }
    }
}
