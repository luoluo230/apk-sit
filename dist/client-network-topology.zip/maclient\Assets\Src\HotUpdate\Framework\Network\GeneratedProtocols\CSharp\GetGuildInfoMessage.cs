﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取自身公会信息及成员列表
/// </summary>
public class GetGuildInfo_c2s
{
}

/// <summary>
/// 公会信息响应
/// </summary>
public class GetGuildInfo_s2c
{
    /// <summary>
    /// 公会信息
    /// </summary>
    public GuildInfo Guild { get; set; }
    /// <summary>
    /// 公会成员列表
    /// </summary>
    public GuildMemberInfo[] Members { get; set; }
}

