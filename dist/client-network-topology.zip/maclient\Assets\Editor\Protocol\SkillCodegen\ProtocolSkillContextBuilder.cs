using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

public sealed class ProtocolSkillContextBuilder
{
    private readonly ProtocolArtifactPaths _paths;

    public ProtocolSkillContextBuilder(ProtocolArtifactPaths paths)
    {
        _paths = paths;
    }

    public List<ProtocolSkillContext> BuildContexts(ProtocolSchemaDocument document, IEnumerable<ProtocolSchemaEntry> selectedEntries, ProtocolSkillCodegenOptions options)
    {
        var result = new List<ProtocolSkillContext>();
        var selectedNames = new HashSet<string>((selectedEntries ?? document.Entries).Select(entry => entry.Name), StringComparer.Ordinal);
        foreach (ProtocolSchemaEntry request in document.Entries.Where(entry => entry.Name.EndsWith("_c2s", StringComparison.Ordinal)))
        {
            string baseName = request.Name.Substring(0, request.Name.Length - 4);
            ProtocolSchemaEntry response = document.Find(baseName + "_s2c");
            if (selectedNames.Count > 0 && !selectedNames.Contains(request.Name) && (response == null || !selectedNames.Contains(response.Name))) continue;
            result.Add(BuildContext(document, baseName, request, response, options));
        }

        foreach (ProtocolSchemaEntry push in document.Entries.Where(entry => entry.Name.EndsWith("_s2c", StringComparison.Ordinal)))
        {
            string baseName = push.Name.Substring(0, push.Name.Length - 4);
            if (document.Find(baseName + "_c2s") != null || !selectedNames.Contains(push.Name)) continue;
            result.Add(BuildContext(document, baseName, null, push, options));
        }

        return result;
    }

    public string WriteContextFiles(ProtocolSkillGenerationPlan plan, string repoRoot)
    {
        string root = Path.GetFullPath(Path.Combine(repoRoot, plan.Options.ContextOutputRoot));
        Directory.CreateDirectory(root);
        foreach (ProtocolSkillContext context in plan.Contexts)
        {
            string safe = Sanitize(context.ProtocolName);
            string jsonPath = Path.Combine(root, safe + ".skill-context.json");
            string mdPath = Path.Combine(root, safe + ".skill-context.md");
            File.WriteAllText(jsonPath, RenderContextJson(context), new UTF8Encoding(false));
            File.WriteAllText(mdPath, RenderContextMarkdown(context), new UTF8Encoding(false));
            plan.ContextFiles.Add(jsonPath);
            plan.ContextFiles.Add(mdPath);
        }

        return root;
    }

    public string RenderContextJson(ProtocolSkillContext context)
    {
        var builder = new StringBuilder();
        builder.AppendLine("{");
        AppendJson(builder, "protocolName", context.ProtocolName, true);
        AppendJson(builder, "module", context.Module, true);
        AppendJson(builder, "requestName", context.RequestName, true);
        AppendJson(builder, "responseName", context.ResponseName, true);
        builder.AppendLine("  \"requestMessageId\": " + context.RequestMessageId + ",");
        builder.AppendLine("  \"responseMessageId\": " + context.ResponseMessageId + ",");
        AppendJson(builder, "comment", context.Comment, true);
        AppendJson(builder, "clientDtoPath", context.ClientDtoPath, true);
        AppendJson(builder, "serverDtoPath", context.ServerDtoPath, true);
        AppendJson(builder, "clientProtocolIdsPath", context.ClientProtocolIdsPath, true);
        AppendJson(builder, "serverProtocolIdsPath", context.ServerProtocolIdsPath, true);
        AppendJson(builder, "clientDictionaryPath", context.ClientDictionaryPath, true);
        AppendJson(builder, "serverDictionaryPath", context.ServerDictionaryPath, true);
        AppendJson(builder, "networkCallPattern", context.NetworkCallPattern, true);
        AppendJson(builder, "serverLanguage", context.ServerLanguage, true);
        AppendJson(builder, "businessDomain", context.BusinessDomain, true);
        AppendFields(builder, "requestFields", context.RequestFields, true);
        AppendFields(builder, "responseFields", context.ResponseFields, false);
        builder.AppendLine("}");
        return builder.ToString();
    }

    public string RenderContextMarkdown(ProtocolSkillContext context)
    {
        var builder = new StringBuilder();
        builder.AppendLine("# " + context.ProtocolName);
        builder.AppendLine();
        builder.AppendLine("- Module: `" + context.Module + "`");
        builder.AppendLine("- Request: `" + context.RequestName + "` #" + context.RequestMessageId);
        builder.AppendLine("- Response: `" + context.ResponseName + "` #" + context.ResponseMessageId);
        builder.AppendLine("- Client DTO: `" + context.ClientDtoPath + "`");
        builder.AppendLine("- Server DTO: `" + context.ServerDtoPath + "`");
        builder.AppendLine("- Network: `" + context.NetworkCallPattern + "`");
        builder.AppendLine("- Business Domain: `" + context.BusinessDomain + "`");
        builder.AppendLine();
        AppendFieldTable(builder, "Request Fields", context.RequestFields);
        AppendFieldTable(builder, "Response Fields", context.ResponseFields);
        builder.AppendLine("## Business Constraints");
        builder.AppendLine("```text");
        builder.AppendLine(context.BusinessConstraintSummary ?? string.Empty);
        builder.AppendLine("```");
        return builder.ToString();
    }

    private ProtocolSkillContext BuildContext(ProtocolSchemaDocument document, string baseName, ProtocolSchemaEntry request, ProtocolSchemaEntry response, ProtocolSkillCodegenOptions options)
    {
        ProtocolStructuredEntry requestModel = request != null ? ProtocolSchemaStructuredCodec.FromEntry(request) : null;
        ProtocolStructuredEntry responseModel = response != null ? ProtocolSchemaStructuredCodec.FromEntry(response) : null;
        string module = requestModel?.Module;
        if (string.IsNullOrWhiteSpace(module)) module = responseModel?.Module;
        if (string.IsNullOrWhiteSpace(module)) module = InferModule(baseName);

        var context = new ProtocolSkillContext
        {
            ProtocolName = baseName,
            Module = module,
            RequestName = request?.Name ?? string.Empty,
            ResponseName = response?.Name ?? string.Empty,
            RequestMessageId = request?.MessageId ?? 0,
            ResponseMessageId = response?.MessageId ?? 0,
            Comment = !string.IsNullOrWhiteSpace(requestModel?.Comment) ? requestModel.Comment : responseModel?.Comment,
            Status = !string.IsNullOrWhiteSpace(requestModel?.Status) ? requestModel.Status : responseModel?.Status,
            SinceVersion = !string.IsNullOrWhiteSpace(requestModel?.SinceVersion) ? requestModel.SinceVersion : responseModel?.SinceVersion,
            ClientDtoPath = Path.Combine(_paths.ClientDtoRoot, (request?.Name ?? response?.Name ?? baseName) + ".cs"),
            ServerDtoPath = Path.Combine(_paths.ServerDtoRoot, (request?.Name ?? response?.Name ?? baseName) + ".cs"),
            ClientProtocolIdsPath = _paths.ClientProtocolIdsPath,
            ServerProtocolIdsPath = _paths.ServerProtocolIdsPath,
            ClientDictionaryPath = _paths.ClientDictionaryPath,
            ServerDictionaryPath = _paths.ServerDictionaryPath,
            NetworkFacadeType = options.NetworkFacadeType,
            NetworkSendMethod = options.RequestSendMethod,
            NetworkCallPattern = options.NetworkFacadeType + "." + options.RequestSendMethod + "<" + (response?.Name ?? "NetMessage") + ">(" + (request?.Name ?? "request") + ", onResponse)",
            ServerHandlerRoot = options.ServerHandlerRoot,
            ServerServiceRoot = options.ServerServiceRoot,
            ServerRepositoryRoot = options.ServerRepositoryRoot,
            ServerDbModelRoot = options.ServerDbModelRoot,
            ServerMigrationRoot = options.ServerMigrationRoot,
            ServerRouteRoot = options.ServerRouteRoot,
            DatabaseAccessPattern = options.DbAccessPattern,
            ClientLanguage = "CSharp",
            ServerLanguage = options.ServerLanguage.ToString()
        };
        if (requestModel != null) context.RequestFields.AddRange(requestModel.Fields);
        if (responseModel != null) context.ResponseFields.AddRange(responseModel.Fields);
        foreach (ProtocolSchemaField field in context.RequestFields.Concat(context.ResponseFields))
        {
            foreach (string dependency in ProtocolTypeReference.Parse(field.Type).GetNamedDependencies())
            {
                if (document.Find(dependency) != null && !context.Dependencies.Contains(dependency)) context.Dependencies.Add(dependency);
            }
        }

        return context;
    }

    private static string InferModule(string protocolName)
    {
        if (string.IsNullOrWhiteSpace(protocolName)) return "Common";
        int index = protocolName.IndexOf('_');
        string raw = index > 0 ? protocolName.Substring(0, index) : protocolName;
        return raw.Length <= 2 ? "Common" : raw;
    }

    private static void AppendJson(StringBuilder builder, string key, string value, bool comma)
    {
        builder.Append("  \"").Append(key).Append("\": \"").Append(ProtocolJson.Escape(value ?? string.Empty)).Append('"');
        if (comma) builder.Append(',');
        builder.AppendLine();
    }

    private static void AppendFields(StringBuilder builder, string name, IReadOnlyList<ProtocolSchemaField> fields, bool comma)
    {
        builder.AppendLine("  \"" + name + "\": [");
        for (int i = 0; i < fields.Count; i++)
        {
            ProtocolSchemaField field = fields[i];
            builder.Append("    { \"name\": \"").Append(ProtocolJson.Escape(field.Name)).Append("\", \"type\": \"").Append(ProtocolJson.Escape(field.Type)).Append("\", \"comment\": \"").Append(ProtocolJson.Escape(field.Comment)).Append("\", \"required\": ").Append(field.Required ? "true" : "false").Append(" }");
            if (i < fields.Count - 1) builder.Append(',');
            builder.AppendLine();
        }
        builder.Append("  ]");
        if (comma) builder.Append(',');
        builder.AppendLine();
    }

    private static void AppendFieldTable(StringBuilder builder, string title, IReadOnlyList<ProtocolSchemaField> fields)
    {
        builder.AppendLine("## " + title);
        builder.AppendLine("| Name | Type | Required | Comment |");
        builder.AppendLine("| --- | --- | --- | --- |");
        foreach (ProtocolSchemaField field in fields)
        {
            builder.AppendLine("| " + field.Name + " | " + field.Type + " | " + field.Required + " | " + field.Comment + " |");
        }
        builder.AppendLine();
    }

    private static string Sanitize(string value)
    {
        return string.Join("_", (value ?? "Protocol").Split(Path.GetInvalidFileNameChars()));
    }
}
