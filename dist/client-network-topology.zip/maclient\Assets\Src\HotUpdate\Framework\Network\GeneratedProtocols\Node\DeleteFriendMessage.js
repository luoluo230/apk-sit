// 自动生成的协议文件

// 定义协议类


// 删除好友
class DeleteFriend_c2s {
    constructor() {
        this.TargetPlayerId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 删除好友结果
class DeleteFriend_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DeleteFriend_c2s,
    DeleteFriend_s2c,
};
