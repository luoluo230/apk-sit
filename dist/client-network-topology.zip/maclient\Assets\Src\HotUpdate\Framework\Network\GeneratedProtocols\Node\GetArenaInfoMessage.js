// 自动生成的协议文件

// 定义协议类


// 获取竞技场信息
class GetArenaInfo_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 竞技场信息响应
class GetArenaInfo_s2c {
    constructor() {
        this.Arena = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetArenaInfo_c2s,
    GetArenaInfo_s2c,
};
