// 自动生成的协议文件

// 定义协议类


// 响应组队邀请(同意/拒绝)
class RespondTeamInvite_c2s {
    constructor() {
        this.InviteId = '';
        this.Accept = false;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 响应组队邀请结果
class RespondTeamInvite_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Team = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    RespondTeamInvite_c2s,
    RespondTeamInvite_s2c,
};
