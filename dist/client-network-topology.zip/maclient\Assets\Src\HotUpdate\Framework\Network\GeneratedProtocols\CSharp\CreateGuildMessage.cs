﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 创建公会
/// </summary>
public class CreateGuild_c2s
{
    /// <summary>
    /// 公会名称
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// 公会图标
    /// </summary>
    public string Badge { get; set; }
    /// <summary>
    /// 公告
    /// </summary>
    public string Notice { get; set; }
}

/// <summary>
/// 创建公会结果
/// </summary>
public class CreateGuild_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 新建的公会信息
    /// </summary>
    public GuildInfo Guild { get; set; }
}

