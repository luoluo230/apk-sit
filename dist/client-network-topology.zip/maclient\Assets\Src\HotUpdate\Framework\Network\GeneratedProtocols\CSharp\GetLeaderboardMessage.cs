﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取排行榜请求
/// </summary>
public class GetLeaderboard_c2s
{
    /// <summary>
    /// 排行榜类型
    /// </summary>
    public string BoardType { get; set; }
    /// <summary>
    /// 页码(从 1 开始)
    /// </summary>
    public int PageIndex { get; set; }
    /// <summary>
    /// 每页数量
    /// </summary>
    public int PageSize { get; set; }
}

/// <summary>
/// 获取排行榜响应
/// </summary>
public class GetLeaderboard_s2c
{
    /// <summary>
    /// 排行榜数据
    /// </summary>
    public LeaderboardInfo Leaderboard { get; set; }
}

