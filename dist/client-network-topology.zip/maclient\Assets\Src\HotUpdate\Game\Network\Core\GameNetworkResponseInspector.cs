using System;
using System.Collections.Generic;
using System.Reflection;

public static class GameNetworkResponseInspector
{
    private static readonly Dictionary<string, MemberInfo> SuccessMemberCache = new Dictionary<string, MemberInfo>();
    private static readonly Dictionary<string, MemberInfo> ErrorCodeMemberCache = new Dictionary<string, MemberInfo>();
    private static readonly Dictionary<string, MemberInfo> MessageMemberCache = new Dictionary<string, MemberInfo>();

    public static bool IsBusinessSuccess<T>(T response) where T : class
    {
        if (response == null)
        {
            return false;
        }

        var member = GetMember(typeof(T), "Success", SuccessMemberCache);
        if (member == null)
        {
            return true;
        }

        try
        {
            var value = ReadMemberValue(member, response);
            if (value is bool b)
            {
                return b;
            }
        }
        catch
        {
        }

        return true;
    }

    public static string GetErrorCode<T>(T response) where T : class
    {
        if (response == null)
        {
            return GameNetworkErrorCodes.EmptyResponse;
        }

        var member = GetMember(typeof(T), "ErrorCode", ErrorCodeMemberCache)
                     ?? GetMember(typeof(T), "Code", ErrorCodeMemberCache);
        if (member == null)
        {
            return GameNetworkErrorCodes.BusinessFailed;
        }

        try
        {
            var value = ReadMemberValue(member, response);
            return value == null ? GameNetworkErrorCodes.BusinessFailed : value.ToString();
        }
        catch
        {
            return GameNetworkErrorCodes.BusinessFailed;
        }
    }

    public static string GetMessage<T>(T response) where T : class
    {
        if (response == null)
        {
            return "Response is null.";
        }

        var member = GetMember(typeof(T), "Message", MessageMemberCache)
                     ?? GetMember(typeof(T), "Msg", MessageMemberCache);
        if (member == null)
        {
            return "Request failed.";
        }

        try
        {
            var value = ReadMemberValue(member, response);
            return value == null ? "Request failed." : value.ToString();
        }
        catch
        {
            return "Request failed.";
        }
    }

    private static MemberInfo GetMember(Type type, string memberName, Dictionary<string, MemberInfo> cache)
    {
        var key = type.FullName + "::" + memberName;
        if (cache.TryGetValue(key, out var cached))
        {
            return cached;
        }

        var flags = BindingFlags.Public | BindingFlags.Instance;
        MemberInfo member = type.GetProperty(memberName, flags);
        if (member == null)
        {
            member = type.GetField(memberName, flags);
        }

        cache[key] = member;
        return member;
    }

    private static object ReadMemberValue(MemberInfo member, object instance)
    {
        if (member is PropertyInfo p)
        {
            return p.GetValue(instance);
        }

        if (member is FieldInfo f)
        {
            return f.GetValue(instance);
        }

        return null;
    }
}
