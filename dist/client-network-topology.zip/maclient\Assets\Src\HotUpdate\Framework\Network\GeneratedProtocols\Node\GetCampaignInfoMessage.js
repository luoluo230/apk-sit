// 自动生成的协议文件

// 定义协议类


// 获取主线推图信息
class GetCampaignInfo_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 返回主线推图信息
class GetCampaignInfo_s2c {
    constructor() {
        this.Campaign = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetCampaignInfo_c2s,
    GetCampaignInfo_s2c,
};
