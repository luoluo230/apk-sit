﻿public sealed class GameNetworkCallResult<T> where T : class
{
    /// <summary>是否调用成功。</summary>
    public bool Success;

    /// <summary>统一错误码；成功时可为空。</summary>
    public string ErrorCode;

    /// <summary>错误消息或附加说明。</summary>
    public string Message;

    /// <summary>响应对象。</summary>
    public T Response;

    /// <summary>最小必要的生效参数摘要（用于排障与日志追踪）。</summary>
    public string EffectiveConfigSummary;
}
