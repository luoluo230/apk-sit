﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 收到新的好友申请通知
/// </summary>
public class FriendRequestNotify_s2c
{
    /// <summary>
    /// 好友申请信息
    /// </summary>
    public FriendRequestInfo Request { get; set; }
}

