# Social Domain Skill

- Client: generate friend/chat/team use cases with notification callback hooks and UI sample for list refresh.
- Server: generate relationship permission checks, target player existence checks, rate-limit hooks, and notification dispatch placeholders.
- Sanitize chat/message text and avoid echoing unsafe content.
