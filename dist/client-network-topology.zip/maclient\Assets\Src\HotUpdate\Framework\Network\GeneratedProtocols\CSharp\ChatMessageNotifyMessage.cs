﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 聊天消息广播(世界/公会/私聊等)
/// </summary>
public class ChatMessageNotify_s2c
{
    /// <summary>
    /// 聊天消息
    /// </summary>
    public ChatMessage Chat { get; set; }
}

