// 自动生成的协议文件

// 定义协议类


// 拉取聊天历史
class GetChatHistory_c2s {
    constructor() {
        this.Channel = null;
        this.ToPlayerId = null;
        this.FromMessageId = null;
        this.Limit = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 聊天历史响应
class GetChatHistory_s2c {
    constructor() {
        this.Channel = null;
        this.Chats = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetChatHistory_c2s,
    GetChatHistory_s2c,
};
