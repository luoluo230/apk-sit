// 自动生成的协议文件

// 定义协议类


// 新的公会申请通知(仅会长/官员)
class GuildApplyNotify_s2c {
    constructor() {
        this.Apply = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GuildApplyNotify_s2c,
};
