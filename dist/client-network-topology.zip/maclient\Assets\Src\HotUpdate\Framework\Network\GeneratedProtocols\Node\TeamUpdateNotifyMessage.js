// 自动生成的协议文件

// 定义协议类


// 队伍变更通知
class TeamUpdateNotify_s2c {
    constructor() {
        this.Team = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    TeamUpdateNotify_s2c,
};
