﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 领取邮件附件
/// </summary>
public class ClaimMailAttachment_c2s
{
    /// <summary>
    /// 邮件 ID
    /// </summary>
    public long MailId { get; set; }
}

/// <summary>
/// 领取邮件附件结果
/// </summary>
public class ClaimMailAttachment_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 附件奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
}

