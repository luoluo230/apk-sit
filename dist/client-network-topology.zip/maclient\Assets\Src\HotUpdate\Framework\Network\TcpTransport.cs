﻿using System;
using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

/// <summary>
/// TCP 传输实现。
/// 适合标准长连接场景，支持持续收发与断线感知。
/// </summary>
public class TcpTransport : MonoBehaviour, ITransportClient
{
    private TcpClient _client;
    private NetworkStream _stream;
    private CancellationTokenSource _cts;
    private int _connectGeneration;

    private readonly ConcurrentQueue<byte[]> _pendingData = new ConcurrentQueue<byte[]>();
    private readonly ConcurrentQueue<string> _pendingErrors = new ConcurrentQueue<string>();
    private volatile bool _pendingConnected;
    private volatile bool _pendingDisconnected;
    private string _pendingDisconnectReason;

    public bool IsConnected { get; private set; }

    public event Action OnConnected;
    public event Action<string> OnDisconnected;
    public event Action<string> OnError;
    public event Action<byte[]> OnDataReceived;

    private void Update()
    {
        while (_pendingData.TryDequeue(out var data))
        {
            OnDataReceived?.Invoke(data);
        }

        while (_pendingErrors.TryDequeue(out var error))
        {
            OnError?.Invoke(error);
        }

        if (_pendingConnected)
        {
            _pendingConnected = false;
            OnConnected?.Invoke();
        }

        if (_pendingDisconnected)
        {
            _pendingDisconnected = false;
            OnDisconnected?.Invoke(_pendingDisconnectReason ?? "disconnected");
            _pendingDisconnectReason = null;
        }
    }

    /// <summary>
    /// 建立 TCP 连接并启动接收循环。
    /// </summary>
    public async void Connect(string url)
    {
        var generation = Interlocked.Increment(ref _connectGeneration);
        try
        {
            TearDownSocket();

            Uri uri = new Uri(url);
            var client = new TcpClient();
            await client.ConnectAsync(uri.Host, uri.Port);
            if (generation != _connectGeneration)
            {
                client.Close();
                return;
            }

            _client = client;
            _stream = _client.GetStream();
            _cts = new CancellationTokenSource();
            IsConnected = true;
            _pendingConnected = true;

            _ = Task.Run(() => ReceiveLoop(_cts.Token, generation));
        }
        catch (Exception ex)
        {
            if (generation == _connectGeneration)
            {
                EnqueueError($"TCP connection failed: {ex.Message}");
                Disconnect();
            }
        }
    }

    /// <summary>
    /// 断开 TCP 连接并释放资源。
    /// </summary>
    public void Disconnect()
    {
        Interlocked.Increment(ref _connectGeneration);
        IsConnected = false;
        TearDownSocket();
    }

    private void TearDownSocket()
    {
        try
        {
            _cts?.Cancel();
            _stream?.Close();
            _client?.Close();
        }
        catch (Exception ex)
        {
            Logger.Log($"Close TCP transport failed: {ex.Message}", LogLevel.Warning);
        }
        finally
        {
            _cts = null;
            _stream = null;
            _client = null;
        }
    }

    /// <summary>
    /// 发送原始字节数据。
    /// </summary>
    public async void Send(byte[] data)
    {
        if (!IsConnected || _stream == null)
        {
            EnqueueError("TCP connection is not established.");
            return;
        }

        try
        {
            await _stream.WriteAsync(data, 0, data.Length);
        }
        catch (Exception ex)
        {
            EnqueueError($"TCP send failed: {ex.Message}");
            Disconnect();
        }
    }

    /// <summary>
    /// 持续读取服务端数据并向上派发（回调在主线程 Update 中触发）。
    /// </summary>
    private async Task ReceiveLoop(CancellationToken token, int generation)
    {
        byte[] buffer = new byte[8192];

        try
        {
            while (!token.IsCancellationRequested && generation == _connectGeneration && _stream != null && _client != null)
            {
                int bytesRead = await _stream.ReadAsync(buffer, 0, buffer.Length, token);
                if (bytesRead <= 0)
                {
                    break;
                }

                byte[] data = new byte[bytesRead];
                Buffer.BlockCopy(buffer, 0, data, 0, bytesRead);
                _pendingData.Enqueue(data);
            }
        }
        catch (Exception ex)
        {
            if (!token.IsCancellationRequested)
            {
                EnqueueError($"TCP receive failed: {ex.Message}");
            }
        }
        finally
        {
            if (generation == _connectGeneration)
            {
                if (IsConnected)
                {
                    IsConnected = false;
                    _pendingDisconnectReason = "Server disconnected or stream ended.";
                    _pendingDisconnected = true;
                }

                TearDownSocket();
            }
        }
    }

    private void EnqueueError(string error)
    {
        if (!string.IsNullOrWhiteSpace(error))
        {
            _pendingErrors.Enqueue(error);
        }
    }

    private void OnDestroy()
    {
        Disconnect();
    }
}
