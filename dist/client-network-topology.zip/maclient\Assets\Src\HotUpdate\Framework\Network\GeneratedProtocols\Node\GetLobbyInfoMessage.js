// 自动生成的协议文件

// 定义协议类


// 获取大厅信息请求
class GetLobbyInfo_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 获取大厅信息响应
class GetLobbyInfo_s2c {
    constructor() {
        this.Lobby = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetLobbyInfo_c2s,
    GetLobbyInfo_s2c,
};
