using System;

/// <summary>
/// 帧同步通道接口。
/// 适用于对固定消息类型做逐帧同步分发的场景。
/// </summary>
public interface IFrameSyncChannel : ISyncChannel
{
    /// <summary>
    /// 注册某个消息 ID 的帧处理函数。
    /// </summary>
    void RegisterFrameHandler(int messageId, Action<NetMessage> handler);
}
