// 自动生成的协议文件

// 定义协议类


// 领取成就奖励
class ClaimAchievementReward_c2s {
    constructor() {
        this.AchievementId = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 领取成就奖励结果
class ClaimAchievementReward_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Achievement = null;
        this.Rewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ClaimAchievementReward_c2s,
    ClaimAchievementReward_s2c,
};
