using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

[Flags]
public enum ProtocolExportLanguage
{
    None = 0,
    CSharp = 1 << 0,
    TypeScript = 1 << 1,
    Python = 1 << 2,
    Java = 1 << 3,
    Go = 1 << 4,
    Kotlin = 1 << 5,
    JsonSchema = 1 << 6,
    Markdown = 1 << 7,
    OpenApi = 1 << 8,
    Protobuf = 1 << 9,
    FlatBuffers = 1 << 10
}

public sealed class ProtocolExportResult
{
    public bool Success;
    public string OutputRoot;
    public readonly List<string> Files = new List<string>();
    public readonly List<string> Errors = new List<string>();
}

public sealed class ProtocolExportOptions
{
    public string CSharpNamespace = "ExportedProtocols";
    public string TypeScriptPackageName = "@game/protocols";
    public string JavaPackageName = "exported.protocols";
    public string KotlinPackageName = "exported.protocols";
    public string GoPackageName = "protocols";
    public bool GenerateManifest = true;
}

public static class ProtocolMultiLanguageExporter
{
    public static ProtocolExportResult Export(ProtocolSchemaDocument document, IEnumerable<ProtocolSchemaEntry> entries, ProtocolExportLanguage languages, string outputRoot, ProtocolExportOptions options)
    {
        var result = new ProtocolExportResult { OutputRoot = outputRoot };
        if (document == null)
        {
            result.Errors.Add("Protocol document is null.");
            return result;
        }

        List<ProtocolSchemaEntry> selected = (entries ?? document.Entries).ToList();
        if (selected.Count == 0)
        {
            result.Errors.Add("No protocol entries selected.");
            return result;
        }

        Directory.CreateDirectory(outputRoot);
        if (languages.HasFlag(ProtocolExportLanguage.CSharp)) Write(result, outputRoot, "csharp/Protocols.cs", RenderCSharp(selected, options));
        if (languages.HasFlag(ProtocolExportLanguage.TypeScript)) Write(result, outputRoot, "typescript/protocols.ts", RenderTypeScript(selected, options));
        if (languages.HasFlag(ProtocolExportLanguage.Python)) Write(result, outputRoot, "python/protocols.py", RenderPython(selected));
        if (languages.HasFlag(ProtocolExportLanguage.Markdown)) Write(result, outputRoot, "protocols.md", RenderMarkdown(selected));
        if (options.GenerateManifest) Write(result, outputRoot, "manifest.json", RenderManifest(selected, languages));
        result.Success = result.Errors.Count == 0;
        return result;
    }

    private static string RenderCSharp(IEnumerable<ProtocolSchemaEntry> entries, ProtocolExportOptions options)
    {
        var builder = new StringBuilder();
        builder.AppendLine("namespace " + SafeNamespace(options.CSharpNamespace));
        builder.AppendLine("{");
        foreach (ProtocolSchemaEntry entry in entries)
        {
            ProtocolStructuredEntry model = ProtocolSchemaStructuredCodec.FromEntry(entry);
            if (model.Kind == ProtocolSchemaEntryKind.Enum)
            {
                builder.AppendLine("    public enum " + entry.Name + " { " + string.Join(", ", model.EnumValues.DefaultIfEmpty("None")) + " }");
                continue;
            }

            builder.AppendLine("    public sealed class " + entry.Name);
            builder.AppendLine("    {");
            foreach (ProtocolSchemaField field in model.Fields)
            {
                builder.AppendLine("        public " + ToCSharpType(field.Type) + " " + ToPascal(field.Name) + " { get; set; }");
            }

            builder.AppendLine("    }");
        }

        builder.AppendLine("}");
        return builder.ToString();
    }

    private static string RenderTypeScript(IEnumerable<ProtocolSchemaEntry> entries, ProtocolExportOptions options)
    {
        var builder = new StringBuilder();
        builder.AppendLine("// package: " + options.TypeScriptPackageName);
        foreach (ProtocolSchemaEntry entry in entries)
        {
            ProtocolStructuredEntry model = ProtocolSchemaStructuredCodec.FromEntry(entry);
            builder.AppendLine("export interface " + entry.Name + " {");
            foreach (ProtocolSchemaField field in model.Fields)
            {
                builder.AppendLine("  " + field.Name + (field.Required ? "" : "?") + ": " + ToTypeScriptType(field.Type) + ";");
            }
            builder.AppendLine("}");
        }
        return builder.ToString();
    }

    private static string RenderPython(IEnumerable<ProtocolSchemaEntry> entries)
    {
        var builder = new StringBuilder();
        builder.AppendLine("from dataclasses import dataclass");
        builder.AppendLine();
        foreach (ProtocolSchemaEntry entry in entries)
        {
            ProtocolStructuredEntry model = ProtocolSchemaStructuredCodec.FromEntry(entry);
            builder.AppendLine("@dataclass");
            builder.AppendLine("class " + entry.Name + ":");
            if (model.Fields.Count == 0) builder.AppendLine("    pass");
            foreach (ProtocolSchemaField field in model.Fields) builder.AppendLine("    " + field.Name + ": " + ToPythonType(field.Type) + " = None");
            builder.AppendLine();
        }
        return builder.ToString();
    }

    private static string RenderMarkdown(IEnumerable<ProtocolSchemaEntry> entries)
    {
        var builder = new StringBuilder();
        foreach (ProtocolSchemaEntry entry in entries)
        {
            ProtocolStructuredEntry model = ProtocolSchemaStructuredCodec.FromEntry(entry);
            builder.AppendLine("## " + entry.Name);
            builder.AppendLine();
            builder.AppendLine("- Kind: `" + model.Kind + "`");
            builder.AppendLine("- MessageID: `" + model.MessageId + "`");
            builder.AppendLine("- Comment: " + model.Comment);
            builder.AppendLine();
            foreach (ProtocolSchemaField field in model.Fields)
            {
                builder.AppendLine("- `" + field.Name + "` `" + field.Type + "` " + field.Comment);
            }
            builder.AppendLine();
        }
        return builder.ToString();
    }

    private static string RenderManifest(IEnumerable<ProtocolSchemaEntry> entries, ProtocolExportLanguage languages)
    {
        var builder = new StringBuilder();
        builder.AppendLine("{");
        builder.AppendLine("  \"languages\": \"" + languages + "\",");
        builder.AppendLine("  \"protocols\": [");
        ProtocolSchemaEntry[] array = entries.ToArray();
        for (int i = 0; i < array.Length; i++)
        {
            builder.Append("    { \"name\": \"").Append(ProtocolJson.Escape(array[i].Name)).Append("\", \"messageId\": ").Append(array[i].MessageId).Append(" }");
            if (i < array.Length - 1) builder.Append(',');
            builder.AppendLine();
        }
        builder.AppendLine("  ]");
        builder.AppendLine("}");
        return builder.ToString();
    }

    private static void Write(ProtocolExportResult result, string root, string relativePath, string content)
    {
        string path = Path.Combine(root, relativePath);
        Directory.CreateDirectory(Path.GetDirectoryName(path) ?? string.Empty);
        File.WriteAllText(path, content, new UTF8Encoding(false));
        result.Files.Add(path);
    }

    private static string ToCSharpType(string type)
    {
        string name = ProtocolTypeReference.Parse(type).Name.ToLowerInvariant();
        if (name == "int32") return "int";
        if (name == "int64") return "long";
        if (name == "boolean") return "bool";
        return name == "string" || name == "int" || name == "long" || name == "float" || name == "double" || name == "bool" ? name : ProtocolTypeReference.Parse(type).Name;
    }

    private static string ToTypeScriptType(string type)
    {
        string name = ProtocolTypeReference.Parse(type).Name.ToLowerInvariant();
        if (name == "int" || name == "int32" || name == "long" || name == "int64" || name == "float" || name == "double") return "number";
        if (name == "bool" || name == "boolean") return "boolean";
        return "string";
    }

    private static string ToPythonType(string type)
    {
        string name = ProtocolTypeReference.Parse(type).Name.ToLowerInvariant();
        if (name == "int" || name == "int32" || name == "long" || name == "int64") return "int";
        if (name == "float" || name == "double") return "float";
        if (name == "bool" || name == "boolean") return "bool";
        return "str";
    }

    private static string ToPascal(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "Value";
        return char.ToUpperInvariant(value[0]) + value.Substring(1);
    }

    private static string SafeNamespace(string value)
    {
        return string.IsNullOrWhiteSpace(value) ? "ExportedProtocols" : value.Replace("-", "_");
    }
}
