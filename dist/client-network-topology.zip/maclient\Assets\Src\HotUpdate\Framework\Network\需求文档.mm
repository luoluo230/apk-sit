<?xml version="1.0" encoding="UTF-8"?>
<map version="1.0.1">
  <node TEXT="挂机RPG 客户端策划需求">
    <node TEXT="一 产品概述与目标">
      <node TEXT="游戏定位">
        <node TEXT="类型 放置类卡牌 RPG 类似剑与远征"/>
        <node TEXT="核心循环 收集英雄 搭配阵容 推图 挂机收益 抽卡养成 PVE PVP"/>
        <node TEXT="主要玩法 主线关卡 爬塔 竞技场 公会 活动 副本"/>
      </node>
      <node TEXT="目标平台与分辨率">
        <node TEXT="平台 iOS Android 可预留 PC 模拟器适配"/>
        <node TEXT="适配 主流全面屏 刘海屏 打孔屏 横屏游玩"/>
      </node>
      <node TEXT="客户端架构要求">
        <node TEXT="强客户端 以服务器为权威 但战斗演算可本地为主配合服端校验"/>
        <node TEXT="所有业务请求必须通过协议文档中 c2s 消息完成"/>
        <node TEXT="数据展示以 s2c 推送和主动拉取为准 支持本地缓存 减少闪烁"/>
      </node>
      <node TEXT="性能与体验目标">
        <node TEXT="主城与战斗场景进入时间 控制在合理范围 内存占用可接受"/>
        <node TEXT="弱网兼容 断网提示 自动重连 重要操作结果可重试"/>
        <node TEXT="战斗帧率设置 与 TickRate FrameDuration 对齐 保证表现稳定"/>
      </node>
    </node>

    <node TEXT="二 网络与协议总则">
      <node TEXT="连接与会话管理">
        <node TEXT="启动时建立长连接 使用 Login_c2s Login_s2c 完成认证"/>
        <node TEXT="进入游戏后定期发送 Heartbeat_c2s 收到 Heartbeat_s2c 校验会话"/>
        <node TEXT="服务端下发 NotifyKickOff_s2c 时 客户端立刻回到登录界面 弹出原因提示"/>
      </node>
      <node TEXT="超时与重连策略">
        <node TEXT="所有请求设置超时 超时弹出重试提示 支持重试和返回大厅"/>
        <node TEXT="战斗中网络波动时 显示弱网图标 暂停战斗逻辑或继续播放回放 根据设计确定"/>
        <node TEXT="重连后需自动调用 GetPlayerProfile GetLobbyInfo 等恢复主界面数据"/>
      </node>
      <node TEXT="时间与服务器权威">
        <node TEXT="以 Heartbeat_s2c ServerTime 为统一服务器时间"/>
        <node TEXT="所有倒计时 活动计时 刷新时间 体力回复等均用服务器时间计算"/>
        <node TEXT="客户端本地时间只用于显示 不作为逻辑依据"/>
      </node>
      <node TEXT="错误处理与提示规范">
        <node TEXT="所有 s2c 中 Success false 或服务端返回错误码时 统一弹出 toast 或对话框"/>
        <node TEXT="耗资源操作 要求明确展示消耗内容和数量 错误时提示资源不足"/>
        <node TEXT="重复点击 请求中状态 禁用按钮 显示转圈 防止重复提交"/>
      </node>
      <node TEXT="数据刷新策略">
        <node TEXT="登录和重连后 统一拉取核心数据 Profile HeroList Inventory Campaign Afk Reward 等"/>
        <node TEXT="优先使用 SyncResource SyncInventory SyncHero NotifyRedPoint 来做增量刷新"/>
        <node TEXT="列表型界面支持手动下拉刷新 对应重新发 c2s 请求"/>
      </node>
    </node>

    <node TEXT="三 账号与登录流程">
      <node TEXT="启动流程">
        <node TEXT="启动 Logo 资源检测 服务端地址配置 可远程配置"/>
        <node TEXT="如本地有 Token 尝试自动登录 Login_c2s 携带 DeviceInfo"/>
        <node TEXT="自动登录成功则直接进入 SelectServer 或进服"/>
      </node>
      <node TEXT="登录界面">
        <node TEXT="展示账号密码输入框 可替换为平台账号 微信 苹果等后续扩展"/>
        <node TEXT="登录按钮 调用 Login_c2s 失败时显示 Message"/>
        <node TEXT="记住账号选项 本地存储 跨次启动自动填充"/>
        <node TEXT="显示当前选择服务器名称与状态 来自 Login_s2c ServerList 或上次记录"/>
      </node>
      <node TEXT="服务器选择界面">
        <node TEXT="界面列出 ServerInfo 列表 区分推荐 新服 拥挤 维护状态"/>
        <node TEXT="点击服务器 调用 SelectServer_c2s 进入选中的服"/>
        <node TEXT="SelectServer_s2c 成功后 若 Profile 为空 则跳转角色创建 否则进游戏主城"/>
      </node>
      <node TEXT="角色创建">
        <node TEXT="界面包含昵称输入 头像 职业性别占位 根据策划需求配置"/>
        <node TEXT="昵称需要本地长度合法性校验 服务器再做敏感词过滤"/>
        <node TEXT="点击创建 调用 CreateRole_c2s 成功后进入主城"/>
      </node>
      <node TEXT="被踢下线处理">
        <node TEXT="收到 NotifyKickOff_s2c 弹出提示框 显示 Message 原因 如顶号 封停 维护"/>
        <node TEXT="关闭提示后回到登录界面 清理当前会话数据"/>
      </node>
    </node>

    <node TEXT="四 主城大厅与整体导航">
      <node TEXT="主城界面布局">
        <node TEXT="上方资源条 显示金币 钻石 体力 挂机收益入口等 实时跟随 SyncResource 更新"/>
        <node TEXT="左上角玩家头像区域 显示昵称 等级 战力 点击进入玩家信息面板"/>
        <node TEXT="右侧功能入口按钮 主线 爬塔 竞技场 公会 抽卡 商店 任务 活动等"/>
        <node TEXT="下方菜单栏 切换主功能 页签可配置"/>
      </node>
      <node TEXT="主城数据来源">
        <node TEXT="进入主城时调用 GetPlayerProfile GetLobbyInfo GetEvents"/>
        <node TEXT="LobbyInfo 中的 FeatureEntries 控制功能按钮解锁状态"/>
        <node TEXT="Notices 显示在公告按钮或跑马灯中"/>
      </node>
      <node TEXT="功能解锁显示">
        <node TEXT="根据玩家等级 当前关卡 LobbyInfo 功能表决定功能是否可见或灰显"/>
        <node TEXT="未解锁点击时弹出解锁条件提示 如玩家等级达到 若干级"/>
      </node>
      <node TEXT="主城红点体系接入">
        <node TEXT="主城按钮通用红点装饰 已读逻辑不影响服务器数据"/>
        <node TEXT="监听 NotifyRedPoint_s2c 根据 Module SubModule 更新各模块按钮红点"/>
      </node>
    </node>

    <node TEXT="五 玩家信息与属性">
      <node TEXT="玩家基础信息面板">
        <node TEXT="展示头像 昵称 等级 经验条 战力 玩家ID 国家 公会名"/>
        <node TEXT="支持更换头像 修改签名 改名功能 改名规则后续扩展 到服务端接口"/>
      </node>
      <node TEXT="经验与升级显示">
        <node TEXT="经验值和升级逻辑以 PlayerProfile Experience Level 为准"/>
        <node TEXT="升级时播放升级动画 解锁功能提示 更新主城数据"/>
      </node>
      <node TEXT="战力显示规则">
        <node TEXT="使用 PlayerProfile CombatPower 为总战力显示 由服务端计算"/>
        <node TEXT="模块内可另外显示阵容战力 英雄战力 等分别读取 HeroInfo 和阵容计算"/>
      </node>
    </node>

    <node TEXT="六 背包与物品系统">
      <node TEXT="背包列表界面">
        <node TEXT="默认分类分页 装备 消耗 材料 任务 货币 其他 对应 ItemCategory"/>
        <node TEXT="进入背包时调用 GetInventory_c2s 优先使用已有缓存 再比对更新时间"/>
        <node TEXT="收到 GetInventory_s2c 或 SyncInventory_s2c 更新本地列表 支持全量与增量"/>
      </node>
      <node TEXT="物品图鉴与格子表现">
        <node TEXT="格子显示图标 品质边框 数量 是否绑定 过期图标"/>
        <node TEXT="品质颜色与边框样式由配置表控制 不在协议中定义"/>
        <node TEXT="过期物品根据 ExpireAt 与服务器时间对比 显示倒计时或已过期标记"/>
      </node>
      <node TEXT="物品详情弹窗">
        <node TEXT="点击物品弹出详情 包含名称 描述 获取途径 使用按钮等"/>
        <node TEXT="可从 RewardItem InventoryItem 映射出展示字段"/>
        <node TEXT="可配置不同类别动作 如使用 出售 丢弃 前往获取"/>
      </node>
      <node TEXT="背包更新逻辑">
        <node TEXT="所有掉落 消耗 奖励后 使用 SyncInventory_s2c 的 Delta 更新列表"/>
        <node TEXT="RemovedItemIds 表示彻底消失的物品 从本地移除"/>
        <node TEXT="配合 SyncResource_s2c 同时更新货币显示 防止不同步"/>
      </node>
      <node TEXT="容量与满包提示">
        <node TEXT="客户端根据配置显示当前容量与上限 真正限制由服务端控制"/>
        <node TEXT="收到 BagFull 错误码时 弹出背包已满提示 引导去清理或扩展"/>
      </node>
    </node>

    <node TEXT="七 英雄系统">
      <node TEXT="英雄列表界面">
        <node TEXT="按 HeroInfo 列出所有拥有英雄 支持按阵营 职业 品质 等筛选"/>
        <node TEXT="进入时发 GetHeroList_c2s 并缓存 HeroInfo 后续由 SyncHero_s2c 增量更新"/>
        <node TEXT="列表显示英雄头像 品质边框 等级 星级 阵营 职业 是否上阵"/>
      </node>
      <node TEXT="英雄详情界面">
        <node TEXT="展示基础信息 名字 品质 阵营 职业 战力 等级 星级 经验条"/>
        <node TEXT="展示详细属性 攻击 生命 防御 速度等 从配置和 HeroInfo 推算"/>
        <node TEXT="技能页签 根据 HeroSkillInfo 列出技能 等级 解锁状态 播放预览"/>
        <node TEXT="装备页签 展示 HeroEquipSlot 上的装备 点击可跳转装备详情"/>
        <node TEXT="锁定开关 绑定 HeroInfo IsLocked 防止一键分解"/>
      </node>
      <node TEXT="英雄升级流程">
        <node TEXT="在英雄详情界面点击升级按钮 弹出所需资源 如经验道具 金币"/>
        <node TEXT="选择使用的经验道具 生成 ItemCost 列表 调用 UpgradeHeroLevel_c2s"/>
        <node TEXT="收到 UpgradeHeroLevel_s2c 成功时 播放升级特效 更新 Hero Inventory Resource"/>
        <node TEXT="失败时根据 Message 提示 如资源不足 升级已达上限"/>
      </node>
      <node TEXT="英雄升星流程">
        <node TEXT="在英雄详情界面点击升星按钮 显示需要同名卡或阵营素材英雄等"/>
        <node TEXT="从已有英雄中选取素材 生成 ConsumeHeroes 和 ConsumeItems"/>
        <node TEXT="调用 UpgradeHeroStar_c2s 成功后播放升星动画 更新英雄星级 移除素材英雄"/>
        <node TEXT="SyncHero_s2c 统一同步英雄列表 移除 RemovedHeroIds"/>
      </node>
      <node TEXT="英雄重置">
        <node TEXT="重置入口在英雄详情或英雄回收界面"/>
        <node TEXT="点击后弹出确认框 提示返还资源 可能消耗钻石"/>
        <node TEXT="调用 ResetHero_c2s 成功后 Hero 恢复初始等级 星级 根据设计 返还 RefundRewards"/>
      </node>
      <node TEXT="英雄排序与筛选体验">
        <node TEXT="支持按品质 星级 等级 战力排序 记忆上次选择"/>
        <node TEXT="筛选条件可多选 如阵营加职业组合"/>
      </node>
    </node>

    <node TEXT="八 装备系统">
      <node TEXT="装备列表界面">
        <node TEXT="按部位 分类展示 Equipments 或通过背包装备分类展示"/>
        <node TEXT="进入时发 GetEquipmentList_c2s 或从 Inventory 中映射 EquipmentInfo"/>
        <node TEXT="格子显示装备图标 品质 等级 部位 是否已穿戴"/>
      </node>
      <node TEXT="装备详情界面">
        <node TEXT="展示基础信息 名称 品质 等级 阶级 主属性 副属性"/>
        <node TEXT="显示当前佩戴英雄信息 EquippedHeroId 可点击跳转英雄详情"/>
        <node TEXT="按钮包括 强化 升阶 分解 穿戴 卸下 等"/>
      </node>
      <node TEXT="穿戴与卸下流程">
        <node TEXT="从英雄详情进入装备界面 选择槽位后弹出推荐装备列表"/>
        <node TEXT="选择装备时 调用 EquipItem_c2s 更新英雄 装备"/>
        <node TEXT="卸下时调用 UnequipItem_c2s 更新英雄装备槽位"/>
        <node TEXT="成功后根据返回的 Hero Equipment 刷新界面 播放装备切换动画"/>
      </node>
      <node TEXT="强化与升阶">
        <node TEXT="在装备详情界面点击强化按钮 打开强化界面 选择素材装备或材料 ItemCost"/>
        <node TEXT="调用 UpgradeEquipment_c2s 返回新属性 播放升级动画"/>
        <node TEXT="失败时提示 原因 资源不足 或已达最高等级"/>
      </node>
      <node TEXT="装备分解">
        <node TEXT="装备列表支持多选分解 功能需有明显二次确认 防止误操作"/>
        <node TEXT="选择装备后调用 DecomposeEquipment_c2s 查看 DecomposeEquipment_s2c Rewards 更新背包"/>
      </node>
      <node TEXT="自动穿戴与一键优化">
        <node TEXT="可支持一键最优装备 对指定英雄选择战力最高或评分最高的方案 客户端本地计算"/>
        <node TEXT="最终仍以 EquipItem_c2s 提交到服务器"/>
      </node>
    </node>

    <node TEXT="九 阵容系统">
      <node TEXT="阵容类型">
        <node TEXT="支持多种 FormationType 主线 阵容 竞技场防守 公会 boss 队伍等"/>
        <node TEXT="阵容槽位数 根据关卡或模式配置 默认五人或更多"/>
      </node>
      <node TEXT="阵容布阵界面">
        <node TEXT="画面分为 布阵区域 英雄列表 筛选排序区域"/>
        <node TEXT="支持拖拽英雄到站位 点击替换 长按查看详情"/>
        <node TEXT="显示阵容总战力 阵营加成 前后排位置提示"/>
      </node>
      <node TEXT="保存阵容流程">
        <node TEXT="布阵完成点击保存 调用 SetFormation_c2s 携带 FormationType 和 Slots"/>
        <node TEXT="成功后更新本地缓存 阵容变化影响其他模块 如战斗准备面板显示"/>
      </node>
      <node TEXT="多套阵容与预设">
        <node TEXT="可支持多套阵容预设 存本地或服务端 扩展字段通过 Custom 保存预设名"/>
        <node TEXT="切换预设时直接应用到当前 FormationType 再调用 SetFormation_c2s"/>
      </node>
    </node>

    <node TEXT="十 战斗系统表现与交互">
      <node TEXT="战斗入口规范">
        <node TEXT="主线 竞技场 爬塔 活动等统一通过 EnterBattle_c2s 或对应接口进入"/>
        <node TEXT="进入前显示战斗准备界面 阵容确认 推荐战力 敌方信息"/>
      </node>
      <node TEXT="战斗加载与预演">
        <node TEXT="收到 EnterBattle_s2c 后 根据 Scene 信息加载对应场景和资源"/>
        <node TEXT="使用 InitialUnits Warmup FrameBundle 预播关键帧 或构建回放数据"/>
        <node TEXT="Sync 参数控制本地时间尺度 确保动画与服务器逻辑匹配"/>
      </node>
      <node TEXT="战斗中交互">
        <node TEXT="挂机战斗默认自动释放技能 支持加速 开启关闭自动等按钮"/>
        <node TEXT="实时战斗模式 BattleFrame_c2s 上报操作 指令本地和服务器同步"/>
        <node TEXT="弱网时显示断线提示 尝试重连 若重连成功可从 Anchor 位置恢复回放或继续"/>
      </node>
      <node TEXT="战斗结果与结算">
        <node TEXT="战斗结束后调用 BattleResult_c2s 或由服务端推送 BattleResult_s2c"/>
        <node TEXT="结算界面展示胜负 掉落 奖励 统计数据如伤害 治疗等"/>
        <node TEXT="结算奖励中 Inventory Resource 使用 SyncInventory SyncResource 刷新"/>
        <node TEXT="支持一键继续挑战 返回主线 或回播放映等二次体验"/>
      </node>
      <node TEXT="战斗回放">
        <node TEXT="利用 FrameBundle Highlights 等数据重现战斗过程"/>
        <node TEXT="回放允许倍速 快进 暂停 无需再向服务器请求逻辑"/>
      </node>
    </node>

    <node TEXT="十一 主线关卡推图">
      <node TEXT="章节与关卡列表界面">
        <node TEXT="界面按章节展示 StageInfo 关卡节点 展示星级 是否已通关奖励领取状态"/>
        <node TEXT="进入界面时调用 GetCampaignInfo_c2s 获取 CampaignInfo"/>
      </node>
      <node TEXT="关卡详情">
        <node TEXT="点击关卡显示敌方阵容 推荐战力 首通奖励 普通掉落"/>
        <node TEXT="根据 StageInfo IsUnlocked IsPassed 控制可否挑战 可否扫荡"/>
      </node>
      <node TEXT="关卡挑战流程">
        <node TEXT="点击挑战 打开阵容准备界面 使用默认主线阵容 可修改"/>
        <node TEXT="确认后调用 EnterBattle_c2s StageId 为当前关卡"/>
        <node TEXT="战斗结束后根据 BattleResult 显示结算 更新 CampaignInfo"/>
      </node>
      <node TEXT="关卡奖励领取">
        <node TEXT="首通奖励与星级宝箱通过 ClaimStageReward_c2s 领取"/>
        <node TEXT="界面应标记已领状态 对应 FirstPassRewardClaimed MaxStarRewardClaimed"/>
      </node>
    </node>

    <node TEXT="十二 挂机收益与快速战斗">
      <node TEXT="挂机收益展示">
        <node TEXT="主城中展示可领取挂机收益按钮 带红点 当 Afk IsFull 或有可领奖励时"/>
        <node TEXT="进入挂机界面时调用 GetAfkRewardInfo_c2s 展示 AccumulateSeconds 预览奖励列表"/>
        <node TEXT="显示离线时间 最大累计时间 差值对应收益倍率表现"/>
      </node>
      <node TEXT="领取挂机奖励">
        <node TEXT="普通领取点击按钮 调用 ClaimAfkReward_c2s UseQuickReward 为 false"/>
        <node TEXT="成功后展示 RewardItem 弹出结算条 更新 AfkRewardInfo 信息"/>
      </node>
      <node TEXT="快速战斗">
        <node TEXT="快速战斗入口按钮标明消耗的资源 如钻石 快速战斗券等 客户端显示 不做真判断"/>
        <node TEXT="点击后设置 UseQuickReward true 设置 QuickRewardTimes 次数 调用 ClaimAfkReward_c2s"/>
        <node TEXT="结算界面突出快速战斗额外奖励 与普通收益区分"/>
      </node>
      <node TEXT="计时与红点逻辑">
        <node TEXT="客户端根据 LastCalcTime LastClaimTime ServerTime 预测 AccumulateSeconds 做本地动态展示"/>
        <node TEXT="红点由 NotifyRedPoint 控制 但客户端也可做预测 在接近上限时提示"/>
      </node>
    </node>

    <node TEXT="十三 爬塔试炼系统">
      <node TEXT="爬塔主界面">
        <node TEXT="展示当前塔 TowerInfo 当前层数 最高层 已通关情况"/>
        <node TEXT="层数列表展示 Floor 数 IsPassed Stars RewardTaken"/>
      </node>
      <node TEXT="挑战流程">
        <node TEXT="选择未通过层数 或最近未三星层 点击挑战 打开阵容准备界面"/>
        <node TEXT="调用 EnterTower_c2s 成功后进入战斗 BattleId 返回"/>
      </node>
      <node TEXT="扫荡功能">
        <node TEXT="对已三星通关层开放扫荡 SweepTower_c2s"/>
        <node TEXT="扫荡次数可选择 多次合并展示 Rewards"/>
      </node>
      <node TEXT="重置规则">
        <node TEXT="根据 TowerInfo ResetCount LastResetTime 客户端显示今日剩余重置次数"/>
        <node TEXT="重置真正逻辑由服务端控制 客户端仅展示按钮和提示"/>
      </node>
    </node>

    <node TEXT="十四 竞技场系统">
      <node TEXT="竞技场主界面">
        <node TEXT="展示当前 Rank BestRank Score Tickets 刷新时间"/>
        <node TEXT="当前对手列表 Rivals 每个显示昵称 战力 排名 简要阵容按钮"/>
      </node>
      <node TEXT="防守阵容设置">
        <node TEXT="防守阵容入口 单独图标 或在竞技场界面按钮"/>
        <node TEXT="布阵界面同阵容系统 调用 SetArenaDefense_c2s 保存"/>
      </node>
      <node TEXT="挑战流程">
        <node TEXT="点击对手头像进入挑战准备界面 展示双方阵容 推荐战力 排名变化预览"/>
        <node TEXT="确认后调用 ArenaChallenge_c2s 服务端创建战斗 返回 BattleId NewRank RankChange"/>
        <node TEXT="战斗逻辑统一走 EnterBattle BattleResult"/>
      </node>
      <node TEXT="战报界面">
        <node TEXT="通过 GetArenaRecords_c2s 拉取 ArenaBattleRecord 列表"/>
        <node TEXT="每条战报展示进攻 防守 方 昵称 结果 时间 排名变化 展开播映回放按钮"/>
        <node TEXT="回放使用 ReplayId 触发战斗回放接口 后续扩展"/>
      </node>
      <node TEXT="奖励与结算展示">
        <node TEXT="每日结算奖励不在当前协议明确 但客户端预留入口 显示排名段奖励"/>
      </node>
    </node>

    <node TEXT="十五 抽卡召唤系统">
      <node TEXT="召唤主界面">
        <node TEXT="通过 GetGachaInfo_c2s 获取 GachaPoolInfo 列表"/>
        <node TEXT="界面展示不同池子标签 名称 类型 今日抽取次数 免费次数倒计时"/>
        <node TEXT="显示单抽 十连按钮 消耗资源类型与数量"/>
      </node>
      <node TEXT="抽卡操作流程">
        <node TEXT="玩家选择池子和次数 点击抽卡按钮 调用 DoGacha_c2s"/>
        <node TEXT="DoGacha_s2c 返回 Result 奖励列表 NewHeroes 触发抽卡演出"/>
      </node>
      <node TEXT="抽卡演出表现">
        <node TEXT="支持普通表现和跳过动画 依据奖励品质调整特效 强弱演出"/>
        <node TEXT="结果页面可切换奖励卡牌 查看新英雄详情"/>
      </node>
      <node TEXT="保底与历史记录展示">
        <node TEXT="使用 GachaPoolInfo PityCount 显示距离保底剩余次数"/>
        <node TEXT="抽卡历史可本地记录 或后续服务端扩展接口"/>
      </node>
    </node>

    <node TEXT="十六 商店系统">
      <node TEXT="商店主界面">
        <node TEXT="按 ShopType 分类标签 普通 竞技场 公会 友情 黑市 活动 每日 每周"/>
        <node TEXT="进入某类型调用 GetShopInfo_c2s 获取 ShopItemInfo 列表"/>
        <node TEXT="显示物品图标 品质 价格 剩余购买次数 是否售罄 刷新时间"/>
      </node>
      <node TEXT="购买流程">
        <node TEXT="点击物品弹出确认框 显示消耗资源和奖励内容 支持设置数量"/>
        <node TEXT="确认后调用 BuyShopItem_c2s 成功返回 BuyShopItem_s2c 更新 Item Reward"/>
        <node TEXT="失败时提示资源不足 或购买上限"/>
      </node>
      <node TEXT="刷新流程">
        <node TEXT="自动刷新时间从 GetShopInfo_s2c RefreshAt 计算 倒计时展示"/>
        <node TEXT="手动刷新调用 RefreshShop_c2s 消耗资源 结果使用 RefreshShop_s2c"/>
      </node>
      <node TEXT="多货币支持">
        <node TEXT="前端根据 PriceType 决定使用哪种货币 Gold Diamond GuildCoin FriendCoin 等"/>
      </node>
    </node>

    <node TEXT="十七 任务系统">
      <node TEXT="任务类型与分页">
        <node TEXT="按 TaskType 分为 每日 每周 主线 引导 活动任务"/>
        <node TEXT="在任务界面调用 GetTaskList_c2s 可按类型筛选"/>
      </node>
      <node TEXT="任务列表显示">
        <node TEXT="每个 TaskInfo 显示名称 描述 目标值 当前进度 进度条 奖励图标"/>
        <node TEXT="状态为 Completed 显示领取按钮 RewardTaken 显示已领取标记"/>
      </node>
      <node TEXT="任务领奖流程">
        <node TEXT="点击领取按钮 调用 ClaimTaskReward_c2s 成功后更新 TaskInfo 和奖励展示"/>
      </node>
      <node TEXT="任务引导链">
        <node TEXT="NextTaskId 字段用于指示后续任务 客户端可在完成后高亮新的引导任务"/>
      </node>
    </node>

    <node TEXT="十八 成就系统">
      <node TEXT="成就列表界面">
        <node TEXT="按类型或分类展示 AchievementInfo 列表 可折叠大类"/>
        <node TEXT="展示名称 描述 进度 条 状态 奖励"/>
      </node>
      <node TEXT="成就进度同步">
        <node TEXT="登录和重连时调用 GetAchievementList_c2s 获取全集"/>
        <node TEXT="任务 成就进度变化可通过事件模块推送 后续扩展"/>
      </node>
      <node TEXT="领取成就奖励">
        <node TEXT="点击可领成就 调用 ClaimAchievementReward_c2s 更新状态并展示奖励"/>
      </node>
    </node>

    <node TEXT="十九 活动系统">
      <node TEXT="活动列表">
        <node TEXT="GetEvents_c2s 获取 EventInfo 列表 按类型排序 显示活动时间 倒计时"/>
        <node TEXT="活动入口的红点由 NotifyRedPoint 控制"/>
      </node>
      <node TEXT="活动详情页构建">
        <node TEXT="进入具体活动时调用 GetEventDetail_c2s 获取 Progress JSON 根据活动类型解析为对应 UI"/>
        <node TEXT="客户端活动界面通用结构 标题 倒计时 玩法说明 奖励预览 操作按钮区"/>
      </node>
      <node TEXT="统一活动操作入口">
        <node TEXT="活动行为统一用 DoEventAction_c2s 例如转盘 签到 翻牌 抽奖等"/>
        <node TEXT="根据 Action 和 Params 构建行为参数 结果界面显示 Rewards 和最新 Progress"/>
      </node>
      <node TEXT="活动结束处理">
        <node TEXT="活动结束后按钮置灰 显示活动已结束 文案 Refresh 列表时不再进入"/>
      </node>
    </node>

    <node TEXT="二十 好友系统">
      <node TEXT="好友主界面">
        <node TEXT="分页显示 好友列表 好友申请 推荐好友 搜索入口"/>
        <node TEXT="进入时调用 GetFriendList_c2s 获取 Friends 和 Requests"/>
      </node>
      <node TEXT="好友列表显示">
        <node TEXT="每条 FriendInfo 显示头像 等级 战力 在线状态 最后在线时间"/>
        <node TEXT="支持点击查看他人详情 阵容 竞技场排名 等后续扩展"/>
      </node>
      <node TEXT="搜索与添加好友">
        <node TEXT="输入关键字 调用 SearchPlayer_c2s 显示候选玩家列表"/>
        <node TEXT="点击添加 调用 ApplyFriend_c2s 可输入附言"/>
      </node>
      <node TEXT="好友申请处理">
        <node TEXT="申请列表使用 FriendRequestInfo 显示申请人信息 附言 时间"/>
        <node TEXT="同意或拒绝时调用 HandleFriendRequest_c2s 同意后刷新好友列表"/>
        <node TEXT="收到 FriendRequestNotify_s2c 时在好友按钮上显示红点"/>
      </node>
      <node TEXT="删除好友与屏蔽">
        <node TEXT="删除好友调用 DeleteFriend_c2s 结果提示 并从列表移除"/>
        <node TEXT="黑名单和屏蔽后续扩展 使用 FriendStatus"/>
      </node>
      <node TEXT="友情点与体力赠送">
        <node TEXT="支持一键赠送 给全部或多选好友 调用 SendFriendEnergy_c2s"/>
        <node TEXT="支持一键领取 调用 ReceiveFriendEnergy_c2s 返回 Rewards"/>
      </node>
      <node TEXT="在线状态同步">
        <node TEXT="收到 FriendOnlineStatusNotify_s2c 更新对应好友在线状态 刷新图标"/>
      </node>
    </node>

    <node TEXT="二十一 聊天系统">
      <node TEXT="聊天频道与入口">
        <node TEXT="支持世界 公会 队伍 私聊 系统频道 切换页签"/>
        <node TEXT="主界面底部入口展示最近消息摘要 和未读数量标记"/>
      </node>
      <node TEXT="消息发送流程">
        <node TEXT="在对应频道输入框输入文本 点击发送调用 SendChatMessage_c2s"/>
        <node TEXT="成功后本地显示 SendChatMessage_s2c 回显的 ChatMessage 保证与服务器一致"/>
      </node>
      <node TEXT="消息接收与展示">
        <node TEXT="服务器通过 ChatMessageNotify_s2c 推送所有频道消息"/>
        <node TEXT="不同频道使用不同颜色标签 过滤屏蔽机制后再展示"/>
      </node>
      <node TEXT="历史聊天记录">
        <node TEXT="从本地缓存一定数量消息 上滑时调用 GetChatHistory_c2s 补全历史"/>
        <node TEXT="私聊需要带 ToPlayerId 请求历史记录"/>
      </node>
      <node TEXT="屏蔽与举报后续扩展">
        <node TEXT="客户端保留屏蔽用户列表 不展示其消息 举报需预留入口"/>
      </node>
    </node>

    <node TEXT="二十二 邮件系统">
      <node TEXT="邮件列表界面">
        <node TEXT="按类别显示 系统 活动 奖励 公会等 可过滤 未读 已读"/>
        <node TEXT="进入时调用 GetMailList_c2s 获取 MailInfo 列表"/>
      </node>
      <node TEXT="邮件详情">
        <node TEXT="点击邮件显示 Title Content 附件 列表"/>
        <node TEXT="首次打开调用 ReadMail_c2s 将状态改为已读"/>
      </node>
      <node TEXT="附件领取流程">
        <node TEXT="有附件时展示一键领取按钮 调用 ClaimMailAttachment_c2s"/>
        <node TEXT="成功后展示 Rewards 同时更新 Mail 状态为 Received"/>
      </node>
      <node TEXT="邮件删除">
        <node TEXT="支持单删 多选删除 调用 DeleteMail_c2s"/>
      </node>
      <node TEXT="新邮件通知">
        <node TEXT="收到 NewMailNotify_s2c 时 在主城邮件按钮上显示红点 并刷新列表"/>
      </node>
    </node>

    <node TEXT="二十三 公会系统">
      <node TEXT="公会主界面">
        <node TEXT="若未加入公会 显示推荐公会列表和创建加入入口"/>
        <node TEXT="若已在公会 显示 GuildInfo 基础信息 公会公告 总战力 成员数量"/>
      </node>
      <node TEXT="公会列表与搜索">
        <node TEXT="通过 GetGuildList_c2s 分页获取公会列表 按活跃人数 战力排序"/>
        <node TEXT="每个公会条目显示名称 徽章 等级 人数 会长名 入会条件 简要介绍"/>
      </node>
      <node TEXT="创建公会">
        <node TEXT="填写名称 徽章 公告 调用 CreateGuild_c2s 成功进入新建公会"/>
      </node>
      <node TEXT="加入公会申请">
        <node TEXT="点击申请加入按钮 调用 ApplyGuild_c2s 可写附言"/>
        <node TEXT="申请状态本地标记 服务端管理实际通过情况"/>
      </node>
      <node TEXT="公会信息与成员列表">
        <node TEXT="进入公会界面调用 GetGuildInfo_c2s 获取 Guild Members 信息"/>
        <node TEXT="成员列表显示职位 等级 战力 最后在线时间 贡献值"/>
      </node>
      <node TEXT="申请列表与审批">
        <node TEXT="会长和官员可查看待审批列表 GuildApplyInfo"/>
        <node TEXT="同意或拒绝通过 HandleGuildApply_c2s 完成"/>
        <node TEXT="收到 GuildApplyNotify_s2c 时在公会审批入口显示红点"/>
      </node>
      <node TEXT="成员管理">
        <node TEXT="会长可踢人 使用 KickGuildMember_c2s 操作前弹二次确认"/>
        <node TEXT="修改公告和入会条件 调用 ChangeGuildSettings_c2s"/>
      </node>
      <node TEXT="退出和解散公会">
        <node TEXT="普通成员通过 LeaveGuild_c2s 退出 需要确认提示"/>
        <node TEXT="解散公会为后续扩展 需服务端配合"/>
      </node>
      <node TEXT="公会捐献与公会玩法预留">
        <node TEXT="捐献入口 调用 DonateGuild_c2s 根据 DonateType 执行操作 显示 Rewards"/>
        <node TEXT="公会副本 公会战后续通过 Event 或专用协议扩展"/>
      </node>
      <node TEXT="公会成员变化通知">
        <node TEXT="监听 GuildMemberUpdateNotify_s2c 更新成员列表 入会 离会 职位变化"/>
      </node>
    </node>

    <node TEXT="二十四 红点与提示系统">
      <node TEXT="红点模块设计">
        <node TEXT="每个功能按钮注册对应 Module SubModule 与协议保持一致"/>
        <node TEXT="NotifyRedPoint_s2c 中 Count 大于零时显示红点 数值显示总数或点"/>
      </node>
      <node TEXT="客户端本地红点补充">
        <node TEXT="客户端可根据任务已完成未领取等自算红点 但以服务端为准"/>
        <node TEXT="当本地推测与服务端冲突时 优先以最新 NotifyRedPoint 为准"/>
      </node>
      <node TEXT="红点清理策略">
        <node TEXT="进入具体界面时可发请求让服务端清除红点 服务端再推送更新"/>
      </node>
    </node>

    <node TEXT="二十五 系统设置与公告">
      <node TEXT="设置界面">
        <node TEXT="功能包括 音量 控制 战斗加速开关 画质简易选项 语言切换 等"/>
        <node TEXT="设置保存在本地 同时部分需发到服务器作为偏好记忆"/>
      </node>
      <node TEXT="公告与活动面板">
        <node TEXT="使用 LobbyInfo Notices 数据 在公告面板展示 图文公告"/>
        <node TEXT="活动入口整合 GetEvents_s2c 中 EventInfo 标记热点活动"/>
      </node>
    </node>

    <node TEXT="二十六 新手引导与功能解锁">
      <node TEXT="新手引导流程逻辑">
        <node TEXT="基于 Task Guide 类型任务 或本地引导配置控制引导步骤"/>
        <node TEXT="重要系统首次开启时 播放引导 如抽卡 英雄升级 装备 强化"/>
      </node>
      <node TEXT="功能解锁条件">
        <node TEXT="根据玩家等级 当前关卡 任务完成情况判断 是否显示或开放功能按钮"/>
        <node TEXT="解锁时弹出功能解锁界面 提示玩法收益"/>
      </node>
    </node>

    <node TEXT="二十七 数据埋点与调试">
      <node TEXT="关键行为埋点">
        <node TEXT="登录 登出 抽卡 付费点 英雄培养 装备强化 副本挑战等行为需埋点"/>
        <node TEXT="埋点内容包括 玩家等级 战力 资源变化 来源等"/>
      </node>
      <node TEXT="战斗调试">
        <node TEXT="可在开发版本通过 GMCommand 调整资源 开启关卡 便于测试"/>
        <node TEXT="战斗中显示帧率 延迟 次数 各项 debug 信息 可根据配置打开"/>
      </node>
    </node>

    <node TEXT="二十八 GM 与测试工具">
      <node TEXT="GM 命令入口">
        <node TEXT="正式服隐藏 仅测试环境通过特殊手势或输入框开启"/>
        <node TEXT="界面支持输入 Command 和 Args JSON 调用 GMCommand_c2s"/>
      </node>
      <node TEXT="GM 结果展示">
        <node TEXT="显示 GMCommand_s2c 中 Result Message 成功或失败原因"/>
      </node>
    </node>
  </node>
</map>
