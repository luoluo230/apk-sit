# M09-07 协议、DTO 与代码生成模块

## 入口

- Unity 菜单：`Tools/HotUpdate/Protocols/Workbench`
- 协议源：`Assets/Src/Protocols/protocols.json`
- 正式生成：`tools/protocols/Generate-ProtocolArtifacts.ps1`
- 产物校验：`tools/protocols/Validate-ProtocolArtifacts.ps1`

## 工作台分区

- `总览`：查看协议源统计、重复 MessageID、关键产物路径，并快速执行生成/校验。
- `协议编辑`：支持搜索、筛选、新增、复制、删除、重命名、全局/模块方向自动分配 MessageID，以及可拖拽排序的结构化字段表格编辑。
- `导出生成`：支持全量或仅导出当前选中协议，语言/目标包括 C#、Python、Node.js TypeScript、Java、Kotlin、Go、OpenAPI、Protobuf、FlatBuffers、Node.js Mock Server，并可配置 namespace/package、导出清理和 manifest。
- 单协议导出会自动带上该协议字段引用到的共享 `Class` / `Enum`，避免导出的后端包缺少依赖类型。
- `协议测试`：支持按字段生成 Mock Payload、保存测试用例、生成可复制请求包、抓包/重放、错误码注入、Mock 响应，并在 HTTP/Tcp/WebSocket 通信方式下直接发送到测试服。
- `网络配置`：配置运行时代码使用的通信方式、协议编码、多环境 endpoint、超时、心跳、重连、可靠投递、压缩和加密开关。
- `网络模拟`：模拟延迟、抖动、丢包、重复包、乱序、带宽限制和断线，方便前端验证弱网行为。
- `版本治理`：支持创建协议兼容性基线，并检测删除协议、修改 MessageID、删除字段、字段类型变化、新增必填字段等 breaking change。
- `Skill 生成`：M09-07A 协议智能业务代码生成入口，可根据协议上下文生成客户端 API、UseCase、Presenter 示例、服务端 Handler/Service/Repository 建议、Mock/Test 和迁移说明。
- `日志`：集中查看工作台操作、校验错误、导出结果和模拟报告。

## 协议源格式

共享数据结构：

```json
"PlayerProfile": {
    "Type": "Class",
    "Comment": "玩家基础信息",
    "Fields": {
        "PlayerId": { "Type": "long", "Comment": "玩家唯一 ID" }
    }
}
```

枚举：

```json
"ItemCategory": {
    "Type": "Enum",
    "Comment": "背包物品类别",
    "Values": ["Equipment", "Consumable", "Material"]
}
```

消息协议：

```json
"Login_c2s": {
    "MessageID": 10001,
    "Comment": "登录请求",
    "Data": {
        "Account": { "Type": "string", "Comment": "账号" }
    }
}
```

## 生成产物

- 客户端 DTO：`Assets/Src/HotUpdate/Framework/Network/GeneratedProtocols/CSharp`
- 服务端 DTO：`game-server/shared/Protocols/Generated`
- 协议 ID：`ProtocolIds.cs`
- 协议字典：`ProtocolDictionary.cs`
- Handler 模板：`protocols/generated/handler-templates`
- 协议目录与报告：`protocols/generated`
- 多语言导出：`protocols/generated/exports`

## 网络配置闭环

工作台会创建或编辑：

- `Assets/Resources/Protocol/ProtocolNetworkSettings.asset`

运行时读取方式：

```csharp
ProtocolNetworkSettings settings = ProtocolNetworkSettingsRuntime.LoadDefault();
ProtocolNetworkSettingsRuntime.TryApplyTo(networkManager, settings, connectImmediately: false);
```

`NetworkFacade` 已支持在 `Awake` 中自动读取 `Resources/Protocol/ProtocolNetworkSettings`，并同步到 `NetworkManager`。如果业务需要热切环境，也可以调用：

```csharp
networkFacade.ConfigureFromProtocolNetworkSettings(settings, connectImmediately: true);
```

## 校验规则

- 协议源必须是顶层 JSON 对象。
- 顶层协议名只能使用字母、数字和下划线，并且必须以字母开头。
- 消息协议必须有有效 `MessageID`，推荐使用 `_c2s` / `_s2c` 后缀。
- `MessageID` 必须全局唯一。
- `Class` 必须包含 `Fields`。
- `Enum` 必须包含 `Values`。
- 正式生成后必须运行产物一致性校验，确保客户端/服务端 DTO、协议 ID、字典、文档和模板同步。
- 强校验会额外检查字段类型是否存在、复杂类型引用、Class 循环引用、字段名/FieldId 是否重复、字段说明是否缺失、请求响应是否配对、模块方向 ID 区间。

## 版本治理

工作台的 `版本治理` 页会使用以下基线文件：

- `protocols/generated/protocol-baseline.json`

推荐流程：

1. 每个稳定版本发包前点击 `创建/覆盖当前基线`。
2. 日常改协议后点击 `对比当前协议与基线`。
3. 如果报告出现 `[Breaking]`，需要确认是否允许破坏旧客户端；不允许时应改成新增字段或新增协议。

## 协议测试

测试用例会保存到：

- `protocols/generated/testcases`

HTTP/Tcp/WebSocket 通信方式下，工作台可以直接发送协议包到测试服。Kcp 通信方式下，工作台会生成统一 envelope 和测试用例，运行时测试器可读取同一用例发包。

## M09-07A Protocol Skill Codegen

`Skill 生成`页签用于把协议 DTO 进一步生成“业务可直接调用”的客户端/服务端逻辑骨架。它不是替代协议生成器，而是在 DTO、ProtocolIds、ProtocolDictionary 已生成并校验通过之后，继续生成业务接入层。

核心流程：

1. 选择协议。
2. 选择目标端：`Client` / `Server` / `Both`。
3. 勾选 Skill：客户端 API、客户端 UseCase、Presenter 示例、服务端 Handler、Service、Repository/DB 建议、Mock/Test、Migration。
4. 点击 `生成 Skill 计划`。
5. 查看计划预览、上下文文件和风险提示。
6. 如果确认无误，关闭 `Dry Run` 后点击 `应用计划写入代码`。

安全约束：

- 不修改 DTO、协议源、ProtocolIds、ProtocolDictionary。
- 先生成 plan，再应用写入。
- 生成代码包裹在 `auto-generated-protocol-skill` 区域。
- 数据库代码默认只生成 schema 建议；需要落 model/repository/migration 时必须人工确认。
- 手写业务逻辑建议放在独立 partial 文件或 manual 区域，避免重新生成时被覆盖。

默认输出：

- 客户端：`Assets/Src/HotUpdate/Business/GeneratedProtocolSkills/Client`
- 服务端：`game-server/shared/ProtocolSkills/Generated`
- Skill 上下文：`protocols/generated/skill-codegen/context`
- Skill 计划：`protocols/generated/skill-codegen/plans`

Skill 模板：

- `Assets/Editor/Protocol/Skills/Capabilities/Client/client-api-wrapper.skill.md`
- `Assets/Editor/Protocol/Skills/Capabilities/Client/client-usecase.skill.md`
- `Assets/Editor/Protocol/Skills/Capabilities/Client/client-presenter-binding.skill.md`
- `Assets/Editor/Protocol/Skills/Capabilities/Server/server-handler.skill.md`
- `Assets/Editor/Protocol/Skills/Capabilities/Server/server-service.skill.md`
- `Assets/Editor/Protocol/Skills/Capabilities/Server/server-repository.skill.md`
- `Assets/Editor/Protocol/Skills/Capabilities/Shared/mock-and-test.skill.md`
- `Assets/Editor/Protocol/Skills/Capabilities/Shared/migration.skill.md`
- `Assets/Editor/Protocol/Skills/Support`
- `Assets/Editor/Protocol/Skills/Domains`
- `Assets/Editor/Protocol/Skills/Scenarios`
