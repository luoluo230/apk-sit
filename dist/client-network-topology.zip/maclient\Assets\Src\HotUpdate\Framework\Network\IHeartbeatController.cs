using System;

/// <summary>
/// 心跳控制器接口。
/// 用于统一管理长连接保活、心跳 RTT 统计与心跳超时判定。
/// </summary>
public interface IHeartbeatController
{
    int HeartbeatRequestId { get; }
    int HeartbeatResponseId { get; }
    float LastHeartbeatRtt { get; }

    /// <summary>
    /// 配置心跳协议 ID 和初始时间。
    /// </summary>
    void Configure(int heartbeatRequestId, int heartbeatResponseId, float currentTime);

    /// <summary>
    /// 连接建立时重置心跳状态。
    /// </summary>
    void OnConnected(float currentTime);

    /// <summary>
    /// 连接断开时清理心跳状态。
    /// </summary>
    void OnDisconnected();

    /// <summary>
    /// 收到任意网络数据时更新活跃时间。
    /// </summary>
    void OnDataReceived(float currentTime);

    /// <summary>
    /// 标记一条心跳请求已经发送。
    /// </summary>
    void MarkHeartbeatSent(float currentTime);

    /// <summary>
    /// 每帧推进心跳检测逻辑。
    /// </summary>
    void Tick(
        float currentTime,
        bool isLongConnection,
        bool isConnected,
        NetworkManager.TransportType transportType,
        float heartbeatInterval,
        float heartbeatTimeoutSeconds,
        bool enableHeartbeatRequest,
        float kcpDisconnectTimeout,
        Action sendHeartbeatRequest,
        Action onHeartbeatTimeout);

    /// <summary>
    /// 尝试处理心跳响应，并在需要时动态调整 KCP 超时阈值。
    /// </summary>
    bool TryHandleHeartbeatResponse(
        NetMessage message,
        bool enableHeartbeatRequest,
        bool swallowHeartbeatResponse,
        float currentTime,
        NetworkManager.TransportType transportType,
        float kcpDisconnectBaseTimeout,
        float kcpDisconnectMinTimeout,
        float kcpDisconnectMaxTimeout,
        float kcpDisconnectRttMultiplier,
        Action<float> setKcpDisconnectTimeout);
}
