// 自动生成的协议文件

// 定义协议类


// 标记邮件为已读
class ReadMail_c2s {
    constructor() {
        this.MailId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 邮件已读操作结果
class ReadMail_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ReadMail_c2s,
    ReadMail_s2c,
};
