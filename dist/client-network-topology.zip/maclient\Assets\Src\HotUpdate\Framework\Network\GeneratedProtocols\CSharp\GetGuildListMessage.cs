﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 公会列表(用于查找加入)
/// </summary>
public class GetGuildList_c2s
{
    /// <summary>
    /// 页码
    /// </summary>
    public int PageIndex { get; set; }
    /// <summary>
    /// 每页数量
    /// </summary>
    public int PageSize { get; set; }
}

/// <summary>
/// 公会列表响应
/// </summary>
public class GetGuildList_s2c
{
    /// <summary>
    /// 公会简要信息列表
    /// </summary>
    public GuildInfo[] Guilds { get; set; }
}

