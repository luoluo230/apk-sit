﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 服务器推送资源变动(任意原因的货币/体力变化)
/// </summary>
public class SyncResource_s2c
{
    /// <summary>
    /// 资源变动列表
    /// </summary>
    public ResourceChange[] Changes { get; set; }
    /// <summary>
    /// 变动原因(字符串标识，方便前端埋点)
    /// </summary>
    public string Reason { get; set; }
}

