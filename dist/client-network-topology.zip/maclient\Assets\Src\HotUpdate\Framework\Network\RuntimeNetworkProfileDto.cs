using System;

/// <summary>
/// Field names use snake_case to match the JSON returned by the Web API,
/// because UnityEngine.JsonUtility requires exact field-name matching.
/// </summary>
[Serializable]
public class RuntimeNetworkProfileDto
{
    public string gateway_ws;
    public string login_http;
    public string game_ws;
    public string ops_http;
    public string notice_url;

    public string GatewayWs => gateway_ws;
    public string LoginHttp => login_http;
    public string GameWs => game_ws;
    public string OpsHttp => ops_http;
    public string NoticeUrl => notice_url;
}
