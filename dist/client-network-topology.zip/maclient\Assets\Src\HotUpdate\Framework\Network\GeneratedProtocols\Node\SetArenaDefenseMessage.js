// 自动生成的协议文件

// 定义协议类


// 设置竞技场防守阵容
class SetArenaDefense_c2s {
    constructor() {
        this.Formation = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 设置竞技场防守阵容结果
class SetArenaDefense_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SetArenaDefense_c2s,
    SetArenaDefense_s2c,
};
