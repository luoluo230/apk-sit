﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 副本进度广播
/// </summary>
public class DungeonProgressNotify_s2c
{
    /// <summary>
    /// 副本 ID
    /// </summary>
    public int DungeonId { get; set; }
    /// <summary>
    /// 进度数据(JSON)
    /// </summary>
    public string Progress { get; set; }
}

