# Scenarios

这里放“具体业务场景”规则，是让 AI 生成具体业务骨架的核心目录。

## 分类

- `Account`：登录、会话、玩家资料。
- `Economy`：支付、背包、奖励、排行榜积分。
- `Combat`：战斗结算、帧同步、匹配房间。
- `Social`：聊天、通知、社交消息。

## 匹配方式

`ProtocolSkillScenarioRegistry` 会根据协议名、模块名、request/response 字段名、字段注释自动匹配场景。

## 规则

- 每个场景必须说明客户端流程、服务端流程、幂等/事务/权限/错误码/测试要求。
- 场景规则可以很具体，Domain 规则必须保持宽泛。
