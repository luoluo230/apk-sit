﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 新邮件到达推送
/// </summary>
public class NewMailNotify_s2c
{
    /// <summary>
    /// 新邮件概要信息
    /// </summary>
    public MailInfo Mail { get; set; }
}

