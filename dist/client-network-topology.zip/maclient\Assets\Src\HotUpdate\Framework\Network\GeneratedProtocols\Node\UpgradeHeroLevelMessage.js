// 自动生成的协议文件

// 定义协议类


// 英雄升级(消耗经验物品/金币)
class UpgradeHeroLevel_c2s {
    constructor() {
        this.HeroId = null;
        this.UseItems = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 英雄升级结果
class UpgradeHeroLevel_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Hero = null;
        this.ResourceChanges = [];
        this.InventoryDelta = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    UpgradeHeroLevel_c2s,
    UpgradeHeroLevel_s2c,
};
