// 自动生成的协议文件

// 定义协议类


// 进入世界 Boss
class EnterWorldBoss_c2s {
    constructor() {
        this.BossId = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 进入世界 Boss 结果
class EnterWorldBoss_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Boss = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    EnterWorldBoss_c2s,
    EnterWorldBoss_s2c,
};
