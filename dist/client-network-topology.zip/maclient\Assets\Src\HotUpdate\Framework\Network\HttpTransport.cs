﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;

/// <summary>
/// HTTP 传输实现。
/// 适合无状态短连接请求（每次发送都是一次独立 POST）。
/// </summary>
public class HttpTransport : MonoBehaviour, ITransportClient
{
    private string _baseUrl;

    public bool IsConnected { get; private set; }

    public event Action OnConnected;
    public event Action<string> OnDisconnected;
    public event Action<string> OnError;
    public event Action<byte[]> OnDataReceived;

    [SerializeField]
    private float _timeout = 15f;

    /// <summary>
    /// 初始化 HTTP 传输。
    /// 注意：这里不会保持真正的长连接，只记录基础地址并标记可发送状态。
    /// </summary>
    public void Connect(string url)
    {
        _baseUrl = url;
        IsConnected = true;
        OnConnected?.Invoke();
    }

    /// <summary>
    /// 关闭 HTTP 传输。
    /// </summary>
    public void Disconnect()
    {
        if (!string.IsNullOrEmpty(_baseUrl))
        {
            OnDisconnected?.Invoke("HTTP connection closed.");
        }

        IsConnected = false;
        _baseUrl = null;
    }

    /// <summary>
    /// 发起一次 HTTP POST 请求。
    /// </summary>
    public void Send(byte[] data)
    {
        if (!IsConnected || string.IsNullOrEmpty(_baseUrl))
        {
            OnError?.Invoke("HTTP transport is not initialized.");
            return;
        }

        StartCoroutine(SendRequest(data));
    }

    /// <summary>
    /// 协程发送请求并回传服务端响应。
    /// </summary>
    private IEnumerator SendRequest(byte[] data)
    {
        using (UnityWebRequest request = new UnityWebRequest(_baseUrl, UnityWebRequest.kHttpVerbPOST))
        {
            request.uploadHandler = new UploadHandlerRaw(data);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.timeout = Mathf.CeilToInt(_timeout);
            request.SetRequestHeader("Content-Type", "application/octet-stream");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                OnDataReceived?.Invoke(request.downloadHandler.data);
            }
            else
            {
                OnError?.Invoke($"HTTP request failed: {request.error}");
            }
        }
    }

    private void OnDestroy()
    {
        Disconnect();
    }
}
