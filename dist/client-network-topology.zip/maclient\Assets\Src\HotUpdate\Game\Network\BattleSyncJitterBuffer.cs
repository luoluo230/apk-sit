using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

/// <summary>
/// Smooths battle frame delivery under network jitter by buffering incoming frames
/// and triggering resync when drift or checksum mismatch exceeds thresholds.
/// </summary>
public sealed class BattleSyncJitterBuffer : IDisposable
{
    private readonly IGameplayBattleSyncModule _battleSync;
    private readonly string _battleId;
    private readonly SortedDictionary<int, BattleFrameBundle> _pendingFrames = new SortedDictionary<int, BattleFrameBundle>();
    private readonly object _gate = new object();
    private int _lastAppliedFrame;
    private int _targetBufferMs = 80;
    private int _maxBufferMs = 180;
    private int _lastJitterMs;
    private CancellationTokenSource _healthLoopCts;

    public BattleSyncJitterBuffer(IGameplayBattleSyncModule battleSync, string battleId, int targetBufferMs = 80)
    {
        _battleSync = battleSync ?? throw new ArgumentNullException(nameof(battleSync));
        _battleId = string.IsNullOrWhiteSpace(battleId) ? throw new ArgumentException("battleId required") : battleId;
        _targetBufferMs = Math.Max(20, targetBufferMs);
    }

    public int LastAppliedFrame => _lastAppliedFrame;
    public int LastJitterMs => _lastJitterMs;

    public void StartHealthLoop(int intervalMs = 1000)
    {
        StopHealthLoop();
        _healthLoopCts = new CancellationTokenSource();
        _ = RunHealthLoopAsync(intervalMs, _healthLoopCts.Token);
    }

    public void StopHealthLoop()
    {
        _healthLoopCts?.Cancel();
        _healthLoopCts?.Dispose();
        _healthLoopCts = null;
    }

    public void PushRemoteFrame(BattleSpectatorFrameNotify_s2c notify)
    {
        if (notify == null || notify.Frames == null)
        {
            return;
        }

        lock (_gate)
        {
            foreach (var bundle in notify.Frames)
            {
                if (bundle == null)
                {
                    continue;
                }

                _pendingFrames[bundle.EndFrame] = bundle;
            }
        }
    }

    public IReadOnlyList<BattleFrameBundle> ConsumeReadyFrames(int serverFrameHint = 0)
    {
        var ready = new List<BattleFrameBundle>();
        lock (_gate)
        {
            var lagMs = EstimateLagMs(serverFrameHint);
            _lastJitterMs = lagMs;
            var holdUntil = serverFrameHint > 0 && lagMs < _maxBufferMs
                ? Math.Max(_lastAppliedFrame, serverFrameHint - Math.Max(1, lagMs / 50))
                : _lastAppliedFrame;

            foreach (var pair in _pendingFrames.ToList())
            {
                if (pair.Key <= holdUntil || lagMs >= _maxBufferMs)
                {
                    ready.Add(pair.Value);
                    _pendingFrames.Remove(pair.Key);
                    _lastAppliedFrame = Math.Max(_lastAppliedFrame, pair.Key);
                }
            }
        }

        return ready;
    }

    public async Task<bool> ReportHealthAndResyncIfNeededAsync(
        int clientFrame,
        string stateHash,
        int networkRttMs,
        int jitterMs,
        float packetLossRate)
    {
        var health = new BattleSyncHealth
        {
            BattleId = _battleId,
            ClientFrame = clientFrame,
            LastConfirmedFrame = _lastAppliedFrame,
            ServerFrame = clientFrame,
            NetworkRttMs = networkRttMs,
            JitterMs = jitterMs,
            PacketLossRate = packetLossRate,
            PendingResync = jitterMs >= _targetBufferMs,
        };
        var checksum = new BattleChecksumInfo
        {
            BattleId = _battleId,
            Frame = clientFrame,
            StateHash = stateHash,
            ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
        };

        var response = await _battleSync.ReportSyncHealthAsync(_battleId, health, checksum, needServerHealth: true)
            .ConfigureAwait(false);
        if (response == null)
        {
            return false;
        }

        if (response.SuggestedResync || response.NeedResync)
        {
            var from = Math.Max(0, response.SuggestedFromFrame);
            var resync = await _battleSync.RequestResyncAsync(new BattleResyncRequestData
            {
                BattleId = _battleId,
                FromFrame = from,
                Reason = response.ResyncReason,
            }).ConfigureAwait(false);

            if (resync?.Response?.Frames != null)
            {
                lock (_gate)
                {
                    foreach (var bundle in resync.Response.Frames)
                    {
                        if (bundle != null)
                        {
                            _pendingFrames[bundle.EndFrame] = bundle;
                        }
                    }
                }
            }

            return true;
        }

        return false;
    }

    private async Task RunHealthLoopAsync(int intervalMs, CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(intervalMs, token).ConfigureAwait(false);
                await ReportHealthAndResyncIfNeededAsync(
                    _lastAppliedFrame,
                    $"client-{_lastAppliedFrame}",
                    networkRttMs: 40,
                    jitterMs: _lastJitterMs,
                    packetLossRate: 0f).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception)
            {
                // health loop is best-effort
            }
        }
    }

    private int EstimateLagMs(int serverFrameHint)
    {
        if (serverFrameHint <= 0)
        {
            return _targetBufferMs;
        }

        var frameGap = Math.Max(0, serverFrameHint - _lastAppliedFrame);
        return Math.Min(_maxBufferMs, frameGap * 50);
    }

    public void Dispose()
    {
        StopHealthLoop();
    }
}
