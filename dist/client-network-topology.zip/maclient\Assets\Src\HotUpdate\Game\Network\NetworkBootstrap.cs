﻿using System;
using System.Reflection;
using UnityEngine;

/// <summary>
/// 网络模块单组件引导壳。
/// 只需要挂载该组件，即可自动创建并托管 NetworkManager / NetworkFacade / GameNetworkClient。
/// 对外语义命名分别对应：NetworkRuntimeCore / ProtocolNetworkBridge / GameNetworkGateway。
/// </summary>
[DisallowMultipleComponent]
[AddComponentMenu("MAClient/协议与网络/网络模块引导壳")]
public sealed class NetworkBootstrap : MonoBehaviour
{
    private const string RuntimeNodeName = "__NetworkRuntime";

    [Header("配置来源")]
    [Tooltip("协议网络配置资产。为空时可从 Resources/Protocol/ProtocolNetworkSettings 自动加载。")]
    [SerializeField] private ProtocolNetworkSettings protocolNetworkSettings;
    [Tooltip("当 protocolNetworkSettings 为空时，是否自动从 Resources 加载。")]
    [SerializeField] private bool autoLoadSettingsFromResources = true;

    [Header("启动行为")]
    [Tooltip("是否跨场景保留该引导壳。")]
    [SerializeField] private bool dontDestroyOnLoad = true;
    [Tooltip("启动后是否自动连接。")]
    [SerializeField] private bool autoConnect = true;

    [Header("去歧义")]
    [Tooltip("是否自动清理场景中不受该壳托管的旧网络组件（NetworkManager/NetworkFacade/GameNetworkClient）。")]
    [SerializeField] private bool autoCleanupLegacyNetworkComponents = true;

    [Header("调试")]
    [Tooltip("是否在 Hierarchy 中隐藏内部运行时节点。")]
    [SerializeField] private bool hideRuntimeNodeInHierarchy = true;

    [SerializeField] private Transform runtimeNode;
    [SerializeField] private NetworkManager networkManager;
    [SerializeField] private NetworkFacade networkFacade;
    [SerializeField] private GameNetworkClient gameNetworkClient;

    /// <summary>业务入口客户端。</summary>
    public GameNetworkClient Client => gameNetworkClient;

    /// <summary>业务模块入口。</summary>
    public GameNetworkModules Modules => gameNetworkClient != null ? gameNetworkClient.Modules : null;

    /// <summary>玩法同步模块入口。</summary>
    public GameplaySyncModules GameplaySync => gameNetworkClient != null ? gameNetworkClient.GameplaySync : null;

    private void Reset()
    {
        EnsureRuntimeGraph();
    }

    private void Awake()
    {
        EnsureRuntimeGraph();

        if (autoCleanupLegacyNetworkComponents)
        {
            CleanupLegacyNetworkComponents();
        }

        ApplySettings();

        if (dontDestroyOnLoad)
        {
            DontDestroyOnLoad(gameObject);
        }

        if (autoConnect
            && networkFacade != null
            && !string.Equals(Environment.GetEnvironmentVariable("UNITY_E2E_DISABLE_AUTO_CONNECT"), "1", StringComparison.Ordinal))
        {
            networkFacade.EnsureConnected(networkFacade.CurrentTransportType, networkFacade.CurrentServerUri);
        }
    }

    private void OnValidate()
    {
        EnsureRuntimeGraph();

        if (autoCleanupLegacyNetworkComponents)
        {
            CleanupLegacyNetworkComponents();
        }
    }

    /// <summary>
    /// 手动应用当前协议配置到运行时。
    /// </summary>
    [ContextMenu("应用当前协议配置")]
    public void ApplySettings()
    {
        if (networkFacade == null)
        {
            return;
        }

        ProtocolNetworkSettings settings = protocolNetworkSettings;
        if (settings == null && autoLoadSettingsFromResources)
        {
            settings = ProtocolNetworkSettingsRuntime.LoadDefault();
        }

        networkFacade.ConfigureFromProtocolNetworkSettings(settings, false);
    }

    /// <summary>
    /// 手动清理旧网络组件。
    /// </summary>
    [ContextMenu("清理旧网络组件")]
    public void CleanupLegacyNetworkComponents()
    {
        CleanupComponentType(UnityEngine.Object.FindObjectsByType<NetworkManager>(FindObjectsSortMode.None), networkManager);
        CleanupComponentType(UnityEngine.Object.FindObjectsByType<NetworkFacade>(FindObjectsSortMode.None), networkFacade);
        CleanupComponentType(UnityEngine.Object.FindObjectsByType<GameNetworkClient>(FindObjectsSortMode.None), gameNetworkClient);
    }

    private void EnsureRuntimeGraph()
    {
        EnsureRuntimeNode();
        EnsureComponents();
        WireDependencies();
        ApplyManagedComponentVisibility();
        ApplyNodeVisibility();
    }

    private void EnsureRuntimeNode()
    {
        if (runtimeNode != null)
        {
            return;
        }

        Transform existing = transform.Find(RuntimeNodeName);
        if (existing != null)
        {
            runtimeNode = existing;
            return;
        }

        var node = new GameObject(RuntimeNodeName);
        node.transform.SetParent(transform, false);
        runtimeNode = node.transform;
    }

    private void EnsureComponents()
    {
        if (runtimeNode == null)
        {
            return;
        }

        if (networkManager == null)
        {
            networkManager = runtimeNode.GetComponent<NetworkManager>();
            if (networkManager == null)
            {
                networkManager = runtimeNode.gameObject.AddComponent<NetworkManager>();
            }
        }

        if (networkFacade == null)
        {
            networkFacade = runtimeNode.GetComponent<NetworkFacade>();
            if (networkFacade == null)
            {
                networkFacade = runtimeNode.gameObject.AddComponent<NetworkFacade>();
            }
        }

        if (gameNetworkClient == null)
        {
            gameNetworkClient = runtimeNode.GetComponent<GameNetworkClient>();
            if (gameNetworkClient == null)
            {
                gameNetworkClient = runtimeNode.gameObject.AddComponent<GameNetworkClient>();
            }
        }
    }

    private void WireDependencies()
    {
        if (networkManager != null)
        {
            // Connection is owned by NetworkFacade / explicit test calls; avoid Start() racing ws:// defaults.
            networkManager.autoConnect = false;
        }

        if (networkFacade != null)
        {
            SetPrivateField(networkFacade, "networkManager", networkManager);
            SetPrivateField(networkFacade, "autoFindNetworkManager", false);
            SetPrivateField(networkFacade, "autoCreateNetworkManager", false);
            SetPrivateField(networkFacade, "dontDestroyOnLoad", false);
            SetPrivateField(networkFacade, "autoConnect", false);
            SetPrivateField(networkFacade, "protocolNetworkSettings", protocolNetworkSettings);
            SetPrivateField(networkFacade, "loadProtocolNetworkSettingsFromResources", autoLoadSettingsFromResources);
        }

        if (gameNetworkClient != null)
        {
            SetPrivateField(gameNetworkClient, "networkFacade", networkFacade);
            SetPrivateField(gameNetworkClient, "autoFindNetworkFacade", false);
        }
    }

    private void ApplyNodeVisibility()
    {
        if (runtimeNode == null)
        {
            return;
        }

        runtimeNode.hideFlags = hideRuntimeNodeInHierarchy ? HideFlags.HideInHierarchy : HideFlags.None;
    }

    /// <summary>
    /// 隐藏壳托管的底层组件，避免在 Inspector 中出现多入口配置歧义。
    /// </summary>
    private void ApplyManagedComponentVisibility()
    {
        ApplyComponentVisibility(networkManager);
        ApplyComponentVisibility(networkFacade);
        ApplyComponentVisibility(gameNetworkClient);
    }

    private void ApplyComponentVisibility(Component component)
    {
        if (component == null)
        {
            return;
        }

        bool shouldHide = hideRuntimeNodeInHierarchy;
        HideFlags targetFlags = shouldHide ? HideFlags.HideInInspector : HideFlags.None;
        if (component.hideFlags == targetFlags)
        {
            return;
        }

        component.hideFlags = targetFlags;
    }

    private void CleanupComponentType<T>(T[] components, T keep) where T : Component
    {
        if (components == null)
        {
            return;
        }

        for (int i = 0; i < components.Length; i++)
        {
            T component = components[i];
            if (component == null || component == keep)
            {
                continue;
            }

            if (IsOwnedByBootstrap(component))
            {
                continue;
            }

            Logger.Log($"[NetworkBootstrap] 清理游离组件: {typeof(T).Name} -> {component.gameObject.name}", LogLevel.Warning);

            if (Application.isPlaying)
            {
                Destroy(component);
            }
            else
            {
                DestroyImmediate(component, true);
            }
        }
    }

    private bool IsOwnedByBootstrap(Component component)
    {
        if (component == null)
        {
            return false;
        }

        if (component == networkManager || component == networkFacade || component == gameNetworkClient)
        {
            return true;
        }

        return runtimeNode != null && component.transform.IsChildOf(runtimeNode);
    }

    private static void SetPrivateField(object target, string fieldName, object value)
    {
        if (target == null || string.IsNullOrWhiteSpace(fieldName))
        {
            return;
        }

        FieldInfo field = target.GetType().GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
        if (field == null)
        {
            return;
        }

        if (value == null && field.FieldType.IsValueType)
        {
            return;
        }

        if (value != null && !field.FieldType.IsAssignableFrom(value.GetType()))
        {
            return;
        }

        field.SetValue(target, value);
    }
}
