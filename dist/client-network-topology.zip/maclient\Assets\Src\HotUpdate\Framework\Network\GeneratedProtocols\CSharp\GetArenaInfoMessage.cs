﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取竞技场信息
/// </summary>
public class GetArenaInfo_c2s
{
}

/// <summary>
/// 竞技场信息响应
/// </summary>
public class GetArenaInfo_s2c
{
    /// <summary>
    /// 竞技场信息
    /// </summary>
    public ArenaInfo Arena { get; set; }
}

