﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取背包信息请求
/// </summary>
public class GetInventory_c2s
{
    /// <summary>
    /// 是否强制刷新
    /// </summary>
    public bool ForceRefresh { get; set; }
}

/// <summary>
/// 获取背包信息响应
/// </summary>
public class GetInventory_s2c
{
    /// <summary>
    /// 背包信息
    /// </summary>
    public InventoryInfo Inventory { get; set; }
}

