// 自动生成的协议文件

// 定义协议类


// 搜索玩家(用于加好友)
class SearchPlayer_c2s {
    constructor() {
        this.Keyword = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 搜索玩家结果
class SearchPlayer_s2c {
    constructor() {
        this.Players = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SearchPlayer_c2s,
    SearchPlayer_s2c,
};
