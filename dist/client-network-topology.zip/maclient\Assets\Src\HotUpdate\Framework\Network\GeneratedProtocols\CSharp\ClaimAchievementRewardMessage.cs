﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 领取成就奖励
/// </summary>
public class ClaimAchievementReward_c2s
{
    /// <summary>
    /// 成就 ID
    /// </summary>
    public int AchievementId { get; set; }
}

/// <summary>
/// 领取成就奖励结果
/// </summary>
public class ClaimAchievementReward_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 更新后的成就状态
    /// </summary>
    public AchievementInfo Achievement { get; set; }
    /// <summary>
    /// 奖励列表
    /// </summary>
    public RewardItem[] Rewards { get; set; }
}

