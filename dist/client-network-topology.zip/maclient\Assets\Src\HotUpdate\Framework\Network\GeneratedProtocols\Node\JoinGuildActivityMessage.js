// 自动生成的协议文件

// 定义协议类


// 加入公会活动
class JoinGuildActivity_c2s {
    constructor() {
        this.ActivityId = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 加入公会活动结果
class JoinGuildActivity_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    JoinGuildActivity_c2s,
    JoinGuildActivity_s2c,
};
