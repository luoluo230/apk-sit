using UnityEngine;

/// <summary>
/// 游戏网络网关（对外新命名）。
/// 作为业务访问入口，内部复用兼容层 GameNetworkClient，避免直接暴露旧命名。
/// </summary>
[AddComponentMenu("")]
[DisallowMultipleComponent]
[RequireComponent(typeof(GameNetworkClient))]
public sealed class GameNetworkGateway : MonoBehaviour
{
    [SerializeField] private GameNetworkClient client;

    /// <summary>
    /// 内部兼容客户端实例。
    /// </summary>
    public GameNetworkClient Client => client;

    /// <summary>
    /// 系统业务网络模块集合。
    /// </summary>
    public GameNetworkModules Modules => client != null ? client.Modules : null;

    /// <summary>
    /// 玩法同步模块集合。
    /// </summary>
    public GameplaySyncModules GameplaySync => client != null ? client.GameplaySync : null;

    /// <summary>
    /// 当前是否已准备完成。
    /// </summary>
    public bool IsReady => client != null && client.IsReady;

    /// <summary>
    /// 当前是否已连接。
    /// </summary>
    public bool IsConnected => client != null && client.IsConnected;

    private void Reset()
    {
        EnsureClient();
    }

    private void Awake()
    {
        EnsureClient();
    }

    private void OnValidate()
    {
        EnsureClient();
    }

    private void EnsureClient()
    {
        if (client == null)
        {
            client = GetComponent<GameNetworkClient>();
        }
    }
}

