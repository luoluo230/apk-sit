using System;
using System.IO;
using UnityEngine;

public static class ProtocolSkillDomainRegistry
{
    private static readonly string DomainRoot = Path.Combine(Application.dataPath, "Editor", "Protocol", "Skills", "Domains");

    public static ProtocolSkillBusinessDomain InferDomain(string protocolName, string module)
    {
        string value = ((protocolName ?? string.Empty) + " " + (module ?? string.Empty)).ToLowerInvariant();
        if (ContainsAny(value, "login", "auth", "token", "session")) return ProtocolSkillBusinessDomain.Login;
        if (ContainsAny(value, "profile", "player", "avatar")) return ProtocolSkillBusinessDomain.Profile;
        if (ContainsAny(value, "inventory", "item", "bag")) return ProtocolSkillBusinessDomain.Inventory;
        if (ContainsAny(value, "hero", "role", "character")) return ProtocolSkillBusinessDomain.Hero;
        if (ContainsAny(value, "battle", "combat", "fight")) return ProtocolSkillBusinessDomain.Battle;
        if (ContainsAny(value, "chat", "social", "friend")) return ProtocolSkillBusinessDomain.Social;
        if (ContainsAny(value, "guild", "club")) return ProtocolSkillBusinessDomain.Guild;
        if (ContainsAny(value, "mail")) return ProtocolSkillBusinessDomain.Mail;
        if (ContainsAny(value, "shop", "pay", "order", "store")) return ProtocolSkillBusinessDomain.Shop;
        if (ContainsAny(value, "activity", "event", "quest", "reward")) return ProtocolSkillBusinessDomain.Activity;
        return ProtocolSkillBusinessDomain.Common;
    }

    public static string GetPromptTemplatePath(ProtocolSkillBusinessDomain domain)
    {
        return Path.Combine(DomainRoot, domain.ToString().ToLowerInvariant() + ".domain.skill.md");
    }

    public static string LoadPromptTemplate(ProtocolSkillBusinessDomain domain)
    {
        string path = GetPromptTemplatePath(domain);
        return File.Exists(path) ? File.ReadAllText(path) : string.Empty;
    }

    private static bool ContainsAny(string value, params string[] keywords)
    {
        foreach (string keyword in keywords)
        {
            if (value.Contains(keyword)) return true;
        }

        return false;
    }
}
