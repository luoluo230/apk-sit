﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取挂机收益预览
/// </summary>
public class GetAfkRewardInfo_c2s
{
}

/// <summary>
/// 挂机收益信息响应
/// </summary>
public class GetAfkRewardInfo_s2c
{
    /// <summary>
    /// 挂机收益预览
    /// </summary>
    public AfkRewardInfo Afk { get; set; }
}

