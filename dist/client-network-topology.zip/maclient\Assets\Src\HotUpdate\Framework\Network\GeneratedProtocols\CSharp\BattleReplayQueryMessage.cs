﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 查询战斗回放元数据/下载定位
/// </summary>
public class BattleReplayQuery_c2s
{
    /// <summary>
    /// 回放 ID(可与BattleId二选一)
    /// </summary>
    public string ReplayId { get; set; }
    /// <summary>
    /// 战斗 ID(可选)
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 是否直接返回分片数据
    /// </summary>
    public bool NeedChunks { get; set; }
    /// <summary>
    /// 分片起始序号
    /// </summary>
    public int ChunkFrom { get; set; }
    /// <summary>
    /// 分片结束序号(0表示到末尾)
    /// </summary>
    public int ChunkTo { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 战斗回放查询响应
/// </summary>
public class BattleReplayQuery_s2c
{
    /// <summary>
    /// 处理结果
    /// </summary>
    public BattleProtocolAck Ack { get; set; }
    /// <summary>
    /// 回放元数据
    /// </summary>
    public BattleReplayMeta Meta { get; set; }
    /// <summary>
    /// 回放下载定位
    /// </summary>
    public BattleReplayLocator Locator { get; set; }
    /// <summary>
    /// 回放分片(按请求返回)
    /// </summary>
    public BattleReplayChunk[] Chunks { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

