// INetworkTransport.cs
using System;

/// <summary>
/// 网络传输最小抽象。
/// 业务层和上层网络框架只依赖该接口，以便在 TCP、WebSocket、KCP、HTTP 之间切换实现。
/// </summary>
public interface INetworkTransport
{
    /// <summary>
    /// 建立连接。
    /// </summary>
    void Connect(string url);

    /// <summary>
    /// 断开连接。
    /// </summary>
    void Disconnect();

    /// <summary>
    /// 发送原始字节数据。
    /// </summary>
    void Send(byte[] data);

    /// <summary>
    /// 当前是否已连接。
    /// </summary>
    bool IsConnected { get; }

    event Action OnConnected;
    event Action<string> OnDisconnected;
    event Action<string> OnError;
    event Action<byte[]> OnDataReceived;
}
