// 自动生成的协议文件

// 定义协议类


// 发送好友申请
class ApplyFriend_c2s {
    constructor() {
        this.TargetPlayerId = null;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 好友申请发送结果
class ApplyFriend_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Request = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ApplyFriend_c2s,
    ApplyFriend_s2c,
};
