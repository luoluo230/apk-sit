﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 发送聊天消息
/// </summary>
public class SendChatMessage_c2s
{
    /// <summary>
    /// 聊天频道
    /// </summary>
    public ChatChannel Channel { get; set; }
    /// <summary>
    /// 私聊对象 ID(非私聊填0)
    /// </summary>
    public long ToPlayerId { get; set; }
    /// <summary>
    /// 文本内容
    /// </summary>
    public string Content { get; set; }
}

/// <summary>
/// 发送聊天消息结果(本地回显)
/// </summary>
public class SendChatMessage_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 成功时返回的完整聊天消息
    /// </summary>
    public ChatMessage Chat { get; set; }
}

