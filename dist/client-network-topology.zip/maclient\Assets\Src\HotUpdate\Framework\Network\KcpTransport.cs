﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using UnityEngine;

/// <summary>
/// KCP 传输（UDP + 4 字节长度前缀），与服务端 KcpTransportServerModule 对齐。
/// </summary>
public class KcpTransport : MonoBehaviour, ITransportClient
{
    private UdpClient _udpClient;
    private IPEndPoint _remoteEndPoint;
    public bool IsConnected { get; private set; }

    public event Action OnConnected;
    public event Action<string> OnDisconnected;
    public event Action<string> OnError;
    public event Action<byte[]> OnDataReceived;

    public void Connect(string url)
    {
        try
        {
            Disconnect();

            Uri uri = new Uri(url);
            IPAddress[] addresses = Dns.GetHostAddresses(uri.Host);
            if (addresses == null || addresses.Length == 0)
            {
                throw new Exception($"Unable to resolve host: {uri.Host}");
            }

            _remoteEndPoint = new IPEndPoint(addresses[0], uri.Port);
            _udpClient = new UdpClient();
            _udpClient.Connect(_remoteEndPoint);
            IsConnected = true;
            OnConnected?.Invoke();
        }
        catch (Exception ex)
        {
            OnError?.Invoke($"KCP initialization failed: {ex.Message}");
            Disconnect();
        }
    }

    public void Disconnect()
    {
        bool wasConnected = IsConnected;
        IsConnected = false;
        try
        {
            _udpClient?.Close();
        }
        catch (Exception ex)
        {
            Logger.Log($"Close KCP transport failed: {ex.Message}", LogLevel.Warning);
        }
        finally
        {
            _udpClient = null;
            _remoteEndPoint = null;
        }

        if (wasConnected)
        {
            OnDisconnected?.Invoke("KCP transport disconnected.");
        }
    }

    public void Send(byte[] data)
    {
        if (!IsConnected || _udpClient == null)
        {
            OnError?.Invoke("KCP transport is not initialized.");
            return;
        }

        if (data == null || data.Length == 0)
        {
            return;
        }

        try
        {
            // data is already NetMessage.Serialize() output (4-byte length + body).
            _udpClient.Send(data, data.Length);
        }
        catch (Exception ex)
        {
            OnError?.Invoke($"KCP send error: {ex.Message}");
        }
    }

    private void Update()
    {
        if (!IsConnected || _udpClient == null)
        {
            return;
        }

        while (_udpClient.Available > 0)
        {
            try
            {
                byte[] datagram = _udpClient.Receive(ref _remoteEndPoint);
                if (datagram == null || datagram.Length == 0)
                {
                    continue;
                }

                OnDataReceived?.Invoke(datagram);
            }
            catch (Exception ex)
            {
                OnError?.Invoke($"KCP receive failed: {ex.Message}");
                break;
            }
        }
    }

    private void OnDestroy()
    {
        Disconnect();
    }
}
