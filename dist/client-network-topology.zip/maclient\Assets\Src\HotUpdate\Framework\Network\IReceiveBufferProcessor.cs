/// <summary>
/// 接收缓冲处理器接口。
/// 负责拼包、拆包、反序列化与过期分片清理。
/// </summary>
public interface IReceiveBufferProcessor
{
    /// <summary>
    /// 向接收缓冲追加一段原始数据。
    /// </summary>
    bool Append(byte[] data);

    /// <summary>
    /// 尝试从缓冲区中取出一条完整消息。
    /// </summary>
    bool TryDequeue(float currentTime, out NetMessage message, out string error);

    /// <summary>
    /// 清理过期分片。
    /// </summary>
    void CleanupExpiredChunks(float currentTime);

    /// <summary>
    /// 重置缓冲状态。
    /// </summary>
    void Reset();
}
