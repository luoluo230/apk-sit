// 自动生成的协议文件

// 定义协议类


// 好友上下线通知
class FriendOnlineStatusNotify_s2c {
    constructor() {
        this.Friend = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    FriendOnlineStatusNotify_s2c,
};
