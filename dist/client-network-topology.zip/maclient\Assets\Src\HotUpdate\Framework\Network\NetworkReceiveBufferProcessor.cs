﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public sealed class NetworkReceiveBufferProcessor : IReceiveBufferProcessor
{
    private readonly int _headerSize;
    private readonly int _maxPacketSize;
    private readonly int _maxReceiveBufferSize;
    private readonly float _chunkTimeout;
    private readonly ByteArrayPool _byteArrayPool;
    private readonly Dictionary<int, ChunkBuffer> _chunkBuffers = new Dictionary<int, ChunkBuffer>();

    private byte[] _receiveBuffer;
    private int _receiveReadIndex;
    private int _receiveWriteIndex;

    private sealed class ChunkBuffer
    {
        public string DataType;
        public int Total;
        public Dictionary<int, byte[]> Parts = new Dictionary<int, byte[]>();
        public float LastUpdateTime;
    }

    public NetworkReceiveBufferProcessor(int initialSize, int maxPacketSize, int maxReceiveBufferSize, float chunkTimeout, ByteArrayPool byteArrayPool, int headerSize = 4)
    {
        _headerSize = headerSize;
        _maxPacketSize = maxPacketSize;
        _maxReceiveBufferSize = maxReceiveBufferSize;
        _chunkTimeout = chunkTimeout;
        _byteArrayPool = byteArrayPool ?? ByteArrayPool.Shared;
        _receiveBuffer = new byte[Math.Max(headerSize * 2, initialSize)];
    }

    public bool Append(byte[] data)
    {
        if (data == null || data.Length == 0)
        {
            return true;
        }

        if (!EnsureCapacity(data.Length))
        {
            return false;
        }

        Buffer.BlockCopy(data, 0, _receiveBuffer, _receiveWriteIndex, data.Length);
        _receiveWriteIndex += data.Length;
        return true;
    }

    public bool TryDequeue(float currentTime, out NetMessage message, out string error)
    {
        message = null;
        error = null;

        while (true)
        {
            if (GetReadableBytes() < _headerSize)
            {
                return false;
            }

            var messageLength = ReadInt32BigEndian(_receiveBuffer, _receiveReadIndex);
            if (messageLength <= 0 || messageLength > _maxPacketSize)
            {
                error = $"Invalid packet size={messageLength}";
                Reset();
                return false;
            }

            if (GetReadableBytes() < _headerSize + messageLength)
            {
                return false;
            }

            var bodyOffset = _receiveReadIndex + _headerSize;
            var messageBody = _byteArrayPool.Rent(messageLength);
            Buffer.BlockCopy(_receiveBuffer, bodyOffset, messageBody, 0, messageLength);
            _receiveReadIndex += _headerSize + messageLength;

            try
            {
                message = NetMessage.Deserialize(messageBody, messageLength);
            }
            catch (Exception ex)
            {
                error = $"Failed to deserialize network message: {ex.Message}";
            }
            finally
            {
                _byteArrayPool.Return(messageBody);
            }

            if (error != null)
            {
                CompactOrReset();
                return true;
            }

            if (message != null && message.IsChunk)
            {
                message = HandleChunk(message, currentTime);
                if (message == null)
                {
                    CompactOrReset();
                    continue;
                }
            }

            CompactOrReset();
            return message != null;
        }
    }

    public void CleanupExpiredChunks(float currentTime)
    {
        if (_chunkBuffers.Count == 0)
        {
            return;
        }

        var expired = new List<int>();
        foreach (var pair in _chunkBuffers)
        {
            if (currentTime - pair.Value.LastUpdateTime > _chunkTimeout)
            {
                expired.Add(pair.Key);
            }
        }

        foreach (var chunkId in expired)
        {
            _chunkBuffers.Remove(chunkId);
        }
    }

    public void Reset()
    {
        _receiveReadIndex = 0;
        _receiveWriteIndex = 0;
        _chunkBuffers.Clear();
    }

    private bool EnsureCapacity(int incomingLength)
    {
        var available = _receiveBuffer.Length - _receiveWriteIndex;
        if (available >= incomingLength)
        {
            return true;
        }

        CompactBuffer();
        available = _receiveBuffer.Length - _receiveWriteIndex;
        if (available >= incomingLength)
        {
            return true;
        }

        var required = _receiveWriteIndex + incomingLength;
        var newSize = Math.Max(_receiveBuffer.Length * 2, required);
        if (newSize > _maxReceiveBufferSize)
        {
            Reset();
            return false;
        }

        var newBuffer = new byte[newSize];
        var dataLength = _receiveWriteIndex - _receiveReadIndex;
        if (dataLength > 0)
        {
            Buffer.BlockCopy(_receiveBuffer, _receiveReadIndex, newBuffer, 0, dataLength);
        }

        _receiveBuffer = newBuffer;
        _receiveReadIndex = 0;
        _receiveWriteIndex = dataLength;
        return true;
    }

    private NetMessage HandleChunk(NetMessage chunkMessage, float currentTime)
    {
        if (!_chunkBuffers.TryGetValue(chunkMessage.ChunkId, out var buffer))
        {
            buffer = new ChunkBuffer
            {
                DataType = chunkMessage.DataType,
                Total = chunkMessage.ChunkTotal,
                LastUpdateTime = currentTime
            };
            _chunkBuffers[chunkMessage.ChunkId] = buffer;
        }

        if (!buffer.Parts.ContainsKey(chunkMessage.ChunkIndex))
        {
            var base64 = chunkMessage.Data?.ToString();
            if (string.IsNullOrEmpty(base64))
            {
                return null;
            }

            buffer.Parts[chunkMessage.ChunkIndex] = Convert.FromBase64String(base64);
            buffer.LastUpdateTime = currentTime;
        }

        if (buffer.Parts.Count < buffer.Total)
        {
            return null;
        }

        var totalLength = buffer.Parts.OrderBy(pair => pair.Key).Sum(pair => pair.Value.Length);
        var merged = new byte[totalLength];
        var offset = 0;
        for (var index = 0; index < buffer.Total; index++)
        {
            var part = buffer.Parts[index];
            Buffer.BlockCopy(part, 0, merged, offset, part.Length);
            offset += part.Length;
        }

        _chunkBuffers.Remove(chunkMessage.ChunkId);

        return new NetMessage
        {
            MessageID = chunkMessage.MessageID,
            DataType = buffer.DataType,
            Data = Encoding.UTF8.GetString(merged),
            SequenceId = chunkMessage.SequenceId,
            RequiresAck = chunkMessage.RequiresAck,
            Priority = chunkMessage.Priority
        };
    }

    private void CompactOrReset()
    {
        if (_receiveReadIndex <= 0)
        {
            return;
        }

        if (_receiveReadIndex == _receiveWriteIndex)
        {
            _receiveReadIndex = 0;
            _receiveWriteIndex = 0;
            return;
        }

        if (_receiveReadIndex > _receiveBuffer.Length / 2)
        {
            CompactBuffer();
        }
    }

    private void CompactBuffer()
    {
        if (_receiveReadIndex == 0)
        {
            return;
        }

        var dataLength = _receiveWriteIndex - _receiveReadIndex;
        if (dataLength > 0)
        {
            Buffer.BlockCopy(_receiveBuffer, _receiveReadIndex, _receiveBuffer, 0, dataLength);
        }

        _receiveReadIndex = 0;
        _receiveWriteIndex = dataLength;
    }

    private int GetReadableBytes()
    {
        return _receiveWriteIndex - _receiveReadIndex;
    }

    private static int ReadInt32BigEndian(byte[] buffer, int offset)
    {
        if (BitConverter.IsLittleEndian)
        {
            return (buffer[offset] << 24) |
                   (buffer[offset + 1] << 16) |
                   (buffer[offset + 2] << 8) |
                   buffer[offset + 3];
        }

        return BitConverter.ToInt32(buffer, offset);
    }
}
