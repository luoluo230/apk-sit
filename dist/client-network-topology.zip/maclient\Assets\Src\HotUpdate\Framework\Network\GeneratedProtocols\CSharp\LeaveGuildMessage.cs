﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 退出公会
/// </summary>
public class LeaveGuild_c2s
{
}

/// <summary>
/// 退出公会结果
/// </summary>
public class LeaveGuild_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

