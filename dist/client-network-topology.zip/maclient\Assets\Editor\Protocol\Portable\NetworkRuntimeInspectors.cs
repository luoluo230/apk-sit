﻿using UnityEditor;
using UnityEngine;

/// <summary>
/// NetworkManager 精简检查器。
/// 默认不暴露底层参数，统一引导到“协议与网络”工作台配置。
/// </summary>
[CustomEditor(typeof(NetworkManager))]
public sealed class NetworkManagerInspector : Editor
{
    public override void OnInspectorGUI()
    {
        var manager = (NetworkManager)target;

        EditorGUILayout.HelpBox(
            "底层参数已收口，请在：Tools/MAClient/协议与网络/协议与代码生成工作台 -> 网络配置 中统一配置。",
            MessageType.Info);

        using (new EditorGUI.DisabledScope(true))
        {
            EditorGUILayout.Toggle("当前是否连接", manager != null && manager.IsConnected);
            EditorGUILayout.TextField("当前传输协议", manager != null ? manager.CurrentTransportType.ToString() : "N/A");
            EditorGUILayout.TextField("当前服务地址", manager != null ? manager.CurrentServerUri : "N/A");
        }

        EditorGUILayout.Space(8f);
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("打开协议与网络工作台", GUILayout.Height(24f)))
        {
            EditorApplication.ExecuteMenuItem("Tools/MAClient/协议与网络/协议与代码生成工作台");
        }

        if (GUILayout.Button("创建网络模块运行时引导", GUILayout.Height(24f)))
        {
            EditorApplication.ExecuteMenuItem("Tools/MAClient/协议与网络/创建网络模块运行时引导");
        }
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space(6f);
        EditorGUILayout.HelpBox("如需排查底层参数，请使用调试分支或专用调试检查器，不在业务分支直接暴露。", MessageType.None);
    }
}

/// <summary>
/// NetworkFacade 精简检查器。
/// 仅保留桥接相关字段，避免与工作台形成双入口配置。
/// </summary>
[CustomEditor(typeof(NetworkFacade))]
public sealed class NetworkFacadeInspector : Editor
{
    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        EditorGUILayout.HelpBox(
            "NetworkFacade 负责把协议工作台配置桥接到运行时。业务请优先通过工作台维护网络参数。",
            MessageType.Info);

        DrawProperty("networkManager", "Network Manager");
        DrawProperty("autoFindNetworkManager", "自动查找 NetworkManager");
        DrawProperty("autoCreateNetworkManager", "自动创建 NetworkManager");
        DrawProperty("dontDestroyOnLoad", "跨场景保留");

        EditorGUILayout.Space(4f);
        DrawProperty("protocolNetworkSettings", "协议网络配置资产");
        DrawProperty("loadProtocolNetworkSettingsFromResources", "启动时从 Resources 自动加载");
        DrawProperty("autoConnect", "启动自动连接");

        EditorGUILayout.Space(8f);
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("打开协议与网络工作台", GUILayout.Height(24f)))
        {
            EditorApplication.ExecuteMenuItem("Tools/MAClient/协议与网络/协议与代码生成工作台");
        }

        if (GUILayout.Button("应用当前协议配置", GUILayout.Height(24f)))
        {
            foreach (Object obj in targets)
            {
                var facade = obj as NetworkFacade;
                if (facade == null)
                {
                    continue;
                }

                SerializedObject so = new SerializedObject(facade);
                var settingsProp = so.FindProperty("protocolNetworkSettings");
                var settings = settingsProp != null ? settingsProp.objectReferenceValue as ProtocolNetworkSettings : null;
                facade.ConfigureFromProtocolNetworkSettings(settings, false);
                EditorUtility.SetDirty(facade);
            }
        }
        EditorGUILayout.EndHorizontal();

        serializedObject.ApplyModifiedProperties();
    }

    private void DrawProperty(string propertyName, string label)
    {
        SerializedProperty property = serializedObject.FindProperty(propertyName);
        if (property == null)
        {
            return;
        }

        EditorGUILayout.PropertyField(property, new GUIContent(label), true);
    }
}
