﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 处理公会申请(会长/官员)
/// </summary>
public class HandleGuildApply_c2s
{
    /// <summary>
    /// 申请 ID
    /// </summary>
    public long ApplyId { get; set; }
    /// <summary>
    /// 是否同意
    /// </summary>
    public bool Accept { get; set; }
}

/// <summary>
/// 处理公会申请结果
/// </summary>
public class HandleGuildApply_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

