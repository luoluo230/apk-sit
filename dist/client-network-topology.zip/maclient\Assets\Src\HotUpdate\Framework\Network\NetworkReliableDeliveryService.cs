using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 可靠投递服务默认实现。
///
/// 负责：
/// - 记录已发送可靠消息
/// - 处理 ACK
/// - 维护待发送 ACK 队列
/// - 在超时后安排重传
/// - 在超过最大重试次数后丢弃消息
///
/// 这个类不直接发送网络包，它只维护“可靠投递状态机”，真正发包仍由 NetworkManager 承担。
/// </summary>
public sealed class NetworkReliableDeliveryService : IReliableDeliveryService
{
    /// <summary>
    /// 单条可靠消息在本地的运行态。
    /// </summary>
    private sealed class ReliableState
    {
        /// <summary>当前已重试次数。</summary>
        public int RetryCount;
        /// <summary>上次发送时间，用于超时判断。</summary>
        public float LastSendTime;
        /// <summary>当前是否已经重新排入发送队列，避免重复排队。</summary>
        public bool InQueue;
    }

    private readonly Dictionary<int, ReliableState> _states = new Dictionary<int, ReliableState>();
    private readonly List<int> _pendingAckIds = new List<int>();

    public int PendingCount => _states.Count;
    public int PendingAckCount => _pendingAckIds.Count;

    /// <summary>记录某条可靠消息刚刚被成功发出。</summary>
    public void TrackSent(int sequenceId, float sentTime)
    {
        if (sequenceId <= 0)
        {
            return;
        }

        var state = GetOrCreate(sequenceId);
        state.LastSendTime = sentTime;
        state.InQueue = false;
    }

    /// <summary>更新某条可靠消息是否已经进入待发送队列。</summary>
    public void MarkQueued(int sequenceId, bool inQueue)
    {
        if (sequenceId <= 0)
        {
            return;
        }

        var state = GetOrCreate(sequenceId);
        state.InQueue = inQueue;
    }

    /// <summary>处理 ACK；如果成功命中，说明该可靠消息已经完成投递闭环。</summary>
    public bool HandleAck(int ackSequenceId)
    {
        if (ackSequenceId <= 0)
        {
            return false;
        }

        return _states.Remove(ackSequenceId);
    }

    /// <summary>把收到的 sequenceId 放入待回发 ACK 队列。</summary>
    public void QueueAck(int sequenceId)
    {
        if (sequenceId > 0)
        {
            _pendingAckIds.Add(sequenceId);
        }
    }

    /// <summary>
    /// 批量刷出待发送 ACK。
    ///
    /// 之所以做批量，是为了避免每收到一条可靠包就立即单独回 ACK，减少小包放大。
    /// </summary>
    public void FlushAckQueue(int maxAckPerFlush, Action<int> enqueueAck)
    {
        if (_pendingAckIds.Count == 0 || maxAckPerFlush <= 0)
        {
            return;
        }

        int count = Mathf.Min(_pendingAckIds.Count, maxAckPerFlush);
        for (int i = 0; i < count; i++)
        {
            enqueueAck?.Invoke(_pendingAckIds[i]);
        }

        _pendingAckIds.RemoveRange(0, count);
    }

    /// <summary>
    /// 扫描超时可靠消息，决定“安排重传”还是“彻底丢弃”。
    /// </summary>
    public void CollectRetries(
        float currentTime,
        float reliableTimeout,
        int reliableMaxRetry,
        float resendJitter,
        Action<int, float> onRetryScheduled,
        Action<int> onDropped)
    {
        if (_states.Count == 0)
        {
            return;
        }

        var dropList = new List<int>();
        foreach (var pair in _states)
        {
            var state = pair.Value;
            if (state.InQueue)
            {
                continue;
            }

            if (currentTime - state.LastSendTime < reliableTimeout)
            {
                continue;
            }

            if (state.RetryCount >= reliableMaxRetry)
            {
                dropList.Add(pair.Key);
                continue;
            }

            state.RetryCount++;
            state.InQueue = true;
            float nextSendTime = currentTime + UnityEngine.Random.Range(0f, resendJitter);
            onRetryScheduled?.Invoke(pair.Key, nextSendTime);
        }

        foreach (int sequenceId in dropList)
        {
            _states.Remove(sequenceId);
            onDropped?.Invoke(sequenceId);
        }
    }

    /// <summary>
    /// 重连后把所有尚未完成确认的可靠消息重新入队。
    /// </summary>
    public void RequeueAllAfterReconnect(float currentTime, Action<int, float> onRetryScheduled)
    {
        foreach (var pair in _states)
        {
            if (pair.Value.InQueue)
            {
                continue;
            }

            pair.Value.InQueue = true;
            onRetryScheduled?.Invoke(pair.Key, currentTime);
        }
    }

    /// <summary>清空可靠投递状态。</summary>
    public void Clear()
    {
        _states.Clear();
        _pendingAckIds.Clear();
    }

    /// <summary>获取或创建某条可靠消息的状态对象。</summary>
    private ReliableState GetOrCreate(int sequenceId)
    {
        if (_states.TryGetValue(sequenceId, out var state))
        {
            return state;
        }

        state = new ReliableState();
        _states[sequenceId] = state;
        return state;
    }
}
