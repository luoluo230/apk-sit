using System;

/// <summary>
/// 可靠投递服务接口。
/// 负责 ACK 管理、超时重发和重连后的待确认消息恢复。
/// </summary>
public interface IReliableDeliveryService
{
    int PendingCount { get; }
    int PendingAckCount { get; }

    /// <summary>
    /// 记录一条已发送的可靠消息。
    /// </summary>
    void TrackSent(int sequenceId, float sentTime);

    /// <summary>
    /// 标记一条消息是否已经进入发送队列。
    /// </summary>
    void MarkQueued(int sequenceId, bool inQueue);

    /// <summary>
    /// 处理服务端 ACK。
    /// </summary>
    bool HandleAck(int ackSequenceId);

    /// <summary>
    /// 将某条 ACK 放入待发送队列。
    /// </summary>
    void QueueAck(int sequenceId);

    /// <summary>
    /// 批量刷新 ACK 队列。
    /// </summary>
    void FlushAckQueue(int maxAckPerFlush, Action<int> enqueueAck);

    /// <summary>
    /// 收集需要重发或丢弃的可靠消息。
    /// </summary>
    void CollectRetries(
        float currentTime,
        float reliableTimeout,
        int reliableMaxRetry,
        float resendJitter,
        Action<int, float> onRetryScheduled,
        Action<int> onDropped);

    /// <summary>
    /// 连接恢复后重排所有待确认消息。
    /// </summary>
    void RequeueAllAfterReconnect(float currentTime, Action<int, float> onRetryScheduled);

    /// <summary>
    /// 清空内部状态。
    /// </summary>
    void Clear();
}
