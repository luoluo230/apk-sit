using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// 默认网络错误展示组件。
/// 既可以直接打日志，也可以通过 UnityEvent 挂接 UI 弹窗或 Toast。
/// </summary>
public class NetworkErrorPresenter : MonoBehaviour, INetworkErrorPresenter
{
    [System.Serializable]
    public class ErrorEvent : UnityEvent<int, string> { }

    [SerializeField] private bool logToConsole = true;
    [SerializeField] private ErrorEvent onShowError = new ErrorEvent();

    /// <summary>
    /// 展示网络错误。
    /// </summary>
    public void ShowError(int code, string message)
    {
        if (logToConsole)
        {
            Logger.Log($"[NetworkError] Code={code} Message={message}", LogLevel.Warning);
        }

        onShowError?.Invoke(code, message);
    }
}
