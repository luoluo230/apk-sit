// 自动生成的协议文件

// 定义协议类


// 创建角色请求
class CreateRole_c2s {
    constructor() {
        this.ServerId = '';
        this.Nickname = '';
        this.Avatar = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 创建角色响应
class CreateRole_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Profile = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    CreateRole_c2s,
    CreateRole_s2c,
};
