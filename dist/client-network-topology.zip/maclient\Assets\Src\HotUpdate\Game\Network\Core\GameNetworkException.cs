using System;

public sealed class GameNetworkException : Exception
{
    public string ErrorCode { get; }

    public GameNetworkException(string errorCode, string message) : base(message)
    {
        ErrorCode = string.IsNullOrWhiteSpace(errorCode) ? GameNetworkErrorCodes.Unknown : errorCode;
    }
}

