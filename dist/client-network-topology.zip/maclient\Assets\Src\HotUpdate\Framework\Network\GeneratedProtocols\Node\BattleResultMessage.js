// 自动生成的协议文件

// 定义协议类


// 客户端上报或拉取战斗结算(结果/统计可选)
class BattleResult_c2s {
    constructor() {
        this.BattleId = '';
        this.Result = null;
        this.ElapsedFrames = 0;
        this.Statistic = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 战斗结算结果(权威统计与奖励)
class BattleResult_s2c {
    constructor() {
        this.BattleId = '';
        this.Result = null;
        this.DurationFrames = 0;
        this.Rewards = [];
        this.Statistic = null;
        this.Highlights = [];
        this.Anchor = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    BattleResult_c2s,
    BattleResult_s2c,
};
