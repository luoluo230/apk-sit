﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 观战帧增量推送
/// </summary>
public class BattleSpectatorFrameNotify_s2c
{
    /// <summary>
    /// 观战会话 ID
    /// </summary>
    public string SessionId { get; set; }
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 当前帧
    /// </summary>
    public int Frame { get; set; }
    /// <summary>
    /// 增量帧数据
    /// </summary>
    public BattleFrameBundle[] Frames { get; set; }
    /// <summary>
    /// 最新锚点
    /// </summary>
    public BattleTimelineAnchor Anchor { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

