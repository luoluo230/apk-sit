﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 红点变化推送
/// </summary>
public class NotifyRedPoint_s2c
{
    /// <summary>
    /// 红点列表
    /// </summary>
    public RedPointInfo[] RedPoints { get; set; }
}

