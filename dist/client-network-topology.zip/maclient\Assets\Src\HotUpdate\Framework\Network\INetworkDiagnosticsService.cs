/// <summary>
/// 网络诊断服务接口。
/// 统一记录收发流量、错误与关键运行日志。
/// </summary>
public interface INetworkDiagnosticsService
{
    /// <summary>
    /// 记录一次网络消息收发。
    /// </summary>
    void LogTraffic(string direction, NetMessage message);

    /// <summary>
    /// 记录一条网络日志。
    /// </summary>
    void Log(string message, LogLevel level = LogLevel.Info);
}
