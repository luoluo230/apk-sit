# Mock And Test Skill

## 职责

生成协议 mock 数据、smoke test helper 和测试用例建议，覆盖客户端与服务端主链路。

## 必须生成

- 合法 request mock。
- 合法 response mock。
- 边界值 mock。
- 异常值 mock。
- 客户端 smoke test helper。
- 服务端 handler/service/repository 测试建议。

## 测试覆盖

- 成功。
- required 缺失。
- 类型/范围错误。
- 网络失败或超时。
- 协议错误码。
- 权限失败。
- 幂等重复提交。

## 质量门禁

- 不依赖外部测试框架时也能作为普通 helper 编译。
- 有真实测试框架时给出迁移到 NUnit/EditMode/服务端测试框架的说明。
