﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 拉取聊天历史
/// </summary>
public class GetChatHistory_c2s
{
    /// <summary>
    /// 频道
    /// </summary>
    public ChatChannel Channel { get; set; }
    /// <summary>
    /// 当拉取私聊历史时的对方 ID
    /// </summary>
    public long ToPlayerId { get; set; }
    /// <summary>
    /// 起始消息 ID(可选)
    /// </summary>
    public long FromMessageId { get; set; }
    /// <summary>
    /// 最大条数
    /// </summary>
    public int Limit { get; set; }
}

/// <summary>
/// 聊天历史响应
/// </summary>
public class GetChatHistory_s2c
{
    /// <summary>
    /// 频道
    /// </summary>
    public ChatChannel Channel { get; set; }
    /// <summary>
    /// 聊天记录
    /// </summary>
    public ChatMessage[] Chats { get; set; }
}

