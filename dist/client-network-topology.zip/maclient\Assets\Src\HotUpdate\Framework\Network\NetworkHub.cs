using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 多通道网络管理入口。
/// 用于在一个场景对象上集中管理登录、游戏、战斗等多个 NetworkManager 实例。
/// </summary>
public class NetworkHub : MonoBehaviour
{
    [Serializable]
    public class ChannelConfig
    {
        public string name;
        public NetworkManager.TransportType transport = NetworkManager.TransportType.WebSocket;
        public string serverUri;
        public bool autoConnect = true;
    }

    [Header("Channels")]
    [SerializeField] private List<ChannelConfig> channels = new List<ChannelConfig>();

    [Header("Error Presenter")]
    [SerializeField] private MonoBehaviour errorPresenter;

    private readonly Dictionary<string, NetworkManager> _channelMap = new Dictionary<string, NetworkManager>();
    private INetworkErrorPresenter _presenter;

    private void Awake()
    {
        _presenter = errorPresenter as INetworkErrorPresenter;
        if (_presenter == null)
        {
            _presenter = GetComponent<INetworkErrorPresenter>();
        }

        foreach (var config in channels)
        {
            if (config == null || string.IsNullOrWhiteSpace(config.name))
            {
                continue;
            }

            RegisterChannel(config.name, config.transport, config.serverUri, config.autoConnect);
        }
    }

    /// <summary>
    /// 注册一个逻辑网络通道。
    /// </summary>
    public NetworkManager RegisterChannel(string name, NetworkManager.TransportType transport, string serverUri, bool autoConnect)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            Logger.Log("RegisterChannel failed: channel name is empty.", LogLevel.Error);
            return null;
        }

        if (_channelMap.TryGetValue(name, out var existing))
        {
            ConfigureChannel(existing, name, transport, serverUri, autoConnect);
            return existing;
        }

        GameObject go = new GameObject($"NetChannel_{name}");
        go.transform.SetParent(transform, false);
        var manager = go.AddComponent<NetworkManager>();
        ConfigureChannel(manager, name, transport, serverUri, autoConnect);
        _channelMap[name] = manager;
        BindErrorEvents(name, manager);
        return manager;
    }

    /// <summary>
    /// 获取指定通道对应的 NetworkManager。
    /// </summary>
    public NetworkManager GetChannel(string name)
    {
        _channelMap.TryGetValue(name, out var manager);
        return manager;
    }

    /// <summary>
    /// 向指定通道发送请求。
    /// </summary>
    public void Send<T>(string channelName, object request, Action<T> onResponse, bool reliable = true, int priority = 1) where T : class
    {
        var manager = GetChannel(channelName);
        if (manager == null)
        {
            ReportError(NetworkErrorCode.ConnectionFailed, $"Channel was not registered: {channelName}");
            return;
        }

        if (!manager.IsConnected)
        {
            manager.Connect();
        }

        manager.SendMessage<T>(request, onResponse, reliable, priority);
    }

    /// <summary>
    /// 对外统一报告网络错误。
    /// </summary>
    public void ReportError(int code, string message)
    {
        if (_presenter != null)
        {
            _presenter.ShowError(code, message);
        }
        else
        {
            Logger.Log($"[NetworkError] Code={code} Message={message}", LogLevel.Warning);
        }
    }

    private void ConfigureChannel(NetworkManager manager, string name, NetworkManager.TransportType transport, string serverUri, bool autoConnect)
    {
        manager.transportType = transport;
        if (!string.IsNullOrWhiteSpace(serverUri))
        {
            manager.serverUri = serverUri;
        }

        manager.autoConnect = false;

        if (autoConnect)
        {
            manager.Connect();
        }
    }

    private void BindErrorEvents(string channelName, NetworkManager manager)
    {
        manager.OnConnectionFailed += () => ReportError(NetworkErrorCode.ConnectionFailed, $"{channelName}: connection failed");
        manager.OnDisconnected += () => ReportError(NetworkErrorCode.Disconnected, $"{channelName}: disconnected");
        manager.OnReconnectFailed += () => ReportError(NetworkErrorCode.ReconnectFailed, $"{channelName}: reconnect failed");
        manager.OnHeartbeatTimeout += () => ReportError(NetworkErrorCode.HeartbeatTimeout, $"{channelName}: heartbeat timeout");
        manager.OnSendQueueOverflowDropped += (messageId, priority) =>
            ReportError(NetworkErrorCode.SendQueueOverflow, $"{channelName}: send queue overflow. messageId={messageId}, priority={priority}");
        manager.OnServerError += (code, message, messageId) =>
            ReportError(code, $"{channelName}: {message} (messageId={messageId})");
        manager.OnRequestFailed += (responseMessageId, reason) =>
        {
            int code = reason != null && reason.Contains("timeout", StringComparison.OrdinalIgnoreCase)
                ? NetworkErrorCode.RequestTimeout
                : NetworkErrorCode.RequestFailed;
            ReportError(code, $"{channelName}: {reason} (responseId={responseMessageId})");
        };
    }
}
