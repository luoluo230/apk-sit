// 自动生成的协议文件

// 定义协议类


// 公会成员列表变化通知(入会/离会/职位变化)
class GuildMemberUpdateNotify_s2c {
    constructor() {
        this.Members = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GuildMemberUpdateNotify_s2c,
};
