﻿using System;
using System.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 认证与会话模块接口。
/// 负责登录、选服、创角、心跳、登出等账号生命周期能力。
/// </summary>
public interface IAuthNetworkModule
{
    /// <summary>
    /// 账号登录。
    /// </summary>
    /// <param name="username">账号名。</param>
    /// <param name="password">密码。</param>
    /// <param name="device">设备信息；为空时自动构建默认设备信息。</param>
    /// <returns>登录响应。</returns>
    Task<Login_s2c> LoginAsync(string username, string password, DeviceInfo device = null);

    /// <summary>
    /// 选择服务器（滚服模式）。
    /// </summary>
    /// <param name="serverId">目标服务器ID。</param>
    /// <returns>选服响应。</returns>
    Task<SelectServer_s2c> SelectServerAsync(string serverId);

    /// <summary>
    /// 注册角色（创角）。
    /// </summary>
    /// <param name="nickname">角色昵称。</param>
    /// <param name="avatar">头像或职业标识。</param>
    /// <param name="serverId">目标服务器ID；为空时使用当前已选服务器。</param>
    /// <returns>创角响应。</returns>
    Task<CreateRole_s2c> RegisterRoleAsync(string nickname, string avatar = "default", string serverId = null);

    /// <summary>
    /// 发送心跳包。
    /// </summary>
    /// <param name="includeProfile">是否在响应中附带角色档案。</param>
    /// <returns>心跳响应。</returns>
    Task<Heartbeat_s2c> PingAsync(bool includeProfile = false);

    /// <summary>
    /// 登出当前会话。
    /// </summary>
    /// <param name="disconnect">是否主动断开连接。</param>
    /// <param name="clearToken">是否清理本地Token。</param>
    void Logout(bool disconnect = true, bool clearToken = true);
}

/// <summary>
/// 匹配与进战斗模块接口。
/// </summary>
public interface IMatchNetworkModule
{
    /// <summary>
    /// 发起匹配（支持1v1/NvN，具体通过业务字段约定承载）。
    /// </summary>
    /// <param name="dungeonId">玩法或副本ID。</param>
    /// <param name="modeOrDifficulty">匹配模式或难度文本。</param>
    /// <param name="formation">出战编队。</param>
    /// <returns>匹配响应。</returns>
    Task<DungeonMatch_s2c> MatchAsync(int dungeonId, string modeOrDifficulty, FormationSlot[] formation = null);

    /// <summary>
    /// 进入战斗。
    /// </summary>
    /// <param name="stageId">关卡或战斗实例ID。</param>
    /// <param name="battleMode">战斗模式文本，如PVP/PVE。</param>
    /// <param name="syncMode">同步模式。</param>
    /// <param name="formation">出战编队。</param>
    /// <param name="customJson">业务透传JSON。</param>
    /// <returns>进战斗响应。</returns>
    Task<EnterBattle_s2c> EnterBattleAsync(
        string stageId,
        string battleMode = "PVP",
        BattleSyncMode syncMode = BattleSyncMode.ServerAuthoritative,
        FormationSlot[] formation = null,
        string customJson = null);
}

/// <summary>
/// 组队模块接口。
/// </summary>
public interface ITeamNetworkModule
{
    Task<CreateTeam_s2c> CreateTeamAsync();
    Task<InviteToTeam_s2c> InviteToTeamAsync(long targetPlayerId);
    Task<RespondTeamInvite_s2c> RespondTeamInviteAsync(string inviteId, bool accept);
    Task<LeaveTeam_s2c> LeaveTeamAsync();
    Task<KickTeamMember_s2c> KickTeamMemberAsync(long targetPlayerId);
}

/// <summary>
/// 世界模块接口（大厅、公告、活动、排行榜）。
/// </summary>
public interface IWorldNetworkModule
{
    Task<NoticeMessage[]> GetAnnouncementsAsync();
    Task<GetLobbyInfo_s2c> GetLobbyInfoAsync();
    Task<GetEvents_s2c> GetEventsAsync();
    Task<GetLeaderboard_s2c> GetLeaderboardAsync(string boardType, int pageIndex = 1, int pageSize = 20);
}

/// <summary>
/// 社交模块接口（好友、聊天）。
/// </summary>
public interface ISocialNetworkModule
{
    Task<GetFriendList_s2c> GetFriendListAsync();
    Task<GetChatHistory_s2c> GetChatHistoryAsync(ChatChannel channel, long toPlayerId = 0, long fromMessageId = 0, int limit = 50);
    Task<SendChatMessage_s2c> SendChatMessageAsync(ChatChannel channel, string content, long toPlayerId = 0);
    Task<ApplyFriend_s2c> ApplyFriendAsync(long targetPlayerId, string message = null);
    Task<HandleFriendRequest_s2c> HandleFriendRequestAsync(long requestId, bool accept);
    IDisposable ObserveFriendRequestNotify(Action<FriendRequestNotify_s2c> handler);
    IDisposable ObserveFriendOnlineStatus(Action<FriendOnlineStatusNotify_s2c> handler);
}

/// <summary>
/// 邮件模块接口。
/// </summary>
public interface IMailNetworkModule
{
    Task<GetMailList_s2c> GetMailListAsync();
    Task<ReadMail_s2c> ReadMailAsync(long mailId);
    Task<ClaimMailAttachment_s2c> ClaimMailAttachmentAsync(long mailId);
    Task<DeleteMail_s2c> DeleteMailAsync(long mailId);
    IDisposable ObserveNewMail(Action<NewMailNotify_s2c> handler);
}

/// <summary>
/// 成长与经济模块接口（背包、商店、任务、成就）。
/// </summary>
public interface IProgressionNetworkModule
{
    Task<GetInventory_s2c> GetInventoryAsync(bool forceRefresh = false);
    Task<GetShopInfo_s2c> GetShopInfoAsync(ShopType shopType);
    Task<BuyShopItem_s2c> BuyShopItemAsync(ShopType shopType, int slotIndex, int buyCount = 1);
    Task<GetTaskList_s2c> GetTaskListAsync(TaskType taskType = TaskType.Daily);
    Task<ClaimTaskReward_s2c> ClaimTaskRewardAsync(int taskId);
    Task<GetAchievementList_s2c> GetAchievementListAsync();
    Task<ClaimAchievementReward_s2c> ClaimAchievementRewardAsync(int achievementId);
}

/// <summary>
/// 统一业务网络模块容器。
/// 业务层按功能域调用，不需要关心传输层细节。
/// </summary>
public sealed class GameNetworkModules
{
    /// <summary>认证模块。</summary>
    public IAuthNetworkModule Auth { get; }

    /// <summary>匹配与战斗入口模块。</summary>
    public IMatchNetworkModule Match { get; }

    /// <summary>组队模块。</summary>
    public ITeamNetworkModule Team { get; }

    /// <summary>世界模块（大厅、公告、活动、排行）。</summary>
    public IWorldNetworkModule World { get; }

    /// <summary>社交模块（好友、聊天）。</summary>
    public ISocialNetworkModule Social { get; }

    /// <summary>邮件模块。</summary>
    public IMailNetworkModule Mail { get; }

    /// <summary>成长模块（背包、商店、任务、成就）。</summary>
    public IProgressionNetworkModule Progression { get; }

    /// <summary>
    /// 构造模块容器。
    /// </summary>
    /// <param name="requester">统一请求器。</param>
    /// <param name="serverIdGetter">当前服务器ID读取函数。</param>
    /// <param name="logoutAction">登出动作委托。</param>
    public GameNetworkModules(IGameNetworkRequester requester, Func<string> serverIdGetter, Action<bool, bool> logoutAction)
    {
        Auth = new AuthNetworkModule(requester, serverIdGetter, logoutAction);
        Match = new MatchNetworkModule(requester);
        Team = new TeamNetworkModule(requester);
        World = new WorldNetworkModule(requester);
        Social = new SocialNetworkModule(requester);
        Mail = new MailNetworkModule(requester);
        Progression = new ProgressionNetworkModule(requester);
    }

    /// <summary>
    /// 认证模块实现。
    /// </summary>
    private sealed class AuthNetworkModule : IAuthNetworkModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        /// <summary>当前服务器ID读取器。</summary>
        private readonly Func<string> _serverIdGetter;

        /// <summary>登出执行委托。</summary>
        private readonly Action<bool, bool> _logoutAction;

        public AuthNetworkModule(IGameNetworkRequester requester, Func<string> serverIdGetter, Action<bool, bool> logoutAction)
        {
            _requester = requester;
            _serverIdGetter = serverIdGetter;
            _logoutAction = logoutAction;
        }

        public async Task<Login_s2c> LoginAsync(string username, string password, DeviceInfo device = null)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "Username or password is empty.");
            }

            var response = await _requester.RequestAsync<Login_s2c>(
                new Login_c2s { Username = username, Password = password, Device = device ?? BuildDefaultDeviceInfo() },
                NetworkChannel.Login,
                requireToken: false);

            // Keep session token behavior consistent with GameNetworkClient.LoginAsync.
            if (!string.IsNullOrWhiteSpace(response?.Token?.Token))
            {
                NetMessage.CacheToken(response.Token.Token, response.Token.ExpireAt);
            }

            return response;
        }

        public Task<SelectServer_s2c> SelectServerAsync(string serverId)
        {
            if (string.IsNullOrWhiteSpace(serverId))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "ServerId is empty.");
            }

            return _requester.RequestAsync<SelectServer_s2c>(
                new SelectServer_c2s { ServerId = serverId },
                NetworkChannel.Login,
                requireToken: true);
        }

        public Task<CreateRole_s2c> RegisterRoleAsync(string nickname, string avatar = "default", string serverId = null)
        {
            var sid = string.IsNullOrWhiteSpace(serverId) ? _serverIdGetter?.Invoke() : serverId;
            if (string.IsNullOrWhiteSpace(sid))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "No selected server.");
            }

            if (string.IsNullOrWhiteSpace(nickname))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "Nickname is empty.");
            }

            return _requester.RequestAsync<CreateRole_s2c>(
                new CreateRole_c2s
                {
                    ServerId = sid,
                    Nickname = nickname,
                    Avatar = string.IsNullOrWhiteSpace(avatar) ? "default" : avatar
                },
                NetworkChannel.Login,
                requireToken: true);
        }

        public Task<Heartbeat_s2c> PingAsync(bool includeProfile = false)
        {
            return _requester.RequestAsync<Heartbeat_s2c>(
                new Heartbeat_c2s { IncludeProfile = includeProfile, ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() },
                NetworkChannel.Login,
                requireToken: true,
                reliable: false,
                priority: 1);
        }

        public void Logout(bool disconnect = true, bool clearToken = true)
        {
            _logoutAction?.Invoke(disconnect, clearToken);
        }

        /// <summary>
        /// 构建默认设备信息。
        /// </summary>
        /// <returns>当前终端环境信息。</returns>
        private static DeviceInfo BuildDefaultDeviceInfo()
        {
            return new DeviceInfo
            {
                Platform = Application.platform.ToString(),
                DeviceId = SystemInfo.deviceUniqueIdentifier,
                ClientVersion = Application.version
            };
        }
    }

    /// <summary>
    /// 匹配与进战斗模块实现。
    /// </summary>
    private sealed class MatchNetworkModule : IMatchNetworkModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public MatchNetworkModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public Task<DungeonMatch_s2c> MatchAsync(int dungeonId, string modeOrDifficulty, FormationSlot[] formation = null)
        {
            if (dungeonId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "DungeonId must be > 0.");
            }

            return _requester.RequestAsync<DungeonMatch_s2c>(
                new DungeonMatch_c2s
                {
                    DungeonId = dungeonId,
                    Difficulty = string.IsNullOrWhiteSpace(modeOrDifficulty) ? "normal" : modeOrDifficulty,
                    Formation = formation ?? Array.Empty<FormationSlot>()
                },
                NetworkChannel.Game,
                requireToken: true);
        }

        public Task<EnterBattle_s2c> EnterBattleAsync(
            string stageId,
            string battleMode = "PVP",
            BattleSyncMode syncMode = BattleSyncMode.ServerAuthoritative,
            FormationSlot[] formation = null,
            string customJson = null)
        {
            if (string.IsNullOrWhiteSpace(stageId))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "StageId is empty.");
            }

            return _requester.RequestAsync<EnterBattle_s2c>(
                new EnterBattle_c2s
                {
                    StageId = stageId,
                    BattleMode = string.IsNullOrWhiteSpace(battleMode) ? "PVP" : battleMode,
                    SyncMode = syncMode,
                    Formation = formation ?? Array.Empty<FormationSlot>(),
                    ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    Custom = string.IsNullOrWhiteSpace(customJson) ? "{}" : customJson
                },
                NetworkChannel.Battle,
                requireToken: true,
                reliable: true,
                priority: 0);
        }
    }

    /// <summary>
    /// 组队模块实现。
    /// </summary>
    private sealed class TeamNetworkModule : ITeamNetworkModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public TeamNetworkModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public Task<CreateTeam_s2c> CreateTeamAsync()
            => _requester.RequestAsync<CreateTeam_s2c>(new CreateTeam_c2s(), NetworkChannel.Game, true);

        public Task<InviteToTeam_s2c> InviteToTeamAsync(long targetPlayerId)
        {
            if (targetPlayerId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "TargetPlayerId must be > 0.");
            }

            return _requester.RequestAsync<InviteToTeam_s2c>(new InviteToTeam_c2s { TargetPlayerId = targetPlayerId }, NetworkChannel.Game, true);
        }

        public Task<RespondTeamInvite_s2c> RespondTeamInviteAsync(string inviteId, bool accept)
        {
            if (string.IsNullOrWhiteSpace(inviteId))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "InviteId is empty.");
            }

            return _requester.RequestAsync<RespondTeamInvite_s2c>(new RespondTeamInvite_c2s { InviteId = inviteId, Accept = accept }, NetworkChannel.Game, true);
        }

        public Task<LeaveTeam_s2c> LeaveTeamAsync()
            => _requester.RequestAsync<LeaveTeam_s2c>(new LeaveTeam_c2s(), NetworkChannel.Game, true);

        public Task<KickTeamMember_s2c> KickTeamMemberAsync(long targetPlayerId)
        {
            if (targetPlayerId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "TargetPlayerId must be > 0.");
            }

            return _requester.RequestAsync<KickTeamMember_s2c>(new KickTeamMember_c2s { TargetPlayerId = targetPlayerId }, NetworkChannel.Game, true);
        }
    }

    /// <summary>
    /// 世界模块实现（大厅、公告、活动、排行榜）。
    /// </summary>
    private sealed class WorldNetworkModule : IWorldNetworkModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public WorldNetworkModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public Task<GetLobbyInfo_s2c> GetLobbyInfoAsync()
            => _requester.RequestAsync<GetLobbyInfo_s2c>(new GetLobbyInfo_c2s(), NetworkChannel.Game, true);

        public async Task<NoticeMessage[]> GetAnnouncementsAsync()
            => (await GetLobbyInfoAsync())?.Lobby?.Notices ?? Array.Empty<NoticeMessage>();

        public Task<GetEvents_s2c> GetEventsAsync()
            => _requester.RequestAsync<GetEvents_s2c>(new GetEvents_c2s(), NetworkChannel.Game, true);

        public Task<GetLeaderboard_s2c> GetLeaderboardAsync(string boardType, int pageIndex = 1, int pageSize = 20)
        {
            return _requester.RequestAsync<GetLeaderboard_s2c>(
                new GetLeaderboard_c2s
                {
                    BoardType = string.IsNullOrWhiteSpace(boardType) ? "power" : boardType,
                    PageIndex = Math.Max(1, pageIndex),
                    PageSize = Math.Min(200, Math.Max(1, pageSize))
                },
                NetworkChannel.Game,
                true);
        }
    }

    /// <summary>
    /// 社交模块实现（好友、聊天）。
    /// </summary>
    private sealed class SocialNetworkModule : ISocialNetworkModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public SocialNetworkModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public Task<GetFriendList_s2c> GetFriendListAsync()
            => _requester.RequestAsync<GetFriendList_s2c>(new GetFriendList_c2s(), NetworkChannel.Game, true);

        public Task<GetChatHistory_s2c> GetChatHistoryAsync(ChatChannel channel, long toPlayerId = 0, long fromMessageId = 0, int limit = 50)
        {
            return _requester.RequestAsync<GetChatHistory_s2c>(
                new GetChatHistory_c2s
                {
                    Channel = channel,
                    ToPlayerId = toPlayerId,
                    FromMessageId = fromMessageId,
                    Limit = Math.Min(200, Math.Max(1, limit))
                },
                NetworkChannel.Game,
                true);
        }

        public Task<SendChatMessage_s2c> SendChatMessageAsync(ChatChannel channel, string content, long toPlayerId = 0)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "Chat content is empty.");
            }

            return _requester.RequestAsync<SendChatMessage_s2c>(
                new SendChatMessage_c2s
                {
                    Channel = channel,
                    ToPlayerId = toPlayerId,
                    Content = content
                },
                NetworkChannel.Game,
                true);
        }

        public Task<ApplyFriend_s2c> ApplyFriendAsync(long targetPlayerId, string message = null)
        {
            if (targetPlayerId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "TargetPlayerId must be > 0.");
            }

            return _requester.RequestAsync<ApplyFriend_s2c>(
                new ApplyFriend_c2s { TargetPlayerId = targetPlayerId, Message = message ?? string.Empty },
                NetworkChannel.Game,
                true);
        }

        public Task<HandleFriendRequest_s2c> HandleFriendRequestAsync(long requestId, bool accept)
        {
            if (requestId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "RequestId must be > 0.");
            }

            return _requester.RequestAsync<HandleFriendRequest_s2c>(
                new HandleFriendRequest_c2s { RequestId = requestId, Accept = accept },
                NetworkChannel.Game,
                true);
        }

        public IDisposable ObserveFriendRequestNotify(Action<FriendRequestNotify_s2c> handler)
            => _requester.Subscribe(handler);

        public IDisposable ObserveFriendOnlineStatus(Action<FriendOnlineStatusNotify_s2c> handler)
            => _requester.Subscribe(handler);
    }

    /// <summary>
    /// 邮件模块实现。
    /// </summary>
    private sealed class MailNetworkModule : IMailNetworkModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public MailNetworkModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public Task<GetMailList_s2c> GetMailListAsync()
            => _requester.RequestAsync<GetMailList_s2c>(new GetMailList_c2s(), NetworkChannel.Game, true);

        public Task<ReadMail_s2c> ReadMailAsync(long mailId)
        {
            if (mailId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "MailId must be > 0.");
            }

            return _requester.RequestAsync<ReadMail_s2c>(new ReadMail_c2s { MailId = mailId }, NetworkChannel.Game, true);
        }

        public Task<ClaimMailAttachment_s2c> ClaimMailAttachmentAsync(long mailId)
        {
            if (mailId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "MailId must be > 0.");
            }

            return _requester.RequestAsync<ClaimMailAttachment_s2c>(new ClaimMailAttachment_c2s { MailId = mailId }, NetworkChannel.Game, true);
        }

        public Task<DeleteMail_s2c> DeleteMailAsync(long mailId)
        {
            if (mailId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "MailId must be > 0.");
            }

            return _requester.RequestAsync<DeleteMail_s2c>(new DeleteMail_c2s { MailId = mailId }, NetworkChannel.Game, true);
        }

        public IDisposable ObserveNewMail(Action<NewMailNotify_s2c> handler)
            => _requester.Subscribe(handler);
    }

    /// <summary>
    /// 成长模块实现（背包、商店、任务、成就）。
    /// </summary>
    private sealed class ProgressionNetworkModule : IProgressionNetworkModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public ProgressionNetworkModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public Task<GetInventory_s2c> GetInventoryAsync(bool forceRefresh = false)
            => _requester.RequestAsync<GetInventory_s2c>(new GetInventory_c2s { ForceRefresh = forceRefresh }, NetworkChannel.Game, true);

        public Task<GetShopInfo_s2c> GetShopInfoAsync(ShopType shopType)
            => _requester.RequestAsync<GetShopInfo_s2c>(new GetShopInfo_c2s { ShopType = shopType }, NetworkChannel.Game, true);

        public Task<BuyShopItem_s2c> BuyShopItemAsync(ShopType shopType, int slotIndex, int buyCount = 1)
        {
            return _requester.RequestAsync<BuyShopItem_s2c>(
                new BuyShopItem_c2s
                {
                    ShopType = shopType,
                    SlotIndex = Math.Max(0, slotIndex),
                    BuyCount = Math.Max(1, buyCount)
                },
                NetworkChannel.Game,
                true);
        }

        public Task<GetTaskList_s2c> GetTaskListAsync(TaskType taskType = TaskType.Daily)
            => _requester.RequestAsync<GetTaskList_s2c>(new GetTaskList_c2s { TaskType = taskType }, NetworkChannel.Game, true);

        public Task<ClaimTaskReward_s2c> ClaimTaskRewardAsync(int taskId)
        {
            if (taskId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "TaskId must be > 0.");
            }

            return _requester.RequestAsync<ClaimTaskReward_s2c>(new ClaimTaskReward_c2s { TaskId = taskId }, NetworkChannel.Game, true);
        }

        public Task<GetAchievementList_s2c> GetAchievementListAsync()
            => _requester.RequestAsync<GetAchievementList_s2c>(new GetAchievementList_c2s(), NetworkChannel.Game, true);

        public Task<ClaimAchievementReward_s2c> ClaimAchievementRewardAsync(int achievementId)
        {
            if (achievementId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "AchievementId must be > 0.");
            }

            return _requester.RequestAsync<ClaimAchievementReward_s2c>(new ClaimAchievementReward_c2s { AchievementId = achievementId }, NetworkChannel.Game, true);
        }
    }
}
