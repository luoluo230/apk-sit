﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取玩家信息请求
/// </summary>
public class GetPlayerProfile_c2s
{
}

/// <summary>
/// 获取玩家信息响应
/// </summary>
public class GetPlayerProfile_s2c
{
    /// <summary>
    /// 玩家基础信息
    /// </summary>
    public PlayerProfile Profile { get; set; }
}

