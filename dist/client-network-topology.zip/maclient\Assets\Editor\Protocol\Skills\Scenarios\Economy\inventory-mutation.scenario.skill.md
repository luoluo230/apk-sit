# 背包/资源变更场景 Skill

## 客户端生成要求

- 生成刷新背包、使用道具、装备变更、资源 delta 应用前后的 hook。
- 默认关闭乐观更新，除非协议明确允许。
- 成功后刷新本地 inventory/resource/equipment cache。

## 服务端生成要求

- 校验道具所有权、数量、状态、过期时间、背包容量。
- 消耗与获得必须在同一事务或可恢复 mutation 中。
- 生成 inventory change log、幂等 key、版本号/乐观锁 hook。
- response delta 只能作为回包，不默认直接落库。

## 测试要求

- 覆盖数量不足、重复请求、过期道具、并发消耗、事务失败恢复。
