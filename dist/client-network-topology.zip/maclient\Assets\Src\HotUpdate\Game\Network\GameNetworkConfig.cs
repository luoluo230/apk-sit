﻿using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 网络通用配置。
/// 通过该配置资产控制滚服/单服、路由、请求行为等，不需要改业务代码。
/// </summary>
[CreateAssetMenu(fileName = "GameNetworkConfig", menuName = "MAClient/Network/Game Network Config")]
public sealed class GameNetworkConfig : ScriptableObject
{
    /// <summary>
    /// 单个通道路由配置。
    /// </summary>
    [Serializable]
    public sealed class Route
    {
        [Tooltip("网络通道（Login/Game/Battle）。")]
        public NetworkChannel Channel = NetworkChannel.Login;

        [Tooltip("传输协议（WebSocket/KCP 等）。")]
        public NetworkManager.TransportType Transport = NetworkManager.TransportType.WebSocket;

        [Tooltip("通道地址覆盖；为空时走 NetworkEndpoints 默认地址。")]
        public string EndpointOverride = string.Empty;

        [Tooltip("该通道默认是否可靠投递。")]
        public bool ReliableByDefault = true;

        [Tooltip("该通道默认优先级，值越小优先级通常越高（由底层实现决定）。")]
        public int DefaultPriority = 1;
    }

    [Header("Routes")]
    [Tooltip("登录/业务/战斗的路由列表。")]
    public List<Route> Routes = new List<Route>
    {
        new Route { Channel = NetworkChannel.Login, Transport = NetworkManager.TransportType.WebSocket },
        new Route { Channel = NetworkChannel.Game, Transport = NetworkManager.TransportType.WebSocket },
        new Route { Channel = NetworkChannel.Battle, Transport = NetworkManager.TransportType.Kcp, ReliableByDefault = true, DefaultPriority = 0 }
    };

    [Header("Behavior")]
    [Tooltip("是否启用滚服模式。启用：登录->选服->进服；关闭：单服直连。")]
    public bool EnableRollingServerMode = true;

    [Tooltip("单服模式默认服务器ID；为空时回退到登录返回的 LastServerId。")]
    public string SingleServerId = string.Empty;

    [Tooltip("断线重连后是否自动恢复会话（例如补选服）。")]
    public bool AutoReconnectResumeSession = true;

    [Tooltip("登录成功后是否自动启动心跳。")]
    public bool AutoStartHeartbeatAfterLogin = true;

    [Tooltip("断线时是否停止心跳。")]
    public bool StopHeartbeatOnDisconnect = true;

    [Tooltip("默认请求超时秒数。")]
    public float RequestTimeoutSeconds = 20f;

    [Tooltip("客户端帧同步基准帧率。玩法层可直接读取该值用于帧节拍控制。")]
    public int ClientFrameRate = 30;

    [Tooltip("快照同步间隔(ms)。玩法层可直接读取该值用于快照拉取/应用节奏。")]
    public int SnapshotIntervalMs = 100;
}
