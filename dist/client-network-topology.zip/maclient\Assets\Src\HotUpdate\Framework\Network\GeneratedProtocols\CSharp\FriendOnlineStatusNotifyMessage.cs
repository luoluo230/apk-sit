﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 好友上下线通知
/// </summary>
public class FriendOnlineStatusNotify_s2c
{
    /// <summary>
    /// 好友信息(只需在线状态字段有效)
    /// </summary>
    public FriendInfo Friend { get; set; }
}

