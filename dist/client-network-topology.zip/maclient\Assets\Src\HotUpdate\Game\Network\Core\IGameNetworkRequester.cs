using System;
using System.Threading.Tasks;

public interface IGameNetworkRequester
{
    Task<TResponse> RequestAsync<TResponse>(
        object request,
        NetworkChannel channel = NetworkChannel.Game,
        bool requireToken = true,
        bool? reliable = null,
        int? priority = null,
        float? timeoutSeconds = null) where TResponse : class;

    Task<GameNetworkCallResult<TResponse>> RequestResultAsync<TResponse>(
        object request,
        NetworkChannel channel = NetworkChannel.Game,
        bool requireToken = true,
        bool? reliable = null,
        int? priority = null,
        float? timeoutSeconds = null) where TResponse : class;

    IDisposable Subscribe<TNotify>(Action<TNotify> handler) where TNotify : class;
}

