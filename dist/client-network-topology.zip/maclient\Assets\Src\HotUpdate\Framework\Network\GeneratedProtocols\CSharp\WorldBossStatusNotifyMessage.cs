﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 世界 Boss 状态广播
/// </summary>
public class WorldBossStatusNotify_s2c
{
    /// <summary>
    /// Boss 信息
    /// </summary>
    public WorldBossInfo Boss { get; set; }
}

