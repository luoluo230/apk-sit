﻿using System;
using System.Collections;
using UnityEngine;

public sealed class NetworkConnectionController : IConnectionController
{
    private readonly MonoBehaviour _owner;
    private readonly IReconnectPolicy _reconnectPolicy;

    private INetworkTransport _transport;
    private MonoBehaviour _transportBehaviour;
    private Coroutine _reconnectCoroutine;

    public NetworkConnectionController(MonoBehaviour owner, IReconnectPolicy reconnectPolicy)
    {
        _owner = owner ?? throw new ArgumentNullException(nameof(owner));
        _reconnectPolicy = reconnectPolicy ?? throw new ArgumentNullException(nameof(reconnectPolicy));
    }

    public INetworkTransport Transport => _transport;
    public bool IsConnected { get; private set; }
    public bool IsReconnecting { get; private set; }
    public int ReconnectAttempts { get; private set; }
    public bool ReconnectCancelled { get; private set; }

    public void InitializeTransport(
        GameObject owner,
        NetworkManager.TransportType transportType,
        Action onConnected,
        Action<string> onDisconnected,
        Action<string> onError,
        Action<byte[]> onDataReceived)
    {
        UnbindTransportEvents(onConnected, onDisconnected, onError, onDataReceived);

        if (_transportBehaviour != null)
        {
            UnityEngine.Object.Destroy(_transportBehaviour);
            _transportBehaviour = null;
        }

        switch (transportType)
        {
            case NetworkManager.TransportType.WebSocket:
                _transportBehaviour = owner.AddComponent<WebSocketTransport>();
                break;
            case NetworkManager.TransportType.Tcp:
                _transportBehaviour = owner.AddComponent<TcpTransport>();
                break;
            case NetworkManager.TransportType.Kcp:
                _transportBehaviour = owner.AddComponent<KcpTransport>();
                break;
            case NetworkManager.TransportType.Http:
                _transportBehaviour = owner.AddComponent<HttpTransport>();
                break;
            default:
                Logger.Log("Unsupported transport type.", LogLevel.Error);
                return;
        }

        _transport = _transportBehaviour as INetworkTransport;
        if (_transport == null)
        {
            Logger.Log("Failed to initialize transport component.", LogLevel.Error);
            return;
        }

        _transport.OnConnected += onConnected;
        _transport.OnDisconnected += onDisconnected;
        _transport.OnError += onError;
        _transport.OnDataReceived += onDataReceived;
    }

    public void Connect(NetworkManager.TransportType transportType, string serverUri, string webSocketPath)
    {
        ReconnectCancelled = false;
        string resolvedUri = ResolveTransportUri(transportType, serverUri, webSocketPath);
        if (string.IsNullOrWhiteSpace(resolvedUri))
        {
            Logger.Log("No valid server URI configured for the selected transport.", LogLevel.Error);
            return;
        }

        Logger.Log($"Connecting with transport={transportType}, uri={resolvedUri}");
        _transport?.Connect(resolvedUri);
    }

    public bool HandleTransportConnected()
    {
        bool wasReconnecting = IsReconnecting;
        IsConnected = true;
        ReconnectAttempts = 0;

        if (_reconnectCoroutine != null)
        {
            _owner.StopCoroutine(_reconnectCoroutine);
            _reconnectCoroutine = null;
        }

        IsReconnecting = false;
        return wasReconnecting;
    }

    public void HandleTransportDisconnected()
    {
        IsConnected = false;
    }

    public bool TryStartReconnect(
        bool isLongConnection,
        int maxReconnectAttempts,
        float reconnectDelay,
        float maxReconnectDelay,
        Action onReconnectFailed,
        Action reconnectAction)
    {
        if (ReconnectCancelled || !isLongConnection)
        {
            return false;
        }

        IsReconnecting = true;
        ReconnectAttempts++;
        if (ReconnectAttempts > maxReconnectAttempts)
        {
            onReconnectFailed?.Invoke();
            IsReconnecting = false;
            return false;
        }

        if (_reconnectCoroutine != null)
        {
            _owner.StopCoroutine(_reconnectCoroutine);
        }

        float delay = _reconnectPolicy.GetDelaySeconds(ReconnectAttempts, reconnectDelay, maxReconnectDelay);
        _reconnectCoroutine = _owner.StartCoroutine(ReconnectCoroutine(delay, reconnectAction));
        return true;
    }

    public void CancelReconnect(Action onReconnectCancelled)
    {
        if (!IsReconnecting)
        {
            return;
        }

        ReconnectCancelled = true;
        if (_reconnectCoroutine != null)
        {
            _owner.StopCoroutine(_reconnectCoroutine);
            _reconnectCoroutine = null;
        }

        IsReconnecting = false;
        onReconnectCancelled?.Invoke();
    }

    public void StopReconnectFlow()
    {
        IsReconnecting = false;
        if (_reconnectCoroutine != null)
        {
            _owner.StopCoroutine(_reconnectCoroutine);
            _reconnectCoroutine = null;
        }
    }

    public void PrepareForManualDisconnect()
    {
        ReconnectCancelled = true;
        StopReconnectFlow();
    }

    public void Disconnect()
    {
        _transport?.Disconnect();
    }

    public void Dispose(
        Action onConnected,
        Action<string> onDisconnected,
        Action<string> onError,
        Action<byte[]> onDataReceived)
    {
        StopReconnectFlow();
        UnbindTransportEvents(onConnected, onDisconnected, onError, onDataReceived);
    }

    private void UnbindTransportEvents(
        Action onConnected,
        Action<string> onDisconnected,
        Action<string> onError,
        Action<byte[]> onDataReceived)
    {
        if (_transport == null)
        {
            return;
        }

        _transport.OnConnected -= onConnected;
        _transport.OnDisconnected -= onDisconnected;
        _transport.OnError -= onError;
        _transport.OnDataReceived -= onDataReceived;
    }

    private IEnumerator ReconnectCoroutine(float delay, Action reconnectAction)
    {
        yield return new WaitForSeconds(delay);

        if (!ReconnectCancelled)
        {
            reconnectAction?.Invoke();
        }

        _reconnectCoroutine = null;
    }

    private static string ResolveTransportUri(NetworkManager.TransportType transportType, string serverUri, string webSocketPath)
    {
        if (transportType != NetworkManager.TransportType.WebSocket || string.IsNullOrWhiteSpace(serverUri))
        {
            return serverUri;
        }

        string cleanedUri = serverUri.Trim();
        string path = string.IsNullOrWhiteSpace(webSocketPath) ? "ws" : webSocketPath.Trim().Trim('/');
        bool normalized = false;

        if (!Uri.TryCreate(cleanedUri, UriKind.Absolute, out var uri) || string.IsNullOrEmpty(uri.Scheme))
        {
            string withScheme = $"ws://{cleanedUri.TrimStart('/')}";
            if (!Uri.TryCreate(withScheme, UriKind.Absolute, out uri))
            {
                Logger.Log($"Invalid WebSocket uri: {serverUri}", LogLevel.Warning);
                return serverUri;
            }

            normalized = true;
        }

        var builder = new UriBuilder(uri);
        string originalScheme = builder.Scheme;
        if (!string.Equals(builder.Scheme, "ws", StringComparison.OrdinalIgnoreCase) &&
            !string.Equals(builder.Scheme, "wss", StringComparison.OrdinalIgnoreCase))
        {
            builder.Scheme = "ws";
            builder.Port = builder.Port <= 0 ? 80 : builder.Port;
            normalized = true;
        }

        string currentPath = (builder.Path ?? string.Empty).Trim('/');
        if (string.IsNullOrEmpty(currentPath) || !string.Equals(currentPath, path, StringComparison.OrdinalIgnoreCase))
        {
            builder.Path = "/" + path + "/";
            normalized = true;
        }

        string finalUri = builder.Uri.ToString();
        if (normalized || !string.Equals(originalScheme, builder.Scheme, StringComparison.OrdinalIgnoreCase))
        {
            Logger.Log($"Normalized WebSocket uri: {serverUri} -> {finalUri}");
        }

        return finalUri;
    }
}
