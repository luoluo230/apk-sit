// 自动生成的协议文件

// 定义协议类


// 发起竞技场挑战
class ArenaChallenge_c2s {
    constructor() {
        this.TargetPlayerId = null;
        this.Formation = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 竞技场挑战结果(简单结算, 详细战斗走 BattleResult)
class ArenaChallenge_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.BattleId = '';
        this.NewRank = 0;
        this.RankChange = 0;
        this.Rewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ArenaChallenge_c2s,
    ArenaChallenge_s2c,
};
