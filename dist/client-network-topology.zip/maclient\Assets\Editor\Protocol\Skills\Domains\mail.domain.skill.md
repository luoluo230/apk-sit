# Mail Domain Skill

- Client: generate mail list/read/claim use cases with attachment refresh hooks.
- Server: generate mailbox ownership validation, attachment claim idempotency, mail repository hooks, and inventory mutation hooks.
- Attachment claim must be transactional or explicitly recoverable.
