﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 英雄升级(消耗经验物品/金币)
/// </summary>
public class UpgradeHeroLevel_c2s
{
    /// <summary>
    /// 英雄 ID
    /// </summary>
    public long HeroId { get; set; }
    /// <summary>
    /// 使用的经验物品
    /// </summary>
    public ItemCost[] UseItems { get; set; }
}

/// <summary>
/// 英雄升级结果
/// </summary>
public class UpgradeHeroLevel_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 失败原因
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 升级后的英雄数据
    /// </summary>
    public HeroInfo Hero { get; set; }
    /// <summary>
    /// 资源变化(金币等)
    /// </summary>
    public ResourceChange[] ResourceChanges { get; set; }
    /// <summary>
    /// 经验道具消耗变化
    /// </summary>
    public InventoryDelta InventoryDelta { get; set; }
}

