﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 新的公会申请通知(仅会长/官员)
/// </summary>
public class GuildApplyNotify_s2c
{
    /// <summary>
    /// 申请信息
    /// </summary>
    public GuildApplyInfo Apply { get; set; }
}

