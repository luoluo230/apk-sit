// 自动生成的协议文件

// 定义协议类


// 赠送好友体力/友情点
class SendFriendEnergy_c2s {
    constructor() {
        this.TargetPlayerIds = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 赠送好友体力结果
class SendFriendEnergy_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SendFriendEnergy_c2s,
    SendFriendEnergy_s2c,
};
