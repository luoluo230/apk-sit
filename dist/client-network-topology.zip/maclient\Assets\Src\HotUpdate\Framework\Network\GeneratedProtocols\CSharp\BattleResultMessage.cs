﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 客户端上报或拉取战斗结算(结果/统计可选)
/// </summary>
public class BattleResult_c2s
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 客户端观测的结果，可为空
    /// </summary>
    public BattleResultType Result { get; set; }
    /// <summary>
    /// 客户端观测的耗时帧数，可为空则置 0
    /// </summary>
    public int ElapsedFrames { get; set; }
    /// <summary>
    /// 客户端统计(可为空)
    /// </summary>
    public BattleStatistic Statistic { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 战斗结算结果(权威统计与奖励)
/// </summary>
public class BattleResult_s2c
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 战斗结果
    /// </summary>
    public BattleResultType Result { get; set; }
    /// <summary>
    /// 战斗耗时(帧)
    /// </summary>
    public int DurationFrames { get; set; }
    /// <summary>
    /// 结算奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 最终统计
    /// </summary>
    public BattleStatistic Statistic { get; set; }
    /// <summary>
    /// 高光片段(用于回放)
    /// </summary>
    public BattleFrameEvent[] Highlights { get; set; }
    /// <summary>
    /// 最终锚点
    /// </summary>
    public BattleTimelineAnchor Anchor { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

