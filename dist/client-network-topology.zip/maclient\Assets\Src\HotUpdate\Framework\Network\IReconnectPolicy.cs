/// <summary>
/// 重连退避策略接口。
/// </summary>
public interface IReconnectPolicy
{
    /// <summary>
    /// 计算指定重试次数下的等待秒数。
    /// </summary>
    float GetDelaySeconds(int attempt, float baseDelaySeconds, float maxDelaySeconds);
}
