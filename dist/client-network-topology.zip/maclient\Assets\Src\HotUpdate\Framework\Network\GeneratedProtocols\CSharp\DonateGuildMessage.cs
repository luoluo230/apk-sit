﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 公会捐献
/// </summary>
public class DonateGuild_c2s
{
    /// <summary>
    /// 捐献档位/类型
    /// </summary>
    public string DonateType { get; set; }
}

/// <summary>
/// 公会捐献结果
/// </summary>
public class DonateGuild_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 获得的个人奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
}

