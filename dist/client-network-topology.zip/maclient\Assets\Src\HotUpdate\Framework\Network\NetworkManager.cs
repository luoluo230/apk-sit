﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

/// <summary>
/// 网络总门面与默认装配根。
///
/// 这个类在当前工程里承担两层职责：
/// 1. 作为面向 Unity 场景的挂载入口，暴露 Inspector 配置
/// 2. 作为网络核心能力的默认组合器，把连接、请求派发、可靠投递、心跳、同步通道和诊断串起来
///
/// 重要约定：
/// - 业务层应优先通过 NetworkFacade 或更高层 Context 访问网络
/// - 传输层差异、ACK、重传、心跳等基础能力应尽量留在这里或独立服务里，不要泄漏到业务层
/// </summary>
[AddComponentMenu("")]
[Obsolete("NetworkManager is internal compatibility only. Use NetworkBootstrap or NetworkRuntimeCore.", false)]
public class NetworkManager : MonoBehaviour
{
    /// <summary>
    /// 当前支持的传输类型。
    ///
    /// 后续如果要新增 QUIC 等实现，优先从这里和对应 transport 扩展。
    /// </summary>
    public enum TransportType
    {
        WebSocket,
        Tcp,
        Kcp,
        Http
    }

    [Header("Connection Settings")]
    public TransportType transportType = TransportType.WebSocket;
    public string serverUri = "ws://115.236.153.170:20660";
    public string webSocketPath = "ws";
    public bool autoConnect = true;
    public float heartBeatInterval = 10f;
    public float reconnectDelay = 5f;
    public int maxReconnectAttempts = 5;
    public float maxReconnectDelay = 60f;

    [Header("Traffic Control")]
    public int maxSendQueueSize = 100;
    public int maxSendPerFrame = 5;
    public float sendJitter = 0.05f;

    [Header("Request Timeout")]
    public float requestTimeoutSeconds = 30f;
    public float connectTimeoutSeconds = 8f;
    public float heartbeatTimeoutSeconds = 20f;

    [Header("Reliable Delivery")]
    public bool enableReliableDelivery = true;
    public float reliableTimeout = 5f;
    public int reliableMaxRetry = 3;
    public float resendJitter = 0.3f;
    public int maxChunkSize = 8 * 1024;
    public float chunkTimeout = 30f;
    public int maxPacketSize = 256 * 1024;
    public int receiveBufferSize = 64 * 1024;
    public int maxReceiveBufferSize = 512 * 1024;

    [Header("Ack Backpressure")]
    public float ackFlushInterval = 0.05f;
    public int maxAckPerFlush = 20;
    public bool dropLowerPriorityWhenQueueFull = true;

    [Header("Dynamic Priority")]
    public bool enableDynamicPriority = true;
    public float highQueueLoadThreshold = 0.7f;
    public float lowQueueLoadThreshold = 0.3f;
    public int reliablePriorityBoost = 1;
    public int largePayloadPenalty = 1;
    public int largePayloadBytes = 32 * 1024;
    public int maxPriorityValue = 10;

    [Header("Diagnostics")]
    public bool enableDebugTrafficLog = false;
    public int debugPayloadPreviewLength = 512;
    public bool interceptServerError = true;
    public bool enableHeartbeatRequest = true;
    public bool swallowHeartbeatResponse = true;
    public float kcpDisconnectTimeout = 30f;
    public float kcpDisconnectBaseTimeout = 10f;
    public float kcpDisconnectMinTimeout = 10f;
    public float kcpDisconnectMaxTimeout = 60f;
    public float kcpDisconnectRttMultiplier = 4f;

    [Header("Protocol Pipeline")]
    public string payloadSerializerName = "json";
    public bool enablePayloadCompression = false;
    public bool enablePayloadEncryption = false;

    [Header("Global Network Simulation")]
    public bool enableGlobalSimulation = false;
    public int simulatedLatencyMs = 120;
    public int simulatedJitterMs = 40;
    [Range(0f, 100f)] public float simulatedPacketLossPercent = 2f;
    [Range(0f, 100f)] public float simulatedDuplicatePercent = 0.5f;
    [Range(0f, 100f)] public float simulatedReorderPercent = 1f;
    public int simulatedBandwidthKbps = 0;
    public float simulatedDisconnectAfterSeconds = 0f;
    public int simulationSeed = 9527;

    private const int HEADER_SIZE = 4;

    private float _nextAckFlushTime;
    private int _sequenceCounter;
    private int _chunkIdCounter;

    private readonly ByteArrayPool _byteArrayPool = ByteArrayPool.Shared;
    private readonly PriorityMessageQueue _sendQueue = new PriorityMessageQueue();
    private readonly Dictionary<int, PendingMessage> _pendingReliableMessages = new Dictionary<int, PendingMessage>();
    private readonly MessageRouter _messageRouter = new MessageRouter();
    private readonly PendingMessagePool _pendingMessagePool = new PendingMessagePool();

    private IConnectionController _connectionController;
    private IRequestDispatcher _requestDispatcher;
    private IHeartbeatController _heartbeatController;
    private IReceiveBufferProcessor _receiveBufferProcessor;
    private INetworkDiagnosticsService _diagnosticsService;
    private IReconnectPolicy _reconnectPolicy;
    private IRequestPolicy _requestPolicy;
    private IReliableDeliveryService _reliableDeliveryService;
    private INetworkSimulationProvider _simulationProvider;
    private readonly ISnapshotSyncChannel _snapshotSyncChannel = new SnapshotSyncChannel();
    private readonly IFrameSyncChannel _frameSyncChannel = new FrameSyncChannel();
    private bool _manualCloseRequested;
    private float _connectStartTime = -1f;
    private float _connectedAtTime = -1f;
    private bool _simulatedDisconnectTriggered;

    private static readonly Dictionary<int, string> ProtocolNames = ProtocolDictionary.Protocols
        .ToDictionary(p => p.Value, p => p.Key);

    public event Action OnConnected;
    public event Action OnConnectionFailed;
    public event Action OnDisconnected;
    public event Action OnConnectionLost;
    public event Action OnReconnecting;
    public event Action OnReconnectFailed;
    public event Action OnHeartbeatTimeout;
    public event Action OnReconnectCancelled;
    public event Action OnReconnected;
    public event Action<int> OnReliableMessageDropped;
    public event Action<int, int> OnSendQueueOverflowDropped;
    public event Action<int, string, int> OnServerError;
    public event Action<int, string> OnRequestFailed;
    public event Action<int, string, string> OnRequestFailedV2;

    public bool IsConnected => _connectionController != null && _connectionController.IsConnected;
    public TransportType CurrentTransportType => transportType;
    public string CurrentServerUri => serverUri;

    /// <summary>
    /// 发送队列。
    ///
    /// 当前采用“按优先级分桶 + 到时可发送”的结构，这样既能做优先级调度，也能承载重传重排。
    /// </summary>
    private sealed class PriorityMessageQueue
    {
        private readonly SortedDictionary<int, Queue<PendingMessage>> _queues = new SortedDictionary<int, Queue<PendingMessage>>();

        public int Count { get; private set; }

        /// <summary>按优先级把待发消息塞入队列。</summary>
        public void Enqueue(PendingMessage pending)
        {
            if (!_queues.TryGetValue(pending.Priority, out var queue))
            {
                queue = new Queue<PendingMessage>();
                _queues[pending.Priority] = queue;
            }

            queue.Enqueue(pending);
            pending.InQueue = true;
            Count++;
        }

        /// <summary>
        /// 尝试取出一条当前时刻允许发送的消息。
        ///
        /// 这里不仅检查优先级，也检查 NextSendTime，便于统一处理抖动发送和重传延迟。
        /// </summary>
        public bool TryDequeue(float currentTime, out PendingMessage pending)
        {
            foreach (var kvp in _queues)
            {
                if (kvp.Value.Count == 0)
                {
                    continue;
                }

                var candidate = kvp.Value.Peek();
                if (candidate.NextSendTime <= currentTime)
                {
                    pending = kvp.Value.Dequeue();
                    candidate.InQueue = false;
                    Count--;
                    return true;
                }
            }

            pending = null;
            return false;
        }

        /// <summary>
        /// 当队列满时，尝试丢弃最差优先级消息给高优消息让路。
        /// </summary>
        public bool TryDropLowestPriority(int incomingPriority, out PendingMessage dropped)
        {
            dropped = null;
            if (_queues.Count == 0)
            {
                return false;
            }

            int worstPriority = int.MinValue;
            foreach (var key in _queues.Keys)
            {
                worstPriority = key;
            }

            if (worstPriority == int.MinValue || worstPriority < incomingPriority)
            {
                return false;
            }

            var queue = _queues[worstPriority];
            while (queue.Count > 0)
            {
                dropped = queue.Dequeue();
                dropped.InQueue = false;
                Count--;
                return true;
            }

            return false;
        }

        /// <summary>清空整条发送队列，并把被丢弃消息交给外部统一清理。</summary>
        public void Drain(Action<PendingMessage> onDrop)
        {
            foreach (var kvp in _queues)
            {
                while (kvp.Value.Count > 0)
                {
                    var pending = kvp.Value.Dequeue();
                    pending.InQueue = false;
                    Count--;
                    onDrop?.Invoke(pending);
                }
            }

            _queues.Clear();
            Count = 0;
        }
    }

    /// <summary>
    /// 内部待发消息描述。
    ///
    /// 这是 NetworkManager 里最核心的内部状态对象之一，记录了待发包的重传、优先级、原始字节、ACK 需求等信息。
    /// </summary>
    private sealed class PendingMessage
    {
        public NetMessage Message;
        public byte[] RawBytes;
        public int Priority;
        public bool RequiresAck;
        public float LastSendTime;
        public float NextSendTime;
        public int RetryCount;
        public bool InQueue;
        public int RawLength;

        public void Reset()
        {
            Message = null;
            RawBytes = null;
            Priority = 0;
            RequiresAck = false;
            LastSendTime = 0f;
            NextSendTime = 0f;
            RetryCount = 0;
            InQueue = false;
            RawLength = 0;
        }
    }

    private sealed class PendingMessagePool
    {
        private readonly Stack<PendingMessage> _pool = new Stack<PendingMessage>(64);

        public PendingMessage Rent()
        {
            return _pool.Count > 0 ? _pool.Pop() : new PendingMessage();
        }

        public void Return(PendingMessage pending)
        {
            if (pending == null)
            {
                return;
            }

            pending.Reset();
            _pool.Push(pending);
        }

        public void Clear()
        {
            _pool.Clear();
        }
    }

    private bool IsLongConnection => transportType != TransportType.Http;

    private void Awake()
    {
        _nextAckFlushTime = Time.time + ackFlushInterval;

        _reconnectPolicy = new ExponentialReconnectPolicy();
        _requestPolicy = new DefaultRequestPolicy();
        _connectionController = new NetworkConnectionController(this, _reconnectPolicy);
        _requestDispatcher = new NetworkRequestDispatcher(_messageRouter, _requestPolicy);
        _heartbeatController = new NetworkHeartbeatController();
        _reliableDeliveryService = new NetworkReliableDeliveryService();
        _simulationProvider = new NetworkSimulationProvider();
        _receiveBufferProcessor = new NetworkReceiveBufferProcessor(receiveBufferSize, maxPacketSize, maxReceiveBufferSize, chunkTimeout, _byteArrayPool, HEADER_SIZE);
        _diagnosticsService = new NetworkDiagnosticsService(enableDebugTrafficLog, debugPayloadPreviewLength, ProtocolNames);
        _heartbeatController.Configure(
            ProtocolDictionary.Protocols.TryGetValue("Heartbeat_c2s", out var reqId) ? reqId : -1,
            ProtocolDictionary.Protocols.TryGetValue("Heartbeat_s2c", out var resId) ? resId : -1,
            Time.time);

        NetworkPayloadPipeline.Configure(payloadSerializerName, enablePayloadCompression, enablePayloadEncryption);
        _simulationProvider.Configure(
            enableGlobalSimulation,
            simulatedLatencyMs,
            simulatedJitterMs,
            simulatedPacketLossPercent,
            simulatedDuplicatePercent,
            simulatedReorderPercent,
            simulatedBandwidthKbps,
            simulatedDisconnectAfterSeconds,
            simulationSeed);

        InitializeTransport();
    }

    private void Start()
    {
        if (autoConnect)
        {
            Connect();
        }
    }

    private void Update()
    {
        int sendCount = 0;
        while (IsConnected && _sendQueue.Count > 0 && sendCount < maxSendPerFrame)
        {
            if (!_sendQueue.TryDequeue(Time.time, out var pending))
            {
                break;
            }

            _connectionController.Transport?.Send(pending.RawBytes);
            pending.LastSendTime = Time.time;

            if (pending.RequiresAck)
            {
                _pendingReliableMessages[pending.Message.SequenceId] = pending;
                _reliableDeliveryService.TrackSent(pending.Message.SequenceId, pending.LastSendTime);
            }
            else
            {
                ReleasePendingMessage(pending);
            }

            sendCount++;
        }

        if (IsConnected && enableReliableDelivery)
        {
            CheckReliableMessages();
        }

        if (Time.time >= _nextAckFlushTime)
        {
            FlushAckQueue();
        }

        _heartbeatController.Tick(
            Time.time,
            IsLongConnection,
            IsConnected,
            transportType,
            heartBeatInterval,
            heartbeatTimeoutSeconds,
            enableHeartbeatRequest,
            kcpDisconnectTimeout,
            SendHeartbeatRequest,
            HandleHeartbeatTimeout);

        if (!IsConnected && _connectStartTime > 0f && !IsLongConnection)
        {
            // no-op for short connection
        }

        if (!IsConnected && _connectStartTime > 0f && connectTimeoutSeconds > 0f && Time.time - _connectStartTime >= connectTimeoutSeconds)
        {
            _connectStartTime = -1f;
            Logger.Log($"Connect timeout after {connectTimeoutSeconds:F1}s", LogLevel.Warning);
            OnConnectionFailed?.Invoke();
            if (IsLongConnection)
            {
                StartReconnect();
            }
        }

        if (IsConnected && _simulationProvider != null && _simulationProvider.Enabled && !_simulatedDisconnectTriggered && _connectedAtTime > 0f)
        {
            if (_simulationProvider.ShouldDisconnect(Time.time - _connectedAtTime))
            {
                _simulatedDisconnectTriggered = true;
                Logger.Log("[Network] Simulated disconnect triggered.", LogLevel.Warning);
                _connectionController.Transport?.Disconnect();
            }
        }

        _receiveBufferProcessor.CleanupExpiredChunks(Time.time);
        _requestDispatcher.CheckTimeouts(Time.time, requestTimeoutSeconds, (responseId, requestInstanceId, reason) =>
        {
            OnRequestFailed?.Invoke(responseId, reason);
            OnRequestFailedV2?.Invoke(responseId, requestInstanceId, reason);
        });
    }

    public void Connect()
    {
        _manualCloseRequested = false;
        _connectStartTime = Time.time;
        _simulatedDisconnectTriggered = false;
        _connectionController.Connect(transportType, serverUri, webSocketPath);
    }

    public void SwitchTransport(TransportType newType, string newUri = null)
    {
        if (transportType == newType && string.IsNullOrEmpty(newUri))
        {
            return;
        }

        CloseConnection();
        transportType = newType;
        if (!string.IsNullOrEmpty(newUri))
        {
            serverUri = newUri;
        }
        Logger.Log($"[TransportSelected] transport={transportType}, endpoint={serverUri}", LogLevel.Info);

        InitializeTransport();

        if (autoConnect)
        {
            Connect();
        }
    }

    public void ConfigurePayloadPipeline(string serializerName, bool compression, bool encryption)
    {
        payloadSerializerName = string.IsNullOrWhiteSpace(serializerName) ? "json" : serializerName;
        enablePayloadCompression = compression;
        enablePayloadEncryption = encryption;
        NetworkPayloadPipeline.Configure(payloadSerializerName, enablePayloadCompression, enablePayloadEncryption);
        Logger.Log($"[SerializerResolved] serializer={payloadSerializerName}, compression={enablePayloadCompression}, encryption={enablePayloadEncryption}", LogLevel.Info);
    }

    public void ConfigureSimulation(
        bool enabled,
        int latencyMs,
        int jitterMs,
        float lossPercent,
        float duplicatePercent,
        float reorderPercent,
        int bandwidthKbps,
        float disconnectAfterSeconds,
        int seed)
    {
        enableGlobalSimulation = enabled;
        simulatedLatencyMs = latencyMs;
        simulatedJitterMs = jitterMs;
        simulatedPacketLossPercent = lossPercent;
        simulatedDuplicatePercent = duplicatePercent;
        simulatedReorderPercent = reorderPercent;
        simulatedBandwidthKbps = bandwidthKbps;
        simulatedDisconnectAfterSeconds = disconnectAfterSeconds;
        simulationSeed = seed;

        _simulationProvider?.Configure(
            enableGlobalSimulation,
            simulatedLatencyMs,
            simulatedJitterMs,
            simulatedPacketLossPercent,
            simulatedDuplicatePercent,
            simulatedReorderPercent,
            simulatedBandwidthKbps,
            simulatedDisconnectAfterSeconds,
            simulationSeed);
        Logger.Log($"[SimulationActive] enabled={enableGlobalSimulation}, latencyMs={simulatedLatencyMs}, jitterMs={simulatedJitterMs}, loss={simulatedPacketLossPercent}, dup={simulatedDuplicatePercent}, reorder={simulatedReorderPercent}, bandwidthKbps={simulatedBandwidthKbps}, disconnectAfter={simulatedDisconnectAfterSeconds}, seed={simulationSeed}", LogLevel.Info);
    }

    public string SendMessage<T>(object data, Action<T> responseCallback = null, bool reliable = true, int priority = 1) where T : class
    {
        if (data == null)
        {
            Logger.Log("Cannot send null network payload.", LogLevel.Error);
            return string.Empty;
        }

        if (_sendQueue.Count >= maxSendQueueSize)
        {
            if (!dropLowerPriorityWhenQueueFull || !_sendQueue.TryDropLowestPriority(Mathf.Max(0, priority), out var dropped))
            {
                Logger.Log("Send queue is full, message dropped.", LogLevel.Warning);
                return string.Empty;
            }

            HandleDroppedPendingMessage(dropped);
        }

        int sequenceId = ++_sequenceCounter;
        reliable = reliable && enableReliableDelivery;
        NetMessage message;
        try
        {
            message = new NetMessage(data, sequenceId, reliable, Mathf.Max(0, priority));
        }
        catch (Exception ex)
        {
            Logger.Log($"Failed to build network message: {ex.Message}", LogLevel.Error);
            OnRequestFailed?.Invoke(-1, ex.Message);
            OnRequestFailedV2?.Invoke(-1, string.Empty, ex.Message);
            return string.Empty;
        }
        _diagnosticsService.LogTraffic("SEND", message);
        if (!QueueMessageWithChunk(message))
        {
            OnRequestFailed?.Invoke(_requestPolicy.GetResponseMessageId(message.MessageID), "Request was not queued.");
            OnRequestFailedV2?.Invoke(_requestPolicy.GetResponseMessageId(message.MessageID), string.Empty, "Request was not queued.");
            return string.Empty;
        }

        var requestInstanceId = _requestDispatcher.RegisterResponseCallback(message.MessageID, responseCallback, Time.time);

        if (!IsConnected)
        {
            Logger.Log("Transport is not connected yet, message queued for later delivery.", LogLevel.Warning);
        }

        return requestInstanceId;
    }

    public void RegisterHandler(int messageId, Action<NetMessage> handler)
    {
        _messageRouter.RegisterHandler(messageId, handler);
    }

    public void RegisterSnapshotHandler(int messageId, Action<NetMessage> handler)
    {
        _snapshotSyncChannel.RegisterSnapshotHandler(messageId, handler);
    }

    public void RegisterFrameHandler(int messageId, Action<NetMessage> handler)
    {
        _frameSyncChannel.RegisterFrameHandler(messageId, handler);
    }

    public void UnregisterHandler(int messageId, Action<NetMessage> handler)
    {
        _messageRouter.UnregisterHandler(messageId, handler);
    }

    public void CancelReconnect()
    {
        _connectionController.CancelReconnect(() => OnReconnectCancelled?.Invoke());
    }

    public void CloseConnection()
    {
        _manualCloseRequested = true;
        _connectionController.PrepareForManualDisconnect();
        _heartbeatController.OnDisconnected();
        _requestDispatcher.Clear("Connection closed.", (responseId, requestInstanceId, reason) =>
        {
            OnRequestFailed?.Invoke(responseId, reason);
            OnRequestFailedV2?.Invoke(responseId, requestInstanceId, reason);
        });
        ClearPendingMessages();
        _connectionController.Disconnect();
        OnDisconnected?.Invoke();
    }

    private void InitializeTransport()
    {
        _connectionController.InitializeTransport(
            gameObject,
            transportType,
            HandleTransportConnected,
            HandleTransportDisconnected,
            HandleTransportError,
            HandleDataReceived);
    }

    private bool QueueMessageWithChunk(NetMessage message)
    {
        string payload = message.Data?.ToString() ?? string.Empty;
        byte[] payloadBytes = Encoding.UTF8.GetBytes(payload);

        if (payloadBytes.Length <= maxChunkSize)
        {
            return EnqueuePendingMessage(message);
        }

        int chunkId = ++_chunkIdCounter;
        int chunkTotal = Mathf.CeilToInt(payloadBytes.Length / (float)maxChunkSize);

        if (_sendQueue.Count + chunkTotal > maxSendQueueSize)
        {
            Logger.Log("Not enough queue space for chunked payload.", LogLevel.Warning);
            return false;
        }

        bool queuedAny = false;

        for (int i = 0; i < chunkTotal; i++)
        {
            int chunkSize = Math.Min(maxChunkSize, payloadBytes.Length - i * maxChunkSize);
            byte[] chunkBytes = new byte[chunkSize];
            Buffer.BlockCopy(payloadBytes, i * maxChunkSize, chunkBytes, 0, chunkSize);

            NetMessage chunkMessage = new NetMessage
            {
                MessageID = message.MessageID,
                DataType = message.DataType,
                Data = Convert.ToBase64String(chunkBytes),
                SequenceId = ++_sequenceCounter,
                RequiresAck = message.RequiresAck,
                Priority = message.Priority,
                IsChunk = true,
                ChunkId = chunkId,
                ChunkIndex = i,
                ChunkTotal = chunkTotal
            };

            queuedAny |= EnqueuePendingMessage(chunkMessage);
        }

        return queuedAny;
    }

    private bool EnqueuePendingMessage(NetMessage message)
    {
        byte[] rawBytes = message.Serialize();
        int bodyLength = rawBytes.Length - HEADER_SIZE;
        if (bodyLength > maxPacketSize)
        {
            Logger.Log($"Packet body too large ({bodyLength} bytes), dropping message.", LogLevel.Warning);
            return false;
        }

        if (_simulationProvider != null && _simulationProvider.Enabled && !message.IsAck && _simulationProvider.ShouldDrop())
        {
            Logger.Log($"[Network] Simulated drop. msgId={message.MessageID}", LogLevel.Warning);
            return false;
        }

        int duplicateCount = (_simulationProvider != null && _simulationProvider.Enabled && !message.IsAck)
            ? Mathf.Max(1, _simulationProvider.GetDuplicateCount())
            : 1;

        for (int copy = 0; copy < duplicateCount; copy++)
        {
            if (_sendQueue.Count >= maxSendQueueSize)
            {
                if (!dropLowerPriorityWhenQueueFull || !_sendQueue.TryDropLowestPriority(Mathf.Max(0, message.Priority), out var dropped))
                {
                    Logger.Log("Send queue is full, message dropped.", LogLevel.Warning);
                    return false;
                }

                HandleDroppedPendingMessage(dropped);
            }

            var pending = _pendingMessagePool.Rent();
            pending.Message = message;
            pending.RawBytes = rawBytes;
            pending.RawLength = rawBytes.Length;
            pending.Priority = ApplyDynamicPriority(Mathf.Max(0, message.Priority), rawBytes.Length, message.RequiresAck);
            pending.RequiresAck = message.RequiresAck;
            pending.LastSendTime = 0f;
            pending.RetryCount = 0;

            float baseDelay = message.IsAck || !IsConnected ? 0f : UnityEngine.Random.Range(0f, sendJitter);
            float simulatedDelay = (_simulationProvider != null && _simulationProvider.Enabled && !message.IsAck)
                ? _simulationProvider.GetDelaySeconds(rawBytes.Length)
                : 0f;
            pending.NextSendTime = Time.time + baseDelay + simulatedDelay;
            _sendQueue.Enqueue(pending);
        }

        if (message.RequiresAck)
        {
            _reliableDeliveryService.MarkQueued(message.SequenceId, true);
        }

        return true;
    }

    private int ApplyDynamicPriority(int basePriority, int rawLength, bool reliable)
    {
        if (!enableDynamicPriority || maxSendQueueSize <= 0)
        {
            return Mathf.Clamp(basePriority, 0, maxPriorityValue);
        }

        float load = _sendQueue.Count / (float)maxSendQueueSize;
        int adjusted = basePriority;

        if (load >= highQueueLoadThreshold)
        {
            if (reliable)
            {
                adjusted -= reliablePriorityBoost;
            }

            if (rawLength >= largePayloadBytes)
            {
                adjusted += largePayloadPenalty;
            }
        }
        else if (load <= lowQueueLoadThreshold && reliable && adjusted > 0)
        {
            adjusted -= 1;
        }

        return Mathf.Clamp(adjusted, 0, maxPriorityValue);
    }

    private void HandleDroppedPendingMessage(PendingMessage dropped)
    {
        if (dropped == null)
        {
            return;
        }

        int messageId = dropped.Message != null ? dropped.Message.MessageID : -1;
        Logger.Log($"Send queue overflow dropped message ID={messageId}, Priority={dropped.Priority}", LogLevel.Warning);
        OnSendQueueOverflowDropped?.Invoke(messageId, dropped.Priority);
        ReleasePendingMessage(dropped);
    }

    private void RequeuePendingMessage(PendingMessage pending)
    {
        if (pending == null)
        {
            return;
        }

        if (_sendQueue.Count >= maxSendQueueSize)
        {
            if (!dropLowerPriorityWhenQueueFull || !_sendQueue.TryDropLowestPriority(pending.Priority, out var dropped))
            {
                HandleDroppedPendingMessage(pending);
                return;
            }

            HandleDroppedPendingMessage(dropped);
        }

        pending.InQueue = false;
        _sendQueue.Enqueue(pending);
        if (pending.RequiresAck && pending.Message != null)
        {
            _reliableDeliveryService.MarkQueued(pending.Message.SequenceId, true);
        }
    }

    private void ReleasePendingMessage(PendingMessage pending)
    {
        if (pending == null)
        {
            return;
        }

        pending.RawBytes = null;
        pending.Message = null;
        _pendingMessagePool.Return(pending);
    }

    private void HandleTransportConnected()
    {
        bool wasReconnecting = _connectionController.HandleTransportConnected();
        _connectStartTime = -1f;
        _connectedAtTime = Time.time;
        _heartbeatController.OnConnected(Time.time);
        OnConnected?.Invoke();

        if (!wasReconnecting)
        {
            return;
        }

        OnReconnected?.Invoke();
        ResendPendingAfterReconnect();
    }

    private void HandleTransportDisconnected(string reason)
    {
        _connectedAtTime = -1f;
        _connectionController.HandleTransportDisconnected();
        _heartbeatController.OnDisconnected();
        _requestDispatcher.Clear("Connection lost.", (responseId, requestInstanceId, failureReason) =>
        {
            OnRequestFailed?.Invoke(responseId, failureReason);
            OnRequestFailedV2?.Invoke(responseId, requestInstanceId, failureReason);
        });

        if (_manualCloseRequested)
        {
            _manualCloseRequested = false;
            return;
        }

        if (_connectionController.ReconnectCancelled)
        {
            OnDisconnected?.Invoke();
            return;
        }

        if (_connectionController.IsReconnecting)
        {
            OnReconnecting?.Invoke();
            StartReconnect();
            return;
        }

        if (IsLongConnection)
        {
            OnConnectionLost?.Invoke();
            StartReconnect();
            return;
        }

        OnDisconnected?.Invoke();
    }

    private void HandleTransportError(string error)
    {
        Logger.Log($"Transport error: {error}", LogLevel.Error);
        OnConnectionFailed?.Invoke();

        if (IsLongConnection)
        {
            StartReconnect();
        }
    }

    private void HandleDataReceived(byte[] data)
    {
        _heartbeatController.OnDataReceived(Time.time);
        if (!_receiveBufferProcessor.Append(data))
        {
            Logger.Log("Receive buffer exceeded limit, dropping incoming data.", LogLevel.Error);
            return;
        }

        ProcessReceivedData();
    }

    private void ProcessReceivedData()
    {
        while (true)
        {
            if (!_receiveBufferProcessor.TryDequeue(Time.time, out var message, out var error))
            {
                break;
            }

            if (!string.IsNullOrEmpty(error))
            {
                Logger.Log(error, LogLevel.Error);
                if (error.StartsWith("Invalid packet size", StringComparison.Ordinal))
                {
                    CloseConnection();
                    return;
                }

                continue;
            }

            if (message == null)
            {
                continue;
            }

            if (message.IsAck)
            {
                HandleAck(message);
                continue;
            }

            if (_heartbeatController.TryHandleHeartbeatResponse(
                message,
                enableHeartbeatRequest,
                swallowHeartbeatResponse,
                Time.time,
                transportType,
                kcpDisconnectBaseTimeout,
                kcpDisconnectMinTimeout,
                kcpDisconnectMaxTimeout,
                kcpDisconnectRttMultiplier,
                timeout => kcpDisconnectTimeout = timeout))
            {
                continue;
            }

            if (message.ErrorCode != 0)
            {
                string errorMessage = string.IsNullOrEmpty(message.ErrorMessage) ? "Server error" : message.ErrorMessage;
                OnServerError?.Invoke(message.ErrorCode, errorMessage, message.MessageID);
                if (interceptServerError)
                {
                    continue;
                }
            }

            if (!ProtocolNames.ContainsKey(message.MessageID))
            {
                Logger.Log($"Unknown message id={message.MessageID}, ignored.", LogLevel.Warning);
                continue;
            }

            _diagnosticsService.LogTraffic("RECV", message);

            if (enableReliableDelivery && message.RequiresAck)
            {
                SendAck(message.SequenceId);
            }

            if (_frameSyncChannel.CanHandle(message))
            {
                _frameSyncChannel.Handle(message);
                continue;
            }

            if (_snapshotSyncChannel.CanHandle(message))
            {
                _snapshotSyncChannel.Handle(message);
                continue;
            }

            _requestDispatcher.Dispatch(message);
        }
    }

    private void HandleAck(NetMessage message)
    {
        if (_reliableDeliveryService.HandleAck(message.AckSequenceId) &&
            _pendingReliableMessages.TryGetValue(message.AckSequenceId, out var pending))
        {
            _pendingReliableMessages.Remove(message.AckSequenceId);
            ReleasePendingMessage(pending);
        }
    }

    private void SendAck(int sequenceId)
    {
        if (sequenceId <= 0)
        {
            return;
        }

        _reliableDeliveryService.QueueAck(sequenceId);
        if (_reliableDeliveryService.PendingAckCount >= maxAckPerFlush)
        {
            FlushAckQueue();
        }
    }

    private void FlushAckQueue()
    {
        _reliableDeliveryService.FlushAckQueue(maxAckPerFlush, sequenceId =>
        {
            NetMessage ackMessage = NetMessage.CreateAck(sequenceId);
            EnqueuePendingMessage(ackMessage);
        });
        _nextAckFlushTime = Time.time + ackFlushInterval;
    }

    private void CheckReliableMessages()
    {
        _reliableDeliveryService.CollectRetries(
            Time.time,
            reliableTimeout,
            reliableMaxRetry,
            resendJitter,
            (sequenceId, nextSendTime) =>
            {
                if (!_pendingReliableMessages.TryGetValue(sequenceId, out var pending))
                {
                    return;
                }

                pending.RetryCount++;
                pending.NextSendTime = nextSendTime;
                RequeuePendingMessage(pending);
            },
            sequenceId =>
            {
                if (!_pendingReliableMessages.TryGetValue(sequenceId, out var pending))
                {
                    return;
                }

                _pendingReliableMessages.Remove(sequenceId);
                ReleasePendingMessage(pending);
                OnReliableMessageDropped?.Invoke(sequenceId);
            });
    }

    private void ResendPendingAfterReconnect()
    {
        _reliableDeliveryService.RequeueAllAfterReconnect(Time.time, (sequenceId, nextSendTime) =>
        {
            if (!_pendingReliableMessages.TryGetValue(sequenceId, out var pending))
            {
                return;
            }

            pending.NextSendTime = nextSendTime;
            RequeuePendingMessage(pending);
        });
    }

    private void SendHeartbeatRequest()
    {
        if (_heartbeatController.HeartbeatRequestId <= 0)
        {
            if (enableDebugTrafficLog)
            {
                Logger.Log("[Network] Heartbeat request id is not configured.", LogLevel.Warning);
            }

            return;
        }

        if (!NetMessage.HasCachedToken)
        {
            if (enableDebugTrafficLog)
            {
                Logger.Log("[Network] No cached token, skipping heartbeat request.", LogLevel.Warning);
            }

            return;
        }

        _heartbeatController.MarkHeartbeatSent(Time.time);

        var request = new Heartbeat_c2s
        {
            IncludeProfile = false,
            ClientTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds()
        };

        if (enableDebugTrafficLog)
        {
            Logger.Log($"[Network] Sending heartbeat request (MsgId={_heartbeatController.HeartbeatRequestId}) Token={NetMessage.CachedToken}");
        }

        SendMessage<Heartbeat_s2c>(request, null, reliable: false, priority: 1);
    }

    private void HandleHeartbeatTimeout()
    {
        OnHeartbeatTimeout?.Invoke();
        StartReconnect();
    }

    private void StartReconnect()
    {
        _connectionController.TryStartReconnect(
            IsLongConnection,
            maxReconnectAttempts,
            reconnectDelay,
            maxReconnectDelay,
            () => OnReconnectFailed?.Invoke(),
            Connect);
    }

    private void ClearPendingMessages()
    {
        _sendQueue.Drain(ReleasePendingMessage);

        if (_pendingReliableMessages.Count > 0)
        {
            foreach (var pending in _pendingReliableMessages.Values)
            {
                ReleasePendingMessage(pending);
            }

            _pendingReliableMessages.Clear();
        }

        _reliableDeliveryService.Clear();
    }

    private void OnDestroy()
    {
        _connectionController.Dispose(
            HandleTransportConnected,
            HandleTransportDisconnected,
            HandleTransportError,
            HandleDataReceived);
        ClearPendingMessages();
        _pendingMessagePool.Clear();
        _receiveBufferProcessor?.Reset();
    }
}

