﻿using System;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;

public class NetMessage
{
    public int MessageID { get; set; }
    public object Data { get; set; }
    public string DataType { get; set; }
    public int SequenceId { get; set; }
    public bool RequiresAck { get; set; }
    public bool IsAck { get; set; }
    public int AckSequenceId { get; set; }
    public int Priority { get; set; }
    public bool IsChunk { get; set; }
    public int ChunkId { get; set; }
    public int ChunkIndex { get; set; }
    public int ChunkTotal { get; set; }
    public string Token { get; set; }
    public int ErrorCode { get; set; }
    public string ErrorMessage { get; set; }

    private const string TokenPrefsKey = "NetworkManager_GlobalToken";
    private const string TokenExpirePrefsKey = "NetworkManager_GlobalTokenExpire";
    private static readonly object TokenLock = new object();
    private static string _cachedToken;
    private static long _cachedTokenExpireAt;

    static NetMessage()
    {
        _cachedToken = PlayerPrefs.GetString(TokenPrefsKey, string.Empty);

        string expireRaw = PlayerPrefs.GetString(TokenExpirePrefsKey, "0");
        if (!long.TryParse(expireRaw, out _cachedTokenExpireAt))
        {
            _cachedTokenExpireAt = 0;
        }
    }

    public static string CachedToken
    {
        get
        {
            lock (TokenLock)
            {
                return _cachedToken;
            }
        }
    }

    public static long CachedTokenExpireAt
    {
        get
        {
            lock (TokenLock)
            {
                return _cachedTokenExpireAt;
            }
        }
    }

    public static bool HasCachedToken => !string.IsNullOrEmpty(CachedToken);

    public static void CacheToken(string token, long expireAt = 0, bool persist = true)
    {
        if (string.IsNullOrEmpty(token))
        {
            return;
        }

        lock (TokenLock)
        {
            _cachedToken = token;
            _cachedTokenExpireAt = expireAt;
        }

        if (persist)
        {
            PlayerPrefs.SetString(TokenPrefsKey, token);
            PlayerPrefs.SetString(TokenExpirePrefsKey, expireAt.ToString());
            PlayerPrefs.Save();
        }
    }

    public static void ClearCachedToken(bool clearPersistent = true)
    {
        lock (TokenLock)
        {
            _cachedToken = null;
            _cachedTokenExpireAt = 0;
        }

        if (clearPersistent)
        {
            PlayerPrefs.DeleteKey(TokenPrefsKey);
            PlayerPrefs.DeleteKey(TokenExpirePrefsKey);
            PlayerPrefs.Save();
        }
    }

    public static bool EnsureTokenForPayload(object payload)
    {
        if (payload == null)
        {
            return false;
        }

        PropertyInfo tokenProperty = payload.GetType().GetProperty("Token");
        if (tokenProperty == null || !tokenProperty.CanWrite)
        {
            return HasCachedToken;
        }

        string current = tokenProperty.GetValue(payload) as string;
        if (!string.IsNullOrEmpty(current))
        {
            return true;
        }

        string token = CachedToken;
        if (string.IsNullOrEmpty(token))
        {
            return false;
        }

        tokenProperty.SetValue(payload, token);
        return true;
    }

    public NetMessage(object data, int sequenceId = 0, bool requiresAck = false, int priority = 1)
    {
        if (data == null)
        {
            throw new ArgumentNullException(nameof(data));
        }

        string typeName = data.GetType().Name;
        if (!ProtocolDictionary.Protocols.TryGetValue(typeName, out var messageId))
        {
            throw new ArgumentException($"Protocol type was not found in ProtocolDictionary: {typeName}. Regenerate GeneratedProtocols first.");
        }

        MessageID = messageId;
        DataType = data.GetType().AssemblyQualifiedName;
        AttachTokenIfNeeded(data);
        Data = NetworkPayloadPipeline.Encode(data);
        SequenceId = sequenceId;
        RequiresAck = requiresAck;
        Priority = priority;

        string token = CachedToken;
        if (!string.IsNullOrEmpty(token))
        {
            Token = token;
        }
    }

    public NetMessage()
    {
    }

    /// <summary>
    /// </summary>
    public byte[] Serialize()
    {
        byte[] bodyBytes = SerializeBody();

        byte[] lengthBytes = BitConverter.GetBytes(bodyBytes.Length);
        if (BitConverter.IsLittleEndian) Array.Reverse(lengthBytes);

        byte[] messageBytes = new byte[lengthBytes.Length + bodyBytes.Length];
        Buffer.BlockCopy(lengthBytes, 0, messageBytes, 0, lengthBytes.Length);
        Buffer.BlockCopy(bodyBytes, 0, messageBytes, lengthBytes.Length, bodyBytes.Length);

        return messageBytes;
    }

    /// <summary>
    /// </summary>
    public byte[] SerializeBody()
    {
        string json = JsonConvert.SerializeObject(this);
        return Encoding.UTF8.GetBytes(json);
    }

    public static NetMessage Deserialize(byte[] bodyBytes)
    {
        if (bodyBytes == null)
        {
            return null;
        }
        string json = Encoding.UTF8.GetString(bodyBytes, 0, bodyBytes.Length);
        return JsonConvert.DeserializeObject<NetMessage>(json);
    }

    public static NetMessage Deserialize(byte[] bodyBytes, int length)
    {
        if (bodyBytes == null || length <= 0)
        {
            return null;
        }
        string json = Encoding.UTF8.GetString(bodyBytes, 0, length);
        return JsonConvert.DeserializeObject<NetMessage>(json);
    }

    public static T DeserializeData<T>(object data) where T : class
    {
        if (data == null)
        {
            return null;
        }

        try
        {
            object value = NetworkPayloadPipeline.Decode(data.ToString(), typeof(T));
            return value as T;
        }
        catch (Exception ex)
        {
            Logger.Log($"Failed to deserialize {typeof(T).Name}: {ex.Message}. Raw={data}", LogLevel.Error);
            return null;
        }
    }

    public static object DeserializeData(NetMessage message)
    {
        if (message?.Data == null || string.IsNullOrEmpty(message.DataType))
        {
            return null;
        }

        Type resolvedType = Type.GetType(message.DataType);

        if (resolvedType == null)
        {
            string simpleName = message.DataType.Split(',')[0].Trim();
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                resolvedType = asm.GetType(simpleName, throwOnError: false, ignoreCase: false);
                if (resolvedType != null)
                {
                    break;
                }
            }
        }

        if (resolvedType == null)
        {
            Logger.Log($"Failed to resolve data type: {message.DataType}. Raw={message.Data}", LogLevel.Error);
            return null;
        }

        try
        {
            return NetworkPayloadPipeline.Decode(message.Data.ToString(), resolvedType);
        }
        catch (Exception ex)
        {
            Logger.Log($"Failed to deserialize {resolvedType.Name}: {ex.Message}. Raw={message.Data}", LogLevel.Error);
            return null;
        }
    }

    public static NetMessage CreateAck(int sequenceId)
    {
        return new NetMessage
        {
            IsAck = true,
            AckSequenceId = sequenceId,
            SequenceId = sequenceId,
            MessageID = -1,
            Data = null,
            RequiresAck = false,
            Priority = 0,
            Token = null
        };
    }

    private static void AttachTokenIfNeeded(object payload)
    {
        EnsureTokenForPayload(payload);
    }
}
