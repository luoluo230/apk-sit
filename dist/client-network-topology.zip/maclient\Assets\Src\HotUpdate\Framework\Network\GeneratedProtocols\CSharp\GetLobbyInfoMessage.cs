﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取大厅信息请求
/// </summary>
public class GetLobbyInfo_c2s
{
}

/// <summary>
/// 获取大厅信息响应
/// </summary>
public class GetLobbyInfo_s2c
{
    /// <summary>
    /// 大厅信息
    /// </summary>
    public LobbyInfo Lobby { get; set; }
}

