// 自动生成的协议文件

// 定义协议类


// 获取玩家信息请求协议
class GetUserInfo_c2s {
    constructor() {
        this.Username = '';
        this.Password = '';
        this.DeviceInfo = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 获取玩家信息响应协议
class GetUserInfo_s2c {
    constructor() {
        this.Username = '';
        this.Password = '';
        this.DeviceInfo = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetUserInfo_c2s,
    GetUserInfo_s2c,
};
