﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 塔扫荡(已通关层快速结算)
/// </summary>
public class SweepTower_c2s
{
    /// <summary>
    /// 塔 ID
    /// </summary>
    public int TowerId { get; set; }
    /// <summary>
    /// 要扫荡的层数
    /// </summary>
    public int Floor { get; set; }
    /// <summary>
    /// 扫荡次数
    /// </summary>
    public int Times { get; set; }
}

/// <summary>
/// 塔扫荡结果
/// </summary>
public class SweepTower_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 总奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
}

