// 自动生成的协议文件

// 定义协议类


// 获取竞技场战报列表
class GetArenaRecords_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 竞技场战报响应
class GetArenaRecords_s2c {
    constructor() {
        this.Records = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetArenaRecords_c2s,
    GetArenaRecords_s2c,
};
