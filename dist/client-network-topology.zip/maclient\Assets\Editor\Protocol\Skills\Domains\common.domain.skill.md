# Common Domain Skill

- Generate conservative business skeletons when protocol semantics are unclear.
- Prefer explicit extension points over invented behavior.
- Client code should expose stable UseCase methods and keep UI samples thin.
- Server code should validate request shape, map errors, log begin/end/exception, and call service/repository through interfaces.
