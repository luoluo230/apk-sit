public static class GameNetworkErrorCodes
{
    public const string Unknown = "UNKNOWN";
    public const string TransportNotReady = "TRANSPORT_NOT_READY";
    public const string TokenMissing = "TOKEN_MISSING";
    public const string RequestTimeout = "REQUEST_TIMEOUT";
    public const string EmptyResponse = "EMPTY_RESPONSE";
    public const string ConnectionLost = "CONNECTION_LOST";
    public const string BusinessFailed = "BUSINESS_FAILED";
    public const string InvalidArgument = "INVALID_ARGUMENT";
    public const string SerializerNotFound = "SERIALIZER_NOT_FOUND";
    public const string SerializerError = "SERIALIZER_ERROR";
    public const string CompressionError = "COMPRESSION_ERROR";
    public const string EncryptionError = "ENCRYPTION_ERROR";
    public const string SimulationConfigInvalid = "SIMULATION_CONFIG_INVALID";
}
