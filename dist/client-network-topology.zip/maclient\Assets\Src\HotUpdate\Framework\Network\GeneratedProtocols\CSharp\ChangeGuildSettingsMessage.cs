﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 修改公会设置(公告/条件)
/// </summary>
public class ChangeGuildSettings_c2s
{
    /// <summary>
    /// 公告(可选)
    /// </summary>
    public string Notice { get; set; }
    /// <summary>
    /// 入会最低战力(可选)
    /// </summary>
    public int RequirePower { get; set; }
    /// <summary>
    /// 是否需要审批(可选)
    /// </summary>
    public bool RequireVerify { get; set; }
}

/// <summary>
/// 修改公会设置结果
/// </summary>
public class ChangeGuildSettings_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

