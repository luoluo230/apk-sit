﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 请求加入战斗观战会话
/// </summary>
public class BattleSpectatorJoin_c2s
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 回放 ID(可选，优先实时战斗)
    /// </summary>
    public string ReplayId { get; set; }
    /// <summary>
    /// 观战起始帧(0表示由服务端决定)
    /// </summary>
    public int StartFrame { get; set; }
    /// <summary>
    /// 延迟模式(LowLatency/Stable)
    /// </summary>
    public string LatencyMode { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 加入战斗观战会话响应
/// </summary>
public class BattleSpectatorJoin_s2c
{
    /// <summary>
    /// 处理结果
    /// </summary>
    public BattleProtocolAck Ack { get; set; }
    /// <summary>
    /// 观战会话信息
    /// </summary>
    public BattleSpectatorSession Session { get; set; }
    /// <summary>
    /// 观战锚点
    /// </summary>
    public BattleTimelineAnchor Anchor { get; set; }
    /// <summary>
    /// 观战预热帧片段
    /// </summary>
    public BattleFrameBundle[] WarmupFrames { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

