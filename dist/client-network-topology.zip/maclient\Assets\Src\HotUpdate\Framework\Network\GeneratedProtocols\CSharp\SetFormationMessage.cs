﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 设置阵容(主线/竞技场/公会Boss等共用)
/// </summary>
public class SetFormation_c2s
{
    /// <summary>
    /// 阵容类型(Campaign/ArenaDefense/GuildBoss等)
    /// </summary>
    public string FormationType { get; set; }
    /// <summary>
    /// 阵容槽位配置
    /// </summary>
    public FormationSlot[] Slots { get; set; }
}

/// <summary>
/// 设置阵容结果
/// </summary>
public class SetFormation_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 阵容类型
    /// </summary>
    public string FormationType { get; set; }
    /// <summary>
    /// 最终生效的阵容
    /// </summary>
    public FormationSlot[] Slots { get; set; }
}

