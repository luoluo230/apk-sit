﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 领取挂机收益/快速战斗奖励
/// </summary>
public class ClaimAfkReward_c2s
{
    /// <summary>
    /// 是否使用快速战斗(额外消耗)
    /// </summary>
    public bool UseQuickReward { get; set; }
    /// <summary>
    /// 快速战斗次数(0或1/多次)
    /// </summary>
    public int QuickRewardTimes { get; set; }
}

/// <summary>
/// 挂机收益领取结果
/// </summary>
public class ClaimAfkReward_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 领取到的所有奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 资源变更
    /// </summary>
    public ResourceChange[] ResourceChanges { get; set; }
    /// <summary>
    /// 更新后的挂机信息
    /// </summary>
    public AfkRewardInfo Afk { get; set; }
}

