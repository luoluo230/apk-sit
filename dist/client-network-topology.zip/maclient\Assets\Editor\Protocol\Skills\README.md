# Protocol Skills

`Assets/Editor/Protocol/Skills` 是 M09-07A Protocol Skill Codegen 的 AI 约束包。工作台生成 AI Payload 时会按固定顺序读取这些规则，用来约束 AI 生成客户端/服务端业务接入代码。

## 目录结构

- `Capabilities/`：标准生成能力。回答“要生成哪一层代码”，例如客户端 API、UseCase、服务端 Handler、Repository。
- `Support/`：跨所有协议都成立的硬约束。回答“所有生成代码都必须遵守什么”，例如网络策略、事务、日志、测试。
- `Domains/`：宽泛业务领域。回答“协议大概属于哪个业务域”，例如 Login、Inventory、Battle、Social、Shop。
- `Scenarios/`：具体业务场景。回答“这条协议像什么业务动作”，例如支付订单、奖励领取、背包变更、战斗结算。

## 读取顺序

1. `Support` 全局硬约束。
2. 工作台勾选的 `Capabilities`。
3. 自动推断出的 `Domains`。
4. 根据协议名和字段匹配出的 `Scenarios`。
5. 当前协议的结构化上下文、DTO 路径、ProtocolIds、网络调用方式和待写文件清单。

## 去重原则

- Capability 不写具体业务流程，只写代码层职责。
- Support 不写某个业务域，只写全局质量门禁。
- Domain 不写完整闭环，只写宽泛领域默认规则。
- Scenario 承载具体业务闭环，是支付、领奖、背包变更、战斗结算、排行榜提交等高风险规则的主要位置。

## 扩展建议

- 要新增“生成能力”，放到 `Capabilities/Client`、`Capabilities/Server` 或 `Capabilities/Shared`，并在 `ProtocolSkillRegistry` 注册。
- 要新增“所有协议都要遵守的规则”，放到 `Support`，文件名使用数字前缀控制读取顺序。
- 要新增“宽泛业务域”，放到 `Domains`，并在 `ProtocolSkillBusinessDomain` 和 `ProtocolSkillDomainRegistry` 注册。
- 要新增“具体业务动作”，优先放到 `Scenarios` 对应分类，并在 `ProtocolSkillScenarioRegistry` 增加协议名关键词和字段关键词。

## 使用边界

这套 Skill 可以生成可落地的业务接入骨架，但不会替代人工确认经济数值、权限规则、事务策略、数据库迁移和支付发货等高风险业务决策。遇到不确定项目框架时，Skill 会要求 AI 生成可替换接口或明确接入 TODO，而不是臆造不存在的类。
