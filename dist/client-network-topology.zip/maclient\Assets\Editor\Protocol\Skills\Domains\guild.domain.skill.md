# Guild Domain Skill

- Client: generate guild list/apply/manage use cases with member list refresh and notification hooks.
- Server: generate guild permission checks, membership status checks, applicant/member repository hooks, and guild event log placeholders.
- Role/permission decisions must be server-authoritative.
