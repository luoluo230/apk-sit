﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 设置竞技场防守阵容
/// </summary>
public class SetArenaDefense_c2s
{
    /// <summary>
    /// 防守阵容
    /// </summary>
    public FormationSlot[] Formation { get; set; }
}

/// <summary>
/// 设置竞技场防守阵容结果
/// </summary>
public class SetArenaDefense_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

