// 自动生成的协议文件

// 定义协议类


// 离开队伍
class LeaveTeam_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 离开队伍结果
class LeaveTeam_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    LeaveTeam_c2s,
    LeaveTeam_s2c,
};
