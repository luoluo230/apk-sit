﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取邮件列表
/// </summary>
public class GetMailList_c2s
{
}

/// <summary>
/// 邮件列表响应
/// </summary>
public class GetMailList_s2c
{
    /// <summary>
    /// 邮件列表
    /// </summary>
    public MailInfo[] Mails { get; set; }
}

