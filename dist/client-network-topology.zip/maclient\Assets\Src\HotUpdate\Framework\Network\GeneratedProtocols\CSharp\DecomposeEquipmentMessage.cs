﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 装备分解/提炼
/// </summary>
public class DecomposeEquipment_c2s
{
    /// <summary>
    /// 要分解的装备 ID 列表
    /// </summary>
    public long[] EquipmentIds { get; set; }
}

/// <summary>
/// 装备分解结果
/// </summary>
public class DecomposeEquipment_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 获得的资源/材料
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 装备移除变更
    /// </summary>
    public InventoryDelta InventoryDelta { get; set; }
}

