﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 英雄升星(消耗同名卡/素材)
/// </summary>
public class UpgradeHeroStar_c2s
{
    /// <summary>
    /// 目标英雄 ID
    /// </summary>
    public long HeroId { get; set; }
    /// <summary>
    /// 作为素材的英雄 ID 列表
    /// </summary>
    public long[] ConsumeHeroes { get; set; }
    /// <summary>
    /// 额外消耗的道具
    /// </summary>
    public ItemCost[] ConsumeItems { get; set; }
}

/// <summary>
/// 英雄升星结果
/// </summary>
public class UpgradeHeroStar_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 失败原因
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 升星后的英雄数据
    /// </summary>
    public HeroInfo Hero { get; set; }
    /// <summary>
    /// 被消耗掉的英雄 ID
    /// </summary>
    public long[] RemovedHeroIds { get; set; }
    /// <summary>
    /// 消耗道具变化
    /// </summary>
    public InventoryDelta InventoryDelta { get; set; }
    /// <summary>
    /// 资源变化
    /// </summary>
    public ResourceChange[] ResourceChanges { get; set; }
}

