// 自动生成的协议文件

// 定义协议类


// 英雄重置(还原等级返还资源)
class ResetHero_c2s {
    constructor() {
        this.HeroId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 英雄重置结果
class ResetHero_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Hero = null;
        this.RefundRewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ResetHero_c2s,
    ResetHero_s2c,
};
