﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 公会成员列表变化通知(入会/离会/职位变化)
/// </summary>
public class GuildMemberUpdateNotify_s2c
{
    /// <summary>
    /// 最新成员列表(或增量)
    /// </summary>
    public GuildMemberInfo[] Members { get; set; }
}

