/// <summary>
/// 网络层统一错误码定义。
/// 上层 UI 和埋点可以基于这些错误码做归类处理。
/// </summary>
public static class NetworkErrorCode
{
    public const int ConnectionFailed = 1001;
    public const int Disconnected = 1002;
    public const int ReconnectFailed = 1003;
    public const int HeartbeatTimeout = 1004;
    public const int SendQueueOverflow = 1005;
    public const int RequestTimeout = 1006;
    public const int RequestFailed = 1007;
    public const int TokenExpired = 1008;
    public const int ServerMaintenance = 1009;
    public const int ServerBusy = 1010;
}
