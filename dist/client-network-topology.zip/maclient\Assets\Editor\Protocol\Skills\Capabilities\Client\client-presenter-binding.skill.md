# Client Presenter Binding Skill

## 职责

生成 UI/Presenter 调用示例，展示开发者如何接入 UseCase，不绑定项目中不存在的具体 UI 框架。

## 必须生成

- Presenter sample 或调用片段。
- 按钮点击/页面打开/刷新请求的典型调用。
- loading、成功、失败、取消、重试提示的接入位置。
- 字段到 UI view model 的映射示例。

## 约束

- 示例代码必须薄，不包含真实页面生命周期假设。
- 不直接引用未知 UI 框架类。
- 不在 Presenter 里拼 DTO。
- 不在 Presenter 里写数据库或服务端逻辑。

## 质量门禁

- 开发者能复制调用方式接入真实页面。
- 未实现的 UI 操作必须通过接口或注释标明替换点。
