using System;
using System.Globalization;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

public sealed class ProtocolOpenAiCompatibleSkillInvoker : IProtocolSkillAiInvoker
{
    private readonly string _endpoint;
    private readonly string _apiKey;
    private readonly string _model;
    private readonly float _temperature;
    private readonly int _timeoutSeconds;
    private readonly int _maxTokens;
    private readonly Action<string, float> _progress;
    private readonly Func<bool> _cancelRequested;

    public ProtocolOpenAiCompatibleSkillInvoker(string endpoint, string apiKey, string model, float temperature = 0.2f, int timeoutSeconds = 600, int maxTokens = 8192, Action<string, float> progress = null, Func<bool> cancelRequested = null)
    {
        _endpoint = endpoint;
        _apiKey = apiKey;
        _model = model;
        _temperature = temperature;
        _timeoutSeconds = Math.Max(10, timeoutSeconds);
        _maxTokens = Math.Max(0, maxTokens);
        _progress = progress;
        _cancelRequested = cancelRequested;
    }

    public ProtocolSkillAiResponse Invoke(ProtocolSkillAiRequest request)
    {
        var response = new ProtocolSkillAiResponse();
        if (string.IsNullOrWhiteSpace(_endpoint)) { response.Message = "AI endpoint is empty."; return response; }
        if (string.IsNullOrWhiteSpace(_apiKey)) { response.Message = "AI api key is empty."; return response; }

        using (var webRequest = new UnityWebRequest(_endpoint, UnityWebRequest.kHttpVerbPOST))
        {
            _progress?.Invoke("正在构建 AI 请求...", 0.05f);
            byte[] bytes = Encoding.UTF8.GetBytes(BuildRequestBody(request));
            webRequest.uploadHandler = new UploadHandlerRaw(bytes);
            webRequest.downloadHandler = new DownloadHandlerBuffer();
            webRequest.timeout = _timeoutSeconds;
            webRequest.SetRequestHeader("Content-Type", "application/json");
            webRequest.SetRequestHeader("Authorization", "Bearer " + _apiKey);
            _progress?.Invoke("已发送请求，等待 AI 响应...", 0.1f);
            UnityWebRequestAsyncOperation operation = webRequest.SendWebRequest();
            DateTime startedAt = DateTime.UtcNow;
            while (!operation.isDone)
            {
                if (_cancelRequested != null && _cancelRequested())
                {
                    webRequest.Abort();
                    response.Message = "AI request cancelled by user.";
                    response.Warnings.Add("当前文件还没有完成，结果没有合并到生成计划。");
                    return response;
                }

                double elapsed = (DateTime.UtcNow - startedAt).TotalSeconds;
                float progress = Mathf.Clamp((float)(elapsed / Math.Max(1, _timeoutSeconds)), 0.1f, 0.95f);
                _progress?.Invoke("等待 AI 响应 " + (int)elapsed + "s / " + _timeoutSeconds + "s", progress);
                System.Threading.Thread.Sleep(100);
            }
            if (webRequest.result != UnityWebRequest.Result.Success)
            {
                response.Message = "AI request failed: " + webRequest.error + " (timeout=" + _timeoutSeconds + "s)\n" + webRequest.downloadHandler.text;
                response.RawResponseJson = webRequest.downloadHandler.text;
                return response;
            }

            _progress?.Invoke("AI 已返回，正在解析文件计划...", 0.97f);
            response.RawResponseJson = webRequest.downloadHandler.text;
            string content = ExtractAssistantContent(webRequest.downloadHandler.text);
            response.RawAssistantContent = content;
            ParsePlanFiles(content, response);
            response.Success = response.Files.Count > 0;
            response.Message = response.Success ? "AI returned " + response.Files.Count + " file(s)." : content;
            if (!response.Success) response.Warnings.Add("AI response is not strict file JSON. The raw response is kept in Message.");
            return response;
        }
    }

    public ProtocolOpenAiCompatibleSkillAsyncOperation BeginInvoke(ProtocolSkillAiRequest request)
    {
        var invalidResponse = new ProtocolSkillAiResponse();
        if (string.IsNullOrWhiteSpace(_endpoint)) { invalidResponse.Message = "AI endpoint is empty."; return ProtocolOpenAiCompatibleSkillAsyncOperation.FromCompleted(invalidResponse); }
        if (string.IsNullOrWhiteSpace(_apiKey)) { invalidResponse.Message = "AI api key is empty."; return ProtocolOpenAiCompatibleSkillAsyncOperation.FromCompleted(invalidResponse); }

        var webRequest = new UnityWebRequest(_endpoint, UnityWebRequest.kHttpVerbPOST);
        string requestBody = BuildRequestBody(request);
        byte[] bytes = Encoding.UTF8.GetBytes(requestBody);
        webRequest.uploadHandler = new UploadHandlerRaw(bytes);
        webRequest.downloadHandler = new DownloadHandlerBuffer();
        webRequest.timeout = _timeoutSeconds;
        webRequest.SetRequestHeader("Content-Type", "application/json");
        webRequest.SetRequestHeader("Authorization", "Bearer " + _apiKey);
        UnityWebRequestAsyncOperation operation = webRequest.SendWebRequest();
        return new ProtocolOpenAiCompatibleSkillAsyncOperation(webRequest, operation, _timeoutSeconds, requestBody);
    }

    internal static ProtocolSkillAiResponse BuildResponseFromWebRequest(UnityWebRequest webRequest, int timeoutSeconds)
    {
        var response = new ProtocolSkillAiResponse();
        if (webRequest.result != UnityWebRequest.Result.Success)
        {
            response.Message = "AI request failed: " + webRequest.error + " (timeout=" + timeoutSeconds + "s)\n" + webRequest.downloadHandler.text;
            response.RawResponseJson = webRequest.downloadHandler.text;
            return response;
        }

        response.RawResponseJson = webRequest.downloadHandler.text;
        string content = ExtractAssistantContent(webRequest.downloadHandler.text);
        response.RawAssistantContent = content;
        ParsePlanFiles(content, response);
        response.Success = response.Files.Count > 0;
        response.Message = response.Success ? "AI returned " + response.Files.Count + " file(s)." : content;
        if (!response.Success) response.Warnings.Add("AI response is not strict file JSON. The raw response is kept in Message.");
        return response;
    }

    public string BuildRequestBodyForLog(ProtocolSkillAiRequest request)
    {
        return BuildRequestBody(request);
    }

    private string BuildRequestBody(ProtocolSkillAiRequest request)
    {
        string system = "You are Protocol Business Logic Studio. Return strict JSON only: {\"files\":[{\"path\":\"relative/path.cs\",\"skill\":\"SkillName\",\"reason\":\"why\",\"content\":\"full file content\"}],\"warnings\":[]}. Do not regenerate DTO, ProtocolIds or ProtocolDictionary. Generated business code must include detailed Chinese comments for classes, methods, parameters, error handling, retry/cache/transaction boundaries and manual TODO points. The generated file must fit the whole integration chain: references/usings, constructors, dependency composition, event subscribe/unsubscribe, client feature entry, server route registration and handler-service-repository-db model wiring. The goal is that developers only fill concrete business rules and UI presentation.";
        string user = (request?.PromptMarkdown ?? string.Empty) + "\n\nJSON Context:\n" + (request?.PromptJson ?? string.Empty);
        if (!string.IsNullOrWhiteSpace(request?.CompileErrorFeedback)) user += "\n\nCompile errors to fix:\n" + request.CompileErrorFeedback;
        if (!string.IsNullOrWhiteSpace(request?.PreviousAiOutput)) user += "\n\nPrevious AI output:\n" + request.PreviousAiOutput;
        return "{"
            + "\"model\":\"" + ProtocolJson.Escape(string.IsNullOrWhiteSpace(_model) ? "gpt-5.4" : _model) + "\","
            + "\"temperature\":" + _temperature.ToString("0.###", CultureInfo.InvariantCulture) + ","
            + (_maxTokens > 0 ? "\"max_tokens\":" + _maxTokens.ToString(CultureInfo.InvariantCulture) + "," : string.Empty)
            + "\"messages\":["
            + "{\"role\":\"system\",\"content\":\"" + ProtocolJson.Escape(system) + "\"},"
            + "{\"role\":\"user\",\"content\":\"" + ProtocolJson.Escape(user) + "\"}"
            + "]}";
    }

    private static string ExtractAssistantContent(string json)
    {
        if (!ProtocolJson.TryParse(json, out ProtocolJsonValue value, out _) || !(value is ProtocolJsonObject root)) return string.Empty;
        ProtocolJsonArray choices = root.GetArray("choices");
        if (choices == null || choices.Items.Count == 0 || !(choices.Items[0] is ProtocolJsonObject choice)) return string.Empty;
        return choice.GetObject("message")?.GetString("content", string.Empty) ?? string.Empty;
    }

    private static void ParsePlanFiles(string content, ProtocolSkillAiResponse response)
    {
        string json = StripMarkdownFence(content);
        if (!ProtocolJson.TryParse(json, out ProtocolJsonValue value, out _) || !(value is ProtocolJsonObject root)) return;
        ProtocolJsonArray warnings = root.GetArray("warnings");
        if (warnings != null)
        {
            foreach (ProtocolJsonValue item in warnings.Items) if (item is ProtocolJsonString warning) response.Warnings.Add(warning.Value);
        }
        ProtocolJsonArray files = root.GetArray("files");
        if (files == null) return;
        foreach (ProtocolJsonValue item in files.Items)
        {
            if (!(item is ProtocolJsonObject file)) continue;
            response.Files.Add(new ProtocolSkillPlanFile
            {
                Path = file.GetString("path", string.Empty),
                Skill = file.GetString("skill", "AiSkill"),
                Reason = file.GetString("reason", "AI generated"),
                Action = "ai-generated",
                Content = file.GetString("content", string.Empty)
            });
        }
    }

    private static string StripMarkdownFence(string content)
    {
        string value = (content ?? string.Empty).Trim();
        if (!value.StartsWith("```", StringComparison.Ordinal)) return value;
        int firstLine = value.IndexOf('\n');
        int lastFence = value.LastIndexOf("```", StringComparison.Ordinal);
        return firstLine < 0 || lastFence <= firstLine ? value : value.Substring(firstLine + 1, lastFence - firstLine - 1).Trim();
    }
}

public sealed class ProtocolOpenAiCompatibleSkillAsyncOperation : IDisposable
{
    private readonly UnityWebRequest _webRequest;
    private readonly UnityWebRequestAsyncOperation _operation;
    private readonly int _timeoutSeconds;
    private readonly DateTime _startedAtUtc;
    private bool _cancelRequested;

    public ProtocolOpenAiCompatibleSkillAsyncOperation(UnityWebRequest webRequest, UnityWebRequestAsyncOperation operation, int timeoutSeconds, string requestBody)
    {
        _webRequest = webRequest;
        _operation = operation;
        _timeoutSeconds = Math.Max(10, timeoutSeconds);
        _startedAtUtc = DateTime.UtcNow;
        RequestBody = requestBody ?? string.Empty;
    }

    private ProtocolOpenAiCompatibleSkillAsyncOperation(ProtocolSkillAiResponse completedResponse)
    {
        _timeoutSeconds = 10;
        _startedAtUtc = DateTime.UtcNow;
        RequestBody = string.Empty;
        Response = completedResponse;
        IsDone = true;
    }

    public bool IsDone { get; private set; }
    public ProtocolSkillAiResponse Response { get; private set; }
    public string RequestBody { get; private set; }
    public float Progress { get; private set; }
    public double ElapsedSeconds => (DateTime.UtcNow - _startedAtUtc).TotalSeconds;

    public static ProtocolOpenAiCompatibleSkillAsyncOperation FromCompleted(ProtocolSkillAiResponse response)
    {
        return new ProtocolOpenAiCompatibleSkillAsyncOperation(response);
    }

    public void Cancel()
    {
        _cancelRequested = true;
        _webRequest?.Abort();
    }

    public void Tick()
    {
        if (IsDone) return;
        if (_cancelRequested)
        {
            CompleteCancelled();
            return;
        }

        float timeProgress = Mathf.Clamp((float)(ElapsedSeconds / Math.Max(1, _timeoutSeconds)), 0.1f, 0.95f);
        float requestProgress = _operation != null ? Mathf.Clamp01(_operation.progress) : 0f;
        Progress = Mathf.Max(timeProgress, requestProgress);
        if (_operation == null || !_operation.isDone) return;
        Response = ProtocolOpenAiCompatibleSkillInvoker.BuildResponseFromWebRequest(_webRequest, _timeoutSeconds);
        IsDone = true;
    }

    public void Dispose()
    {
        _webRequest?.Dispose();
    }

    private void CompleteCancelled()
    {
        Response = new ProtocolSkillAiResponse { Message = "AI request cancelled by user." };
        Response.RawAssistantContent = "AI request cancelled by user.";
        Response.Warnings.Add("当前文件还没有完成，结果没有合并到生成计划。");
        IsDone = true;
    }
}
