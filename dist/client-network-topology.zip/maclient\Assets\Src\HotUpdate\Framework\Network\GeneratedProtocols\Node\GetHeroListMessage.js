// 自动生成的协议文件

// 定义协议类


// 获取英雄列表
class GetHeroList_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 英雄列表响应
class GetHeroList_s2c {
    constructor() {
        this.Heroes = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetHeroList_c2s,
    GetHeroList_s2c,
};
