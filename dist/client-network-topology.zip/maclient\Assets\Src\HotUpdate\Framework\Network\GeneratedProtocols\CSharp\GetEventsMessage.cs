﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取活动列表请求
/// </summary>
public class GetEvents_c2s
{
}

/// <summary>
/// 获取活动列表响应
/// </summary>
public class GetEvents_s2c
{
    /// <summary>
    /// 活动列表
    /// </summary>
    public EventInfo[] Events { get; set; }
}

