// 自动生成的协议文件

// 定义协议类


// 拾取物品
class PickUpItem_c2s {
    constructor() {
        this.ItemId = null;
        this.Quantity = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 拾取物品结果
class PickUpItem_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Inventory = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    PickUpItem_c2s,
    PickUpItem_s2c,
};
