using UnityEngine;

/// <summary>
/// 网络运行时核心（对外新命名）。
/// 该类型是对旧 NetworkManager 的语义化别名，便于跨项目复用时理解职责。
/// </summary>
[AddComponentMenu("")]
public class NetworkRuntimeCore : NetworkManager
{
}

