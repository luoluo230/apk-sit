﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 英雄数据同步(升级/升星/获取/分解等)
/// </summary>
public class SyncHero_s2c
{
    /// <summary>
    /// 新增或变化的英雄
    /// </summary>
    public HeroInfo[] UpdatedHeroes { get; set; }
    /// <summary>
    /// 被删除/分解的英雄 ID
    /// </summary>
    public long[] RemovedHeroIds { get; set; }
    /// <summary>
    /// 变更原因
    /// </summary>
    public string Reason { get; set; }
}

