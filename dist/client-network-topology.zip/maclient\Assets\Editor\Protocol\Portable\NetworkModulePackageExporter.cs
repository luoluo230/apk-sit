using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

/// <summary>
/// 网络模块可移植导出器。
/// 一键导出“编辑器 + 运行时 + 协议配置”为 unitypackage，便于跨项目复用。
/// </summary>
public static class NetworkModulePackageExporter
{
    private static readonly string[] ExportRoots =
    {
        "Assets/Src/HotUpdate/Framework/Network",
        "Assets/Src/HotUpdate/Game/Network",
        "Assets/Editor/Protocol/Workbench",
        "Assets/Editor/Protocol/Generation",
        "Assets/Editor/Protocol/Portable",
        "Assets/Src/Protocols/protocols.json",
        "Assets/Src/Protocols/protocol-core-required-list.json",
        "Assets/Src/Protocols/protocol-business-extension-list.json",
        "Assets/Resources/Protocol/ProtocolNetworkSettings.asset"
    };

    [MenuItem("Tools/MAClient/协议与网络/导出网络模块复用包", priority = 12)]
    public static void ExportNetworkModulePackage()
    {
        string defaultFileName = "MAClient_NetworkModule_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".unitypackage";
        string outputPath = EditorUtility.SaveFilePanel(
            "导出网络模块复用包",
            Directory.GetCurrentDirectory(),
            defaultFileName,
            "unitypackage");

        if (string.IsNullOrWhiteSpace(outputPath))
        {
            return;
        }

        string[] assets = CollectExistingAssets();
        if (assets.Length == 0)
        {
            EditorUtility.DisplayDialog("导出失败", "未找到可导出的网络模块资源。", "确定");
            return;
        }

        try
        {
            AssetDatabase.ExportPackage(assets, outputPath, ExportPackageOptions.Recurse | ExportPackageOptions.IncludeDependencies);
            EditorUtility.RevealInFinder(outputPath);
            Debug.Log("[NetworkModulePackageExporter] 导出成功: " + outputPath);
        }
        catch (Exception ex)
        {
            Debug.LogError("[NetworkModulePackageExporter] 导出失败: " + ex);
            EditorUtility.DisplayDialog("导出失败", ex.Message, "确定");
        }
    }

    private static string[] CollectExistingAssets()
    {
        var list = new List<string>();
        foreach (var path in ExportRoots)
        {
            if (AssetDatabase.IsValidFolder(path) || AssetDatabase.LoadMainAssetAtPath(path) != null)
            {
                list.Add(path);
            }
            else
            {
                Debug.LogWarning("[NetworkModulePackageExporter] 跳过不存在路径: " + path);
            }
        }

        return list.ToArray();
    }
}
