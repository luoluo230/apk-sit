// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 重连后会话恢复请求
/// </summary>
public class SessionResume_c2s
{
    /// <summary>
    /// 目标服务器 ID
    /// </summary>
    public string ServerId { get; set; }
    /// <summary>
    /// 是否返回最新档案
    /// </summary>
    public bool IncludeProfile { get; set; }
    /// <summary>
    /// 客户端时间戳(Unix)
    /// </summary>
    public long ClientTime { get; set; }
}

/// <summary>
/// 重连后会话恢复响应
/// </summary>
public class SessionResume_s2c
{
    /// <summary>
    /// 恢复是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 恢复到的服务器 ID
    /// </summary>
    public string ServerId { get; set; }
    /// <summary>
    /// 最新角色档案（可选）
    /// </summary>
    public PlayerProfile Profile { get; set; }
}

