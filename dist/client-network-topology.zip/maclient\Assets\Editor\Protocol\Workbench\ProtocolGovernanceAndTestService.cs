using System.Text;

public static class ProtocolGovernanceAndTestService
{
    public static string BuildCompatibilitySummary(ProtocolSchemaDocument document)
    {
        if (document == null) return "Protocol document is null.";
        ProtocolSchemaValidationResult validation = document.Validate();
        var builder = new StringBuilder();
        builder.AppendLine(validation.IsValid ? "Protocol validation passed." : "Protocol validation failed.");
        foreach (string error in validation.Errors) builder.AppendLine("[Error] " + error);
        foreach (string warning in validation.Warnings) builder.AppendLine("[Warning] " + warning);
        return builder.ToString();
    }

    public static string BuildNetworkSimulationReport(ProtocolNetworkSettings settings, int packetCount, int packetBytes)
    {
        if (settings == null) return "Network settings is null.";
        return "Simulation packets=" + packetCount + ", bytes=" + packetBytes + ", latencyMs=" + settings.SimulatedLatencyMs + ", loss=" + settings.SimulatedPacketLossPercent + "%";
    }
}
