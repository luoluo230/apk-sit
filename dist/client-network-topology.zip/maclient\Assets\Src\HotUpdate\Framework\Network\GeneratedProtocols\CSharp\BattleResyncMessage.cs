﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 请求战斗重同步/补帧
/// </summary>
public class BattleResync_c2s
{
    /// <summary>
    /// 重同步请求数据
    /// </summary>
    public BattleResyncRequestData Request { get; set; }
}

/// <summary>
/// 战斗重同步/补帧响应
/// </summary>
public class BattleResync_s2c
{
    /// <summary>
    /// 重同步响应数据
    /// </summary>
    public BattleResyncResponseData Response { get; set; }
}

