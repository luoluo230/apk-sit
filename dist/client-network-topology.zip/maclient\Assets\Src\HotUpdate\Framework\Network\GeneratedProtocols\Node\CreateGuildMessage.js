// 自动生成的协议文件

// 定义协议类


// 创建公会
class CreateGuild_c2s {
    constructor() {
        this.Name = '';
        this.Badge = '';
        this.Notice = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 创建公会结果
class CreateGuild_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Guild = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    CreateGuild_c2s,
    CreateGuild_s2c,
};
