// 自动生成的协议文件

// 定义协议类


// 聊天消息广播(世界/公会/私聊等)
class ChatMessageNotify_s2c {
    constructor() {
        this.Chat = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ChatMessageNotify_s2c,
};
