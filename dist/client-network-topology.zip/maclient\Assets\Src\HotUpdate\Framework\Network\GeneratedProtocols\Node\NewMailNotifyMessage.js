// 自动生成的协议文件

// 定义协议类


// 新邮件到达推送
class NewMailNotify_s2c {
    constructor() {
        this.Mail = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    NewMailNotify_s2c,
};
