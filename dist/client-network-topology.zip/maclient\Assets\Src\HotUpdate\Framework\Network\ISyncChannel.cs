/// <summary>
/// 同步通道最小接口。
/// 网络层可把不同同步模型拆成多个通道独立分发。
/// </summary>
public interface ISyncChannel
{
    string Name { get; }
    bool CanHandle(NetMessage message);
    void Handle(NetMessage message);
}
