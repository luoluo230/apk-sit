// MessageRouter.cs
using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 消息路由器。
/// 负责把未命中请求回调链的普通消息按 messageId 分发给注册处理器。
/// </summary>
public class MessageRouter
{
    private static MessageRouter _instance;
    public static MessageRouter Instance => _instance ?? (_instance = new MessageRouter());

    private Dictionary<int, List<Action<NetMessage>>> _messageHandlers = new Dictionary<int, List<Action<NetMessage>>>();

    /// <summary>
    /// 注册一条消息处理函数。
    /// </summary>
    public void RegisterHandler(int messageId, Action<NetMessage> handler)
    {
        if (!_messageHandlers.ContainsKey(messageId))
        {
            _messageHandlers[messageId] = new List<Action<NetMessage>>();
        }

        if (!_messageHandlers[messageId].Contains(handler))
        {
            _messageHandlers[messageId].Add(handler);
        }
    }

    /// <summary>
    /// 取消注册消息处理函数。
    /// </summary>
    public void UnregisterHandler(int messageId, Action<NetMessage> handler)
    {
        if (_messageHandlers.TryGetValue(messageId, out var handlers))
        {
            handlers.Remove(handler);
            if (handlers.Count == 0)
            {
                _messageHandlers.Remove(messageId);
            }
        }
    }

    /// <summary>
    /// 分发收到的消息。
    /// </summary>
    public void Dispatch(NetMessage message)
    {
        if (_messageHandlers.TryGetValue(message.MessageID, out var handlers))
        {
            var handlerList = new List<Action<NetMessage>>(handlers);
            foreach (var handler in handlerList)
            {
                handler?.Invoke(message);
            }
        }
        else
        {
            Logger.Log($"No handler registered for message ID: {message.MessageID}", LogLevel.Warning);
        }
    }
}
