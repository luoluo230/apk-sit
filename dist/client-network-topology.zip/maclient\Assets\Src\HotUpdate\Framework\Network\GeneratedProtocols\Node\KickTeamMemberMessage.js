// 自动生成的协议文件

// 定义协议类


// 踢出队伍成员
class KickTeamMember_c2s {
    constructor() {
        this.TargetPlayerId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 踢出队伍成员结果
class KickTeamMember_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Team = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    KickTeamMember_c2s,
    KickTeamMember_s2c,
};
