﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 被踢下线通知(顶号/封号/维护)
/// </summary>
public class NotifyKickOff_s2c
{
    /// <summary>
    /// 原因编码(例如 MultiLogin/Banned/Maintenance)
    /// </summary>
    public string ReasonCode { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
}

