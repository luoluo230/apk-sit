// 自动生成的协议文件

// 定义协议类


// 领取邮件附件
class ClaimMailAttachment_c2s {
    constructor() {
        this.MailId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 领取邮件附件结果
class ClaimMailAttachment_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Rewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ClaimMailAttachment_c2s,
    ClaimMailAttachment_s2c,
};
