﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 穿戴装备
/// </summary>
public class EquipItem_c2s
{
    /// <summary>
    /// 英雄 ID
    /// </summary>
    public long HeroId { get; set; }
    /// <summary>
    /// 槽位类型
    /// </summary>
    public string SlotType { get; set; }
    /// <summary>
    /// 装备 ID
    /// </summary>
    public long EquipmentId { get; set; }
}

/// <summary>
/// 穿戴装备结果
/// </summary>
public class EquipItem_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 更新后的英雄
    /// </summary>
    public HeroInfo Hero { get; set; }
    /// <summary>
    /// 更新后的装备信息
    /// </summary>
    public EquipmentInfo Equipment { get; set; }
}

