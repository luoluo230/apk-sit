﻿using System;
using UnityEngine;

/// <summary>
/// NetworkManager 的业务友好门面。
///
/// 业务层优先依赖这个门面，而不是直接和 NetworkManager 的底层状态、连接细节打交道。
/// </summary>
[AddComponentMenu("")]
[Obsolete("NetworkFacade is internal compatibility only. Use NetworkBootstrap or ProtocolNetworkBridge.", false)]
public class NetworkFacade : MonoBehaviour
{
    private const string ConfigLogTag = "[NetworkConfig]";
    [Header("依赖配置")]
    [SerializeField] private NetworkManager networkManager;
    [SerializeField] private bool autoFindNetworkManager = true;
    [SerializeField] private bool autoCreateNetworkManager = true;
    [SerializeField] private bool dontDestroyOnLoad = true;

    [Header("默认配置")]
    [SerializeField] private NetworkManager.TransportType defaultTransport = NetworkManager.TransportType.WebSocket;
    [SerializeField] private string defaultServerUri = "";
    [Tooltip("协议工作台生成/维护的网络配置资产。为空时可从 Resources/Protocol/ProtocolNetworkSettings 自动加载。")]
    [SerializeField] private ProtocolNetworkSettings protocolNetworkSettings;
    [Tooltip("启动时自动读取 Resources/Protocol/ProtocolNetworkSettings，并同步到 NetworkManager。")]
    [SerializeField] private bool loadProtocolNetworkSettingsFromResources = true;
    [SerializeField] private bool autoConnect = true;

    private bool _pendingStartupConnect;

    private void Awake()
    {
        EnsureManager();
        ApplyProtocolNetworkSettings();
        if (dontDestroyOnLoad)
        {
            DontDestroyOnLoad(gameObject);
        }

        // Defer to Start so NetworkBootstrap can disable autoConnect during its Awake wiring.
        _pendingStartupConnect = autoConnect;
    }

    private void Start()
    {
        if (!_pendingStartupConnect || !autoConnect)
        {
            return;
        }

        _pendingStartupConnect = false;
        EnsureConnected(defaultTransport, defaultServerUri);
    }

    public HeartbeatService HeartbeatService { get; private set; }
    public bool IsConnected => EnsureManager() && networkManager.IsConnected;
    public NetworkManager Manager => EnsureManager() ? networkManager : null;
    public NetworkManager.TransportType CurrentTransportType => EnsureManager() ? networkManager.CurrentTransportType : defaultTransport;
    public string CurrentServerUri => EnsureManager() ? networkManager.CurrentServerUri : defaultServerUri;

    /// <summary>
    /// 发送一条请求并等待指定响应类型。
    /// </summary>
    public string Send<T>(
        object request,
        Action<T> onResponse,
        NetworkManager.TransportType? transport = null,
        string serverUriOverride = null,
        bool reliable = true,
        int priority = 1) where T : class
    {
        if (!EnsureManager())
        {
            Logger.Log("NetworkFacade.Send failed: NetworkManager was not found.", LogLevel.Error);
            return string.Empty;
        }

        var targetTransport = transport ?? defaultTransport;
        EnsureConnected(targetTransport, serverUriOverride ?? defaultServerUri);
        return networkManager.SendMessage<T>(request, onResponse, reliable, priority);
    }

    /// <summary>
    /// 确保连接已经建立，并在必要时切换传输层或目标地址。
    /// </summary>
    public void EnsureConnected(NetworkManager.TransportType transport, string serverUri = null)
    {
        if (!EnsureManager())
        {
            return;
        }

        string resolvedUri = string.IsNullOrWhiteSpace(serverUri) ? networkManager.CurrentServerUri : serverUri;

        bool switched = networkManager.CurrentTransportType != transport
            || (!string.IsNullOrWhiteSpace(resolvedUri) && resolvedUri != networkManager.CurrentServerUri);
        if (switched)
        {
            networkManager.SwitchTransport(transport, resolvedUri);
        }

        if (!networkManager.IsConnected)
        {
            networkManager.Connect();
        }

        if (HeartbeatService == null)
        {
            HeartbeatService = new HeartbeatService(this);
        }
    }

    /// <summary>
    /// 主动断开当前连接。
    /// </summary>
    public void Disconnect()
    {
        if (EnsureManager())
        {
            networkManager.CloseConnection();
        }
    }

    public void RegisterSnapshotHandler(int messageId, Action<NetMessage> handler)
    {
        if (EnsureManager())
        {
            networkManager.RegisterSnapshotHandler(messageId, handler);
        }
    }

    public void RegisterFrameHandler(int messageId, Action<NetMessage> handler)
    {
        if (EnsureManager())
        {
            networkManager.RegisterFrameHandler(messageId, handler);
        }
    }

    public void UnregisterHandler(int messageId, Action<NetMessage> handler)
    {
        if (EnsureManager())
        {
            networkManager.UnregisterHandler(messageId, handler);
        }
    }

    public void ConfigureDefaultEndpoint(NetworkManager.TransportType transport, string serverUri, bool connectImmediately = false)
    {
        defaultTransport = transport;
        defaultServerUri = serverUri;
        if (connectImmediately)
        {
            EnsureConnected(defaultTransport, defaultServerUri);
        }
    }

    /// <summary>
    /// 应用 M09-07 协议工作台里的网络参数。
    /// 这样编辑器工作台配置的通信方式、地址、超时、心跳、重连和可靠投递参数，会进入运行时 NetworkManager。
    /// </summary>
    public void ConfigureFromProtocolNetworkSettings(ProtocolNetworkSettings settings, bool connectImmediately = false)
    {
        if (settings == null || !EnsureManager())
        {
            return;
        }

        protocolNetworkSettings = settings;
        defaultTransport = ProtocolNetworkSettingsRuntime.ResolveTransport(settings);
        defaultServerUri = ProtocolNetworkSettingsRuntime.ResolveEndpoint(settings);
        var gameConfig = ResolveOrCreateGameNetworkConfig();
        ProtocolNetworkSettingsRuntime.ApplyAll(networkManager, gameConfig, settings, connectImmediately);
        SyncGameNetworkClient(gameConfig);
        Logger.Log(
            $"{ConfigLogTag} Applied. Version={ProtocolNetworkSettingsRuntime.LastAppliedVersionStamp}, AppliedUtc={ProtocolNetworkSettingsRuntime.LastAppliedUtc:O}, Rolling={settings.EnableRollingServerMode}, SingleServerId={settings.SingleServerId}, Endpoint={defaultServerUri}",
            LogLevel.Info);
        Logger.Log("[TransportSelected] " + ProtocolNetworkSettingsRuntime.BuildTransportCapabilityMatrix(), LogLevel.Info);
        Logger.Log("[ConfigApplied] " + ProtocolNetworkSettingsRuntime.BuildClosureAuditReport(settings), LogLevel.Info);
        Logger.Log("[ConfigApplied] LifecycleMatrix=" + NetworkLifecycleMatrix.BuildReport(), LogLevel.Info);
        if (ProtocolNetworkSettingsRuntime.IsClosure100(out var missing))
        {
            Logger.Log("[ConfigApplied] closure=100%", LogLevel.Info);
        }
        else
        {
            Logger.Log("[ConfigApplied] closure<100%, missing=" + string.Join(",", missing), LogLevel.Error);
        }
    }

    /// <summary>
    /// 把协议工作台的网络配置桥接到 GameNetworkClient 使用的 GameNetworkConfig。
    /// </summary>
    private GameNetworkConfig ResolveOrCreateGameNetworkConfig()
    {
        var client = FindFirstObjectByType<GameNetworkClient>();
        return client != null && client.Config != null ? client.Config : ScriptableObject.CreateInstance<GameNetworkConfig>();
    }

    private void SyncGameNetworkClient(GameNetworkConfig gameConfig)
    {
        var client = FindFirstObjectByType<GameNetworkClient>();
        if (client == null)
        {
            return;
        }

        client.Configure(gameConfig);
    }

    private void ApplyProtocolNetworkSettings()
    {
        ProtocolNetworkSettings settings = protocolNetworkSettings;
        if (settings == null && loadProtocolNetworkSettingsFromResources)
        {
            settings = ProtocolNetworkSettingsRuntime.LoadDefault();
        }

        ConfigureFromProtocolNetworkSettings(settings, false);
    }

    private bool EnsureManager()
    {
        if (networkManager != null)
        {
            return true;
        }

        if (!autoFindNetworkManager)
        {
            return false;
        }

        networkManager = FindFirstObjectByType<NetworkManager>();
        if (networkManager == null && autoCreateNetworkManager)
        {
            networkManager = gameObject.AddComponent<NetworkManager>();
        }
        return networkManager != null;
    }
}
