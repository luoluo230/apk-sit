﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取商店信息
/// </summary>
public class GetShopInfo_c2s
{
    /// <summary>
    /// 商店类型
    /// </summary>
    public ShopType ShopType { get; set; }
}

/// <summary>
/// 商店信息响应
/// </summary>
public class GetShopInfo_s2c
{
    /// <summary>
    /// 商店类型
    /// </summary>
    public ShopType ShopType { get; set; }
    /// <summary>
    /// 商店格子列表
    /// </summary>
    public ShopItemInfo[] Items { get; set; }
    /// <summary>
    /// 下次自动刷新时间
    /// </summary>
    public long RefreshAt { get; set; }
}

