// 自动生成的协议文件

// 定义协议类


// 塔扫荡(已通关层快速结算)
class SweepTower_c2s {
    constructor() {
        this.TowerId = 0;
        this.Floor = 0;
        this.Times = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 塔扫荡结果
class SweepTower_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Rewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SweepTower_c2s,
    SweepTower_s2c,
};
