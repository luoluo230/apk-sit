﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 进行抽卡/召唤
/// </summary>
public class DoGacha_c2s
{
    /// <summary>
    /// 抽卡池 ID
    /// </summary>
    public int PoolId { get; set; }
    /// <summary>
    /// 抽卡次数(1/10/自定义)
    /// </summary>
    public int Times { get; set; }
}

/// <summary>
/// 抽卡结果响应
/// </summary>
public class DoGacha_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 失败原因
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 抽卡结果
    /// </summary>
    public GachaResult Result { get; set; }
}

