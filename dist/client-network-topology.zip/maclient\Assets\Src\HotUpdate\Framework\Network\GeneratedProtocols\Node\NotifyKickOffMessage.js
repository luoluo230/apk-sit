// 自动生成的协议文件

// 定义协议类


// 被踢下线通知(顶号/封号/维护)
class NotifyKickOff_s2c {
    constructor() {
        this.ReasonCode = '';
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    NotifyKickOff_s2c,
};
