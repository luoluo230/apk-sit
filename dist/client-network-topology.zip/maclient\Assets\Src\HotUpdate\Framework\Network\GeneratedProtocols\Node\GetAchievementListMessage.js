// 自动生成的协议文件

// 定义协议类


// 获取成就列表
class GetAchievementList_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 成就列表响应
class GetAchievementList_s2c {
    constructor() {
        this.Achievements = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetAchievementList_c2s,
    GetAchievementList_s2c,
};
