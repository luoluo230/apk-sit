// 自动生成的协议注册表

const { Login_c2s, Login_s2c } = require("./LoginMessage");
const { SelectServer_c2s, SelectServer_s2c } = require("./SelectServerMessage");
const { CreateRole_c2s, CreateRole_s2c } = require("./CreateRoleMessage");
const { Heartbeat_c2s, Heartbeat_s2c } = require("./HeartbeatMessage");
const { NotifyKickOff_s2c } = require("./NotifyKickOffMessage");
const { GetPlayerProfile_c2s, GetPlayerProfile_s2c } = require("./GetPlayerProfileMessage");
const { GetLobbyInfo_c2s, GetLobbyInfo_s2c } = require("./GetLobbyInfoMessage");
const { GetLeaderboard_c2s, GetLeaderboard_s2c } = require("./GetLeaderboardMessage");
const { GetEvents_c2s, GetEvents_s2c } = require("./GetEventsMessage");
const { GetInventory_c2s, GetInventory_s2c } = require("./GetInventoryMessage");
const { SyncResource_s2c } = require("./SyncResourceMessage");
const { SyncInventory_s2c } = require("./SyncInventoryMessage");
const { SyncHero_s2c } = require("./SyncHeroMessage");
const { NotifyRedPoint_s2c } = require("./NotifyRedPointMessage");
const { GetHeroList_c2s, GetHeroList_s2c } = require("./GetHeroListMessage");
const { UpgradeHeroLevel_c2s, UpgradeHeroLevel_s2c } = require("./UpgradeHeroLevelMessage");
const { UpgradeHeroStar_c2s, UpgradeHeroStar_s2c } = require("./UpgradeHeroStarMessage");
const { ResetHero_c2s, ResetHero_s2c } = require("./ResetHeroMessage");
const { GetEquipmentList_c2s, GetEquipmentList_s2c } = require("./GetEquipmentListMessage");
const { EquipItem_c2s, EquipItem_s2c } = require("./EquipItemMessage");
const { UnequipItem_c2s, UnequipItem_s2c } = require("./UnequipItemMessage");
const { UpgradeEquipment_c2s, UpgradeEquipment_s2c } = require("./UpgradeEquipmentMessage");
const { DecomposeEquipment_c2s, DecomposeEquipment_s2c } = require("./DecomposeEquipmentMessage");
const { SetFormation_c2s, SetFormation_s2c } = require("./SetFormationMessage");
const { GetCampaignInfo_c2s, GetCampaignInfo_s2c } = require("./GetCampaignInfoMessage");
const { ClaimStageReward_c2s, ClaimStageReward_s2c } = require("./ClaimStageRewardMessage");
const { GetAfkRewardInfo_c2s, GetAfkRewardInfo_s2c } = require("./GetAfkRewardInfoMessage");
const { ClaimAfkReward_c2s, ClaimAfkReward_s2c } = require("./ClaimAfkRewardMessage");
const { GetTowerInfo_c2s, GetTowerInfo_s2c } = require("./GetTowerInfoMessage");
const { EnterTower_c2s, EnterTower_s2c } = require("./EnterTowerMessage");
const { SweepTower_c2s, SweepTower_s2c } = require("./SweepTowerMessage");
const { EnterBattle_c2s, EnterBattle_s2c } = require("./EnterBattleMessage");
const { BattleFrame_c2s, BattleFrame_s2c } = require("./BattleFrameMessage");
const { BattleResult_c2s, BattleResult_s2c } = require("./BattleResultMessage");
const { DungeonMatch_c2s, DungeonMatch_s2c } = require("./DungeonMatchMessage");
const { GetArenaInfo_c2s, GetArenaInfo_s2c } = require("./GetArenaInfoMessage");
const { SetArenaDefense_c2s, SetArenaDefense_s2c } = require("./SetArenaDefenseMessage");
const { ArenaChallenge_c2s, ArenaChallenge_s2c } = require("./ArenaChallengeMessage");
const { GetArenaRecords_c2s, GetArenaRecords_s2c } = require("./GetArenaRecordsMessage");
const { GetGachaInfo_c2s, GetGachaInfo_s2c } = require("./GetGachaInfoMessage");
const { DoGacha_c2s, DoGacha_s2c } = require("./DoGachaMessage");
const { GetShopInfo_c2s, GetShopInfo_s2c } = require("./GetShopInfoMessage");
const { BuyShopItem_c2s, BuyShopItem_s2c } = require("./BuyShopItemMessage");
const { RefreshShop_c2s, RefreshShop_s2c } = require("./RefreshShopMessage");
const { GetTaskList_c2s, GetTaskList_s2c } = require("./GetTaskListMessage");
const { ClaimTaskReward_c2s, ClaimTaskReward_s2c } = require("./ClaimTaskRewardMessage");
const { GetAchievementList_c2s, GetAchievementList_s2c } = require("./GetAchievementListMessage");
const { ClaimAchievementReward_c2s, ClaimAchievementReward_s2c } = require("./ClaimAchievementRewardMessage");
const { GetEventDetail_c2s, GetEventDetail_s2c } = require("./GetEventDetailMessage");
const { DoEventAction_c2s, DoEventAction_s2c } = require("./DoEventActionMessage");
const { GetFriendList_c2s, GetFriendList_s2c } = require("./GetFriendListMessage");
const { SearchPlayer_c2s, SearchPlayer_s2c } = require("./SearchPlayerMessage");
const { ApplyFriend_c2s, ApplyFriend_s2c } = require("./ApplyFriendMessage");
const { HandleFriendRequest_c2s, HandleFriendRequest_s2c } = require("./HandleFriendRequestMessage");
const { DeleteFriend_c2s, DeleteFriend_s2c } = require("./DeleteFriendMessage");
const { SendFriendEnergy_c2s, SendFriendEnergy_s2c } = require("./SendFriendEnergyMessage");
const { ReceiveFriendEnergy_c2s, ReceiveFriendEnergy_s2c } = require("./ReceiveFriendEnergyMessage");
const { FriendOnlineStatusNotify_s2c } = require("./FriendOnlineStatusNotifyMessage");
const { FriendRequestNotify_s2c } = require("./FriendRequestNotifyMessage");
const { SendChatMessage_c2s, SendChatMessage_s2c } = require("./SendChatMessageMessage");
const { ChatMessageNotify_s2c } = require("./ChatMessageNotifyMessage");
const { GetChatHistory_c2s, GetChatHistory_s2c } = require("./GetChatHistoryMessage");
const { GetMailList_c2s, GetMailList_s2c } = require("./GetMailListMessage");
const { ReadMail_c2s, ReadMail_s2c } = require("./ReadMailMessage");
const { ClaimMailAttachment_c2s, ClaimMailAttachment_s2c } = require("./ClaimMailAttachmentMessage");
const { DeleteMail_c2s, DeleteMail_s2c } = require("./DeleteMailMessage");
const { NewMailNotify_s2c } = require("./NewMailNotifyMessage");
const { GetGuildInfo_c2s, GetGuildInfo_s2c } = require("./GetGuildInfoMessage");
const { GetGuildList_c2s, GetGuildList_s2c } = require("./GetGuildListMessage");
const { CreateGuild_c2s, CreateGuild_s2c } = require("./CreateGuildMessage");
const { ApplyGuild_c2s, ApplyGuild_s2c } = require("./ApplyGuildMessage");
const { HandleGuildApply_c2s, HandleGuildApply_s2c } = require("./HandleGuildApplyMessage");
const { LeaveGuild_c2s, LeaveGuild_s2c } = require("./LeaveGuildMessage");
const { KickGuildMember_c2s, KickGuildMember_s2c } = require("./KickGuildMemberMessage");
const { ChangeGuildSettings_c2s, ChangeGuildSettings_s2c } = require("./ChangeGuildSettingsMessage");
const { DonateGuild_c2s, DonateGuild_s2c } = require("./DonateGuildMessage");
const { GuildMemberUpdateNotify_s2c } = require("./GuildMemberUpdateNotifyMessage");
const { GuildApplyNotify_s2c } = require("./GuildApplyNotifyMessage");
const { CreateTeam_c2s, CreateTeam_s2c } = require("./CreateTeamMessage");
const { InviteToTeam_c2s, InviteToTeam_s2c } = require("./InviteToTeamMessage");
const { RespondTeamInvite_c2s, RespondTeamInvite_s2c } = require("./RespondTeamInviteMessage");
const { KickTeamMember_c2s, KickTeamMember_s2c } = require("./KickTeamMemberMessage");
const { LeaveTeam_c2s, LeaveTeam_s2c } = require("./LeaveTeamMessage");
const { TeamUpdateNotify_s2c } = require("./TeamUpdateNotifyMessage");
const { PickUpItem_c2s, PickUpItem_s2c } = require("./PickUpItemMessage");
const { UseItem_c2s, UseItem_s2c } = require("./UseItemMessage");
const { EnterDungeon_c2s, EnterDungeon_s2c } = require("./EnterDungeonMessage");
const { DungeonProgress_c2s, DungeonProgress_s2c } = require("./DungeonProgressMessage");
const { DungeonProgressNotify_s2c } = require("./DungeonProgressNotifyMessage");
const { SendMail_c2s, SendMail_s2c } = require("./SendMailMessage");
const { EnterWorldBoss_c2s, EnterWorldBoss_s2c } = require("./EnterWorldBossMessage");
const { WorldBossAttack_c2s, WorldBossAttack_s2c } = require("./WorldBossAttackMessage");
const { WorldBossStatusNotify_s2c } = require("./WorldBossStatusNotifyMessage");
const { GetGuildActivities_c2s, GetGuildActivities_s2c } = require("./GetGuildActivitiesMessage");
const { JoinGuildActivity_c2s, JoinGuildActivity_s2c } = require("./JoinGuildActivityMessage");

// 映射 MessageID 到协议类
const messageMap = {
  10001: Login_c2s,
  10002: Login_s2c,
  10003: SelectServer_c2s,
  10004: SelectServer_s2c,
  10005: CreateRole_c2s,
  10006: CreateRole_s2c,
  10007: Heartbeat_c2s,
  10008: Heartbeat_s2c,
  10009: NotifyKickOff_s2c,
  10011: GetPlayerProfile_c2s,
  10012: GetPlayerProfile_s2c,
  10013: GetLobbyInfo_c2s,
  10014: GetLobbyInfo_s2c,
  10015: GetLeaderboard_c2s,
  10016: GetLeaderboard_s2c,
  10017: GetEvents_c2s,
  10018: GetEvents_s2c,
  10021: GetInventory_c2s,
  10022: GetInventory_s2c,
  10023: SyncResource_s2c,
  10024: SyncInventory_s2c,
  10025: SyncHero_s2c,
  10026: NotifyRedPoint_s2c,
  10031: GetHeroList_c2s,
  10032: GetHeroList_s2c,
  10033: UpgradeHeroLevel_c2s,
  10034: UpgradeHeroLevel_s2c,
  10035: UpgradeHeroStar_c2s,
  10036: UpgradeHeroStar_s2c,
  10037: ResetHero_c2s,
  10038: ResetHero_s2c,
  10041: GetEquipmentList_c2s,
  10042: GetEquipmentList_s2c,
  10043: EquipItem_c2s,
  10044: EquipItem_s2c,
  10045: UnequipItem_c2s,
  10046: UnequipItem_s2c,
  10047: UpgradeEquipment_c2s,
  10048: UpgradeEquipment_s2c,
  10049: DecomposeEquipment_c2s,
  10050: DecomposeEquipment_s2c,
  10051: SetFormation_c2s,
  10052: SetFormation_s2c,
  10061: GetCampaignInfo_c2s,
  10062: GetCampaignInfo_s2c,
  10063: ClaimStageReward_c2s,
  10064: ClaimStageReward_s2c,
  10065: GetAfkRewardInfo_c2s,
  10066: GetAfkRewardInfo_s2c,
  10067: ClaimAfkReward_c2s,
  10068: ClaimAfkReward_s2c,
  10069: GetTowerInfo_c2s,
  10070: GetTowerInfo_s2c,
  10071: EnterTower_c2s,
  10072: EnterTower_s2c,
  10073: SweepTower_c2s,
  10074: SweepTower_s2c,
  10081: EnterBattle_c2s,
  10082: EnterBattle_s2c,
  10083: BattleFrame_c2s,
  10084: BattleFrame_s2c,
  10085: BattleResult_c2s,
  10086: BattleResult_s2c,
  10087: DungeonMatch_c2s,
  10088: DungeonMatch_s2c,
  10089: GetArenaInfo_c2s,
  10090: GetArenaInfo_s2c,
  10091: SetArenaDefense_c2s,
  10092: SetArenaDefense_s2c,
  10093: ArenaChallenge_c2s,
  10094: ArenaChallenge_s2c,
  10095: GetArenaRecords_c2s,
  10096: GetArenaRecords_s2c,
  10101: GetGachaInfo_c2s,
  10102: GetGachaInfo_s2c,
  10103: DoGacha_c2s,
  10104: DoGacha_s2c,
  10105: GetShopInfo_c2s,
  10106: GetShopInfo_s2c,
  10107: BuyShopItem_c2s,
  10108: BuyShopItem_s2c,
  10109: RefreshShop_c2s,
  10110: RefreshShop_s2c,
  10121: GetTaskList_c2s,
  10122: GetTaskList_s2c,
  10123: ClaimTaskReward_c2s,
  10124: ClaimTaskReward_s2c,
  10125: GetAchievementList_c2s,
  10126: GetAchievementList_s2c,
  10127: ClaimAchievementReward_c2s,
  10128: ClaimAchievementReward_s2c,
  10129: GetEventDetail_c2s,
  10130: GetEventDetail_s2c,
  10131: DoEventAction_c2s,
  10132: DoEventAction_s2c,
  10141: GetFriendList_c2s,
  10142: GetFriendList_s2c,
  10143: SearchPlayer_c2s,
  10144: SearchPlayer_s2c,
  10145: ApplyFriend_c2s,
  10146: ApplyFriend_s2c,
  10147: HandleFriendRequest_c2s,
  10148: HandleFriendRequest_s2c,
  10149: DeleteFriend_c2s,
  10150: DeleteFriend_s2c,
  10151: SendFriendEnergy_c2s,
  10152: SendFriendEnergy_s2c,
  10153: ReceiveFriendEnergy_c2s,
  10154: ReceiveFriendEnergy_s2c,
  10155: FriendOnlineStatusNotify_s2c,
  10156: FriendRequestNotify_s2c,
  10161: SendChatMessage_c2s,
  10162: SendChatMessage_s2c,
  10163: ChatMessageNotify_s2c,
  10164: GetChatHistory_c2s,
  10165: GetChatHistory_s2c,
  10171: GetMailList_c2s,
  10172: GetMailList_s2c,
  10173: ReadMail_c2s,
  10174: ReadMail_s2c,
  10175: ClaimMailAttachment_c2s,
  10176: ClaimMailAttachment_s2c,
  10177: DeleteMail_c2s,
  10178: DeleteMail_s2c,
  10179: NewMailNotify_s2c,
  10181: GetGuildInfo_c2s,
  10182: GetGuildInfo_s2c,
  10183: GetGuildList_c2s,
  10184: GetGuildList_s2c,
  10185: CreateGuild_c2s,
  10186: CreateGuild_s2c,
  10187: ApplyGuild_c2s,
  10188: ApplyGuild_s2c,
  10189: HandleGuildApply_c2s,
  10190: HandleGuildApply_s2c,
  10191: LeaveGuild_c2s,
  10192: LeaveGuild_s2c,
  10193: KickGuildMember_c2s,
  10194: KickGuildMember_s2c,
  10195: ChangeGuildSettings_c2s,
  10196: ChangeGuildSettings_s2c,
  10197: DonateGuild_c2s,
  10198: DonateGuild_s2c,
  10199: GuildMemberUpdateNotify_s2c,
  10200: GuildApplyNotify_s2c,
  10201: CreateTeam_c2s,
  10202: CreateTeam_s2c,
  10203: InviteToTeam_c2s,
  10204: InviteToTeam_s2c,
  10205: RespondTeamInvite_c2s,
  10206: RespondTeamInvite_s2c,
  10207: KickTeamMember_c2s,
  10208: KickTeamMember_s2c,
  10209: LeaveTeam_c2s,
  10210: LeaveTeam_s2c,
  10211: TeamUpdateNotify_s2c,
  10221: PickUpItem_c2s,
  10222: PickUpItem_s2c,
  10223: UseItem_c2s,
  10224: UseItem_s2c,
  10251: EnterDungeon_c2s,
  10252: EnterDungeon_s2c,
  10253: DungeonProgress_c2s,
  10254: DungeonProgress_s2c,
  10255: DungeonProgressNotify_s2c,
  10261: SendMail_c2s,
  10262: SendMail_s2c,
  10271: EnterWorldBoss_c2s,
  10272: EnterWorldBoss_s2c,
  10273: WorldBossAttack_c2s,
  10274: WorldBossAttack_s2c,
  10275: WorldBossStatusNotify_s2c,
  10281: GetGuildActivities_c2s,
  10282: GetGuildActivities_s2c,
  10283: JoinGuildActivity_c2s,
  10284: JoinGuildActivity_s2c,
};

// 根据 MessageID 获取协议类
function getProtocolClass(messageID) {
    return messageMap[messageID];
}

module.exports = { getProtocolClass };

