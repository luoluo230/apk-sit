using System;

/// <summary>
/// 连接控制器接口。
/// 负责管理底层传输初始化、连接建立、断线重连与主动断开等生命周期。
/// </summary>
public interface IConnectionController
{
    INetworkTransport Transport { get; }
    bool IsConnected { get; }
    bool IsReconnecting { get; }
    int ReconnectAttempts { get; }
    bool ReconnectCancelled { get; }

    /// <summary>
    /// 初始化底层传输对象并绑定回调。
    /// </summary>
    void InitializeTransport(
        UnityEngine.GameObject owner,
        NetworkManager.TransportType transportType,
        Action onConnected,
        Action<string> onDisconnected,
        Action<string> onError,
        Action<byte[]> onDataReceived);

    /// <summary>
    /// 发起连接。
    /// </summary>
    void Connect(NetworkManager.TransportType transportType, string serverUri, string webSocketPath);

    /// <summary>
    /// 处理传输层连接成功事件。
    /// </summary>
    bool HandleTransportConnected();

    /// <summary>
    /// 处理传输层断开事件。
    /// </summary>
    void HandleTransportDisconnected();

    /// <summary>
    /// 尝试启动重连流程。
    /// </summary>
    bool TryStartReconnect(
        bool isLongConnection,
        int maxReconnectAttempts,
        float reconnectDelay,
        float maxReconnectDelay,
        Action onReconnectFailed,
        Action reconnectAction);

    /// <summary>
    /// 取消重连流程。
    /// </summary>
    void CancelReconnect(Action onReconnectCancelled);

    /// <summary>
    /// 停止重连相关状态机。
    /// </summary>
    void StopReconnectFlow();

    /// <summary>
    /// 在业务主动断开前设置内部状态，避免被误判为异常断线。
    /// </summary>
    void PrepareForManualDisconnect();

    /// <summary>
    /// 主动断开连接。
    /// </summary>
    void Disconnect();

    /// <summary>
    /// 释放控制器持有的传输和回调。
    /// </summary>
    void Dispose(
        Action onConnected,
        Action<string> onDisconnected,
        Action<string> onError,
        Action<byte[]> onDataReceived);
}
