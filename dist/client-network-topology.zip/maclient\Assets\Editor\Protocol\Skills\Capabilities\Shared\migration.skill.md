# Migration And Compatibility Skill

## 职责

根据协议上下文和基线差异生成兼容性报告、迁移建议和人工审查清单。

## 必须检查

- MessageID 是否变化或冲突。
- request/response pair 是否断裂。
- required 字段新增是否影响旧客户端。
- 字段删除/重命名/改类型是否破坏二进制或 JSON 兼容。
- Deprecated 字段是否被复用。
- DB 字段是否需要 backfill、索引、迁移、回滚。

## 输出

- breaking change 列表。
- 客户端兼容建议。
- 服务端兼容建议。
- 数据库迁移建议。
- 灰度/回滚建议。

## 质量门禁

- 高风险变更必须显式标红或标记 high risk。
- 不确定兼容性时必须要求人工 review，不能默认安全。
