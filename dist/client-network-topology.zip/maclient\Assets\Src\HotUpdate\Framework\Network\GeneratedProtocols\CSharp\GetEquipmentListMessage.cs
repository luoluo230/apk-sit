﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取装备列表
/// </summary>
public class GetEquipmentList_c2s
{
}

/// <summary>
/// 装备列表响应
/// </summary>
public class GetEquipmentList_s2c
{
    /// <summary>
    /// 所有装备详细信息
    /// </summary>
    public EquipmentInfo[] Equipments { get; set; }
}

