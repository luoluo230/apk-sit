﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 邀请加入队伍
/// </summary>
public class InviteToTeam_c2s
{
    /// <summary>
    /// 邀请对象玩家 ID
    /// </summary>
    public long TargetPlayerId { get; set; }
}

/// <summary>
/// 邀请加入队伍结果
/// </summary>
public class InviteToTeam_s2c
{
    /// <summary>
    /// 是否成功发出邀请
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 邀请信息
    /// </summary>
    public TeamInviteInfo Invite { get; set; }
}

