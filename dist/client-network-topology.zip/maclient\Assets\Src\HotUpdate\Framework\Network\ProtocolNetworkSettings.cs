﻿using UnityEngine;

/// <summary>
/// 网络环境预设。
/// 协议工作台可维护 dev/test/staging/prod 等多套 endpoint，运行时按 ActiveEnvironmentId 解析。
/// </summary>
[System.Serializable]
public sealed class ProtocolNetworkEnvironmentPreset
{
    [Tooltip("环境 ID，例如 dev/test/staging/prod。")]
    public string EnvironmentId = "dev";

    [Tooltip("环境显示名称。")]
    public string DisplayName = "开发服";

    [Tooltip("该环境连接地址。")]
    public string EndpointUrl = "ws://127.0.0.1:15050/ws";
}

/// <summary>
/// 传输层类型。
/// </summary>
public enum ProtocolTransportKind
{
    Tcp,
    WebSocket,
    Http,
    Kcp
}

/// <summary>
/// 负载编码类型。
/// </summary>
public enum ProtocolPayloadEncodingKind
{
    Json,
    Binary,
    ProtobufLike,
    Custom
}

/// <summary>
/// 通信模式。
/// </summary>
public enum ProtocolCommunicationMode
{
    RequestResponse,
    Push,
    FrameSync,
    SnapshotSync
}

/// <summary>
/// 协议与网络配置真源。
/// 编辑器工作台维护此资产，运行时通过 ProtocolNetworkSettingsRuntime 应用到 NetworkManager 与 GameNetworkConfig。
/// </summary>
[CreateAssetMenu(fileName = "ProtocolNetworkSettings", menuName = "HotUpdate/Network/Protocol Network Settings")]
public sealed class ProtocolNetworkSettings : ScriptableObject
{
    [Header("项目身份配置")]
    [Tooltip("项目 ID。用于与内网运营中心进行 gameId/gameKey 同步。")]
    public string ProjectId = string.Empty;

    [Tooltip("游戏 ID。")]
    public string GameId = string.Empty;

    [Tooltip("本地加密后的 gameKey（编辑器写入，运行时默认不直读）。")]
    public string EncryptedGameKey = string.Empty;

    [Tooltip("本地凭据版本戳。")]
    public string CredentialLocalVersion = string.Empty;

    [Tooltip("内网凭据版本戳。")]
    public string CredentialRemoteVersion = string.Empty;

    [Tooltip("最后同步时间（UTC ISO8601）。")]
    public string CredentialLastSyncAtUtc = string.Empty;

    [Header("通信协议选择")]
    [Tooltip("底层传输方式。")]
    public ProtocolTransportKind TransportKind = ProtocolTransportKind.WebSocket;

    [Tooltip("负载编码方式。")]
    public ProtocolPayloadEncodingKind PayloadEncoding = ProtocolPayloadEncodingKind.Json;

    [Tooltip("通信模式。")]
    public ProtocolCommunicationMode CommunicationMode = ProtocolCommunicationMode.RequestResponse;

    [Tooltip("自定义序列化器名。仅 PayloadEncoding=Custom 时使用。")]
    public string CustomSerializerName = string.Empty;

    [Header("连接参数")]
    [Tooltip("默认连接地址。")]
    public string EndpointUrl = "ws://127.0.0.1:15050/ws";

    [Tooltip("当前生效环境 ID。")]
    public string ActiveEnvironmentId = "dev";

    [Header("业务登录")]
    [Tooltip("是否滚服。true: 登录后选服；false: 单服直连。")]
    public bool EnableRollingServerMode = true;

    [Tooltip("单服模式默认 serverId。")]
    public string SingleServerId = string.Empty;

    [Tooltip("多环境预设。")]
    public ProtocolNetworkEnvironmentPreset[] EnvironmentPresets =
    {
        new ProtocolNetworkEnvironmentPreset { EnvironmentId = "dev", DisplayName = "开发服", EndpointUrl = "ws://127.0.0.1:15050/ws" },
        new ProtocolNetworkEnvironmentPreset { EnvironmentId = "test", DisplayName = "测试服", EndpointUrl = "ws://127.0.0.1:9001" },
        new ProtocolNetworkEnvironmentPreset { EnvironmentId = "staging", DisplayName = "预发布", EndpointUrl = "ws://127.0.0.1:9001" },
        new ProtocolNetworkEnvironmentPreset { EnvironmentId = "prod", DisplayName = "正式服", EndpointUrl = "ws://127.0.0.1:9001" }
    };

    [Tooltip("连接超时(ms)。")]
    public int ConnectTimeoutMs = 8000;

    [Tooltip("请求超时(ms)。")]
    public int RequestTimeoutMs = 10000;

    [Tooltip("心跳间隔(ms)，0 表示关闭。")]
    public int HeartbeatIntervalMs = 15000;

    [Tooltip("心跳超时(ms)。")]
    public int HeartbeatTimeoutMs = 5000;

    [Header("重连与可靠投递")]
    [Tooltip("最大重连次数；<0 为无限重连；0 为不重连。")]
    public int MaxReconnectAttempts = 5;

    [Tooltip("重连基准延迟(ms)。")]
    public int ReconnectBaseDelayMs = 1000;

    [Tooltip("是否启用可靠投递。")]
    public bool EnableReliableDelivery = true;

    [Tooltip("ACK 超时(ms)。")]
    public int AckTimeoutMs = 3000;

    [Tooltip("最大重试次数。")]
    public int MaxRetryCount = 3;

    [Header("安全与压缩")]
    [Tooltip("是否启用压缩。")]
    public bool EnableCompression;

    [Tooltip("是否启用加密。")]
    public bool EnableEncryption;

    [Header("同步参数")]
    [Tooltip("客户端帧率。")]
    public int ClientFrameRate = 30;

    [Tooltip("快照间隔(ms)。")]
    public int SnapshotIntervalMs = 100;

    [Header("网络模拟")]
    [Tooltip("是否启用弱网模拟。")]
    public bool EnableSimulation;

    [Tooltip("基础延迟(ms)。")]
    public int SimulatedLatencyMs = 120;

    [Tooltip("抖动(ms)。")]
    public int SimulatedJitterMs = 40;

    [Range(0f, 100f)]
    [Tooltip("丢包率(%)。")]
    public float SimulatedPacketLossPercent = 2f;

    [Range(0f, 100f)]
    [Tooltip("重复包概率(%)。")]
    public float SimulatedDuplicatePercent = 0.5f;

    [Range(0f, 100f)]
    [Tooltip("乱序概率(%)。")]
    public float SimulatedReorderPercent = 1f;

    [Tooltip("带宽限制(Kbps)，0 为不限制。")]
    public int SimulatedBandwidthKbps = 0;

    [Tooltip("多少秒后主动断线模拟，0 为不主动断线。")]
    public float SimulatedDisconnectAfterSeconds = 0f;

    [Tooltip("模拟随机种子。")]
    public int SimulationSeed = 9527;
}
