// 自动生成的协议文件

// 定义协议类


// 获取好友列表及申请列表
class GetFriendList_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 好友列表响应
class GetFriendList_s2c {
    constructor() {
        this.Friends = [];
        this.Requests = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetFriendList_c2s,
    GetFriendList_s2c,
};
