// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// Token 刷新请求
/// </summary>
public class TokenRefresh_c2s
{
    /// <summary>
    /// 刷新令牌（为空时可回退到当前 token）
    /// </summary>
    public string RefreshToken { get; set; }
    /// <summary>
    /// 客户端时间戳(Unix)
    /// </summary>
    public long ClientTime { get; set; }
}

/// <summary>
/// Token 刷新响应
/// </summary>
public class TokenRefresh_s2c
{
    /// <summary>
    /// 刷新是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 新 token
    /// </summary>
    public string Token { get; set; }
    /// <summary>
    /// 新 token 过期时间(Unix)
    /// </summary>
    public long ExpireAt { get; set; }
}

