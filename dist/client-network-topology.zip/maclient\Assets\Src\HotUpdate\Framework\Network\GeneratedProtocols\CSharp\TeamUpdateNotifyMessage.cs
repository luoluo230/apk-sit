﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 队伍变更通知
/// </summary>
public class TeamUpdateNotify_s2c
{
    /// <summary>
    /// 队伍信息
    /// </summary>
    public TeamInfo Team { get; set; }
}

