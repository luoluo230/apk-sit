// 自动生成的协议文件

// 定义协议类


// 装备分解/提炼
class DecomposeEquipment_c2s {
    constructor() {
        this.EquipmentIds = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 装备分解结果
class DecomposeEquipment_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Rewards = [];
        this.InventoryDelta = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DecomposeEquipment_c2s,
    DecomposeEquipment_s2c,
};
