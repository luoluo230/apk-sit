﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 发送邮件(玩家对玩家)
/// </summary>
public class SendMail_c2s
{
    /// <summary>
    /// 收件人玩家 ID
    /// </summary>
    public long ToPlayerId { get; set; }
    /// <summary>
    /// 标题
    /// </summary>
    public string Title { get; set; }
    /// <summary>
    /// 内容
    /// </summary>
    public string Content { get; set; }
}

/// <summary>
/// 发送邮件结果
/// </summary>
public class SendMail_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 新邮件 ID
    /// </summary>
    public long MailId { get; set; }
}

