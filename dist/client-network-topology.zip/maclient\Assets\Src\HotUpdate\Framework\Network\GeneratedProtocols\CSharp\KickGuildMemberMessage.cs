﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 踢出公会成员
/// </summary>
public class KickGuildMember_c2s
{
    /// <summary>
    /// 目标成员 ID
    /// </summary>
    public long TargetPlayerId { get; set; }
}

/// <summary>
/// 踢出成员结果
/// </summary>
public class KickGuildMember_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

