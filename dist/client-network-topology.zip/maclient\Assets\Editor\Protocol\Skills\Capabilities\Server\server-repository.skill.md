# Server Repository / DB Skill

## 职责

根据协议上下文生成 repository、db model、migration 草案和数据库接入建议。

## 必须生成

- Repository 接口或类。
- 查询/写入方法骨架。
- DB model 草案。
- migration SQL 或迁移说明。
- 索引、唯一键、乐观锁、幂等字段建议。

## 安全规则

- 默认只生成建议，不能声称可以直接生产执行。
- response-only 字段、客户端展示字段、临时字段不能默认落库。
- 敏感字段必须标注加密/脱敏/不落库。
- 删除字段必须走生命周期，不直接 drop。

## 质量门禁

- 每个落库字段都能追溯来源和用途。
- 每个写入方法都有事务上下文参数或替代说明。
