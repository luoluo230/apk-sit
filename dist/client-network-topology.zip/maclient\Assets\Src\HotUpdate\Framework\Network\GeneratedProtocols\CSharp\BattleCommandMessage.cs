﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 统一战斗命令上报(技能/移动/交互等)
/// </summary>
public class BattleCommand_c2s
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 命令唯一 ID
    /// </summary>
    public string CommandId { get; set; }
    /// <summary>
    /// 操作者 ID
    /// </summary>
    public long ActorId { get; set; }
    /// <summary>
    /// 命令类型
    /// </summary>
    public string CommandType { get; set; }
    /// <summary>
    /// 目标 Tick
    /// </summary>
    public int TickIndex { get; set; }
    /// <summary>
    /// 客户端帧
    /// </summary>
    public int Frame { get; set; }
    /// <summary>
    /// 客户端时间戳
    /// </summary>
    public long ClientTime { get; set; }
    /// <summary>
    /// 幂等键
    /// </summary>
    public string IdempotencyKey { get; set; }
    /// <summary>
    /// 命令载荷(JSON)
    /// </summary>
    public string PayloadJson { get; set; }
}

/// <summary>
/// 统一战斗命令受理结果
/// </summary>
public class BattleCommand_s2c
{
    /// <summary>
    /// 是否受理成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 结果说明
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 命令 ID
    /// </summary>
    public string CommandId { get; set; }
    /// <summary>
    /// 服务端受理 Tick
    /// </summary>
    public int TickIndex { get; set; }
    /// <summary>
    /// 错误码(失败时)
    /// </summary>
    public string ErrorCode { get; set; }
    /// <summary>
    /// 是否可重试
    /// </summary>
    public bool Retryable { get; set; }
}

