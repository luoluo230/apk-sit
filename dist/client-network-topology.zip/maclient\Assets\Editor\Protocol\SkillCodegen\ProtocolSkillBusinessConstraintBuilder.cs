using System.Text;

public static class ProtocolSkillBusinessConstraintBuilder
{
    public static string Build(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        var builder = new StringBuilder();
        builder.AppendLine("Client must call " + options.NetworkFacadeType + "." + options.RequestSendMethod + " and must not recreate DTO classes.");
        builder.AppendLine("Server must separate Handler, Service, Repository, DB model, Migration and RouteRegistration responsibilities.");
        builder.AppendLine("Generated code must preserve manual blocks and should be safe to regenerate.");
        builder.AppendLine("High risk flows such as payment, assets, inventory, reward, battle and leaderboard must include authority, idempotency and transaction gates.");
        builder.AppendLine("Errors must be mapped into response fields when code/message/success fields exist.");
        if (!string.IsNullOrWhiteSpace(options.BusinessRequirementSupplement))
        {
            builder.AppendLine("Business supplement:");
            builder.AppendLine(options.BusinessRequirementSupplement);
        }

        if (context != null)
        {
            builder.AppendLine("Protocol: " + context.ProtocolName + "; request=" + context.RequestName + "; response=" + context.ResponseName);
        }

        return builder.ToString();
    }
}
