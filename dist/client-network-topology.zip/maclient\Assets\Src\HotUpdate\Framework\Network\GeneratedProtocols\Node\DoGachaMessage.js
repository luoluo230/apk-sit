// 自动生成的协议文件

// 定义协议类


// 进行抽卡/召唤
class DoGacha_c2s {
    constructor() {
        this.PoolId = 0;
        this.Times = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 抽卡结果响应
class DoGacha_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Result = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DoGacha_c2s,
    DoGacha_s2c,
};
