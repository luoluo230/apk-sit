/// <summary>
/// 传输客户端别名接口。
/// 当前等价于 <see cref="INetworkTransport"/>，保留是为了让上层语义更贴近“客户端连接实例”。
/// </summary>
public interface ITransportClient : INetworkTransport
{
}
