# Shop Domain Skill

- Client: generate shop list, product detail, purchase-entry and result-refresh hooks. Keep UI samples thin and do not bind a concrete payment SDK here.
- Server: generate product availability, price version, stock/limit, currency balance and delivery extension points.
- Non-idempotent commerce operations must expose double-click guard, idempotency hook and audit log placeholder.
- Concrete order, receipt, payment confirmation and make-up delivery rules belong to `payment-order.scenario.skill.md`.
