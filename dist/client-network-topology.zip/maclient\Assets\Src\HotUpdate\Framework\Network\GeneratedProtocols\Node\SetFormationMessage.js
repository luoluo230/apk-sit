// 自动生成的协议文件

// 定义协议类


// 设置阵容(主线/竞技场/公会Boss等共用)
class SetFormation_c2s {
    constructor() {
        this.FormationType = '';
        this.Slots = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 设置阵容结果
class SetFormation_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.FormationType = '';
        this.Slots = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SetFormation_c2s,
    SetFormation_s2c,
};
