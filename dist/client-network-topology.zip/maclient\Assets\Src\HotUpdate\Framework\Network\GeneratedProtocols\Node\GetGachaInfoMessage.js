// 自动生成的协议文件

// 定义协议类


// 获取召唤/抽卡池信息
class GetGachaInfo_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 召唤/抽卡池信息响应
class GetGachaInfo_s2c {
    constructor() {
        this.Pools = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetGachaInfo_c2s,
    GetGachaInfo_s2c,
};
