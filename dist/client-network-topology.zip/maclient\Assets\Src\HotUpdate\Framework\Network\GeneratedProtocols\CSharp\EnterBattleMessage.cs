﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 服务器权威战斗启动请求(兼容旧版 EnterBattle)
/// </summary>
public class EnterBattle_c2s
{
    /// <summary>
    /// 关卡/房间 ID
    /// </summary>
    public string StageId { get; set; }
    /// <summary>
    /// PVE/PVP/活动等模式
    /// </summary>
    public string BattleMode { get; set; }
    /// <summary>
    /// 同步模式(权威/锁步/回放)
    /// </summary>
    public BattleSyncMode SyncMode { get; set; }
    /// <summary>
    /// 阵容配置
    /// </summary>
    public FormationSlot[] Formation { get; set; }
    /// <summary>
    /// 客户端发起时间戳
    /// </summary>
    public long ClientTime { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 战斗启动响应(兼容客户端表演字段)
/// </summary>
public class EnterBattle_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示/失败原因
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 战斗唯一 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 当前战斗阶段
    /// </summary>
    public BattlePhase Phase { get; set; }
    /// <summary>
    /// 服务器时间戳
    /// </summary>
    public long ServerTime { get; set; }
    /// <summary>
    /// 场景信息
    /// </summary>
    public BattleSceneInfo Scene { get; set; }
    /// <summary>
    /// 同步参数
    /// </summary>
    public BattleServerTuning Sync { get; set; }
    /// <summary>
    /// 参战方信息
    /// </summary>
    public BattleParticipant[] Participants { get; set; }
    /// <summary>
    /// 己方信息
    /// </summary>
    public BattlePlayerInfo Self { get; set; }
    /// <summary>
    /// 队友信息
    /// </summary>
    public BattlePlayerInfo[] Allies { get; set; }
    /// <summary>
    /// 敌方信息
    /// </summary>
    public BattlePlayerInfo[] Enemies { get; set; }
    /// <summary>
    /// 初始单位状态
    /// </summary>
    public BattleUnitSnapshot[] InitialUnits { get; set; }
    /// <summary>
    /// 预演帧/回放段
    /// </summary>
    public BattleFrameBundle[] Warmup { get; set; }
    /// <summary>
    /// 重连锚点
    /// </summary>
    public BattleTimelineAnchor Anchor { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

