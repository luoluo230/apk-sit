using UnityEngine;

/// <summary>
/// 协议网络桥接器（对外新命名）。
/// 负责把协议工作台配置桥接到运行时网络核心。
/// </summary>
[AddComponentMenu("")]
public class ProtocolNetworkBridge : NetworkFacade
{
}

