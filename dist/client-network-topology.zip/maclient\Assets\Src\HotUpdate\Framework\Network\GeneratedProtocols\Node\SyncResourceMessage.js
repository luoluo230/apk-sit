// 自动生成的协议文件

// 定义协议类


// 服务器推送资源变动(任意原因的货币/体力变化)
class SyncResource_s2c {
    constructor() {
        this.Changes = [];
        this.Reason = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SyncResource_s2c,
};
