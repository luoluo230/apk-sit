﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取竞技场战报列表
/// </summary>
public class GetArenaRecords_c2s
{
}

/// <summary>
/// 竞技场战报响应
/// </summary>
public class GetArenaRecords_s2c
{
    /// <summary>
    /// 战报列表
    /// </summary>
    public ArenaBattleRecord[] Records { get; set; }
}

