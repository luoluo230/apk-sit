using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

public sealed class ProtocolSkillCodegenService
{
    private static readonly string SupportSkillRoot = Path.Combine("Assets", "Editor", "Protocol", "Skills", "Support");
    private readonly string _repoRoot;
    private readonly ProtocolSkillContextBuilder _contextBuilder;

    public ProtocolSkillCodegenService(string repoRoot, ProtocolArtifactPaths paths)
    {
        _repoRoot = repoRoot;
        _contextBuilder = new ProtocolSkillContextBuilder(paths);
    }

    public ProtocolSkillGenerationPlan BuildPlan(ProtocolSchemaDocument document, IEnumerable<ProtocolSchemaEntry> selectedEntries, ProtocolSkillCodegenOptions options)
    {
        var plan = new ProtocolSkillGenerationPlan { PlanId = DateTime.UtcNow.ToString("yyyyMMddHHmmss"), GeneratedAtUtc = DateTime.UtcNow.ToString("O"), Options = options };
        plan.Contexts.AddRange(_contextBuilder.BuildContexts(document, options.IncludeSelectedOnly ? selectedEntries : document.Entries, options));
        Enrich(plan);
        AddClientRuntimeInfrastructure(plan);
        AddRoutingInfrastructure(plan);
        foreach (ProtocolSkillContext context in plan.Contexts)
        {
            AddClientFiles(plan, context);
            AddServerFiles(plan, context);
            AddMockAndMigrationFiles(plan, context);
        }

        if (options.GenerateSkillContext) _contextBuilder.WriteContextFiles(plan, _repoRoot);
        WritePlanFiles(plan);
        return plan;
    }

    public string RenderPlanMarkdown(ProtocolSkillGenerationPlan plan)
    {
        var builder = new StringBuilder();
        builder.AppendLine("# Protocol Business Logic Generation Plan");
        builder.AppendLine("- PlanId: `" + plan.PlanId + "`");
        builder.AppendLine("- Target: `" + plan.Options.Target + "`");
        builder.AppendLine("- Skills: `" + plan.Options.Skills + "`");
        builder.AppendLine("- Client: `CSharp`");
        builder.AppendLine("- Server: `" + plan.Options.ServerLanguage + "`");
        builder.AppendLine("- Files: `" + plan.Files.Count + "`");
        builder.AppendLine("- Contexts: `" + plan.Contexts.Count + "`");
        builder.AppendLine();
        builder.AppendLine("## Business Supplement");
        builder.AppendLine(string.IsNullOrWhiteSpace(plan.Options.BusinessRequirementSupplement) ? "No supplement." : plan.Options.BusinessRequirementSupplement);
        builder.AppendLine();
        builder.AppendLine("## Protocols");
        foreach (ProtocolSkillContext context in plan.Contexts) builder.AppendLine("- `" + context.ProtocolName + "` request=`" + context.RequestName + "` response=`" + context.ResponseName + "` module=`" + context.Module + "`");
        builder.AppendLine();
        builder.AppendLine("## Risks");
        foreach (string risk in plan.Risks) builder.AppendLine("- " + risk);
        builder.AppendLine();
        builder.AppendLine("## Files");
        foreach (ProtocolSkillPlanFile file in plan.Files) builder.AppendLine("- `" + file.Action + "` `" + file.Path + "` [" + file.Skill + "] " + file.Reason);
        return builder.ToString();
    }

    public ProtocolSkillAiRequest BuildAiRequest(ProtocolSkillGenerationPlan plan)
    {
        var request = new ProtocolSkillAiRequest { PlanId = plan.PlanId, PromptMarkdown = RenderAiPromptMarkdown(plan), PromptJson = RenderAiPromptJson(plan) };
        request.Contexts.AddRange(plan.Contexts);
        return request;
    }

    public string ApplyPlan(ProtocolSkillGenerationPlan plan)
    {
        int written = 0;
        foreach (ProtocolSkillPlanFile file in plan.Files)
        {
            string absolutePath = ToAbsolutePath(file.Path);
            Directory.CreateDirectory(Path.GetDirectoryName(absolutePath) ?? string.Empty);
            string content = WrapGeneratedContent(file);
            if (File.Exists(absolutePath)) content = ReplaceGeneratedBlock(File.ReadAllText(absolutePath, Encoding.UTF8), content, file.Skill);
            File.WriteAllText(absolutePath, content, new UTF8Encoding(false));
            written++;
        }

        return "Skill codegen wrote " + written + " file(s).";
    }

    private void Enrich(ProtocolSkillGenerationPlan plan)
    {
        ProtocolServerArchitectureProfile profile = ProtocolServerArchitectureScanner.Scan(_repoRoot);
        foreach (ProtocolSkillContext context in plan.Contexts)
        {
            ProtocolSkillBusinessDomain domain = ProtocolSkillDomainRegistry.InferDomain(context.ProtocolName, context.Module);
            context.BusinessDomain = domain.ToString();
            context.DomainPromptTemplatePath = ProtocolSkillDomainRegistry.GetPromptTemplatePath(domain);
            context.ServerArchitectureSummary = profile.Summary;
            context.DetectedDbFramework = profile.DbFramework;
            context.DetectedDbContextType = profile.DbContextType;
            context.DetectedLoggerPattern = profile.LoggerPattern;
            context.DetectedErrorCodeType = profile.ErrorCodeType;
            context.DetectedTransactionPattern = profile.TransactionPattern;
            context.BusinessConstraintSummary = ProtocolSkillBusinessConstraintBuilder.Build(plan.Options, context);
            if (plan.Options.EnableCodebaseRetrieval) new ProtocolSkillCodeRetrievalService(_repoRoot).Enrich(context);
        }

        plan.Risks.Add("Generated code must be reviewed before applying.");
        plan.Risks.Add("Payment, asset, battle and database migration code requires manual review gates.");
        plan.Risks.Add("AI prompt must not contain secrets, player privacy data or production database connection strings.");
    }

    private void AddClientFiles(ProtocolSkillGenerationPlan plan, ProtocolSkillContext context)
    {
        if (!TargetsClient(plan.Options.Target)) return;
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.ClientApiWrapper))
        {
            AddFile(plan, Path.Combine(plan.Options.ClientOutputRoot, context.Module, context.ProtocolName + "ProtocolApi.generated.cs"), "ClientApiWrapper", "Client protocol API wrapper.", RenderClientApi(plan.Options, context));
            AddFile(plan, Path.Combine(plan.Options.ClientOutputRoot, context.Module, context.ProtocolName + "ClientPolicy.generated.cs"), "ClientPolicy", "Client loading/retry/error/cache policy.", RenderClientPolicy(plan.Options, context));
        }
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.ClientUseCase)) AddFile(plan, Path.Combine(plan.Options.ClientOutputRoot, context.Module, context.ProtocolName + "UseCase.generated.cs"), "ClientUseCase", "Client business use case wrapper.", RenderClientUseCase(plan.Options, context));
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.ClientPresenterBinding)) AddFile(plan, Path.Combine(plan.Options.ClientOutputRoot, context.Module, context.ProtocolName + "PresenterSample.generated.cs"), "ClientPresenterBinding", "Client UI/Presenter sample.", RenderClientPresenter(plan.Options, context));
        if (HasClientCompositionPipeline(plan.Options)) AddFile(plan, Path.Combine(plan.Options.ClientOutputRoot, context.Module, context.ProtocolName + "ClientFeature.generated.cs"), "ClientFeatureComposition", "Client dependency composition, event registration and business entry.", RenderClientFeature(plan.Options, context));
    }

    private void AddServerFiles(ProtocolSkillGenerationPlan plan, ProtocolSkillContext context)
    {
        if (!TargetsServer(plan.Options.Target)) return;
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.ServerHandler))
        {
            AddServerCodeFile(plan, plan.Options.ServerHandlerRoot, context.Module, context.ProtocolName + "Handler.generated", "ServerHandler", "Server handler entry.", RenderServerHandler(plan.Options, context), context);
            AddServerCodeFile(plan, plan.Options.ServerHandlerRoot, context.Module, context.ProtocolName + "ServerGuards.generated", "ServerGuards", "Server validation/auth/transaction/error/observability guards.", RenderServerGuards(plan.Options, context), context);
        }
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.ServerService)) AddServerCodeFile(plan, plan.Options.ServerServiceRoot, context.Module, context.ProtocolName + "Service.generated", "ServerService", "Server service layer.", RenderServerService(plan.Options, context), context);
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.ServerRepository) && plan.Options.DatabaseStrategy != ProtocolSkillDatabaseStrategy.None)
        {
            AddServerCodeFile(plan, plan.Options.ServerRepositoryRoot, context.Module, context.ProtocolName + "Repository.generated", "ServerRepository", "Server repository layer.", RenderServerRepository(plan.Options, context), context);
            if (plan.Options.DatabaseStrategy != ProtocolSkillDatabaseStrategy.SuggestSchemaOnly) AddServerCodeFile(plan, plan.Options.ServerDbModelRoot, context.Module, context.ProtocolName + "DbModel.generated", "ServerDbModel", "Server database model draft.", RenderServerDbModel(plan.Options, context), context);
            if (plan.Options.DatabaseStrategy == ProtocolSkillDatabaseStrategy.GenerateModelRepositoryAndMigration) AddFile(plan, Path.Combine(plan.Options.ServerMigrationRoot, context.Module, context.ProtocolName + ".migration.sql"), "ServerMigrationSql", "Server migration SQL draft.", RenderServerMigrationSql(context));
        }
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.ServerRouteRegistration)) AddServerCodeFile(plan, plan.Options.ServerRouteRoot, context.Module, context.ProtocolName + "RouteRegistration.generated", "ServerRouteRegistration", "Server route registration by MessageID.", RenderServerRouteRegistration(plan.Options, context), context);
        if (HasServerCompositionPipeline(plan.Options)) AddServerCodeFile(plan, plan.Options.ServerRouteRoot, context.Module, context.ProtocolName + "ServerFeature.generated", "ServerFeatureComposition", "Server dependency composition and route wiring.", RenderServerFeature(plan.Options, context), context);
    }

    private void AddMockAndMigrationFiles(ProtocolSkillGenerationPlan plan, ProtocolSkillContext context)
    {
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.MockAndTest))
        {
            string root = TargetsClient(plan.Options.Target) ? plan.Options.ClientOutputRoot : plan.Options.ServerOutputRoot;
            AddFile(plan, Path.Combine(root, context.Module, context.ProtocolName + "MockAndTest.generated.cs"), "MockAndTest", "Mock data and smoke test helper.", RenderMockAndTest(plan.Options, context));
        }
        if (plan.Options.Skills.HasFlag(ProtocolSkillKind.Migration)) AddFile(plan, Path.Combine(plan.Options.PlanOutputRoot, context.ProtocolName + ".migration.md"), "Migration", "Compatibility and migration notes.", RenderMigration(context));
    }

    private void AddRoutingInfrastructure(ProtocolSkillGenerationPlan plan)
    {
        if (TargetsServer(plan.Options.Target) && plan.Options.Skills.HasFlag(ProtocolSkillKind.ServerRouteRegistration))
        {
            AddServerCodeFile(plan, plan.Options.ServerRouteRoot, "Common", "ProtocolSkillServerRouting.generated", "ServerRouteRegistration", "Shared server routing adapter.", RenderServerRoutingInfrastructure(plan.Options), plan.Contexts.FirstOrDefault() ?? new ProtocolSkillContext());
        }
    }

    private void AddClientRuntimeInfrastructure(ProtocolSkillGenerationPlan plan)
    {
        if (TargetsClient(plan.Options.Target) && HasClientCompositionPipeline(plan.Options))
        {
            AddFile(plan, Path.Combine(plan.Options.ClientOutputRoot, "Common", "ProtocolSkillClientRuntime.generated.cs"), "ClientRuntimeSupport", "Shared client event bus and disposable helpers.", RenderClientRuntimeInfrastructure(plan.Options));
        }
    }

    private string RenderClientRuntimeInfrastructure(ProtocolSkillCodegenOptions options)
    {
        return "using System;\nusing System.Collections.Generic;\n\nnamespace " + options.ClientNamespace + "\n{\n"
            + "    /// <summary>\n"
            + "    /// 协议业务层的轻量事件总线。\n"
            + "    /// 生成的 Feature 会通过它发布请求成功、失败、缓存刷新等事件，业务层可以替换为项目自己的 EventBus。\n"
            + "    /// </summary>\n"
            + "    public interface IProtocolSkillEventBus\n    {\n"
            + "        IDisposable Subscribe<TEvent>(Action<TEvent> handler);\n"
            + "        void Publish<TEvent>(TEvent evt);\n"
            + "    }\n\n"
            + "    /// <summary>\n"
            + "    /// 默认内存事件总线，只用于让生成代码开箱可接入。\n"
            + "    /// 正式项目可以在 Feature 构造时传入自己的事件系统适配器。\n"
            + "    /// </summary>\n"
            + "    public sealed class InMemoryProtocolSkillEventBus : IProtocolSkillEventBus\n    {\n"
            + "        private readonly Dictionary<Type, List<Delegate>> _handlers = new Dictionary<Type, List<Delegate>>();\n"
            + "        public IDisposable Subscribe<TEvent>(Action<TEvent> handler)\n        {\n"
            + "            if (handler == null) return ProtocolSkillDisposable.Empty;\n"
            + "            Type type = typeof(TEvent);\n"
            + "            if (!_handlers.TryGetValue(type, out List<Delegate> handlers)) { handlers = new List<Delegate>(); _handlers[type] = handlers; }\n"
            + "            handlers.Add(handler);\n"
            + "            return new ProtocolSkillDisposable(() => handlers.Remove(handler));\n"
            + "        }\n"
            + "        public void Publish<TEvent>(TEvent evt)\n        {\n"
            + "            if (!_handlers.TryGetValue(typeof(TEvent), out List<Delegate> handlers)) return;\n"
            + "            foreach (Delegate handler in handlers.ToArray()) ((Action<TEvent>)handler)?.Invoke(evt);\n"
            + "        }\n"
            + "    }\n\n"
            + "    /// <summary>\n"
            + "    /// 统一的取消订阅句柄，确保 Feature Dispose 时能清理事件监听，避免重复回调和内存泄漏。\n"
            + "    /// </summary>\n"
            + "    public sealed class ProtocolSkillDisposable : IDisposable\n    {\n"
            + "        public static readonly IDisposable Empty = new ProtocolSkillDisposable(null);\n"
            + "        private Action _dispose;\n"
            + "        public ProtocolSkillDisposable(Action dispose) { _dispose = dispose; }\n"
            + "        public void Dispose() { Action action = _dispose; _dispose = null; action?.Invoke(); }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderClientApi(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        string requestType = RequestType(context);
        string responseType = ResponseType(context);
        string networkType = CSharpTypeName(options.NetworkFacadeType);
        var builder = new StringBuilder();
        builder.AppendLine("using System;");
        if (options.CodeStyle == ProtocolSkillCodeStyle.TaskAsync || options.CodeStyle == ProtocolSkillCodeStyle.UniTask) builder.AppendLine("using System.Threading;\nusing System.Threading.Tasks;");
        if (options.CodeStyle == ProtocolSkillCodeStyle.Coroutine) builder.AppendLine("using System.Collections;");
        builder.AppendLine("namespace " + options.ClientNamespace);
        builder.AppendLine("{");
        builder.AppendLine("    public sealed class " + context.ProtocolName + "ProtocolApi");
        builder.AppendLine("    {");
        builder.AppendLine("        private readonly " + networkType + " _network;");
        builder.AppendLine("        public " + context.ProtocolName + "ProtocolApi(" + networkType + " network) { _network = network; }");
        builder.AppendLine("        public void Send(" + requestType + " request, Action<" + responseType + "> onSuccess, Action<string> onError = null)");
        builder.AppendLine("        {");
        builder.AppendLine("            if (_network == null) { onError?.Invoke(\"NetworkFacade is null.\"); return; }");
        builder.AppendLine("            _network." + options.RequestSendMethod + "<" + responseType + ">(request, response =>");
        builder.AppendLine("            {");
        builder.AppendLine("                if (response == null) { onError?.Invoke(\"Empty response for " + context.ProtocolName + ".\"); return; }");
        builder.AppendLine("                onSuccess?.Invoke(response);");
        builder.AppendLine("            });");
        builder.AppendLine("        }");
        if (options.CodeStyle == ProtocolSkillCodeStyle.TaskAsync) AppendTaskApi(builder, requestType, responseType);
        if (options.CodeStyle == ProtocolSkillCodeStyle.UniTask) AppendUniTaskApi(builder, requestType, responseType);
        if (options.CodeStyle == ProtocolSkillCodeStyle.Coroutine) AppendCoroutineApi(builder, requestType, responseType);
        builder.AppendLine("    }");
        builder.AppendLine("}");
        return builder.ToString();
    }

    private string RenderClientPolicy(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        return "using System;\nusing UnityEngine;\n\nnamespace " + options.ClientNamespace + "\n{\n"
            + "    public sealed class " + context.ProtocolName + "ClientPolicy\n    {\n"
            + "        public int MaxRetryCount = 1;\n"
            + "        public float RetryDelaySeconds = 0.3f;\n"
            + "        public IDisposable BeginLoading(string reason) { Debug.Log(\"[ProtocolSkill] Begin \" + reason); return new LoadingScope(reason); }\n"
            + "        public bool ShouldRetry(int attempt, string error) { return attempt < MaxRetryCount && !string.IsNullOrWhiteSpace(error); }\n"
            + "        public string ToUserMessage(string error) { return string.IsNullOrWhiteSpace(error) ? \"Request failed.\" : error; }\n"
            + "        public void RefreshCache(" + ResponseType(context) + " response) { }\n"
            + "        private sealed class LoadingScope : IDisposable { private readonly string _reason; public LoadingScope(string reason) { _reason = reason; } public void Dispose() { Debug.Log(\"[ProtocolSkill] End \" + _reason); } }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderClientUseCase(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        string requestType = RequestType(context);
        string responseType = ResponseType(context);
        return "using System;\n\nnamespace " + options.ClientNamespace + "\n{\n"
            + "    public sealed class " + context.ProtocolName + "UseCase\n    {\n"
            + "        private readonly " + context.ProtocolName + "ProtocolApi _api;\n"
            + "        private readonly " + context.ProtocolName + "ClientPolicy _policy;\n"
            + "        public " + context.ProtocolName + "UseCase(" + context.ProtocolName + "ProtocolApi api, " + context.ProtocolName + "ClientPolicy policy = null) { _api = api; _policy = policy ?? new " + context.ProtocolName + "ClientPolicy(); }\n"
            + "        public void Execute(" + requestType + " request, Action<" + responseType + "> onCompleted, Action<string> onFailed = null)\n        {\n"
            + "            using (_policy.BeginLoading(\"" + context.ProtocolName + "\")) SendWithRetry(request, 0, onCompleted, onFailed);\n"
            + "        }\n"
            + "        private void SendWithRetry(" + requestType + " request, int attempt, Action<" + responseType + "> onCompleted, Action<string> onFailed)\n        {\n"
            + "            _api.Send(request, response => { _policy.RefreshCache(response); onCompleted?.Invoke(response); }, error => { if (_policy.ShouldRetry(attempt, error)) { SendWithRetry(request, attempt + 1, onCompleted, onFailed); return; } onFailed?.Invoke(_policy.ToUserMessage(error)); });\n"
            + "        }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderClientPresenter(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        return "namespace " + options.ClientNamespace + "\n{\n"
            + "    public sealed class " + context.ProtocolName + "PresenterSample\n    {\n"
            + "        private readonly " + context.ProtocolName + "UseCase _useCase;\n"
            + "        public " + context.ProtocolName + "PresenterSample(" + context.ProtocolName + "UseCase useCase) { _useCase = useCase; }\n"
            + "        public void Submit() { var request = new " + RequestType(context) + "(); _useCase.Execute(request, response => { }, error => { }); }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderClientFeature(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        string requestType = RequestType(context);
        string responseType = ResponseType(context);
        string networkType = CSharpTypeName(options.NetworkFacadeType);
        return "using System;\nusing System.Collections.Generic;\n\nnamespace " + options.ClientNamespace + "\n{\n"
            + "    /// <summary>\n"
            + "    /// " + context.ProtocolName + " 客户端协议业务入口。\n"
            + "    /// 这个类把 NetworkFacade、ProtocolApi、Policy、UseCase、Presenter 示例和事件总线完整串起来。\n"
            + "    /// 业务层通常只需要持有本 Feature，调用 Execute，并在 OnSucceeded/OnFailed 或 EventBus 中补具体表现逻辑。\n"
            + "    /// </summary>\n"
            + "    public sealed class " + context.ProtocolName + "ClientFeature : IDisposable\n    {\n"
            + "        private readonly List<IDisposable> _subscriptions = new List<IDisposable>();\n"
            + "        public " + context.ProtocolName + "ProtocolApi Api { get; }\n"
            + "        public " + context.ProtocolName + "ClientPolicy Policy { get; }\n"
            + "        public " + context.ProtocolName + "UseCase UseCase { get; }\n"
            + "        public " + context.ProtocolName + "PresenterSample Presenter { get; }\n"
            + "        public IProtocolSkillEventBus EventBus { get; }\n"
            + "        public event Action<" + responseType + "> OnSucceeded;\n"
            + "        public event Action<string> OnFailed;\n\n"
            + "        /// <summary>\n"
            + "        /// 构造时完成全部依赖装配。network 来自 M09-03 NetworkFacade，eventBus 可替换为项目自己的事件系统。\n"
            + "        /// </summary>\n"
            + "        public " + context.ProtocolName + "ClientFeature(" + networkType + " network, IProtocolSkillEventBus eventBus = null, " + context.ProtocolName + "ClientPolicy policy = null)\n        {\n"
            + "            EventBus = eventBus ?? new InMemoryProtocolSkillEventBus();\n"
            + "            Policy = policy ?? new " + context.ProtocolName + "ClientPolicy();\n"
            + "            Api = new " + context.ProtocolName + "ProtocolApi(network);\n"
            + "            UseCase = new " + context.ProtocolName + "UseCase(Api, Policy);\n"
            + "            Presenter = new " + context.ProtocolName + "PresenterSample(UseCase);\n"
            + "            RegisterGeneratedEvents();\n"
            + "        }\n\n"
            + "        /// <summary>\n"
            + "        /// 标准业务调用入口。生成层负责 loading、retry、错误映射、缓存刷新和事件分发；人工只需要补 UI 表现和领域规则。\n"
            + "        /// </summary>\n"
            + "        public void Execute(" + requestType + " request, Action<" + responseType + "> onSucceeded = null, Action<string> onFailed = null)\n        {\n"
            + "            UseCase.Execute(request, response =>\n"
            + "            {\n"
            + "                OnSucceeded?.Invoke(response);\n"
            + "                onSucceeded?.Invoke(response);\n"
            + "                EventBus.Publish(new " + context.ProtocolName + "SucceededEvent(request, response));\n"
            + "            }, error =>\n"
            + "            {\n"
            + "                OnFailed?.Invoke(error);\n"
            + "                onFailed?.Invoke(error);\n"
            + "                EventBus.Publish(new " + context.ProtocolName + "FailedEvent(request, error));\n"
            + "            });\n"
            + "        }\n\n"
            + "        /// <summary>\n"
            + "        /// 生成事件注册区。这里统一维护内部订阅，Dispose 时会自动注销，避免页面反复打开导致重复监听。\n"
            + "        /// </summary>\n"
            + "        private void RegisterGeneratedEvents()\n        {\n"
            + "            _subscriptions.Add(EventBus.Subscribe<" + context.ProtocolName + "SucceededEvent>(evt => Policy.RefreshCache(evt.Response)));\n"
            + "            // TODO: 在这里接入项目级埋点、红点刷新、背包/角色/邮件等领域事件转发。\n"
            + "        }\n\n"
            + "        public void Dispose()\n        {\n"
            + "            foreach (IDisposable subscription in _subscriptions) subscription.Dispose();\n"
            + "            _subscriptions.Clear();\n"
            + "            OnSucceeded = null;\n"
            + "            OnFailed = null;\n"
            + "        }\n"
            + "    }\n\n"
            + "    /// <summary>请求成功事件，供页面、缓存、埋点或业务系统订阅。</summary>\n"
            + "    public sealed class " + context.ProtocolName + "SucceededEvent\n    {\n"
            + "        public " + requestType + " Request { get; }\n"
            + "        public " + responseType + " Response { get; }\n"
            + "        public " + context.ProtocolName + "SucceededEvent(" + requestType + " request, " + responseType + " response) { Request = request; Response = response; }\n"
            + "    }\n\n"
            + "    /// <summary>请求失败事件，供页面提示、日志和降级策略订阅。</summary>\n"
            + "    public sealed class " + context.ProtocolName + "FailedEvent\n    {\n"
            + "        public " + requestType + " Request { get; }\n"
            + "        public string Error { get; }\n"
            + "        public " + context.ProtocolName + "FailedEvent(" + requestType + " request, string error) { Request = request; Error = error; }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderServerHandler(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        return "using System.Threading.Tasks;\n\nnamespace " + options.ServerNamespace + "\n{\n"
            + "    public sealed class " + context.ProtocolName + "Handler\n    {\n"
            + "        private readonly " + context.ProtocolName + "Service _service;\n"
            + "        private readonly " + context.ProtocolName + "Validator _validator = new " + context.ProtocolName + "Validator();\n"
            + "        private readonly " + context.ProtocolName + "Authorization _authorization = new " + context.ProtocolName + "Authorization();\n"
            + "        private readonly " + context.ProtocolName + "TransactionBoundary _transaction = new " + context.ProtocolName + "TransactionBoundary();\n"
            + "        private readonly " + context.ProtocolName + "ErrorMapper _errorMapper = new " + context.ProtocolName + "ErrorMapper();\n"
            + "        private readonly " + context.ProtocolName + "ServerObservability _observability = new " + context.ProtocolName + "ServerObservability();\n"
            + "        public " + context.ProtocolName + "Handler(" + context.ProtocolName + "Service service) { _service = service; }\n"
            + "        public async Task<" + ResponseType(context) + "> HandleAsync(" + RequestType(context) + " request, object session)\n        {\n"
            + "            _observability.Begin(\"" + context.ProtocolName + "\", request, session);\n"
            + "            try { string validationError = _validator.Validate(request); if (!string.IsNullOrWhiteSpace(validationError)) return _errorMapper.ToResponse(validationError); if (!_authorization.CanHandle(session, request)) return _errorMapper.ToResponse(\"permission_denied\"); return await _transaction.ExecuteAsync(() => _service.ExecuteAsync(request, session)); }\n"
            + "            catch (System.Exception ex) { _observability.Exception(\"" + context.ProtocolName + "\", ex); return _errorMapper.ToResponse(ex.Message); }\n"
            + "            finally { _observability.End(\"" + context.ProtocolName + "\"); }\n"
            + "        }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderServerGuards(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        string requestType = RequestType(context);
        string responseType = ResponseType(context);
        return "using System;\nusing System.Threading.Tasks;\nnamespace " + options.ServerNamespace + "\n{\n"
            + "    public sealed class " + context.ProtocolName + "Validator { public string Validate(" + requestType + " request) { if (request == null) return \"request_null\"; return string.Empty; } }\n"
            + "    public sealed class " + context.ProtocolName + "Authorization { public bool CanHandle(object session, " + requestType + " request) { return session != null; } }\n"
            + "    public sealed class " + context.ProtocolName + "TransactionBoundary { public Task<" + responseType + "> ExecuteAsync(Func<Task<" + responseType + ">> action) { return action(); } }\n"
            + "    public sealed class " + context.ProtocolName + "ErrorMapper { public " + responseType + " ToResponse(string error) { var response = new " + responseType + "(); " + KnownErrorAssignments(context) + " return response; } }\n"
            + "    public sealed class " + context.ProtocolName + "ServerObservability { public void Begin(string protocol, object request, object session) { Console.WriteLine(\"[Begin] \" + protocol); } public void End(string protocol) { Console.WriteLine(\"[End] \" + protocol); } public void Exception(string protocol, Exception exception) { Console.WriteLine(exception); } }\n"
            + "}\n";
    }

    private string RenderServerService(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        bool useRepository = options.DatabaseStrategy != ProtocolSkillDatabaseStrategy.None && options.Skills.HasFlag(ProtocolSkillKind.ServerRepository);
        string repositoryField = useRepository ? "        private readonly " + context.ProtocolName + "Repository _repository;\n" : string.Empty;
        string constructor = useRepository ? "        public " + context.ProtocolName + "Service(" + context.ProtocolName + "Repository repository) { _repository = repository; }\n" : "        public " + context.ProtocolName + "Service() { }\n";
        string repositoryCall = useRepository ? "            await _repository.TouchAsync(request, session);\n" : string.Empty;
        return "using System.Threading.Tasks;\nnamespace " + options.ServerNamespace + "\n{\n"
            + "    public sealed class " + context.ProtocolName + "Service\n    {\n"
            + repositoryField + constructor
            + "        public async Task<" + ResponseType(context) + "> ExecuteAsync(" + RequestType(context) + " request, object session)\n        {\n"
            + repositoryCall
            + "            return new " + ResponseType(context) + "();\n"
            + "        }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderServerRepository(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        return "using System.Threading.Tasks;\nnamespace " + options.ServerNamespace + "\n{\n"
            + "    public sealed class " + context.ProtocolName + "Repository\n    {\n"
            + "        public Task TouchAsync(" + RequestType(context) + " request, object session) { return Task.CompletedTask; }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderServerDbModel(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        var builder = new StringBuilder();
        builder.AppendLine("namespace " + options.ServerNamespace);
        builder.AppendLine("{");
        builder.AppendLine("    public sealed class " + context.ProtocolName + "DbModel");
        builder.AppendLine("    {");
        builder.AppendLine("        public long Id { get; set; }");
        builder.AppendLine("        public long CreatedAtUnixMs { get; set; }");
        builder.AppendLine("        public long UpdatedAtUnixMs { get; set; }");
        foreach (ProtocolSchemaField field in context.RequestFields.Where(field => !field.Deprecated)) builder.AppendLine("        public " + ToServerType(field.Type) + " " + ToPascal(field.Name) + " { get; set; }");
        builder.AppendLine("    }");
        builder.AppendLine("}");
        return builder.ToString();
    }

    private string RenderServerRouteRegistration(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        if (string.IsNullOrWhiteSpace(context.RequestName)) return "namespace " + options.ServerNamespace + "\n{\n    public static class " + context.ProtocolName + "RouteRegistration { public static void Register(IServerProtocolRouteRegistry registry) { } }\n}\n";
        return "namespace " + options.ServerNamespace + "\n{\n"
            + "    public static class " + context.ProtocolName + "RouteRegistration\n    {\n"
            + "        public const int RequestMessageId = " + context.RequestMessageId + ";\n"
            + "        public const int ResponseMessageId = " + context.ResponseMessageId + ";\n"
            + "        public static void Register(IServerProtocolRouteRegistry registry, " + context.ProtocolName + "Handler handler)\n        {\n"
            + "            if (registry == null) throw new System.ArgumentNullException(nameof(registry));\n"
            + "            if (handler == null) throw new System.ArgumentNullException(nameof(handler));\n"
            + "            registry.Register<" + RequestType(context) + ", " + ResponseType(context) + ">(RequestMessageId, \"" + context.RequestName + "\", \"" + context.ResponseName + "\", handler.HandleAsync);\n"
            + "        }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderServerFeature(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        bool useRepository = options.DatabaseStrategy != ProtocolSkillDatabaseStrategy.None && options.Skills.HasFlag(ProtocolSkillKind.ServerRepository);
        string repositoryProperty = useRepository ? "        public " + context.ProtocolName + "Repository Repository { get; }\n" : string.Empty;
        string repositoryCreate = useRepository ? "            Repository = new " + context.ProtocolName + "Repository();\n" : string.Empty;
        string serviceCreate = useRepository ? "            Service = new " + context.ProtocolName + "Service(Repository);\n" : "            Service = new " + context.ProtocolName + "Service();\n";
        return "namespace " + options.ServerNamespace + "\n{\n"
            + "    /// <summary>\n"
            + "    /// " + context.ProtocolName + " 服务端协议业务装配入口。\n"
            + "    /// 这里集中创建 Repository、Service、Handler，并完成 MessageID 到 Handler 的路由注册。\n"
            + "    /// 接入真实服务器时，可以把构造逻辑替换成项目 DI 容器，但 RegisterRoutes 的接入点保持稳定。\n"
            + "    /// </summary>\n"
            + "    public sealed class " + context.ProtocolName + "ServerFeature\n    {\n"
            + repositoryProperty
            + "        public " + context.ProtocolName + "Service Service { get; }\n"
            + "        public " + context.ProtocolName + "Handler Handler { get; }\n\n"
            + "        public " + context.ProtocolName + "ServerFeature()\n        {\n"
            + repositoryCreate
            + serviceCreate
            + "            Handler = new " + context.ProtocolName + "Handler(Service);\n"
            + "        }\n\n"
            + "        /// <summary>\n"
            + "        /// 把当前协议注册到服务器分发器。服务器启动时调用一次即可完成路由接入。\n"
            + "        /// </summary>\n"
            + "        public void RegisterRoutes(IServerProtocolRouteRegistry registry)\n        {\n"
            + "            " + context.ProtocolName + "RouteRegistration.Register(registry, Handler);\n"
            + "        }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderServerRoutingInfrastructure(ProtocolSkillCodegenOptions options)
    {
        return "using System;\nusing System.Collections.Generic;\nusing System.Threading.Tasks;\nnamespace " + options.ServerNamespace + "\n{\n"
            + "    public interface IServerProtocolRouteRegistry { void Register<TRequest, TResponse>(int requestMessageId, string requestName, string responseName, Func<TRequest, object, Task<TResponse>> handler); }\n"
            + "    public interface IServerProtocolDispatcher { Task<object> DispatchAsync(int requestMessageId, object request, object session); }\n"
            + "    public sealed class ProtocolSkillServerFeatureCollection\n    {\n"
            + "        private readonly List<Action<IServerProtocolRouteRegistry>> _registrations = new List<Action<IServerProtocolRouteRegistry>>();\n"
            + "        public void Add(Action<IServerProtocolRouteRegistry> registration) { if (registration != null) _registrations.Add(registration); }\n"
            + "        public void RegisterAll(IServerProtocolRouteRegistry registry) { foreach (Action<IServerProtocolRouteRegistry> registration in _registrations) registration(registry); }\n"
            + "    }\n"
            + "    public sealed class InMemoryServerProtocolRouteRegistry : IServerProtocolRouteRegistry, IServerProtocolDispatcher\n    {\n"
            + "        private readonly Dictionary<int, Func<object, object, Task<object>>> _routes = new Dictionary<int, Func<object, object, Task<object>>>();\n"
            + "        public void Register<TRequest, TResponse>(int requestMessageId, string requestName, string responseName, Func<TRequest, object, Task<TResponse>> handler) { _routes[requestMessageId] = async (request, session) => await handler((TRequest)request, session); }\n"
            + "        public Task<object> DispatchAsync(int requestMessageId, object request, object session) { if (!_routes.TryGetValue(requestMessageId, out var route)) throw new InvalidOperationException(\"No route: \" + requestMessageId); return route(request, session); }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderMockAndTest(ProtocolSkillCodegenOptions options, ProtocolSkillContext context)
    {
        string ns = TargetsClient(options.Target) ? options.ClientNamespace : options.ServerNamespace;
        return "namespace " + ns + "\n{\n"
            + "    public static class " + context.ProtocolName + "MockAndTest\n    {\n"
            + "        public static " + RequestType(context) + " CreateRequest() { return new " + RequestType(context) + "(); }\n"
            + "        public static " + ResponseType(context) + " CreateResponse() { return new " + ResponseType(context) + "(); }\n"
            + "        public static void SmokeTest() { }\n"
            + "    }\n"
            + "}\n";
    }

    private string RenderServerMigrationSql(ProtocolSkillContext context)
    {
        return "-- Review before applying.\nCREATE TABLE IF NOT EXISTS " + ToSnake(context.ProtocolName) + " (\n    id BIGINT PRIMARY KEY,\n    created_at_unix_ms BIGINT NOT NULL,\n    updated_at_unix_ms BIGINT NOT NULL\n);\n";
    }

    private string RenderMigration(ProtocolSkillContext context)
    {
        return "# " + context.ProtocolName + " Migration\n\n- Check old client compatibility.\n- Check request/response pair semantics.\n- Check DB backfill and rollback plan.\n";
    }

    private string RenderAiPromptMarkdown(ProtocolSkillGenerationPlan plan)
    {
        var builder = new StringBuilder();
        builder.AppendLine("# Protocol Business Logic AI Payload");
        builder.AppendLine("You are an AI coding skill inside a controlled Unity/game server toolchain. Generate business integration code only. Do not regenerate DTO, ProtocolIds or ProtocolDictionary.");
        builder.AppendLine();
        builder.AppendLine("## Business Requirement Supplement");
        builder.AppendLine("```text");
        builder.AppendLine(string.IsNullOrWhiteSpace(plan.Options.BusinessRequirementSupplement) ? "No extra requirement. Generate safe scaffolding only." : plan.Options.BusinessRequirementSupplement.Trim());
        builder.AppendLine("```");
        builder.AppendLine();
        builder.AppendLine("## Constraints");
        builder.AppendLine("- Client language is C#.");
        builder.AppendLine("- Server language is " + plan.Options.ServerLanguage + ".");
        builder.AppendLine("- Preserve manual code and generated blocks.");
        builder.AppendLine("- Include review gates for payment, assets, battle, database migration and permissions.");
        builder.AppendLine("- 必须生成可闭环接入代码：引用、构造函数、依赖装配、事件注册/注销、客户端 Feature 入口、服务端 route registration、handler/service/repository/DB model 之间的调用链都要补齐。");
        builder.AppendLine("- 生成完成后的目标是开发者只写具体业务规则和 UI 表现，不再手动补基础 wiring。");
        builder.AppendLine("- Return strict JSON with files/path/skill/reason/content.");
        builder.AppendLine();
        builder.AppendLine("## Support Skill Packs");
        foreach (string prompt in LoadSupportSkillPrompts()) builder.AppendLine("```markdown\n" + prompt.Trim() + "\n```");
        builder.AppendLine();
        builder.AppendLine("## Capability Skills");
        foreach (ProtocolSkillDefinition skill in ProtocolSkillRegistry.GetAll().Where(skill => plan.Options.Skills.HasFlag(skill.Kind)))
        {
            builder.AppendLine("### " + skill.DisplayName);
            builder.AppendLine(skill.Description);
            if (File.Exists(skill.PromptTemplatePath)) builder.AppendLine("```markdown\n" + File.ReadAllText(skill.PromptTemplatePath, Encoding.UTF8).Trim() + "\n```");
        }
        builder.AppendLine();
        builder.AppendLine("## Contexts");
        foreach (ProtocolSkillContext context in plan.Contexts)
        {
            foreach (ProtocolSkillScenarioDefinition scenario in ProtocolSkillScenarioRegistry.GetMatches(context))
            {
                builder.AppendLine("Matched scenario: " + scenario.DisplayName + " - " + scenario.Description);
                string scenarioPrompt = ProtocolSkillScenarioRegistry.LoadPromptTemplate(scenario);
                if (!string.IsNullOrWhiteSpace(scenarioPrompt)) builder.AppendLine("```markdown\n" + scenarioPrompt.Trim() + "\n```");
            }
            builder.AppendLine(_contextBuilder.RenderContextMarkdown(context));
        }
        builder.AppendLine("## Planned Files");
        foreach (ProtocolSkillPlanFile file in plan.Files) builder.AppendLine("- `" + file.Path + "` [" + file.Skill + "] " + file.Reason);
        return builder.ToString();
    }

    private string RenderAiPromptJson(ProtocolSkillGenerationPlan plan)
    {
        var builder = new StringBuilder();
        builder.AppendLine("{");
        builder.AppendLine("  \"planId\": \"" + plan.PlanId + "\",");
        builder.AppendLine("  \"target\": \"" + plan.Options.Target + "\",");
        builder.AppendLine("  \"skills\": \"" + plan.Options.Skills + "\",");
        builder.AppendLine("  \"clientLanguage\": \"CSharp\",");
        builder.AppendLine("  \"serverLanguage\": \"" + plan.Options.ServerLanguage + "\",");
        builder.AppendLine("  \"businessRequirementSupplement\": \"" + ProtocolJson.Escape(plan.Options.BusinessRequirementSupplement) + "\",");
        builder.AppendLine("  \"contexts\": [");
        for (int i = 0; i < plan.Contexts.Count; i++)
        {
            builder.Append(Indent(_contextBuilder.RenderContextJson(plan.Contexts[i]).Trim(), 2));
            if (i < plan.Contexts.Count - 1) builder.Append(",");
            builder.AppendLine();
        }
        builder.AppendLine("  ]");
        builder.AppendLine("}");
        return builder.ToString();
    }

    private void WritePlanFiles(ProtocolSkillGenerationPlan plan)
    {
        string root = ToAbsolutePath(plan.Options.PlanOutputRoot);
        Directory.CreateDirectory(root);
        if (plan.Options.GeneratePlanMarkdown) File.WriteAllText(Path.Combine(root, plan.PlanId + ".skill-plan.md"), RenderPlanMarkdown(plan), new UTF8Encoding(false));
        if (plan.Options.GenerateAiPromptPayload)
        {
            File.WriteAllText(Path.Combine(root, plan.PlanId + ".ai-payload.md"), RenderAiPromptMarkdown(plan), new UTF8Encoding(false));
            File.WriteAllText(Path.Combine(root, plan.PlanId + ".ai-payload.json"), RenderAiPromptJson(plan), new UTF8Encoding(false));
        }
    }

    private IEnumerable<string> LoadSupportSkillPrompts()
    {
        string root = ToAbsolutePath(SupportSkillRoot);
        if (!Directory.Exists(root)) yield break;
        foreach (string path in Directory.GetFiles(root, "*.support.skill.md").OrderBy(path => path, StringComparer.OrdinalIgnoreCase)) yield return File.ReadAllText(path, Encoding.UTF8);
    }

    private void AddFile(ProtocolSkillGenerationPlan plan, string path, string skill, string reason, string content)
    {
        plan.Files.Add(new ProtocolSkillPlanFile { Path = path.Replace("\\", "/"), Action = File.Exists(ToAbsolutePath(path)) ? "update-generated-block" : "create", Skill = skill, Reason = reason, Content = content });
    }

    private void AddServerCodeFile(ProtocolSkillGenerationPlan plan, string root, string module, string fileName, string skill, string reason, string csharpContent, ProtocolSkillContext context)
    {
        string extension = GetServerLanguageExtension(plan.Options.ServerLanguage);
        string content = plan.Options.ServerLanguage == ProtocolSkillServerLanguage.CSharp ? csharpContent : RenderNonCSharpServerSkeleton(plan.Options, context, skill, csharpContent);
        AddFile(plan, Path.Combine(root, module, fileName + extension), skill, reason + " [" + plan.Options.ServerLanguage + "]", content);
    }

    private string WrapGeneratedContent(ProtocolSkillPlanFile file)
    {
        if (file.Path.EndsWith(".md", StringComparison.OrdinalIgnoreCase) || file.Path.EndsWith(".sql", StringComparison.OrdinalIgnoreCase)) return file.Content ?? string.Empty;
        return "// <auto-generated-protocol-skill skill=\"" + file.Skill + "\">\n" + (file.Content ?? string.Empty).TrimEnd() + "\n// </auto-generated-protocol-skill>\n";
    }

    private string ReplaceGeneratedBlock(string current, string generated, string skill)
    {
        string start = "// <auto-generated-protocol-skill skill=\"" + skill + "\">";
        string end = "// </auto-generated-protocol-skill>";
        int startIndex = current.IndexOf(start, StringComparison.Ordinal);
        int endIndex = current.IndexOf(end, StringComparison.Ordinal);
        return startIndex >= 0 && endIndex > startIndex ? current.Substring(0, startIndex) + generated + current.Substring(endIndex + end.Length) : current.TrimEnd() + "\n\n" + generated;
    }

    private string ToAbsolutePath(string path) { return Path.IsPathRooted(path) ? path : Path.GetFullPath(Path.Combine(_repoRoot, path)); }
    private static bool TargetsClient(ProtocolSkillTarget target) { return target == ProtocolSkillTarget.Client || target == ProtocolSkillTarget.Both; }
    private static bool TargetsServer(ProtocolSkillTarget target) { return target == ProtocolSkillTarget.Server || target == ProtocolSkillTarget.Both; }
    private static bool HasClientSkill(ProtocolSkillCodegenOptions options)
    {
        return options.Skills.HasFlag(ProtocolSkillKind.ClientApiWrapper)
            || options.Skills.HasFlag(ProtocolSkillKind.ClientUseCase)
            || options.Skills.HasFlag(ProtocolSkillKind.ClientPresenterBinding);
    }

    private static bool HasServerSkill(ProtocolSkillCodegenOptions options)
    {
        return options.Skills.HasFlag(ProtocolSkillKind.ServerHandler)
            || options.Skills.HasFlag(ProtocolSkillKind.ServerService)
            || options.Skills.HasFlag(ProtocolSkillKind.ServerRepository)
            || options.Skills.HasFlag(ProtocolSkillKind.ServerRouteRegistration);
    }

    private static bool HasClientCompositionPipeline(ProtocolSkillCodegenOptions options)
    {
        return options.Skills.HasFlag(ProtocolSkillKind.ClientApiWrapper)
            && options.Skills.HasFlag(ProtocolSkillKind.ClientUseCase)
            && options.Skills.HasFlag(ProtocolSkillKind.ClientPresenterBinding);
    }

    private static bool HasServerCompositionPipeline(ProtocolSkillCodegenOptions options)
    {
        return options.Skills.HasFlag(ProtocolSkillKind.ServerHandler)
            && options.Skills.HasFlag(ProtocolSkillKind.ServerService)
            && options.Skills.HasFlag(ProtocolSkillKind.ServerRouteRegistration);
    }

    private static string RequestType(ProtocolSkillContext context) { return string.IsNullOrWhiteSpace(context.RequestName) ? "object" : "global::" + context.RequestName; }
    private static string ResponseType(ProtocolSkillContext context) { return string.IsNullOrWhiteSpace(context.ResponseName) ? "NetMessage" : "global::" + context.ResponseName; }
    private static string CSharpTypeName(string typeName)
    {
        if (string.IsNullOrWhiteSpace(typeName)) return "object";
        if (typeName.StartsWith("global::", StringComparison.Ordinal) || typeName.IndexOf('.') >= 0) return typeName;
        return "global::" + typeName;
    }

    private static void AppendTaskApi(StringBuilder builder, string requestType, string responseType)
    {
        builder.AppendLine("        public Task<" + responseType + "> SendAsync(" + requestType + " request, CancellationToken cancellationToken = default) { var source = new TaskCompletionSource<" + responseType + ">(); if (cancellationToken.CanBeCanceled) cancellationToken.Register(() => source.TrySetCanceled(cancellationToken)); Send(request, r => source.TrySetResult(r), e => source.TrySetException(new InvalidOperationException(e))); return source.Task; }");
    }

    private static void AppendUniTaskApi(StringBuilder builder, string requestType, string responseType)
    {
        builder.AppendLine("#if CYSHARP_UNITASK");
        builder.AppendLine("        public Cysharp.Threading.Tasks.UniTask<" + responseType + "> SendUniTaskAsync(" + requestType + " request, CancellationToken cancellationToken = default) { var source = new Cysharp.Threading.Tasks.UniTaskCompletionSource<" + responseType + ">(); if (cancellationToken.CanBeCanceled) cancellationToken.Register(() => source.TrySetCanceled(cancellationToken)); Send(request, r => source.TrySetResult(r), e => source.TrySetException(new InvalidOperationException(e))); return source.Task; }");
        builder.AppendLine("#endif");
    }

    private static void AppendCoroutineApi(StringBuilder builder, string requestType, string responseType)
    {
        builder.AppendLine("        public IEnumerator SendCoroutine(" + requestType + " request, Action<" + responseType + "> onSuccess, Action<string> onError = null) { bool done = false; Send(request, r => { done = true; onSuccess?.Invoke(r); }, e => { done = true; onError?.Invoke(e); }); while (!done) yield return null; }");
    }

    private static string KnownErrorAssignments(ProtocolSkillContext context)
    {
        var builder = new StringBuilder();
        foreach (ProtocolSchemaField field in context.ResponseFields)
        {
            string lower = (field.Name ?? string.Empty).ToLowerInvariant();
            if ((lower == "code" || lower == "errorcode" || lower == "resultcode") && IsInteger(field.Type)) builder.Append("response.").Append(field.Name).Append(" = -1; ");
            if ((lower == "message" || lower == "errormessage" || lower == "reason") && IsString(field.Type)) builder.Append("response.").Append(field.Name).Append(" = error; ");
            if ((lower == "success" || lower == "ok") && IsBool(field.Type)) builder.Append("response.").Append(field.Name).Append(" = false; ");
        }
        return builder.ToString();
    }

    private static string ToServerType(string type)
    {
        string name = ProtocolTypeReference.Parse(type).Name.ToLowerInvariant();
        if (name == "int32") return "int";
        if (name == "int64") return "long";
        if (name == "boolean") return "bool";
        if (name == "int" || name == "long" || name == "float" || name == "double" || name == "bool" || name == "string") return name;
        return "string";
    }

    private static string ToSnake(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "unnamed";
        var builder = new StringBuilder();
        for (int i = 0; i < value.Length; i++) { char c = value[i]; if (char.IsUpper(c) && i > 0) builder.Append('_'); builder.Append(char.ToLowerInvariant(c)); }
        return builder.ToString();
    }

    private static string ToPascal(string value) { return string.IsNullOrWhiteSpace(value) ? "Value" : char.ToUpperInvariant(value[0]) + value.Substring(1); }
    private static bool IsInteger(string type) { string n = ProtocolTypeReference.Parse(type).Name.ToLowerInvariant(); return n == "int" || n == "int32" || n == "long" || n == "int64"; }
    private static bool IsString(string type) { return ProtocolTypeReference.Parse(type).Name.Equals("string", StringComparison.OrdinalIgnoreCase); }
    private static bool IsBool(string type) { string n = ProtocolTypeReference.Parse(type).Name.ToLowerInvariant(); return n == "bool" || n == "boolean"; }
    private static string GetServerLanguageExtension(ProtocolSkillServerLanguage language)
    {
        switch (language)
        {
            case ProtocolSkillServerLanguage.TypeScriptNodeJs: return ".ts";
            case ProtocolSkillServerLanguage.Python: return ".py";
            case ProtocolSkillServerLanguage.Java: return ".java";
            case ProtocolSkillServerLanguage.Go: return ".go";
            case ProtocolSkillServerLanguage.Kotlin: return ".kt";
            default: return ".cs";
        }
    }
    private static string RenderNonCSharpServerSkeleton(ProtocolSkillCodegenOptions options, ProtocolSkillContext context, string skill, string csharpReference)
    {
        return "# Generated by Protocol Business Logic Studio\n# Language: " + options.ServerLanguage + "\n# Protocol: " + context.ProtocolName + "\n# Skill: " + skill + "\n\n/*\n" + csharpReference.Replace("/*", "/ *").Replace("*/", "* /") + "\n*/\n";
    }
    private static string Indent(string text, int depth)
    {
        string pad = new string(' ', depth * 2);
        return string.Join("\n", (text ?? string.Empty).Replace("\r\n", "\n").Split('\n').Select(line => pad + line));
    }
}
