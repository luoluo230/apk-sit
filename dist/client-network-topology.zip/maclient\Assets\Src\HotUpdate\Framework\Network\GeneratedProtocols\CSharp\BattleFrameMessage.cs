﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 战斗帧上报/追帧请求(兼容旧版帧同步)
/// </summary>
public class BattleFrame_c2s
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 客户端当前帧号
    /// </summary>
    public int Frame { get; set; }
    /// <summary>
    /// 输入指令列表
    /// </summary>
    public BattleOperation[] Operations { get; set; }
    /// <summary>
    /// 客户端预测状态哈希(可空)
    /// </summary>
    public string PredictedStateHash { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 服务器权威帧下发/回放片段
/// </summary>
public class BattleFrame_s2c
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 当前阶段
    /// </summary>
    public BattlePhase Phase { get; set; }
    /// <summary>
    /// 当前帧索引/确认帧
    /// </summary>
    public int Frame { get; set; }
    /// <summary>
    /// 已确认/模拟到的帧
    /// </summary>
    public int AckFrame { get; set; }
    /// <summary>
    /// 帧事件包
    /// </summary>
    public BattleFrameBundle[] Frames { get; set; }
    /// <summary>
    /// 新的锚点
    /// </summary>
    public BattleTimelineAnchor NextAnchor { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

