// 自动生成的协议文件

// 定义协议类


// 获取排行榜请求
class GetLeaderboard_c2s {
    constructor() {
        this.BoardType = '';
        this.PageIndex = 0;
        this.PageSize = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 获取排行榜响应
class GetLeaderboard_s2c {
    constructor() {
        this.Leaderboard = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetLeaderboard_c2s,
    GetLeaderboard_s2c,
};
