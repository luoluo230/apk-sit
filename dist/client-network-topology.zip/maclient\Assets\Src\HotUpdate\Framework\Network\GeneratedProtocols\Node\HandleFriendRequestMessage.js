// 自动生成的协议文件

// 定义协议类


// 处理好友申请(同意/拒绝)
class HandleFriendRequest_c2s {
    constructor() {
        this.RequestId = null;
        this.Accept = false;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 处理好友申请结果
class HandleFriendRequest_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    HandleFriendRequest_c2s,
    HandleFriendRequest_s2c,
};
