// 自动生成的协议文件

// 定义协议类


// 领取好友赠送的体力/友情点
class ReceiveFriendEnergy_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 领取好友体力结果
class ReceiveFriendEnergy_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Rewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ReceiveFriendEnergy_c2s,
    ReceiveFriendEnergy_s2c,
};
