using System;
using System.Collections.Generic;

/// <summary>
/// 网络层字节数组对象池。
/// 主要用于接收缓冲和拆包过程，减少频繁分配大块 byte[] 带来的 GC 压力。
/// </summary>
public sealed class ByteArrayPool
{
    private readonly Dictionary<int, Stack<byte[]>> _buckets = new Dictionary<int, Stack<byte[]>>();
    private readonly int _maxBucketSize;

    public static readonly ByteArrayPool Shared = new ByteArrayPool(1 << 20); // 1 MB max bucket

    /// <summary>
    /// 创建一个按 2 的幂分桶的字节数组池。
    /// </summary>
    public ByteArrayPool(int maxBucketSize)
    {
        _maxBucketSize = Math.Max(1024, maxBucketSize);
    }

    /// <summary>
    /// 租用一个至少能容纳指定长度的缓冲区。
    /// </summary>
    public byte[] Rent(int minimumLength)
    {
        int size = GetBucketSize(minimumLength);
        if (size > _maxBucketSize)
        {
            return new byte[minimumLength];
        }

        if (_buckets.TryGetValue(size, out var bucket) && bucket.Count > 0)
        {
            return bucket.Pop();
        }

        return new byte[size];
    }

    /// <summary>
    /// 归还缓冲区到对象池。
    /// </summary>
    public void Return(byte[] buffer)
    {
        if (buffer == null)
        {
            return;
        }

        int size = buffer.Length;
        if (size > _maxBucketSize)
        {
            return;
        }

        if (!_buckets.TryGetValue(size, out var bucket))
        {
            bucket = new Stack<byte[]>();
            _buckets[size] = bucket;
        }

        bucket.Push(buffer);
    }

    /// <summary>
    /// 计算最接近的 2 的幂桶大小。
    /// </summary>
    private static int GetBucketSize(int minimumLength)
    {
        int size = 1;
        while (size < minimumLength)
        {
            size <<= 1;
        }

        return size;
    }
}
