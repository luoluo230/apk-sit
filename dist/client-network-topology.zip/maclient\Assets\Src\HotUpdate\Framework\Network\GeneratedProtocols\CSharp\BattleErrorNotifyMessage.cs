﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 战斗错误通知(推送)
/// </summary>
public class BattleErrorNotify_s2c
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 错误码
    /// </summary>
    public string ErrorCode { get; set; }
    /// <summary>
    /// 错误说明
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 是否可重试
    /// </summary>
    public bool Retryable { get; set; }
    /// <summary>
    /// 是否需要终止战斗
    /// </summary>
    public bool NeedTerminate { get; set; }
    /// <summary>
    /// 错误发生 Tick
    /// </summary>
    public int TickIndex { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

