// 自动生成的协议文件

// 定义协议类


// 购买商店物品
class BuyShopItem_c2s {
    constructor() {
        this.ShopType = null;
        this.SlotIndex = 0;
        this.BuyCount = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 购买商店物品结果
class BuyShopItem_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Item = null;
        this.Rewards = [];
        this.ResourceChanges = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    BuyShopItem_c2s,
    BuyShopItem_s2c,
};
