using System;
using System.Collections.Generic;

/// <summary>
/// 底层通用链路矩阵。
/// 该矩阵不绑定具体业务 DTO，仅描述网络底层生命周期阶段、输入输出、状态变化与可观测点。
/// </summary>
public static class NetworkLifecycleMatrix
{
    /// <summary>
    /// 链路阶段定义。
    /// </summary>
    public enum Stage
    {
        Bootstrap,
        EndpointResolve,
        AuthSession,
        KeepAlive,
        ConnectionResilience,
        Messaging,
        LogoutTeardown
    }

    /// <summary>
    /// 单阶段链路描述。
    /// </summary>
    public sealed class Entry
    {
        /// <summary>阶段。</summary>
        public Stage StageName;
        /// <summary>输入。</summary>
        public string Input;
        /// <summary>输出。</summary>
        public string Output;
        /// <summary>状态机行为。</summary>
        public string StateTransition;
        /// <summary>超时与重试。</summary>
        public string TimeoutRetry;
        /// <summary>错误码集合。</summary>
        public string ErrorCodes;
        /// <summary>关键日志键。</summary>
        public string LogKeys;
    }

    /// <summary>
    /// 通用链路矩阵快照。
    /// </summary>
    public static readonly IReadOnlyList<Entry> Entries = new List<Entry>
    {
        new Entry
        {
            StageName = Stage.Bootstrap,
            Input = "ProtocolNetworkSettings",
            Output = "NetworkManager/GameNetworkConfig生效参数",
            StateTransition = "Uninitialized -> ConfigApplied",
            TimeoutRetry = "N/A",
            ErrorCodes = "INVALID_ARGUMENT,SERIALIZER_NOT_FOUND,SIMULATION_CONFIG_INVALID",
            LogKeys = "ConfigApplied,SerializerResolved"
        },
        new Entry
        {
            StageName = Stage.EndpointResolve,
            Input = "EnableRollingServerMode,SingleServerId,EnvironmentPresets",
            Output = "serverId + endpoint",
            StateTransition = "Resolved",
            TimeoutRetry = "N/A",
            ErrorCodes = "INVALID_ARGUMENT",
            LogKeys = "LoginModeDecision,ConfigApplied"
        },
        new Entry
        {
            StageName = Stage.AuthSession,
            Input = "Register/Login/SelectServer/Token",
            Output = "Token缓存 + 会话建立",
            StateTransition = "Unauthenticated -> Authenticated",
            TimeoutRetry = "RequestTimeout + reconnect policy",
            ErrorCodes = "TOKEN_MISSING,BUSINESS_FAILED,REQUEST_TIMEOUT",
            LogKeys = "TransportSelected,ConfigApplied"
        },
        new Entry
        {
            StageName = Stage.KeepAlive,
            Input = "HeartbeatIntervalMs/HeartbeatTimeoutMs",
            Output = "会话存活与服务器时间校准",
            StateTransition = "Alive/Timeout",
            TimeoutRetry = "HeartbeatTimeout触发重连",
            ErrorCodes = "REQUEST_TIMEOUT",
            LogKeys = "ConfigApplied"
        },
        new Entry
        {
            StageName = Stage.ConnectionResilience,
            Input = "MaxReconnectAttempts,ReconnectBaseDelayMs",
            Output = "重连成功或失败",
            StateTransition = "Disconnected -> Reconnecting -> Recovered/Failed",
            TimeoutRetry = "指数退避重连",
            ErrorCodes = "TRANSPORT_NOT_READY,REQUEST_TIMEOUT",
            LogKeys = "ConfigApplied,SimulationActive"
        },
        new Entry
        {
            StageName = Stage.Messaging,
            Input = "PayloadEncoding,Reliable,Compression,Encryption",
            Output = "请求响应/推送/ACK",
            StateTransition = "Send -> Acked/Failed",
            TimeoutRetry = "AckTimeout + MaxRetryCount",
            ErrorCodes = "SERIALIZER_ERROR,COMPRESSION_ERROR,ENCRYPTION_ERROR",
            LogKeys = "SerializerResolved,TransportSelected"
        },
        new Entry
        {
            StageName = Stage.LogoutTeardown,
            Input = "Logout request + clear token",
            Output = "连接关闭 + 本地状态清理",
            StateTransition = "Authenticated -> LoggedOut",
            TimeoutRetry = "N/A",
            ErrorCodes = "UNKNOWN",
            LogKeys = "ConfigApplied"
        }
    };

    /// <summary>
    /// 生成可日志输出的链路矩阵文本。
    /// </summary>
    /// <returns>矩阵文本。</returns>
    public static string BuildReport()
    {
        var lines = new List<string>(Entries.Count);
        foreach (var entry in Entries)
        {
            lines.Add(
                $"{entry.StageName}:IN={entry.Input};OUT={entry.Output};STATE={entry.StateTransition};TIMEOUT={entry.TimeoutRetry};ERR={entry.ErrorCodes};LOG={entry.LogKeys}");
        }

        return string.Join(" | ", lines);
    }
}
