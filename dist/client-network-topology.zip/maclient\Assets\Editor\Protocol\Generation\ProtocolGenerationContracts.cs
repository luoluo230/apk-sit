using System.Collections.Generic;

public interface IProtocolSourceProvider
{
    string SchemaPath { get; }
    string LoadSource();
}

public interface IProtocolArtifactGenerator
{
    bool GenerateAll(out string output);
}

public interface IProtocolCompatibilityChecker
{
    bool Validate(out string output);
}

public interface IProtocolDocGenerator
{
    IReadOnlyList<string> GetGeneratedDocumentPaths();
}

public interface IProtocolTemplateGenerator
{
    string TemplateRoot { get; }
}

public interface IProtocolCatalogWriter
{
    string CatalogPath { get; }
}

public interface IProtocolArtifactReporter
{
    ProtocolArtifactPaths GetArtifactPaths();
    ProtocolSourceSummary BuildSourceSummary();
}

public sealed class ProtocolArtifactPaths
{
    public string SourceSchemaPath { get; set; }
    public string NormalizedCatalogPath { get; set; }
    public string GeneratedRoot { get; set; }
    public string ClientDtoRoot { get; set; }
    public string ServerDtoRoot { get; set; }
    public string HandlerTemplateRoot { get; set; }
    public string ClientProtocolIdsPath { get; set; }
    public string ServerProtocolIdsPath { get; set; }
    public string ClientDictionaryPath { get; set; }
    public string ServerDictionaryPath { get; set; }
    public string CompatibilityReportPath { get; set; }
    public string DtoManifestPath { get; set; }
    public string StatusDocPath { get; set; }
}

public sealed class ProtocolSourceSummary
{
    public string SourcePath { get; set; }
    public int TotalDefinitions { get; set; }
    public int MessageCount { get; set; }
    public int RequestCount { get; set; }
    public int ResponseCount { get; set; }
    public int PushCount { get; set; }
    public int CustomClassCount { get; set; }
    public int EnumCount { get; set; }
    public int DuplicateIdCount { get; set; }
    public bool SourceExists { get; set; }
}
