// 自动生成的协议文件

// 定义协议类


// 邀请加入队伍
class InviteToTeam_c2s {
    constructor() {
        this.TargetPlayerId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 邀请加入队伍结果
class InviteToTeam_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Invite = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    InviteToTeam_c2s,
    InviteToTeam_s2c,
};
