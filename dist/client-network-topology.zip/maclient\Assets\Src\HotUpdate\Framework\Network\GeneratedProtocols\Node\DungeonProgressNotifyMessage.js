// 自动生成的协议文件

// 定义协议类


// 副本进度广播
class DungeonProgressNotify_s2c {
    constructor() {
        this.DungeonId = 0;
        this.Progress = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DungeonProgressNotify_s2c,
};
