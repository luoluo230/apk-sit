﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 会话心跳请求，轻量校验 Token 并可选返回档案
/// </summary>
public class Heartbeat_c2s
{
    /// <summary>
    /// 是否需要返回玩家档案，默认 false
    /// </summary>
    public bool IncludeProfile { get; set; }
    /// <summary>
    /// 客户端时间戳(Unix)，用于时间差调试，可选
    /// </summary>
    public long ClientTime { get; set; }
}

/// <summary>
/// 会话心跳响应，返回会话有效性与服务器时间
/// </summary>
public class Heartbeat_s2c
{
    /// <summary>
    /// 会话是否有效
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 服务器当前 Unix 时间戳
    /// </summary>
    public long ServerTime { get; set; }
    /// <summary>
    /// Token 过期时间戳(Unix)
    /// </summary>
    public long TokenExpireAt { get; set; }
    /// <summary>
    /// 当 IncludeProfile=true 且会话有效时返回最新档案
    /// </summary>
    public PlayerProfile Profile { get; set; }
}

