﻿using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ProtocolNetworkSettings 的运行时加载与应用入口。
/// 负责把编辑器配置闭环应用到 NetworkManager 与 GameNetworkConfig。
/// </summary>
public static class ProtocolNetworkSettingsRuntime
{
    /// <summary>
    /// 网络配置字段到运行时生效点的映射表（用于闭环自检与排障）。
    /// Key: ProtocolNetworkSettings 字段名
    /// Value: 生效目标 + 生效时机 + 关键日志键
    /// </summary>
    public static readonly IReadOnlyDictionary<string, string> EffectiveMappingTable = new Dictionary<string, string>
    {
        { "TransportKind", "NetworkManager.transportType | ApplyAll时立即生效 | TransportSelected" },
        { "EndpointUrl", "NetworkManager.serverUri(经环境解析) | ApplyAll时立即生效 | ConfigApplied" },
        { "ActiveEnvironmentId", "ResolveEndpoint环境选择器 | ApplyAll时立即生效 | ConfigApplied" },
        { "EnvironmentPresets", "ResolveEndpoint候选列表 | ApplyAll时立即生效 | ConfigApplied" },
        { "PayloadEncoding", "NetworkPayloadPipeline serializer选择 | ApplyAll时立即生效 | SerializerResolved" },
        { "CustomSerializerName", "Custom serializer注册名解析 | 首次发送前校验 | SerializerResolved" },
        { "CommunicationMode", "GameNetworkConfig默认路由模板(可靠性/优先级) | ApplyAll时生效 | ConfigApplied" },
        { "ConnectTimeoutMs", "NetworkManager.connectTimeoutSeconds | Connect流程内生效 | ConfigApplied" },
        { "RequestTimeoutMs", "NetworkManager.requestTimeoutSeconds + GameNetworkConfig.RequestTimeoutSeconds | 请求生命周期生效 | ConfigApplied" },
        { "HeartbeatIntervalMs", "NetworkManager.heartBeatInterval + enableHeartbeatRequest | Tick周期生效 | ConfigApplied" },
        { "HeartbeatTimeoutMs", "NetworkManager.heartbeatTimeoutSeconds | Tick超时判定生效 | ConfigApplied" },
        { "MaxReconnectAttempts", "NetworkManager.maxReconnectAttempts | 重连流程生效 | ConfigApplied" },
        { "ReconnectBaseDelayMs", "NetworkManager.reconnectDelay | 重连流程生效 | ConfigApplied" },
        { "EnableReliableDelivery", "NetworkManager.enableReliableDelivery | 发送/ACK流程生效 | ConfigApplied" },
        { "AckTimeoutMs", "NetworkManager.reliableTimeout | ACK重试流程生效 | ConfigApplied" },
        { "MaxRetryCount", "NetworkManager.reliableMaxRetry | ACK重试流程生效 | ConfigApplied" },
        { "EnableCompression", "NetworkPayloadPipeline压缩开关 | 编解码流程生效 | ConfigApplied" },
        { "EnableEncryption", "NetworkPayloadPipeline加密开关 | 编解码流程生效 | ConfigApplied" },
        { "ClientFrameRate", "GameNetworkConfig.ClientFrameRate | 玩法同步节拍读取生效 | ConfigApplied" },
        { "SnapshotIntervalMs", "GameNetworkConfig.SnapshotIntervalMs | 快照节奏读取生效 | ConfigApplied" },
        { "EnableSimulation", "NetworkManager.enableGlobalSimulation | 全局发送链路生效 | SimulationActive" },
        { "SimulatedLatencyMs", "NetworkManager.simulatedLatencyMs | 全局发送链路生效 | SimulationActive" },
        { "SimulatedJitterMs", "NetworkManager.simulatedJitterMs | 全局发送链路生效 | SimulationActive" },
        { "SimulatedPacketLossPercent", "NetworkManager.simulatedPacketLossPercent | 全局发送链路生效 | SimulationActive" },
        { "SimulatedDuplicatePercent", "NetworkManager.simulatedDuplicatePercent | 全局发送链路生效 | SimulationActive" },
        { "SimulatedReorderPercent", "NetworkManager.simulatedReorderPercent | 全局发送链路生效 | SimulationActive" },
        { "SimulatedBandwidthKbps", "NetworkManager.simulatedBandwidthKbps | 全局发送链路生效 | SimulationActive" },
        { "SimulatedDisconnectAfterSeconds", "NetworkManager.simulatedDisconnectAfterSeconds | 全局发送链路生效 | SimulationActive" },
        { "SimulationSeed", "NetworkManager.simulationSeed | 全局发送链路生效 | SimulationActive" },
        { "EnableRollingServerMode", "GameNetworkConfig.EnableRollingServerMode | 登录进服决策生效 | LoginModeDecision" },
        { "SingleServerId", "GameNetworkConfig.SingleServerId | 单服进服决策生效 | LoginModeDecision" }
    };
    /// <summary>
    /// 默认资源路径，对应 Assets/Resources/Protocol/ProtocolNetworkSettings.asset。
    /// </summary>
    public const string DefaultResourcesPath = "Protocol/ProtocolNetworkSettings";

    /// <summary>
    /// 默认序列化器 key。
    /// </summary>
    public const string DefaultSerializerName = "json";

    /// <summary>
    /// 最后一次应用时间（UTC）。
    /// </summary>
    public static DateTime LastAppliedUtc { get; private set; }

    /// <summary>
    /// 最后一次配置版本戳（按配置内容计算）。
    /// </summary>
    public static int LastAppliedVersionStamp { get; private set; }

    /// <summary>
    /// 从 Resources 加载默认配置。
    /// </summary>
    public static ProtocolNetworkSettings LoadDefault()
    {
        return Resources.Load<ProtocolNetworkSettings>(DefaultResourcesPath);
    }

    /// <summary>
    /// 一次性应用全部网络配置。
    /// </summary>
    /// <param name="manager">运行时 NetworkManager。</param>
    /// <param name="gameConfig">业务层 GameNetworkConfig。</param>
    /// <param name="settings">协议工作台配置。</param>
    /// <param name="connectImmediately">是否立即连接。</param>
    /// <returns>是否应用成功。</returns>
    public static bool ApplyAll(NetworkManager manager, GameNetworkConfig gameConfig, ProtocolNetworkSettings settings, bool connectImmediately)
    {
        if (manager == null || settings == null)
        {
            return false;
        }

        if (!ValidateSettings(settings, out var validationError))
        {
            Logger.Log("[ConfigApplied] Validation failed: " + validationError, LogLevel.Error);
            return false;
        }

        ApplyToNetworkManager(manager, settings, connectImmediately);
        ApplyToGameNetworkConfig(gameConfig, settings);

        LastAppliedUtc = DateTime.UtcNow;
        LastAppliedVersionStamp = ComputeVersionStamp(settings);

        Logger.Log(
            $"[ProtocolNetworkSettingsRuntime] Applied config. VersionStamp={LastAppliedVersionStamp}, AppliedUtc={LastAppliedUtc:O}, Endpoint={ResolveEndpoint(settings)}, Transport={settings.TransportKind}, Rolling={settings.EnableRollingServerMode}, SingleServerId={settings.SingleServerId}",
            LogLevel.Info);
        Logger.Log("[ConfigApplied] " + BuildAppliedSnapshot(manager, gameConfig, settings), LogLevel.Info);

        return true;
    }

    /// <summary>
    /// 对协议网络配置做运行时合法性校验，避免“配置存在但无法生效”的静默路径。
    /// </summary>
    public static bool ValidateSettings(ProtocolNetworkSettings settings, out string reason)
    {
        reason = string.Empty;
        if (settings == null)
        {
            reason = "settings is null";
            return false;
        }

        if (settings.PayloadEncoding == ProtocolPayloadEncodingKind.Custom &&
            string.IsNullOrWhiteSpace(settings.CustomSerializerName))
        {
            reason = "PayloadEncoding=Custom but CustomSerializerName is empty.";
            return false;
        }

        string resolvedSerializer = ResolveSerializerName(settings);
        if (!NetworkPayloadPipeline.HasSerializer(resolvedSerializer))
        {
            reason = "Serializer not registered: " + resolvedSerializer;
            return false;
        }

        if (settings.EnableRollingServerMode == false && string.IsNullOrWhiteSpace(settings.SingleServerId))
        {
            Logger.Log("[LoginModeDecision] single-server mode enabled but SingleServerId is empty, runtime will fallback to login LastServerId.", LogLevel.Warning);
        }

        if (settings.SimulatedLatencyMs < 0 || settings.SimulatedJitterMs < 0 || settings.SimulatedBandwidthKbps < 0)
        {
            reason = "Simulation params contain negative value.";
            return false;
        }

        return true;
    }

    /// <summary>
    /// 审计配置参数是否全部纳入闭环映射。
    /// </summary>
    public static bool IsClosure100(out List<string> missingFields)
    {
        missingFields = new List<string>();
        string[] required =
        {
            "TransportKind","EndpointUrl","ActiveEnvironmentId","EnvironmentPresets",
            "PayloadEncoding","CustomSerializerName","CommunicationMode",
            "ConnectTimeoutMs","RequestTimeoutMs","HeartbeatIntervalMs","HeartbeatTimeoutMs",
            "MaxReconnectAttempts","ReconnectBaseDelayMs","EnableReliableDelivery","AckTimeoutMs","MaxRetryCount",
            "EnableCompression","EnableEncryption","ClientFrameRate","SnapshotIntervalMs",
            "EnableSimulation","SimulatedLatencyMs","SimulatedJitterMs","SimulatedPacketLossPercent",
            "SimulatedDuplicatePercent","SimulatedReorderPercent","SimulatedBandwidthKbps","SimulatedDisconnectAfterSeconds","SimulationSeed",
            "EnableRollingServerMode","SingleServerId"
        };

        foreach (var field in required)
        {
            if (!EffectiveMappingTable.ContainsKey(field))
            {
                missingFields.Add(field);
            }
        }

        return missingFields.Count == 0;
    }

    /// <summary>
    /// 输出“编辑器参数 -> 运行时生效点”的闭环审计报告。
    /// </summary>
    /// <param name="settings">协议网络配置。</param>
    /// <returns>闭环审计文本。</returns>
    public static string BuildClosureAuditReport(ProtocolNetworkSettings settings)
    {
        bool closure100 = IsClosure100(out var missing);
        string closure = closure100 ? "closure=100%" : "closure<100%,missing=" + string.Join(",", missing);
        string version = $"version={LastAppliedVersionStamp};appliedUtc={LastAppliedUtc:O}";
        string endpoint = "endpoint=" + ResolveEndpoint(settings);
        string serializer = "serializer=" + ResolveSerializerName(settings);
        return $"{closure};{version};{endpoint};{serializer};mappingCount={EffectiveMappingTable.Count}";
    }

    /// <summary>
    /// 仅应用到 NetworkManager。
    /// </summary>
    public static void ApplyToNetworkManager(NetworkManager manager, ProtocolNetworkSettings settings, bool connectImmediately)
    {
        if (manager == null || settings == null)
        {
            return;
        }

        manager.transportType = ResolveTransport(settings);
        manager.serverUri = ResolveEndpoint(settings);
        manager.connectTimeoutSeconds = Mathf.Max(0f, settings.ConnectTimeoutMs / 1000f);
        manager.requestTimeoutSeconds = Mathf.Max(0f, settings.RequestTimeoutMs / 1000f);
        manager.heartBeatInterval = Mathf.Max(0f, settings.HeartbeatIntervalMs / 1000f);
        manager.heartbeatTimeoutSeconds = Mathf.Max(0f, settings.HeartbeatTimeoutMs / 1000f);
        manager.reconnectDelay = Mathf.Max(0f, settings.ReconnectBaseDelayMs / 1000f);
        manager.maxReconnectAttempts = settings.MaxReconnectAttempts;

        manager.enableReliableDelivery = settings.EnableReliableDelivery;
        manager.reliableTimeout = Mathf.Max(0f, settings.AckTimeoutMs / 1000f);
        manager.reliableMaxRetry = Mathf.Max(0, settings.MaxRetryCount);
        manager.enableHeartbeatRequest = settings.HeartbeatIntervalMs > 0;

        manager.ConfigurePayloadPipeline(ResolveSerializerName(settings), settings.EnableCompression, settings.EnableEncryption);

        manager.ConfigureSimulation(
            settings.EnableSimulation,
            settings.SimulatedLatencyMs,
            settings.SimulatedJitterMs,
            settings.SimulatedPacketLossPercent,
            settings.SimulatedDuplicatePercent,
            settings.SimulatedReorderPercent,
            settings.SimulatedBandwidthKbps,
            settings.SimulatedDisconnectAfterSeconds,
            settings.SimulationSeed);

        if (connectImmediately)
        {
            manager.Connect();
        }
    }

    /// <summary>
    /// 兼容旧调用。
    /// </summary>
    public static bool TryApplyTo(NetworkManager manager, ProtocolNetworkSettings settings, bool connectImmediately)
    {
        if (manager == null || settings == null)
        {
            return false;
        }

        ApplyToNetworkManager(manager, settings, connectImmediately);
        return true;
    }

    /// <summary>
    /// 应用到业务层 GameNetworkConfig。
    /// </summary>
    public static void ApplyToGameNetworkConfig(GameNetworkConfig target, ProtocolNetworkSettings settings)
    {
        if (target == null || settings == null)
        {
            return;
        }

        target.EnableRollingServerMode = settings.EnableRollingServerMode;
        target.SingleServerId = settings.SingleServerId ?? string.Empty;
        target.RequestTimeoutSeconds = Mathf.Max(1f, settings.RequestTimeoutMs / 1000f);
        target.AutoStartHeartbeatAfterLogin = settings.HeartbeatIntervalMs > 0;
        target.ClientFrameRate = Mathf.Max(1, settings.ClientFrameRate);
        target.SnapshotIntervalMs = Mathf.Max(1, settings.SnapshotIntervalMs);

        if (target.Routes == null)
        {
            target.Routes = new List<GameNetworkConfig.Route>();
        }

        string endpoint = ResolveEndpoint(settings);
        var transport = ResolveTransport(settings);
        bool reliableByDefault = settings.EnableReliableDelivery;
        int defaultPriority = ResolveDefaultPriority(settings.CommunicationMode);

        UpsertRoute(target, NetworkChannel.Login, transport, endpoint, reliableByDefault, defaultPriority);
        UpsertRoute(target, NetworkChannel.Game, transport, endpoint, reliableByDefault, defaultPriority);
        UpsertRoute(target, NetworkChannel.Battle, transport, endpoint, ResolveBattleReliable(settings), 0);
    }

    /// <summary>
    /// 解析最终 endpoint。
    /// </summary>
    public static string ResolveEndpoint(ProtocolNetworkSettings settings)
    {
        if (settings == null)
        {
            return string.Empty;
        }

        var overlay = GetRuntimeOverlay(settings.ActiveEnvironmentId);
        if (overlay != null && !string.IsNullOrWhiteSpace(overlay.GatewayWs))
        {
            return overlay.GatewayWs;
        }

        if (settings.EnvironmentPresets != null)
        {
            foreach (var preset in settings.EnvironmentPresets)
            {
                if (preset != null && preset.EnvironmentId == settings.ActiveEnvironmentId && !string.IsNullOrWhiteSpace(preset.EndpointUrl))
                {
                    return preset.EndpointUrl;
                }
            }
        }

        return settings.EndpointUrl;
    }

    /// <summary>
    /// 解析序列化器 key。
    /// </summary>
    public static string ResolveSerializerName(ProtocolNetworkSettings settings)
    {
        if (settings == null)
        {
            return DefaultSerializerName;
        }

        switch (settings.PayloadEncoding)
        {
            case ProtocolPayloadEncodingKind.Binary:
                return "binary";
            case ProtocolPayloadEncodingKind.ProtobufLike:
                return "protobuflike";
            case ProtocolPayloadEncodingKind.Custom:
                return string.IsNullOrWhiteSpace(settings.CustomSerializerName) ? DefaultSerializerName : settings.CustomSerializerName.Trim();
            default:
                return "json";
        }
    }

    /// <summary>
    /// 生成当前配置最终生效快照，便于定位“配置已改但行为未变”的问题。
    /// </summary>
    public static string BuildAppliedSnapshot(NetworkManager manager, GameNetworkConfig gameConfig, ProtocolNetworkSettings settings)
    {
        if (settings == null)
        {
            return "settings=null";
        }

        var transport = manager != null ? manager.transportType.ToString() : "N/A";
        var serializer = ResolveSerializerName(settings);
        var endpoint = ResolveEndpoint(settings);
        var rolling = gameConfig != null ? gameConfig.EnableRollingServerMode : settings.EnableRollingServerMode;
        var singleServerId = gameConfig != null ? gameConfig.SingleServerId : settings.SingleServerId;

        return $"source=ProtocolNetworkSettings;version={LastAppliedVersionStamp};appliedUtc={LastAppliedUtc:O};transport={transport};endpoint={endpoint};serializer={serializer};compression={settings.EnableCompression};encryption={settings.EnableEncryption};reliable={settings.EnableReliableDelivery};sim={settings.EnableSimulation};rolling={rolling};singleServerId={singleServerId};frameRate={settings.ClientFrameRate};snapshotMs={settings.SnapshotIntervalMs}";
    }

    /// <summary>
    /// 输出当前传输能力矩阵结果（用于运行时日志与验收记录）。
    /// </summary>
    public static string BuildTransportCapabilityMatrix()
    {
        return "TransportMatrix: Http=短连接(每次POST收发,无长连状态); Tcp=长连接(保持连接+持续收发); Kcp=UDP长连接(基于KcpPeer); WebSocket=长连接(UnityWebSocket实现)";
    }

    /// <summary>
    /// 根据 endpoint scheme 与配置解析最终传输层。
    /// </summary>
    public static NetworkManager.TransportType ResolveTransport(ProtocolNetworkSettings settings)
    {
        string endpoint = ResolveEndpoint(settings);
        if (TryInferTransportFromEndpoint(endpoint, out NetworkManager.TransportType inferred))
        {
            return inferred;
        }

        return ToNetworkManagerTransport(settings != null ? settings.TransportKind : ProtocolTransportKind.WebSocket);
    }

    private static bool TryInferTransportFromEndpoint(string endpoint, out NetworkManager.TransportType transport)
    {
        transport = NetworkManager.TransportType.WebSocket;
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            return false;
        }

        if (endpoint.StartsWith("ws://", System.StringComparison.OrdinalIgnoreCase)
            || endpoint.StartsWith("wss://", System.StringComparison.OrdinalIgnoreCase))
        {
            transport = NetworkManager.TransportType.WebSocket;
            return true;
        }

        if (endpoint.StartsWith("kcp://", System.StringComparison.OrdinalIgnoreCase))
        {
            transport = NetworkManager.TransportType.Kcp;
            return true;
        }

        if (endpoint.StartsWith("http://", System.StringComparison.OrdinalIgnoreCase)
            || endpoint.StartsWith("https://", System.StringComparison.OrdinalIgnoreCase))
        {
            transport = NetworkManager.TransportType.Http;
            return true;
        }

        if (endpoint.StartsWith("tcp://", System.StringComparison.OrdinalIgnoreCase))
        {
            transport = NetworkManager.TransportType.Tcp;
            return true;
        }

        return false;
    }

    /// <summary>
    /// 映射传输枚举。
    /// </summary>
    public static NetworkManager.TransportType ToNetworkManagerTransport(ProtocolTransportKind kind)
    {
        switch (kind)
        {
            case ProtocolTransportKind.Tcp:
                return NetworkManager.TransportType.Tcp;
            case ProtocolTransportKind.Http:
                return NetworkManager.TransportType.Http;
            case ProtocolTransportKind.Kcp:
                return NetworkManager.TransportType.Kcp;
            default:
                return NetworkManager.TransportType.WebSocket;
        }
    }

    private static bool ResolveBattleReliable(ProtocolNetworkSettings settings)
    {
        if (settings == null)
        {
            return true;
        }

        switch (settings.CommunicationMode)
        {
            case ProtocolCommunicationMode.FrameSync:
                return false;
            default:
                return settings.EnableReliableDelivery;
        }
    }

    private static int ResolveDefaultPriority(ProtocolCommunicationMode mode)
    {
        switch (mode)
        {
            case ProtocolCommunicationMode.FrameSync:
                return 0;
            case ProtocolCommunicationMode.SnapshotSync:
                return 1;
            case ProtocolCommunicationMode.Push:
                return 1;
            default:
                return 1;
        }
    }

    private static void UpsertRoute(
        GameNetworkConfig config,
        NetworkChannel channel,
        NetworkManager.TransportType transport,
        string endpoint,
        bool reliableByDefault,
        int defaultPriority)
    {
        for (int i = 0; i < config.Routes.Count; i++)
        {
            var route = config.Routes[i];
            if (route == null || route.Channel != channel)
            {
                continue;
            }

            route.Transport = transport;
            route.EndpointOverride = endpoint ?? string.Empty;
            route.ReliableByDefault = reliableByDefault;
            route.DefaultPriority = defaultPriority;
            return;
        }

        config.Routes.Add(new GameNetworkConfig.Route
        {
            Channel = channel,
            Transport = transport,
            EndpointOverride = endpoint ?? string.Empty,
            ReliableByDefault = reliableByDefault,
            DefaultPriority = defaultPriority
        });
    }

    private static int ComputeVersionStamp(ProtocolNetworkSettings settings)
    {
        unchecked
        {
            int hash = 17;
            hash = hash * 31 + (int)settings.TransportKind;
            hash = hash * 31 + (int)settings.PayloadEncoding;
            hash = hash * 31 + (int)settings.CommunicationMode;
            hash = hash * 31 + (settings.CustomSerializerName ?? string.Empty).GetHashCode();
            hash = hash * 31 + (ResolveEndpoint(settings) ?? string.Empty).GetHashCode();
            hash = hash * 31 + settings.ConnectTimeoutMs;
            hash = hash * 31 + settings.RequestTimeoutMs;
            hash = hash * 31 + settings.HeartbeatIntervalMs;
            hash = hash * 31 + settings.HeartbeatTimeoutMs;
            hash = hash * 31 + settings.MaxReconnectAttempts;
            hash = hash * 31 + settings.ReconnectBaseDelayMs;
            hash = hash * 31 + (settings.EnableReliableDelivery ? 1 : 0);
            hash = hash * 31 + settings.AckTimeoutMs;
            hash = hash * 31 + settings.MaxRetryCount;
            hash = hash * 31 + (settings.EnableCompression ? 1 : 0);
            hash = hash * 31 + (settings.EnableEncryption ? 1 : 0);
            hash = hash * 31 + settings.ClientFrameRate;
            hash = hash * 31 + settings.SnapshotIntervalMs;
            hash = hash * 31 + (settings.EnableSimulation ? 1 : 0);
            hash = hash * 31 + settings.SimulatedLatencyMs;
            hash = hash * 31 + settings.SimulatedJitterMs;
            hash = hash * 31 + settings.SimulatedPacketLossPercent.GetHashCode();
            hash = hash * 31 + settings.SimulatedDuplicatePercent.GetHashCode();
            hash = hash * 31 + settings.SimulatedReorderPercent.GetHashCode();
            hash = hash * 31 + settings.SimulatedBandwidthKbps;
            hash = hash * 31 + settings.SimulatedDisconnectAfterSeconds.GetHashCode();
            hash = hash * 31 + settings.SimulationSeed;
            hash = hash * 31 + (settings.EnableRollingServerMode ? 1 : 0);
            hash = hash * 31 + (settings.SingleServerId ?? string.Empty).GetHashCode();
            return hash;
        }
    }

    private static readonly System.Collections.Generic.Dictionary<string, RuntimeNetworkProfileDto> RuntimeOverlays
        = new System.Collections.Generic.Dictionary<string, RuntimeNetworkProfileDto>(System.StringComparer.OrdinalIgnoreCase);

    public static void SetRuntimeOverlay(string envKey, RuntimeNetworkProfileDto profile)
    {
        if (string.IsNullOrWhiteSpace(envKey) || profile == null)
        {
            return;
        }
        RuntimeOverlays[envKey.Trim()] = profile;
    }

    public static RuntimeNetworkProfileDto GetRuntimeOverlay(string envKey)
    {
        if (string.IsNullOrWhiteSpace(envKey))
        {
            return null;
        }
        RuntimeOverlays.TryGetValue(envKey.Trim(), out var profile);
        return profile;
    }

    public static string GetGatewayWs(ProtocolNetworkSettings settings, string envKey)
    {
        var overlay = GetRuntimeOverlay(envKey);
        if (overlay != null && !string.IsNullOrWhiteSpace(overlay.GatewayWs))
        {
            return overlay.GatewayWs;
        }
        return ResolveEndpoint(settings);
    }
}
