# Login Domain Skill

- Client: generate account/session oriented API, loading state, retry only for transient network errors, and UI sample for login submit.
- Server: generate authentication guard, session/token validation hooks, account lookup repository hooks, and safe error codes for invalid credentials/session expired.
- Never log password, token, device id, or secret fields in plain text.
