using System;
using System.IO;
using UnityEngine;

[Obsolete("ProtocolGenerator is deprecated. Use Tools/MAClient/协议与网络/M09-07 协议、DTO与代码生成工作台 instead.")]
public sealed class ProtocolGenerator
{
    private static readonly string GenerateScriptPath = Path.GetFullPath(Path.Combine(Application.dataPath, "..", "tools", "protocols", "Generate-ProtocolArtifacts.ps1"));
    private static readonly string ValidateScriptPath = Path.GetFullPath(Path.Combine(Application.dataPath, "..", "tools", "protocols", "Validate-ProtocolArtifacts.ps1"));

    public void GenerateProtocols(string jsonPath)
    {
        var service = new PowerShellProtocolArtifactService(GenerateScriptPath, ValidateScriptPath);
        if (!service.GenerateAll(out string output))
        {
            throw new InvalidOperationException(string.IsNullOrWhiteSpace(output) ? "Protocol generation failed." : output.Trim());
        }

        if (!string.IsNullOrWhiteSpace(jsonPath))
        {
            Debug.Log("[ProtocolGenerator] Ignored legacy schema path. Unified generation uses Assets/Src/Protocols/protocols.json.");
        }
    }
}
