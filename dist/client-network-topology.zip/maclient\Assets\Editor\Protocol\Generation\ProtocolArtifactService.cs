using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

public sealed class JsonProtocolSourceProvider : IProtocolSourceProvider
{
    public JsonProtocolSourceProvider(string schemaPath) { SchemaPath = schemaPath; }
    public string SchemaPath { get; }
    public string LoadSource() { return File.Exists(SchemaPath) ? File.ReadAllText(SchemaPath, Encoding.UTF8) : string.Empty; }
}

public sealed class PowerShellProtocolArtifactService :
    IProtocolArtifactGenerator,
    IProtocolCompatibilityChecker,
    IProtocolDocGenerator,
    IProtocolTemplateGenerator,
    IProtocolCatalogWriter,
    IProtocolArtifactReporter
{
    private readonly string _generateScriptPath;
    private readonly string _validateScriptPath;
    private readonly ProtocolArtifactPaths _paths;

    public PowerShellProtocolArtifactService(string generateScriptPath, string validateScriptPath)
    {
        _generateScriptPath = generateScriptPath;
        _validateScriptPath = validateScriptPath;
        string repoRoot = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(generateScriptPath) ?? string.Empty, "..", ".."));
        string generatedRoot = Path.Combine(repoRoot, "protocols", "generated");
        string clientDtoRoot = Path.Combine(repoRoot, "Assets", "Src", "HotUpdate", "Framework", "Network", "GeneratedProtocols", "CSharp");
        string serverDtoRoot = Path.Combine(repoRoot, "game-server", "shared", "Protocols", "Generated");
        _paths = new ProtocolArtifactPaths
        {
            SourceSchemaPath = Path.Combine(repoRoot, "Assets", "Src", "Protocols", "protocols.json"),
            NormalizedCatalogPath = Path.Combine(repoRoot, "protocols", "protocols.json"),
            GeneratedRoot = generatedRoot,
            ClientDtoRoot = clientDtoRoot,
            ServerDtoRoot = serverDtoRoot,
            HandlerTemplateRoot = Path.Combine(generatedRoot, "handler-templates"),
            ClientProtocolIdsPath = Path.Combine(clientDtoRoot, "ProtocolIds.cs"),
            ServerProtocolIdsPath = Path.Combine(serverDtoRoot, "ProtocolIds.cs"),
            ClientDictionaryPath = Path.Combine(clientDtoRoot, "ProtocolDictionary.cs"),
            ServerDictionaryPath = Path.Combine(serverDtoRoot, "ProtocolDictionary.cs"),
            CompatibilityReportPath = Path.Combine(generatedRoot, "protocol-compatibility-report.md"),
            DtoManifestPath = Path.Combine(generatedRoot, "protocol-dto-manifest.json"),
            StatusDocPath = Path.Combine(generatedRoot, "protocol-status.md")
        };
        TemplateRoot = _paths.HandlerTemplateRoot;
        CatalogPath = Path.Combine(generatedRoot, "protocol-catalog.json");
    }

    public string TemplateRoot { get; }
    public string CatalogPath { get; }
    public ProtocolArtifactPaths GetArtifactPaths() { return _paths; }

    public bool GenerateAll(out string output) { return RunPowerShellFile(_generateScriptPath, out output); }
    public bool Validate(out string output) { return RunPowerShellFile(_validateScriptPath, out output); }

    public IReadOnlyList<string> GetGeneratedDocumentPaths()
    {
        return new[] { _paths.StatusDocPath, _paths.CompatibilityReportPath, CatalogPath, _paths.DtoManifestPath };
    }

    public ProtocolSourceSummary BuildSourceSummary()
    {
        ProtocolSchemaDocument document = ProtocolSchemaDocument.Load(_paths.SourceSchemaPath);
        var names = document.Entries.Select(entry => entry.Name ?? string.Empty).ToArray();
        var requestBases = new HashSet<string>(names.Where(name => name.EndsWith("_c2s", StringComparison.Ordinal)).Select(name => name.Substring(0, name.Length - 4)), StringComparer.Ordinal);
        return new ProtocolSourceSummary
        {
            SourcePath = _paths.SourceSchemaPath,
            SourceExists = File.Exists(_paths.SourceSchemaPath),
            TotalDefinitions = document.Entries.Count,
            MessageCount = document.Entries.Count(entry => entry.Kind == ProtocolSchemaEntryKind.Message),
            RequestCount = requestBases.Count,
            ResponseCount = names.Count(name => name.EndsWith("_s2c", StringComparison.Ordinal) && requestBases.Contains(name.Substring(0, name.Length - 4))),
            PushCount = names.Count(name => name.EndsWith("_s2c", StringComparison.Ordinal) && !requestBases.Contains(name.Substring(0, name.Length - 4))),
            CustomClassCount = document.Entries.Count(entry => entry.Kind == ProtocolSchemaEntryKind.Class),
            EnumCount = document.Entries.Count(entry => entry.Kind == ProtocolSchemaEntryKind.Enum),
            DuplicateIdCount = document.Entries.Where(entry => entry.Kind == ProtocolSchemaEntryKind.Message && entry.MessageId > 0).GroupBy(entry => entry.MessageId).Count(group => group.Count() > 1)
        };
    }

    private static bool RunPowerShellFile(string scriptPath, out string output)
    {
        output = string.Empty;
        if (!File.Exists(scriptPath))
        {
            output = "Script not found: " + scriptPath;
            return false;
        }

        var startInfo = new ProcessStartInfo
        {
            FileName = "powershell",
            Arguments = "-ExecutionPolicy Bypass -File \"" + scriptPath + "\"",
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using (Process process = Process.Start(startInfo))
        {
            if (process == null)
            {
                output = "Failed to start PowerShell.";
                return false;
            }

            string stdout = process.StandardOutput.ReadToEnd();
            string stderr = process.StandardError.ReadToEnd();
            process.WaitForExit();
            output = string.IsNullOrWhiteSpace(stderr) ? stdout : stdout + Environment.NewLine + stderr;
            return process.ExitCode == 0;
        }
    }
}
