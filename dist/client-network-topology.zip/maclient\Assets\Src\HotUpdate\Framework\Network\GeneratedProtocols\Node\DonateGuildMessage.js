// 自动生成的协议文件

// 定义协议类


// 公会捐献
class DonateGuild_c2s {
    constructor() {
        this.DonateType = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 公会捐献结果
class DonateGuild_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Rewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DonateGuild_c2s,
    DonateGuild_s2c,
};
