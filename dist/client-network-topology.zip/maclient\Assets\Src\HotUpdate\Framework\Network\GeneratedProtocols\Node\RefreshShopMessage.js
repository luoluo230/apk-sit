// 自动生成的协议文件

// 定义协议类


// 手动刷新商店
class RefreshShop_c2s {
    constructor() {
        this.ShopType = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 商店刷新结果
class RefreshShop_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Items = [];
        this.ResourceChanges = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    RefreshShop_c2s,
    RefreshShop_s2c,
};
