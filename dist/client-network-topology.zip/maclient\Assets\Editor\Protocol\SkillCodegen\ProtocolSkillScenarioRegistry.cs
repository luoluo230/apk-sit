using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

public sealed class ProtocolSkillScenarioDefinition
{
    public string Id;
    public string DisplayName;
    public string Description;
    public string PromptTemplatePath;
    public string[] Keywords;
}

public static class ProtocolSkillScenarioRegistry
{
    private static readonly string ScenarioRoot = Path.Combine(Application.dataPath, "Editor", "Protocol", "Skills", "Scenarios");

    private static readonly ProtocolSkillScenarioDefinition[] Scenarios =
    {
        Create("login-session", "Login / Session", "Login, server selection, token, session and device identity protocols.", Path.Combine("Account", "login-session.scenario.skill.md"), "login", "auth", "token", "session", "server"),
        Create("profile-update", "Player Profile", "Player profile query, nickname/avatar changes and public profile synchronization.", Path.Combine("Account", "profile-update.scenario.skill.md"), "profile", "player", "avatar", "name"),
        Create("payment-order", "Payment / Order", "Order creation, receipt verification, compensation and delivery flows.", Path.Combine("Economy", "payment-order.scenario.skill.md"), "pay", "payment", "order", "receipt", "iap"),
        Create("inventory-mutation", "Inventory Mutation", "Inventory sync, item usage, equipment changes and resource delta updates.", Path.Combine("Economy", "inventory-mutation.scenario.skill.md"), "inventory", "item", "bag", "asset", "delta"),
        Create("reward-claim", "Reward Claim", "Quest, mail, activity, achievement and gift reward claim flows.", Path.Combine("Economy", "reward-claim.scenario.skill.md"), "reward", "claim", "mail", "gift", "quest"),
        Create("leaderboard-score", "Leaderboard / Score", "Leaderboard query, score submission and season settlement flows.", Path.Combine("Economy", "leaderboard-score.scenario.skill.md"), "leaderboard", "rank", "score"),
        Create("battle-result", "Battle Result", "Battle result, loot, validation and anti-cheat review flows.", Path.Combine("Combat", "battle-result.scenario.skill.md"), "battle", "fight", "combat", "result"),
        Create("matchmaking-room", "Matchmaking / Room", "Matchmaking queue, cancel, room creation and status confirmation flows.", Path.Combine("Combat", "matchmaking-room.scenario.skill.md"), "match", "room", "team"),
        Create("chat-message", "Chat / Notice", "Chat send, pull, unread state and push notification flows.", Path.Combine("Social", "chat-message.scenario.skill.md"), "chat", "message", "notice")
    };

    public static IReadOnlyList<ProtocolSkillScenarioDefinition> GetAll()
    {
        return Scenarios;
    }

    public static IReadOnlyList<ProtocolSkillScenarioDefinition> GetMatches(ProtocolSkillContext context)
    {
        string haystack = ((context?.ProtocolName ?? string.Empty) + " " + (context?.Module ?? string.Empty) + " " + (context?.Comment ?? string.Empty) + " "
            + string.Join(" ", context?.RequestFields.Select(f => f.Name + " " + f.Comment) ?? Enumerable.Empty<string>()) + " "
            + string.Join(" ", context?.ResponseFields.Select(f => f.Name + " " + f.Comment) ?? Enumerable.Empty<string>())).ToLowerInvariant();
        return Scenarios.Where(scenario => scenario.Keywords.Any(keyword => haystack.Contains(keyword))).ToArray();
    }

    public static string LoadPromptTemplate(ProtocolSkillScenarioDefinition scenario)
    {
        return scenario != null && File.Exists(scenario.PromptTemplatePath) ? File.ReadAllText(scenario.PromptTemplatePath) : string.Empty;
    }

    private static ProtocolSkillScenarioDefinition Create(string id, string displayName, string description, string relativePath, params string[] keywords)
    {
        return new ProtocolSkillScenarioDefinition
        {
            Id = id,
            DisplayName = displayName,
            Description = description,
            PromptTemplatePath = Path.Combine(ScenarioRoot, relativePath),
            Keywords = keywords ?? Array.Empty<string>()
        };
    }
}
