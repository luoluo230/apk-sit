// 自动生成的协议文件

// 定义协议类


// 退出公会
class LeaveGuild_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 退出公会结果
class LeaveGuild_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    LeaveGuild_c2s,
    LeaveGuild_s2c,
};
