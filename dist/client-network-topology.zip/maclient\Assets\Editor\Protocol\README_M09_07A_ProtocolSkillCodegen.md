# M09-07A Protocol Skill Codegen

这个模块用于把已经生成并校验通过的协议 DTO 继续加工成业务接入骨架。它不替代协议生成器，也不重新生成 `ProtocolIds` 或 `ProtocolDictionary`，只负责把“协议怎么被客户端/服务端业务使用”这部分沉淀成可复用、可审查、可交给 AI 继续扩写的结构。

## 当前闭环

- 工作台入口：`Tools/HotUpdate/Protocols/Workbench`，打开后进入 `Skill 生成` 页签。
- 协议选择：支持勾选单个协议、一组协议、当前模块或全量消息协议。
- 领域化 Skill：会根据协议名/模块自动识别 Login、Inventory、Battle、Social、Guild、Mail、Shop、Activity 等领域模板。
- 代码库检索增强：会按协议名、模块、领域关键词扫描客户端和服务端相关代码，把参考路径和关键片段写入 AI Payload。
- 业务框架约束模板：会把当前网络入口、UI 调用约束、服务端 DB/日志/错误码/事务模式写成硬约束喂给 AI。
- 客户端生成：支持 `ProtocolApi`、`UseCase`、`ClientPolicy`、`PresenterSample`。
- 客户端调用风格：支持 `Callback`、`TaskAsync`、`UniTask`、`Coroutine`，其中 `UniTask` 分支使用 `CYSHARP_UNITASK` 宏保护。
- 服务端生成：支持 `Handler`、`ServerGuards`、`Service`、`Repository`、`DbModel`、`Migration SQL`。
- AI 上下文：导出每个协议的 `.skill-context.json` 与 `.skill-context.md`。
- AI Payload：导出 `.ai-payload.md` 与 `.ai-payload.json`，后续可直接作为 AI API 输入。
- AI 编译修复：AI 返回文件后可临时写入并跑 Unity batch 编译，若出现 `error CS` 会把编译错误回喂 AI 修复，再恢复原文件并把修复后的内容合并回计划。
- 写入策略：生成计划先预览，关闭 `Dry Run` 后才写入代码；写入内容只进入 `auto-generated-protocol-skill` 区域。

## 后续接 AI API

如果你的 AI 服务兼容 OpenAI `/v1/chat/completions` 格式，工作台里只需要填写：

- `API 地址`：例如 `https://api.openai.com/v1/chat/completions` 或公司内部兼容网关。
- `API Key`：保存在 Unity `EditorPrefs`，不会写入项目资产。
- `模型名`：按网关支持填写，例如 `gpt-5.4`。

工作台会把当前生成计划转换成 AI Payload，然后要求 AI 返回严格 JSON：

```json
{
  "files": [
    {
      "path": "Assets/Src/HotUpdate/Business/GeneratedProtocolSkills/Client/Login/LoginProtocolApi.generated.cs",
      "skill": "ClientApiWrapper",
      "reason": "生成客户端协议封装",
      "content": "完整文件内容"
    }
  ],
  "warnings": []
}
```

如果后续不是 OpenAI-compatible 网关，也可以实现 `IProtocolSkillAiInvoker` 替换调用器。

接入原则：

- AI 只生成业务接入骨架，不生成 DTO、ProtocolIds、ProtocolDictionary。
- 客户端必须继续依赖工作台配置的网络入口，默认是 `NetworkFacade.Send<T>`。
- 服务端必须保持 `handler / service / repository / db model / migration` 分层。
- AI 返回结果必须先进入 Plan 预览，确认后再写入 generated 区域。
- 手写业务逻辑放在 manual 或 partial 文件中，避免重新生成时被覆盖。

## 推荐使用流程

1. 先运行协议正式生成与产物校验，确保 DTO 和协议字典已同步。
2. 在 `Skill 生成` 页签勾选协议和目标端。
3. 选择需要的 Skill 能力，例如客户端 API、UseCase、服务端 Handler、Service、Repository。
4. 点击 `生成 Skill 计划`，查看计划、上下文和风险提示。
5. 如果只想把上下文交给 AI，复制或发送 `.ai-payload.md` / `.ai-payload.json`。
6. 确认计划无误后关闭 `Dry Run`，点击 `应用计划写入代码`。
