﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 领取好友赠送的体力/友情点
/// </summary>
public class ReceiveFriendEnergy_c2s
{
}

/// <summary>
/// 领取好友体力结果
/// </summary>
public class ReceiveFriendEnergy_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 获得的体力/友情点
    /// </summary>
    public RewardItem[] Rewards { get; set; }
}

