// 自动生成的协议文件

// 定义协议类


// 进入副本
class EnterDungeon_c2s {
    constructor() {
        this.DungeonId = 0;
        this.Formation = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 进入副本结果
class EnterDungeon_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.DungeonId = 0;
        this.BattleId = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    EnterDungeon_c2s,
    EnterDungeon_s2c,
};
