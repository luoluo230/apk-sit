// 自动生成的协议文件

// 定义协议类


// 收到新的好友申请通知
class FriendRequestNotify_s2c {
    constructor() {
        this.Request = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    FriendRequestNotify_s2c,
};
