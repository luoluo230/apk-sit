using System;

/// <summary>
/// 请求分发器接口。
/// 负责请求回调注册、响应派发与超时失败回调。
/// </summary>
public interface IRequestDispatcher
{
    /// <summary>
    /// 注册某个请求消息对应的响应回调。
    /// </summary>
    string RegisterResponseCallback<T>(int requestMessageId, Action<T> callback, float currentTime) where T : class;

    /// <summary>
    /// 取消一个尚未完成的请求回调。
    /// </summary>
    void CancelResponseCallback(int requestMessageId, string reason, Action<int, string, string> onRequestFailed);

    /// <summary>
    /// 检查并清理超时请求。
    /// </summary>
    void CheckTimeouts(float currentTime, float timeoutSeconds, Action<int, string, string> onRequestFailed);

    /// <summary>
    /// 派发一条收到的网络消息。
    /// </summary>
    void Dispatch(NetMessage message);

    /// <summary>
    /// 清理所有待处理请求，并对外报告失败原因。
    /// </summary>
    void Clear(string reason, Action<int, string, string> onRequestFailed);
}
