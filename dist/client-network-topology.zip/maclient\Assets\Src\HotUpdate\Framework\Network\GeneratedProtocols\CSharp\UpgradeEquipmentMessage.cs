﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 装备强化/升阶
/// </summary>
public class UpgradeEquipment_c2s
{
    /// <summary>
    /// 装备 ID
    /// </summary>
    public long EquipmentId { get; set; }
    /// <summary>
    /// 消耗的素材装备/道具
    /// </summary>
    public ItemCost[] UseItems { get; set; }
}

/// <summary>
/// 装备强化/升阶结果
/// </summary>
public class UpgradeEquipment_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 更新后的装备
    /// </summary>
    public EquipmentInfo Equipment { get; set; }
    /// <summary>
    /// 素材消耗变更
    /// </summary>
    public InventoryDelta InventoryDelta { get; set; }
    /// <summary>
    /// 资源变化
    /// </summary>
    public ResourceChange[] ResourceChanges { get; set; }
}

