// 自动生成的协议文件

// 定义协议类


// 获取邮件列表
class GetMailList_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 邮件列表响应
class GetMailList_s2c {
    constructor() {
        this.Mails = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetMailList_c2s,
    GetMailList_s2c,
};
