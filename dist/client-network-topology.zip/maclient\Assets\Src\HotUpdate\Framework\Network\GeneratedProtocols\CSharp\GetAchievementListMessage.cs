﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取成就列表
/// </summary>
public class GetAchievementList_c2s
{
}

/// <summary>
/// 成就列表响应
/// </summary>
public class GetAchievementList_s2c
{
    /// <summary>
    /// 成就列表
    /// </summary>
    public AchievementInfo[] Achievements { get; set; }
}

