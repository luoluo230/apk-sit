// 自动生成的协议文件

// 定义协议类


// 战斗帧上报/追帧请求(兼容旧版帧同步)
class BattleFrame_c2s {
    constructor() {
        this.BattleId = '';
        this.Frame = 0;
        this.Operations = [];
        this.PredictedStateHash = '';
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 服务器权威帧下发/回放片段
class BattleFrame_s2c {
    constructor() {
        this.BattleId = '';
        this.Phase = null;
        this.Frame = 0;
        this.AckFrame = 0;
        this.Frames = [];
        this.NextAnchor = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    BattleFrame_c2s,
    BattleFrame_s2c,
};
