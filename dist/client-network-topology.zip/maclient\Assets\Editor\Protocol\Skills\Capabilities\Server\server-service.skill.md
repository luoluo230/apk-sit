# Server Service Skill

## 职责

生成服务端领域 Service，承载业务编排、事务边界、仓储调用、领域事件、日志与埋点。

## 必须生成

- Service 类和 Execute/Handle 方法。
- 业务规则校验入口。
- transaction begin/commit/rollback 接入点。
- repository 调用顺序。
- domain event / notification / analytics hook。
- 业务错误到错误码的映射。

## 约束

- 不直接依赖具体 ORM，除非 context 检测到项目已有写法。
- 非幂等操作必须包含幂等键或重复提交处理建议。
- 支付、购买、领奖、消耗、战斗结算必须强调服务端权威。

## 质量门禁

- 每个 TODO 都必须说明接什么框架或规则。
- 事务失败时有恢复/回滚路径说明。
