﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 参与活动行为(翻牌/转盘/签到等统一入口)
/// </summary>
public class DoEventAction_c2s
{
    /// <summary>
    /// 活动 ID
    /// </summary>
    public int EventId { get; set; }
    /// <summary>
    /// 行为类型(Spin/Draw/Flip/Sign等)
    /// </summary>
    public string Action { get; set; }
    /// <summary>
    /// 行为参数(JSON)
    /// </summary>
    public string Params { get; set; }
}

/// <summary>
/// 活动行为结果
/// </summary>
public class DoEventAction_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 奖励(如有)
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 最新活动进度(JSON)
    /// </summary>
    public string Progress { get; set; }
}

