﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

[AddComponentMenu("")]
[Obsolete("GameNetworkClient is internal compatibility only. Use NetworkBootstrap or GameNetworkGateway.", false)]
public sealed class GameNetworkClient : MonoBehaviour, IGameNetworkRequester, IEndpointResolver, IAuthTransport, IConnectionLifecycle, IHeartbeatService, IMessageChannel, ISessionStore, ILogoutService
{
    [Header("Dependencies")]
    [SerializeField] private NetworkFacade networkFacade;
    [SerializeField] private GameNetworkConfig config;
    [SerializeField] private bool autoFindNetworkFacade = true;

    private readonly Dictionary<NetworkChannel, GameNetworkConfig.Route> _routeMap = new Dictionary<NetworkChannel, GameNetworkConfig.Route>();
    private readonly List<IDisposable> _subscriptions = new List<IDisposable>();

    private string _lastUsername = string.Empty;
    private string _lastPassword = string.Empty;
    private DeviceInfo _lastDevice;
    private string _selectedServerId = string.Empty;
    private Login_s2c _lastLoginResponse;
    private GameNetworkModules _modules;
    private GameplaySyncModules _gameplaySync;

    public event Action<Login_s2c> OnLoginSucceeded;
    public event Action<string> OnLoginFailed;
    public event Action<SelectServer_s2c> OnServerSelected;
    public event Action<CreateRole_s2c> OnRoleCreated;
    public event Action<NotifyKickOff_s2c> OnKickedOff;
    public event Action<ServerInfo[]> OnServerListUpdated;
    public event Action OnDisconnected;
    public event Action OnReconnected;

    public bool IsReady => EnsureFacade();
    public bool IsConnected => networkFacade != null && networkFacade.IsConnected;
    public Login_s2c LastLoginResponse => _lastLoginResponse;
    public ServerInfo[] CurrentServerList => _lastLoginResponse?.ServerList ?? Array.Empty<ServerInfo>();
    public string CurrentServerId => _selectedServerId;
    public GameNetworkModules Modules => _modules;
    public GameplaySyncModules GameplaySync => _gameplaySync;
    public GameNetworkConfig Config => config;

    private void Awake()
    {
        EnsureFacade();
        RebuildRouteMap();
        BindManagerEvents();
        RegisterBuiltInNotifications();
        _modules = new GameNetworkModules(this, () => _selectedServerId, Logout);
        _gameplaySync = new GameplaySyncModules(this);
    }

    private void OnDestroy()
    {
        UnbindManagerEvents();
        ClearSubscriptions();
    }

    public void Configure(GameNetworkConfig newConfig)
    {
        config = newConfig;
        RebuildRouteMap();
    }

    public void SetRoute(NetworkChannel channel, NetworkManager.TransportType transport, string endpoint, bool reliableByDefault = true, int defaultPriority = 1)
    {
        _routeMap[channel] = new GameNetworkConfig.Route
        {
            Channel = channel,
            Transport = transport,
            EndpointOverride = endpoint ?? string.Empty,
            ReliableByDefault = reliableByDefault,
            DefaultPriority = defaultPriority
        };
    }

    public void Connect(NetworkChannel channel = NetworkChannel.Login)
    {
        var route = ResolveRoute(channel);
        networkFacade.EnsureConnected(route.Transport, ResolveEndpoint(route));
    }

    public void Disconnect(bool clearToken = false)
    {
        if (config != null && config.StopHeartbeatOnDisconnect)
        {
            networkFacade?.HeartbeatService?.StopHeartbeat();
        }

        networkFacade?.Disconnect();
        if (clearToken)
        {
            NetMessage.ClearCachedToken();
        }
    }

    public async Task<Login_s2c> LoginAsync(string username, string password, DeviceInfo device = null)
    {
        try
        {
            if (!EnsureFacade())
            {
                throw new GameNetworkException(GameNetworkErrorCodes.TransportNotReady, "NetworkFacade is not ready.");
            }

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "Username or password is empty.");
            }

            var request = new Login_c2s
            {
                Username = username,
                Password = password,
                Device = device ?? BuildDefaultDeviceInfo()
            };

            var response = await RequestAsync<Login_s2c>(request, NetworkChannel.Login, requireToken: false);

            _lastUsername = username;
            _lastPassword = password;
            _lastDevice = request.Device;
            _lastLoginResponse = response;
            _selectedServerId = response.LastServerId ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(response.Token?.Token))
            {
                NetMessage.CacheToken(response.Token.Token, response.Token.ExpireAt);
            }

            if (config != null && config.AutoStartHeartbeatAfterLogin)
            {
                networkFacade.HeartbeatService?.StartHeartbeat();
            }

            OnServerListUpdated?.Invoke(response.ServerList ?? Array.Empty<ServerInfo>());
            OnLoginSucceeded?.Invoke(response);
            return response;
        }
        catch (Exception ex)
        {
            OnLoginFailed?.Invoke(ex.Message);
            throw;
        }
    }

    public async Task<SelectServer_s2c> SelectServerAsync(string serverId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(serverId))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "ServerId is empty.");
            }

            var response = await RequestAsync<SelectServer_s2c>(
                new SelectServer_c2s { ServerId = serverId },
                NetworkChannel.Login,
                requireToken: true);

            _selectedServerId = response.ServerId ?? serverId;
            OnServerSelected?.Invoke(response);
            return response;
        }
        catch (Exception ex)
        {
            OnLoginFailed?.Invoke(ex.Message);
            throw;
        }
    }

    public async Task<SelectServer_s2c> EnsureServerEntryAsync(string preferredServerId = null)
    {
        var rolling = config == null || config.EnableRollingServerMode;
        Logger.Log($"[GameNetworkClient] EnsureServerEntry mode={(rolling ? "RollingServer" : "SingleServer")}, preferredServerId={preferredServerId}, configSingleServerId={config?.SingleServerId}", LogLevel.Info);
        if (rolling)
        {
            var sid = string.IsNullOrWhiteSpace(preferredServerId)
                ? (_lastLoginResponse?.LastServerId ?? _selectedServerId)
                : preferredServerId;
            if (string.IsNullOrWhiteSpace(sid))
            {
                sid = _lastLoginResponse?.ServerList != null && _lastLoginResponse.ServerList.Length > 0
                    ? _lastLoginResponse.ServerList[0].ServerId
                    : string.Empty;
            }
            if (string.IsNullOrWhiteSpace(sid))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "No available server id for rolling-server mode.");
            }
            return await SelectServerAsync(sid);
        }

        var singleServerId = string.IsNullOrWhiteSpace(preferredServerId)
            ? (config != null && !string.IsNullOrWhiteSpace(config.SingleServerId) ? config.SingleServerId : _lastLoginResponse?.LastServerId)
            : preferredServerId;
        _selectedServerId = string.IsNullOrWhiteSpace(singleServerId) ? "single-server" : singleServerId;
        Logger.Log($"[GameNetworkClient] Single-server mode selected serverId={_selectedServerId}", LogLevel.Info);

        var pseudo = new SelectServer_s2c
        {
            Success = true,
            Message = "Single-server mode: select-server step skipped.",
            ServerId = _selectedServerId,
            Profile = _lastLoginResponse?.Profile
        };
        OnServerSelected?.Invoke(pseudo);
        return pseudo;
    }

    public async Task<CreateRole_s2c> RegisterRoleAsync(string nickname, string avatar = "default", string serverId = null)
    {
        try
        {
            var targetServer = string.IsNullOrWhiteSpace(serverId) ? _selectedServerId : serverId;
            if (string.IsNullOrWhiteSpace(targetServer))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "No selected server.");
            }

            if (string.IsNullOrWhiteSpace(nickname))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "Nickname is empty.");
            }

            var response = await RequestAsync<CreateRole_s2c>(
                new CreateRole_c2s
                {
                    ServerId = targetServer,
                    Nickname = nickname,
                    Avatar = string.IsNullOrWhiteSpace(avatar) ? "default" : avatar
                },
                NetworkChannel.Login,
                requireToken: true);

            OnRoleCreated?.Invoke(response);
            return response;
        }
        catch (Exception ex)
        {
            OnLoginFailed?.Invoke(ex.Message);
            throw;
        }
    }

    public async Task<Heartbeat_s2c> PingAsync(bool includeProfile = false)
    {
        return await RequestAsync<Heartbeat_s2c>(
            new Heartbeat_c2s
            {
                IncludeProfile = includeProfile,
                ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
            },
            NetworkChannel.Login,
            requireToken: true,
            reliable: false,
            priority: 1);
    }

    public async Task<GetLobbyInfo_s2c> GetLobbyInfoAsync()
    {
        return await RequestAsync<GetLobbyInfo_s2c>(new GetLobbyInfo_c2s(), NetworkChannel.Game, requireToken: true);
    }

    public async Task<NoticeMessage[]> GetAnnouncementsAsync()
    {
        var response = await GetLobbyInfoAsync();
        return response?.Lobby?.Notices ?? Array.Empty<NoticeMessage>();
    }

    public async Task<DungeonMatch_s2c> MatchAsync(int dungeonId, string modeOrDifficulty, FormationSlot[] formation = null)
    {
        var response = await RequestAsync<DungeonMatch_s2c>(
            new DungeonMatch_c2s
            {
                DungeonId = dungeonId,
                Difficulty = string.IsNullOrWhiteSpace(modeOrDifficulty) ? "normal" : modeOrDifficulty,
                Formation = formation ?? Array.Empty<FormationSlot>()
            },
            NetworkChannel.Game,
            requireToken: true);

        return response;
    }

    public async Task<EnterBattle_s2c> EnterBattleAsync(
        string stageId,
        string battleMode = "PVP",
        BattleSyncMode syncMode = BattleSyncMode.ServerAuthoritative,
        FormationSlot[] formation = null,
        string customJson = null)
    {
        var response = await RequestAsync<EnterBattle_s2c>(
            new EnterBattle_c2s
            {
                StageId = stageId ?? string.Empty,
                BattleMode = string.IsNullOrWhiteSpace(battleMode) ? "PVP" : battleMode,
                SyncMode = syncMode,
                Formation = formation ?? Array.Empty<FormationSlot>(),
                ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                Custom = string.IsNullOrWhiteSpace(customJson) ? "{}" : customJson
            },
            NetworkChannel.Battle,
            requireToken: true,
            reliable: true,
            priority: 0);

        return response;
    }

    public Task<CreateTeam_s2c> CreateTeamAsync()
    {
        return RequestAsync<CreateTeam_s2c>(new CreateTeam_c2s(), NetworkChannel.Game, requireToken: true);
    }

    public Task<InviteToTeam_s2c> InviteToTeamAsync(long targetPlayerId)
    {
        return RequestAsync<InviteToTeam_s2c>(
            new InviteToTeam_c2s { TargetPlayerId = targetPlayerId },
            NetworkChannel.Game,
            requireToken: true);
    }

    public Task<RespondTeamInvite_s2c> RespondTeamInviteAsync(string inviteId, bool accept)
    {
        return RequestAsync<RespondTeamInvite_s2c>(
            new RespondTeamInvite_c2s { InviteId = inviteId ?? string.Empty, Accept = accept },
            NetworkChannel.Game,
            requireToken: true);
    }

    public Task<LeaveTeam_s2c> LeaveTeamAsync()
    {
        return RequestAsync<LeaveTeam_s2c>(new LeaveTeam_c2s(), NetworkChannel.Game, requireToken: true);
    }

    public Task<KickTeamMember_s2c> KickTeamMemberAsync(long targetPlayerId)
    {
        return RequestAsync<KickTeamMember_s2c>(
            new KickTeamMember_c2s { TargetPlayerId = targetPlayerId },
            NetworkChannel.Game,
            requireToken: true);
    }

    public Task<GetEvents_s2c> GetEventsAsync()
    {
        return RequestAsync<GetEvents_s2c>(new GetEvents_c2s(), NetworkChannel.Game, requireToken: true);
    }

    public Task<GetMailList_s2c> GetMailListAsync()
    {
        return RequestAsync<GetMailList_s2c>(new GetMailList_c2s(), NetworkChannel.Game, requireToken: true);
    }

    public Task<GetFriendList_s2c> GetFriendListAsync()
    {
        return RequestAsync<GetFriendList_s2c>(new GetFriendList_c2s(), NetworkChannel.Game, requireToken: true);
    }

    public Task<GetLeaderboard_s2c> GetLeaderboardAsync(string boardType, int pageIndex = 1, int pageSize = 20)
    {
        return RequestAsync<GetLeaderboard_s2c>(
            new GetLeaderboard_c2s
            {
                BoardType = boardType ?? "power",
                PageIndex = Mathf.Max(1, pageIndex),
                PageSize = Mathf.Clamp(pageSize, 1, 200)
            },
            NetworkChannel.Game,
            requireToken: true);
    }

    public Task<GetChatHistory_s2c> GetChatHistoryAsync(ChatChannel channel, long toPlayerId = 0, long fromMessageId = 0, int limit = 50)
    {
        return RequestAsync<GetChatHistory_s2c>(
            new GetChatHistory_c2s
            {
                Channel = channel,
                ToPlayerId = toPlayerId,
                FromMessageId = fromMessageId,
                Limit = Mathf.Clamp(limit, 1, 200)
            },
            NetworkChannel.Game,
            requireToken: true);
    }

    public void Logout(bool disconnect = true, bool clearToken = true)
    {
        _selectedServerId = string.Empty;
        _lastLoginResponse = null;
        _lastUsername = string.Empty;
        _lastPassword = string.Empty;
        _lastDevice = null;

        if (clearToken)
        {
            NetMessage.ClearCachedToken();
        }

        if (disconnect)
        {
            Disconnect(clearToken: false);
        }
    }


    public async Task<TokenRefresh_s2c> RefreshTokenAsync(string refreshToken = null)
    {
        var request = new TokenRefresh_c2s
        {
            RefreshToken = string.IsNullOrWhiteSpace(refreshToken) ? NetMessage.CachedToken : refreshToken,
            ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        };

        var response = await RequestAsync<TokenRefresh_s2c>(request, NetworkChannel.Login, requireToken: false);
        if (response != null && !string.IsNullOrWhiteSpace(response.Token))
        {
            NetMessage.CacheToken(response.Token, response.ExpireAt);
        }

        return response;
    }

    public async Task<SessionResume_s2c> ResumeSessionAsync(string serverId = null, bool includeProfile = true)
    {
        var targetServerId = string.IsNullOrWhiteSpace(serverId) ? _selectedServerId : serverId;
        return await RequestAsync<SessionResume_s2c>(
            new SessionResume_c2s
            {
                ServerId = targetServerId ?? string.Empty,
                IncludeProfile = includeProfile,
                ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
            },
            NetworkChannel.Login,
            requireToken: true);
    }

    public async Task<Logout_s2c> LogoutAsync(bool disconnect = true, bool clearToken = true)
    {
        var response = await RequestAsync<Logout_s2c>(
            new Logout_c2s
            {
                ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                Reason = "ClientLogout"
            },
            NetworkChannel.Login,
            requireToken: true);

        Logout(disconnect, clearToken);
        return response;
    }

    public void StartHeartbeat()
    {
        networkFacade?.HeartbeatService?.StartHeartbeat();
    }

    public void StopHeartbeat()
    {
        networkFacade?.HeartbeatService?.StopHeartbeat();
    }

    public string ResolveEndpoint(NetworkChannel channel)
    {
        var route = ResolveRoute(channel);
        return ResolveEndpoint(route);
    }

    public string ResolveServerId(string preferredServerId = null)
    {
        if (!string.IsNullOrWhiteSpace(preferredServerId))
        {
            return preferredServerId;
        }

        if (config != null && !config.EnableRollingServerMode && !string.IsNullOrWhiteSpace(config.SingleServerId))
        {
            return config.SingleServerId;
        }

        if (!string.IsNullOrWhiteSpace(_selectedServerId))
        {
            return _selectedServerId;
        }

        return _lastLoginResponse?.LastServerId ?? string.Empty;
    }

    public bool HasToken => NetMessage.HasCachedToken;

    public string GetToken() => NetMessage.CachedToken;

    public long GetTokenExpireAt() => NetMessage.CachedTokenExpireAt;

    public void SaveToken(string token, long expireAt = 0) => NetMessage.CacheToken(token, expireAt);

    public void ClearToken(bool clearPersistent = true) => NetMessage.ClearCachedToken(clearPersistent);

    public async Task<TResponse> RequestAsync<TResponse>(
        object request,
        NetworkChannel channel = NetworkChannel.Game,
        bool requireToken = true,
        bool? reliable = null,
        int? priority = null,
        float? timeoutSeconds = null) where TResponse : class
    {
        var result = await RequestResultAsync<TResponse>(request, channel, requireToken, reliable, priority, timeoutSeconds);
        if (!result.Success)
        {
            throw new GameNetworkException(
                string.IsNullOrWhiteSpace(result.ErrorCode) ? GameNetworkErrorCodes.BusinessFailed : result.ErrorCode,
                string.IsNullOrWhiteSpace(result.Message) ? "Request failed." : result.Message);
        }

        return result.Response;
    }

    public async Task<GameNetworkCallResult<TResponse>> RequestResultAsync<TResponse>(
        object request,
        NetworkChannel channel = NetworkChannel.Game,
        bool requireToken = true,
        bool? reliable = null,
        int? priority = null,
        float? timeoutSeconds = null) where TResponse : class
    {
        string effectiveSummary = BuildEffectiveConfigSummary(channel, reliable, priority, timeoutSeconds);

        if (request == null)
        {
            return new GameNetworkCallResult<TResponse> { Success = false, ErrorCode = GameNetworkErrorCodes.InvalidArgument, Message = "Request is null.", EffectiveConfigSummary = effectiveSummary };
        }

        if (!EnsureFacade())
        {
            return new GameNetworkCallResult<TResponse> { Success = false, ErrorCode = GameNetworkErrorCodes.TransportNotReady, Message = "NetworkFacade is not ready.", EffectiveConfigSummary = effectiveSummary };
        }

        if (requireToken && !NetMessage.EnsureTokenForPayload(request))
        {
            return new GameNetworkCallResult<TResponse> { Success = false, ErrorCode = GameNetworkErrorCodes.TokenMissing, Message = "Token is missing.", EffectiveConfigSummary = effectiveSummary };
        }

        var route = ResolveRoute(channel);
        var endpoint = ResolveEndpoint(route);
        var reqReliable = reliable ?? route.ReliableByDefault;
        var reqPriority = priority ?? route.DefaultPriority;
        var reqTimeout = timeoutSeconds ?? (config != null ? config.RequestTimeoutSeconds : 20f);

        networkFacade.EnsureConnected(route.Transport, endpoint);

        var tcs = new TaskCompletionSource<GameNetworkCallResult<TResponse>>();
        var done = false;
        var expectedResponseId = ResolveResponseId(request.GetType());
        var requestInstanceId = string.Empty;
        Action<int, string, string> onRequestFailedV2 = null;

        onRequestFailedV2 = (responseId, failedRequestInstanceId, reason) =>
        {
            if (done)
            {
                return;
            }

            if (responseId != expectedResponseId)
            {
                return;
            }

            if (!string.IsNullOrWhiteSpace(requestInstanceId) &&
                !string.IsNullOrWhiteSpace(failedRequestInstanceId) &&
                !string.Equals(requestInstanceId, failedRequestInstanceId, StringComparison.Ordinal))
            {
                return;
            }

            done = true;
            tcs.TrySetResult(new GameNetworkCallResult<TResponse>
            {
                Success = false,
                ErrorCode = GameNetworkErrorCodes.ConnectionLost,
                Message = string.IsNullOrWhiteSpace(reason) ? "Request failed." : reason,
                Response = null,
                EffectiveConfigSummary = effectiveSummary
            });
        };

        try
        {
            var manager = networkFacade.Manager;
            if (manager != null)
            {
                manager.OnRequestFailedV2 += onRequestFailedV2;
            }

            requestInstanceId = networkFacade.Send<TResponse>(
                request,
                response =>
                {
                    if (done)
                    {
                        return;
                    }

                    done = true;
                    if (response == null)
                    {
                        tcs.TrySetResult(new GameNetworkCallResult<TResponse>
                        {
                            Success = false,
                            ErrorCode = GameNetworkErrorCodes.EmptyResponse,
                            Message = "Response is null.",
                            Response = null,
                            EffectiveConfigSummary = effectiveSummary
                        });
                        return;
                    }

                    var businessSuccess = GameNetworkResponseInspector.IsBusinessSuccess(response);
                    tcs.TrySetResult(new GameNetworkCallResult<TResponse>
                    {
                        Success = businessSuccess,
                        ErrorCode = businessSuccess ? null : GameNetworkResponseInspector.GetErrorCode(response),
                        Message = businessSuccess ? null : GameNetworkResponseInspector.GetMessage(response),
                        Response = response,
                        EffectiveConfigSummary = effectiveSummary
                    });
                },
                route.Transport,
                endpoint,
                reqReliable,
                reqPriority);
        }
        catch (Exception ex)
        {
            var mappedErrorCode = MapInfrastructureErrorCode(ex);
            return new GameNetworkCallResult<TResponse>
            {
                Success = false,
                ErrorCode = mappedErrorCode,
                Message = ex.Message,
                Response = null,
                EffectiveConfigSummary = effectiveSummary
            };
        }

        if (reqTimeout > 0f)
        {
            _ = Task.Run(async () =>
            {
                await Task.Delay(Mathf.Max(1, Mathf.RoundToInt(reqTimeout * 1000f)));
                if (done)
                {
                    return;
                }

                done = true;
                tcs.TrySetResult(new GameNetworkCallResult<TResponse>
                {
                    Success = false,
                    ErrorCode = GameNetworkErrorCodes.RequestTimeout,
                    Message = $"Request timed out after {reqTimeout:F1}s.",
                    EffectiveConfigSummary = effectiveSummary
                });
            });
        }
        var callResult = await tcs.Task;
        var cleanupManager = networkFacade != null ? networkFacade.Manager : null;
        if (cleanupManager != null && onRequestFailedV2 != null)
        {
            cleanupManager.OnRequestFailedV2 -= onRequestFailedV2;
        }

        return callResult;
    }

    private static string MapInfrastructureErrorCode(Exception ex)
    {
        if (ex == null || string.IsNullOrWhiteSpace(ex.Message))
        {
            return GameNetworkErrorCodes.Unknown;
        }

        string message = ex.Message;
        if (message.Contains("NETWORK_SERIALIZER_NOT_FOUND", StringComparison.OrdinalIgnoreCase))
        {
            return GameNetworkErrorCodes.SerializerNotFound;
        }

        if (message.Contains("compress", StringComparison.OrdinalIgnoreCase) || message.Contains("decompress", StringComparison.OrdinalIgnoreCase))
        {
            return GameNetworkErrorCodes.CompressionError;
        }

        if (message.Contains("encrypt", StringComparison.OrdinalIgnoreCase) || message.Contains("decrypt", StringComparison.OrdinalIgnoreCase))
        {
            return GameNetworkErrorCodes.EncryptionError;
        }

        if (message.Contains("serial", StringComparison.OrdinalIgnoreCase) || message.Contains("deserialize", StringComparison.OrdinalIgnoreCase))
        {
            return GameNetworkErrorCodes.SerializerError;
        }

        if (message.Contains("simulation", StringComparison.OrdinalIgnoreCase))
        {
            return GameNetworkErrorCodes.SimulationConfigInvalid;
        }

        return GameNetworkErrorCodes.Unknown;
    }

    private string BuildEffectiveConfigSummary(NetworkChannel channel, bool? reliable, int? priority, float? timeoutSeconds)
    {
        var route = ResolveRoute(channel);
        var endpoint = ResolveEndpoint(route);
        var reqReliable = reliable ?? route.ReliableByDefault;
        var reqPriority = priority ?? route.DefaultPriority;
        var reqTimeout = timeoutSeconds ?? (config != null ? config.RequestTimeoutSeconds : 20f);
        var rolling = config == null || config.EnableRollingServerMode;
        var singleServerId = config != null ? config.SingleServerId : string.Empty;
        return $"channel={channel};transport={route.Transport};endpoint={endpoint};reliable={reqReliable};priority={reqPriority};timeout={reqTimeout:F1};rolling={rolling};singleServerId={singleServerId};frameRate={config?.ClientFrameRate ?? 30};snapshotMs={config?.SnapshotIntervalMs ?? 100}";
    }

    private static int ResolveResponseId(Type requestType)
    {
        if (requestType == null)
        {
            return -1;
        }

        var requestTypeName = requestType.Name;
        if (ProtocolDictionary.Protocols.TryGetValue(requestTypeName, out var requestId))
        {
            return requestId + 1;
        }

        if (requestTypeName.EndsWith("_c2s", StringComparison.Ordinal))
        {
            var responseTypeName = requestTypeName.Substring(0, requestTypeName.Length - 4) + "_s2c";
            if (ProtocolDictionary.Protocols.TryGetValue(responseTypeName, out var responseId))
            {
                return responseId;
            }
        }

        return -1;
    }

    public IDisposable Subscribe<TNotify>(Action<TNotify> handler) where TNotify : class
    {
        if (handler == null)
        {
            return Disposable.Empty;
        }

        if (!EnsureFacade() || networkFacade.Manager == null)
        {
            return Disposable.Empty;
        }

        if (!ProtocolDictionary.Protocols.TryGetValue(typeof(TNotify).Name, out var messageId))
        {
            Logger.Log($"[GameNetworkClient] Unknown protocol type: {typeof(TNotify).Name}", LogLevel.Warning);
            return Disposable.Empty;
        }

        Action<NetMessage> raw = message =>
        {
            var data = NetMessage.DeserializeData(message) as TNotify;
            if (data != null)
            {
                handler.Invoke(data);
            }
        };

        networkFacade.Manager.RegisterHandler(messageId, raw);
        var disposable = new Disposable(() => networkFacade.Manager.UnregisterHandler(messageId, raw));
        _subscriptions.Add(disposable);
        return disposable;
    }

    private void RegisterBuiltInNotifications()
    {
        Subscribe<NotifyKickOff_s2c>(msg =>
        {
            OnKickedOff?.Invoke(msg);
            if (config != null && config.StopHeartbeatOnDisconnect)
            {
                networkFacade?.HeartbeatService?.StopHeartbeat();
            }
        });
    }

    private void BindManagerEvents()
    {
        var manager = networkFacade != null ? networkFacade.Manager : null;
        if (manager == null)
        {
            return;
        }

        manager.OnDisconnected += HandleDisconnected;
        manager.OnConnectionLost += HandleDisconnected;
        manager.OnReconnected += HandleReconnected;
    }

    private void UnbindManagerEvents()
    {
        var manager = networkFacade != null ? networkFacade.Manager : null;
        if (manager == null)
        {
            return;
        }

        manager.OnDisconnected -= HandleDisconnected;
        manager.OnConnectionLost -= HandleDisconnected;
        manager.OnReconnected -= HandleReconnected;
    }

    private void HandleDisconnected()
    {
        if (config != null && config.StopHeartbeatOnDisconnect)
        {
            networkFacade?.HeartbeatService?.StopHeartbeat();
        }
        OnDisconnected?.Invoke();
    }

    private async void HandleReconnected()
    {
        OnReconnected?.Invoke();

        if (config == null || !config.AutoReconnectResumeSession)
        {
            return;
        }

        if (!string.IsNullOrWhiteSpace(_selectedServerId) && NetMessage.HasCachedToken)
        {
            try
            {
                await SelectServerAsync(_selectedServerId);
            }
            catch (Exception ex)
            {
                Logger.Log("[GameNetworkClient] Reconnect resume select server failed: " + ex.Message, LogLevel.Warning);
            }
        }
    }

    private GameNetworkConfig.Route ResolveRoute(NetworkChannel channel)
    {
        if (_routeMap.TryGetValue(channel, out var route) && route != null)
        {
            return route;
        }

        return new GameNetworkConfig.Route
        {
            Channel = channel,
            Transport = channel == NetworkChannel.Battle ? NetworkManager.TransportType.Kcp : NetworkManager.TransportType.WebSocket,
            EndpointOverride = string.Empty,
            ReliableByDefault = true,
            DefaultPriority = 1
        };
    }

    private static string ResolveEndpoint(GameNetworkConfig.Route route)
    {
        if (!string.IsNullOrWhiteSpace(route.EndpointOverride))
        {
            return route.EndpointOverride.Trim();
        }

        return NetworkEndpoints.GetEndpoint((NetworkEndpoints.Channel)(int)route.Channel);
    }

    private void RebuildRouteMap()
    {
        _routeMap.Clear();
        if (config == null || config.Routes == null)
        {
            return;
        }

        for (var i = 0; i < config.Routes.Count; i++)
        {
            var route = config.Routes[i];
            if (route == null)
            {
                continue;
            }

            _routeMap[route.Channel] = route;
        }
    }

    private bool EnsureFacade()
    {
        if (networkFacade != null)
        {
            return true;
        }

        if (!autoFindNetworkFacade)
        {
            return false;
        }

        networkFacade = FindFirstObjectByType<NetworkFacade>();
        return networkFacade != null;
    }

    private void ClearSubscriptions()
    {
        for (var i = 0; i < _subscriptions.Count; i++)
        {
            _subscriptions[i]?.Dispose();
        }
        _subscriptions.Clear();
    }

    private static DeviceInfo BuildDefaultDeviceInfo()
    {
        return new DeviceInfo
        {
            Platform = Application.platform.ToString(),
            DeviceId = SystemInfo.deviceUniqueIdentifier,
            ClientVersion = Application.version
        };
    }

    private sealed class Disposable : IDisposable
    {
        public static readonly Disposable Empty = new Disposable(null);
        private readonly Action _dispose;
        private bool _disposed;

        public Disposable(Action dispose)
        {
            _dispose = dispose;
        }

        public void Dispose()
        {
            if (_disposed)
            {
                return;
            }

            _disposed = true;
            _dispose?.Invoke();
        }
    }
}


