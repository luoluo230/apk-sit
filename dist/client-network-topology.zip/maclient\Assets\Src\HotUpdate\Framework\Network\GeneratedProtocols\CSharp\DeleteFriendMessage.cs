﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 删除好友
/// </summary>
public class DeleteFriend_c2s
{
    /// <summary>
    /// 好友玩家 ID
    /// </summary>
    public long TargetPlayerId { get; set; }
}

/// <summary>
/// 删除好友结果
/// </summary>
public class DeleteFriend_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

