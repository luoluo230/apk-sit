using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public sealed class ProtocolSchemaField
{
    public string Name = "Field";
    public string Type = "string";
    public string Comment = string.Empty;
    public bool Required;
    public string DefaultValue = string.Empty;
    public bool Deprecated;
    public string SinceVersion = string.Empty;
    public int FieldId;
    public string Tags = string.Empty;
    public string Migration = string.Empty;
}

public sealed class ProtocolStructuredEntry
{
    public string Name = string.Empty;
    public ProtocolSchemaEntryKind Kind = ProtocolSchemaEntryKind.Message;
    public int MessageId;
    public string Comment = string.Empty;
    public string Module = string.Empty;
    public string Status = "Stable";
    public string SinceVersion = string.Empty;
    public string DeprecatedSince = string.Empty;
    public readonly List<ProtocolSchemaField> Fields = new List<ProtocolSchemaField>();
    public readonly List<string> EnumValues = new List<string>();
}

public sealed class ProtocolDeepValidationIssue
{
    public string EntryName;
    public string Message;
    public bool IsError;
}

public static class ProtocolSchemaStructuredCodec
{
    private static readonly HashSet<string> PrimitiveTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "int", "int32", "long", "int64", "float", "double", "bool", "boolean", "string", "byte", "short"
    };

    public static ProtocolStructuredEntry FromEntry(ProtocolSchemaEntry entry)
    {
        var model = new ProtocolStructuredEntry
        {
            Name = entry?.Name ?? string.Empty,
            Kind = entry?.Kind ?? ProtocolSchemaEntryKind.Unknown,
            MessageId = entry?.MessageId ?? 0
        };

        if (!ProtocolJson.TryParse(entry?.Json, out ProtocolJsonValue value, out _) || !(value is ProtocolJsonObject root))
        {
            return model;
        }

        model.Comment = root.GetString("Comment", string.Empty);
        model.Module = root.GetString("Module", string.Empty);
        model.Status = string.IsNullOrWhiteSpace(root.GetString("Status", string.Empty)) ? "Stable" : root.GetString("Status", "Stable");
        model.SinceVersion = root.GetString("SinceVersion", string.Empty);
        model.DeprecatedSince = root.GetString("DeprecatedSince", string.Empty);

        if (model.Kind == ProtocolSchemaEntryKind.Enum)
        {
            ProtocolJsonArray values = root.GetArray("Values");
            if (values != null)
            {
                foreach (ProtocolJsonValue item in values.Items)
                {
                    if (item is ProtocolJsonString text) model.EnumValues.Add(text.Value);
                }
            }
        }
        else
        {
            ProtocolJsonObject fields = root.GetObject(model.Kind == ProtocolSchemaEntryKind.Message ? "Data" : "Fields");
            if (fields != null)
            {
                foreach (KeyValuePair<string, ProtocolJsonValue> pair in fields.Properties)
                {
                    if (!(pair.Value is ProtocolJsonObject fieldObj)) continue;
                    model.Fields.Add(new ProtocolSchemaField
                    {
                        Name = pair.Key,
                        Type = fieldObj.GetString("Type", "string"),
                        Comment = fieldObj.GetString("Comment", string.Empty),
                        Required = fieldObj.GetBool("Required"),
                        DefaultValue = fieldObj.GetString("Default", string.Empty),
                        Deprecated = fieldObj.GetBool("Deprecated"),
                        SinceVersion = fieldObj.GetString("SinceVersion", string.Empty),
                        FieldId = fieldObj.GetInt("FieldId"),
                        Tags = fieldObj.GetString("Tags", string.Empty),
                        Migration = fieldObj.GetString("Migration", string.Empty)
                    });
                }
            }
        }

        return model;
    }

    public static string ToJson(ProtocolStructuredEntry model)
    {
        var root = new ProtocolJsonObject();
        if (model.Kind == ProtocolSchemaEntryKind.Message)
        {
            root.Properties["MessageID"] = new ProtocolJsonNumber(Math.Max(1, model.MessageId).ToString());
        }
        else
        {
            root.Properties["Type"] = new ProtocolJsonString(model.Kind == ProtocolSchemaEntryKind.Enum ? "Enum" : "Class");
        }

        root.Properties["Comment"] = new ProtocolJsonString(model.Comment ?? string.Empty);
        AddOptional(root, "Module", model.Module);
        AddOptional(root, "Status", model.Status);
        AddOptional(root, "SinceVersion", model.SinceVersion);
        AddOptional(root, "DeprecatedSince", model.DeprecatedSince);

        if (model.Kind == ProtocolSchemaEntryKind.Enum)
        {
            var values = new ProtocolJsonArray();
            foreach (string enumValue in model.EnumValues) values.Items.Add(new ProtocolJsonString(enumValue));
            root.Properties["Values"] = values;
        }
        else
        {
            var fields = new ProtocolJsonObject();
            foreach (ProtocolSchemaField field in model.Fields)
            {
                var fieldObj = new ProtocolJsonObject();
                fieldObj.Properties["Type"] = new ProtocolJsonString(field.Type ?? "string");
                fieldObj.Properties["Comment"] = new ProtocolJsonString(field.Comment ?? string.Empty);
                if (field.Required) fieldObj.Properties["Required"] = new ProtocolJsonBoolean(true);
                AddOptional(fieldObj, "Default", field.DefaultValue);
                if (field.Deprecated) fieldObj.Properties["Deprecated"] = new ProtocolJsonBoolean(true);
                AddOptional(fieldObj, "SinceVersion", field.SinceVersion);
                if (field.FieldId > 0) fieldObj.Properties["FieldId"] = new ProtocolJsonNumber(field.FieldId.ToString());
                AddOptional(fieldObj, "Tags", field.Tags);
                AddOptional(fieldObj, "Migration", field.Migration);
                fields.Properties[field.Name] = fieldObj;
            }

            root.Properties[model.Kind == ProtocolSchemaEntryKind.Message ? "Data" : "Fields"] = fields;
        }

        return root.ToJson(0);
    }

    public static int GetNextMessageId(ProtocolSchemaDocument document, int minimum = 10000)
    {
        int max = document?.Entries.Where(e => e.Kind == ProtocolSchemaEntryKind.Message).Select(e => e.MessageId).DefaultIfEmpty(minimum - 1).Max() ?? minimum - 1;
        return Math.Max(minimum, max + 1);
    }

    public static int GetNextMessageId(ProtocolSchemaDocument document, int moduleCode, int blockSize, bool serverToClient)
    {
        int safeModule = Math.Max(1, moduleCode);
        int safeBlock = Math.Max(100, blockSize);
        int start = safeModule * safeBlock;
        int directionStart = serverToClient ? start + safeBlock / 2 : start;
        int directionEnd = serverToClient ? start + safeBlock - 1 : start + safeBlock / 2 - 1;
        HashSet<int> used = new HashSet<int>(document?.Entries.Where(e => e.Kind == ProtocolSchemaEntryKind.Message).Select(e => e.MessageId) ?? Enumerable.Empty<int>());
        for (int id = directionStart; id <= directionEnd; id++)
        {
            if (!used.Contains(id)) return id;
        }

        return GetNextMessageId(document, start + safeBlock);
    }

    public static List<string> GetTypeOptions(ProtocolSchemaDocument document)
    {
        var result = new List<string> { "int", "long", "float", "double", "bool", "string" };
        if (document != null)
        {
            result.AddRange(document.Entries.Where(e => e.Kind == ProtocolSchemaEntryKind.Class || e.Kind == ProtocolSchemaEntryKind.Enum).Select(e => e.Name));
        }

        result.AddRange(result.ToArray().Select(type => type + "[]"));
        result.Add("List<string>");
        result.Add("Map<string,int>");
        result.Add("string?");
        return result.Distinct(StringComparer.Ordinal).OrderBy(v => v, StringComparer.Ordinal).ToList();
    }

    public static List<ProtocolDeepValidationIssue> ValidateDeep(ProtocolSchemaDocument document)
    {
        var issues = new List<ProtocolDeepValidationIssue>();
        if (document == null)
        {
            issues.Add(new ProtocolDeepValidationIssue { Message = "Protocol document is null.", IsError = true });
            return issues;
        }

        var knownTypes = new HashSet<string>(PrimitiveTypes, StringComparer.OrdinalIgnoreCase);
        foreach (ProtocolSchemaEntry entry in document.Entries) knownTypes.Add(entry.Name);

        foreach (ProtocolSchemaEntry entry in document.Entries)
        {
            ProtocolStructuredEntry model = FromEntry(entry);
            if (entry.Kind == ProtocolSchemaEntryKind.Message && !entry.Name.EndsWith("_c2s", StringComparison.Ordinal) && !entry.Name.EndsWith("_s2c", StringComparison.Ordinal))
            {
                issues.Add(new ProtocolDeepValidationIssue { EntryName = entry.Name, Message = "Message protocol should use _c2s or _s2c suffix.", IsError = false });
            }

            foreach (ProtocolSchemaField field in model.Fields)
            {
                if (string.IsNullOrWhiteSpace(field.Name))
                {
                    issues.Add(new ProtocolDeepValidationIssue { EntryName = entry.Name, Message = "Field name is empty.", IsError = true });
                }

                foreach (string dependency in ProtocolTypeReference.Parse(field.Type).GetNamedDependencies())
                {
                    if (!knownTypes.Contains(dependency))
                    {
                        issues.Add(new ProtocolDeepValidationIssue { EntryName = entry.Name, Message = "Unknown field type: " + dependency, IsError = true });
                    }
                }
            }
        }

        return issues;
    }

    private static void AddOptional(ProtocolJsonObject obj, string key, string value)
    {
        if (!string.IsNullOrWhiteSpace(value)) obj.Properties[key] = new ProtocolJsonString(value);
    }
}
