// 自动生成的协议文件

// 定义协议类


// 修改公会设置(公告/条件)
class ChangeGuildSettings_c2s {
    constructor() {
        this.Notice = '';
        this.RequirePower = 0;
        this.RequireVerify = false;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 修改公会设置结果
class ChangeGuildSettings_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ChangeGuildSettings_c2s,
    ChangeGuildSettings_s2c,
};
