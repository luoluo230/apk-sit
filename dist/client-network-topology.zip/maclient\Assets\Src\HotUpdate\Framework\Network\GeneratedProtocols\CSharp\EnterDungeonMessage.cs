﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 进入副本
/// </summary>
public class EnterDungeon_c2s
{
    /// <summary>
    /// 副本 ID
    /// </summary>
    public int DungeonId { get; set; }
    /// <summary>
    /// 阵容
    /// </summary>
    public FormationSlot[] Formation { get; set; }
}

/// <summary>
/// 进入副本结果
/// </summary>
public class EnterDungeon_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 副本 ID
    /// </summary>
    public int DungeonId { get; set; }
    /// <summary>
    /// 战斗/副本会话 ID
    /// </summary>
    public string BattleId { get; set; }
}

