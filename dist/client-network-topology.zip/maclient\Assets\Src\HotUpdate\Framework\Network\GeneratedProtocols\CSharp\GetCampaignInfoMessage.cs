﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取主线推图信息
/// </summary>
public class GetCampaignInfo_c2s
{
}

/// <summary>
/// 返回主线推图信息
/// </summary>
public class GetCampaignInfo_s2c
{
    /// <summary>
    /// 主线进度信息
    /// </summary>
    public CampaignInfo Campaign { get; set; }
}

