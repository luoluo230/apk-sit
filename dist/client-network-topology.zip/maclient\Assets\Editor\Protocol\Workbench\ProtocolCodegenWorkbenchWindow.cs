﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using UnityEditor;
using UnityEngine;

public sealed class ProtocolCodegenWorkbenchWindow : EditorWindow
{
    private static readonly string RepoRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
    private static readonly string GenerateScriptPath = Path.Combine(RepoRoot, "tools", "protocols", "Generate-ProtocolArtifacts.ps1");
    private static readonly string ValidateScriptPath = Path.Combine(RepoRoot, "tools", "protocols", "Validate-ProtocolArtifacts.ps1");
    private static readonly string NetworkSettingsAssetPath = "Assets/Resources/Protocol/ProtocolNetworkSettings.asset";
    private static readonly string[] Tabs = { "总览", "协议编辑", "导出生成", "协议测试", "网络配置", "网络模拟" };

    private readonly HashSet<string> _selectedForExport = new HashSet<string>(StringComparer.Ordinal);
    private readonly Dictionary<string, bool> _moduleFoldouts = new Dictionary<string, bool>(StringComparer.Ordinal);
    private readonly Dictionary<string, ProtocolStructuredEntry> _modelCache = new Dictionary<string, ProtocolStructuredEntry>(StringComparer.Ordinal);
    private readonly Dictionary<string, string> _moduleCache = new Dictionary<string, string>(StringComparer.Ordinal);
    private readonly List<ProtocolSchemaEntry> _visibleEntries = new List<ProtocolSchemaEntry>();
    private PowerShellProtocolArtifactService _service;
    private ProtocolSchemaDocument _document;
    private ProtocolSourceSummary _summary;
    private ProtocolSchemaValidationResult _basicValidation;
    private List<ProtocolDeepValidationIssue> _deepIssues = new List<ProtocolDeepValidationIssue>();
    private List<string> _typeOptions = new List<string>();
    private ProtocolSchemaEntry _selectedEntry;
    private ProtocolStructuredEntry _editModel;
    private ProtocolNetworkSettings _networkSettings;
    private SerializedObject _networkSerializedObject;
    private Vector2 _leftScroll;
    private Vector2 _mainScroll;
    private Vector2 _logScroll;
    private Vector2 _fieldScroll;
    private string _search = string.Empty;
    private string _moduleFilter = "全部";
    private string[] _moduleOptions = { "全部" };
    private string _lastSearch = null;
    private string _lastModuleFilter = null;
    private ProtocolSchemaEntryKind _kindFilter = ProtocolSchemaEntryKind.All;
    private ProtocolSchemaEntryKind _lastKindFilter = ProtocolSchemaEntryKind.Unknown;
    private int _tab;
    private string _newProtocolName = "NewProtocol_c2s";
    private int _newModuleCode = 10;
    private int _messageBlockSize = 1000;
    private bool _newProtocolIsS2c;
    private ProtocolExportLanguage _exportLanguages = ProtocolExportLanguage.CSharp | ProtocolExportLanguage.TypeScript | ProtocolExportLanguage.Markdown;
    private readonly ProtocolExportOptions _exportOptions = new ProtocolExportOptions();
    private string _exportRoot = "protocols/generated/manual-export";
    private string _testRequestJson = "{\n  \"example\": \"value\"\n}";
    private string _testResult = string.Empty;
    private string _log = string.Empty;
    private bool _showCredentialPlainText;
    private string _credentialPlainInput = string.Empty;

    public static void Open()
    {
        var window = GetWindow<ProtocolCodegenWorkbenchWindow>("协议工作台");
        window.minSize = new Vector2(1220f, 720f);
        window.Show();
    }

    private void OnEnable()
    {
        _service = new PowerShellProtocolArtifactService(GenerateScriptPath, ValidateScriptPath);
        ReloadDocument();
        LoadOrCreateNetworkSettings();
    }

    private void OnGUI()
    {
        if (_service == null) OnEnable();
        DrawHeader();
        EditorGUILayout.BeginHorizontal();
        DrawProtocolList();
        DrawMainArea();
        EditorGUILayout.EndHorizontal();
        DrawLog();
    }

    private void DrawHeader()
    {
        Rect rect = EditorGUILayout.GetControlRect(false, 64f);
        EditorGUI.DrawRect(rect, new Color(0.13f, 0.17f, 0.2f));
        GUILayout.BeginArea(rect);
        EditorGUILayout.Space(8f);
        EditorGUILayout.BeginHorizontal();
        GUILayout.Space(12f);
        EditorGUILayout.BeginVertical();
        GUIStyle title = new GUIStyle(EditorStyles.boldLabel) { fontSize = 18, normal = { textColor = Color.white } };
        GUIStyle sub = new GUIStyle(EditorStyles.miniLabel) { normal = { textColor = new Color(0.82f, 0.9f, 1f) } };
        GUILayout.Label("M09-07 协议、DTO 与代码生成工作台", title);
        GUILayout.Label("负责协议编辑、格式校验、多语言导出、正式产物生成、网络配置、协议测试与弱网模拟。业务逻辑 AI 生成已拆分到 M09-07B。", sub);
        EditorGUILayout.EndVertical();
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("重新加载", GUILayout.Width(92f), GUILayout.Height(28f))) ReloadDocument();
        if (GUILayout.Button("保存协议", GUILayout.Width(92f), GUILayout.Height(28f))) SaveCurrentEntryAndDocument();
        if (GUILayout.Button("生成产物", GUILayout.Width(92f), GUILayout.Height(28f))) RunGenerate();
        if (GUILayout.Button("校验产物", GUILayout.Width(92f), GUILayout.Height(28f))) RunValidate();
        GUILayout.Space(10f);
        EditorGUILayout.EndHorizontal();
        GUILayout.EndArea();
    }

    private void DrawProtocolList()
    {
        EditorGUILayout.BeginVertical("box", GUILayout.Width(360f), GUILayout.ExpandHeight(true));
        GUILayout.Label("协议列表", EditorStyles.boldLabel);
        _search = EditorGUILayout.TextField("搜索", _search);
        _kindFilter = (ProtocolSchemaEntryKind)EditorGUILayout.EnumPopup("类型", _kindFilter);
        string[] modules = GetModuleOptions();
        int moduleIndex = Mathf.Max(0, Array.IndexOf(modules, _moduleFilter));
        moduleIndex = EditorGUILayout.Popup("模块", moduleIndex, modules);
        _moduleFilter = modules.Length > 0 ? modules[moduleIndex] : "全部";
        RefreshVisibleEntriesIfNeeded();

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("全选可见")) SelectVisibleForExport();
        if (GUILayout.Button("清空导出")) _selectedForExport.Clear();
        EditorGUILayout.EndHorizontal();

        _leftScroll = EditorGUILayout.BeginScrollView(_leftScroll, GUILayout.ExpandHeight(true));
        foreach (IGrouping<string, ProtocolSchemaEntry> group in _visibleEntries.GroupBy(GetModuleName).OrderBy(group => group.Key, StringComparer.Ordinal))
        {
            string module = string.IsNullOrWhiteSpace(group.Key) ? "Common" : group.Key;
            if (!_moduleFoldouts.ContainsKey(module)) _moduleFoldouts[module] = true;
            _moduleFoldouts[module] = EditorGUILayout.Foldout(_moduleFoldouts[module], module + " (" + group.Count() + ")", true);
            if (!_moduleFoldouts[module]) continue;
            foreach (ProtocolSchemaEntry entry in group.OrderBy(entry => entry.Name, StringComparer.Ordinal))
            {
                DrawProtocolRow(entry);
            }
        }
        EditorGUILayout.EndScrollView();

        DrawCreateProtocolPanel();
        EditorGUILayout.EndVertical();
    }

    private void DrawProtocolRow(ProtocolSchemaEntry entry)
    {
        EditorGUILayout.BeginHorizontal();
        bool exportSelected = _selectedForExport.Contains(entry.Name);
        bool nextExportSelected = GUILayout.Toggle(exportSelected, GUIContent.none, GUILayout.Width(18f));
        if (nextExportSelected != exportSelected)
        {
            if (nextExportSelected) _selectedForExport.Add(entry.Name);
            else _selectedForExport.Remove(entry.Name);
            SelectEntry(entry);
        }

        string label = GetKindShort(entry.Kind) + "  " + entry.Name + (entry.MessageId > 0 ? "  #" + entry.MessageId : string.Empty);
        GUIStyle style = entry == _selectedEntry ? EditorStyles.miniButtonMid : EditorStyles.miniButton;
        if (GUILayout.Button(label, style))
        {
            SelectEntry(entry);
        }
        EditorGUILayout.EndHorizontal();
    }

    private void DrawCreateProtocolPanel()
    {
        EditorGUILayout.Space(4f);
        EditorGUILayout.BeginVertical("box");
        GUILayout.Label("新增协议/类型", EditorStyles.boldLabel);
        _newProtocolName = EditorGUILayout.TextField("名称", _newProtocolName);
        _kindFilter = _kindFilter == ProtocolSchemaEntryKind.Unknown ? ProtocolSchemaEntryKind.All : _kindFilter;
        ProtocolSchemaEntryKind newKind = (ProtocolSchemaEntryKind)EditorGUILayout.EnumPopup("新增类型", ProtocolSchemaEntryKind.Message);
        _newModuleCode = EditorGUILayout.IntField("模块号", _newModuleCode);
        _messageBlockSize = EditorGUILayout.IntField("区间大小", _messageBlockSize);
        _newProtocolIsS2c = EditorGUILayout.ToggleLeft("服务端推送/响应 _s2c 区间", _newProtocolIsS2c);
        int nextId = ProtocolSchemaStructuredCodec.GetNextMessageId(_document, _newModuleCode, _messageBlockSize, _newProtocolIsS2c);
        EditorGUILayout.LabelField("下一个 MessageID", nextId.ToString());
        if (GUILayout.Button("新增到协议"))
        {
            AddNewEntry(newKind, nextId);
        }
        EditorGUILayout.EndVertical();
    }

    private void DrawMainArea()
    {
        EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
        _tab = GUILayout.Toolbar(_tab, Tabs, GUILayout.Height(28f));
        _mainScroll = EditorGUILayout.BeginScrollView(_mainScroll, GUILayout.ExpandHeight(true));
        switch (_tab)
        {
            case 0: DrawOverviewTab(); break;
            case 1: DrawEditTab(); break;
            case 2: DrawExportTab(); break;
            case 3: DrawProtocolTestTab(); break;
            case 4: DrawNetworkConfigTab(); break;
            case 5: DrawNetworkSimulationTab(); break;
        }
        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();
    }

    private void DrawOverviewTab()
    {
        DrawSection("协议概览", () =>
        {
            EditorGUILayout.LabelField("协议源", _summary != null ? _summary.SourcePath : "-");
            EditorGUILayout.LabelField("源文件存在", _summary != null && _summary.SourceExists ? "是" : "否");
            EditorGUILayout.LabelField("定义总数", _summary != null ? _summary.TotalDefinitions.ToString() : "0");
            EditorGUILayout.LabelField("消息数量", _summary != null ? _summary.MessageCount.ToString() : "0");
            EditorGUILayout.LabelField("请求/响应/推送", _summary != null ? (_summary.RequestCount + " / " + _summary.ResponseCount + " / " + _summary.PushCount) : "0 / 0 / 0");
            EditorGUILayout.LabelField("Class/Enum", _summary != null ? (_summary.CustomClassCount + " / " + _summary.EnumCount) : "0 / 0");
            EditorGUILayout.LabelField("重复 MessageID", _summary != null ? _summary.DuplicateIdCount.ToString() : "0");
        });

        DrawSection("格式与兼容性检查", () =>
        {
            if (_document == null)
            {
                EditorGUILayout.HelpBox("协议尚未加载。", MessageType.Warning);
                return;
            }

            ProtocolSchemaValidationResult basic = _basicValidation ?? new ProtocolSchemaValidationResult();
            foreach (string error in basic.Errors.Take(20)) EditorGUILayout.HelpBox(error, MessageType.Error);
            foreach (string warning in basic.Warnings.Take(20)) EditorGUILayout.HelpBox(warning, MessageType.Warning);
            List<ProtocolDeepValidationIssue> deep = _deepIssues;
            foreach (ProtocolDeepValidationIssue issue in deep.Take(40))
            {
                EditorGUILayout.HelpBox((issue.EntryName ?? "Document") + ": " + issue.Message, issue.IsError ? MessageType.Error : MessageType.Warning);
            }
            if (basic.Errors.Count == 0 && basic.Warnings.Count == 0 && deep.Count == 0)
            {
                EditorGUILayout.HelpBox("基础校验与深度类型校验均通过。", MessageType.Info);
            }
        });

        DrawSection("职责边界", () =>
        {
            EditorGUILayout.HelpBox("本工具负责协议编辑、DTO/ProtocolIds/ProtocolDictionary 生成、网络配置、协议测试和弱网模拟。业务逻辑 AI 工作台在 M09-07B。", MessageType.Info);
        });
    }

    private void DrawEditTab()
    {
        if (_selectedEntry == null || _editModel == null)
        {
            EditorGUILayout.HelpBox("请先在左侧选择一个协议、Class 或 Enum。", MessageType.Info);
            return;
        }

        DrawSection("协议详情", () =>
        {
            string newName = EditorGUILayout.TextField("协议/类型名", _editModel.Name);
            if (!string.Equals(newName, _editModel.Name, StringComparison.Ordinal)) _editModel.Name = newName;
            _editModel.Kind = (ProtocolSchemaEntryKind)EditorGUILayout.EnumPopup("类型", _editModel.Kind);
            if (_editModel.Kind == ProtocolSchemaEntryKind.Message) _editModel.MessageId = EditorGUILayout.IntField("MessageID", _editModel.MessageId);
            _editModel.Comment = EditorGUILayout.TextField("中文说明", _editModel.Comment);
            _editModel.Module = EditorGUILayout.TextField("模块", _editModel.Module);
            _editModel.Status = EditorGUILayout.TextField("状态", _editModel.Status);
            _editModel.SinceVersion = EditorGUILayout.TextField("引入版本", _editModel.SinceVersion);
            _editModel.DeprecatedSince = EditorGUILayout.TextField("废弃版本", _editModel.DeprecatedSince);
        });

        if (_editModel.Kind == ProtocolSchemaEntryKind.Enum) DrawEnumEditor();
        else DrawFieldEditor();

        DrawSection("操作", () =>
        {
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("保存当前协议", GUILayout.Height(30f))) SaveCurrentEntryAndDocument();
            if (GUILayout.Button("复制 JSON", GUILayout.Height(30f))) EditorGUIUtility.systemCopyBuffer = ProtocolSchemaStructuredCodec.ToJson(_editModel);
            if (GUILayout.Button("删除当前协议", GUILayout.Height(30f))) DeleteCurrentEntry();
            EditorGUILayout.EndHorizontal();
        });
    }

    private void DrawFieldEditor()
    {
        DrawSection("字段表格", () =>
        {
            List<string> typeOptions = _typeOptions;
            _fieldScroll = EditorGUILayout.BeginScrollView(_fieldScroll, GUILayout.Height(360f));
            for (int i = 0; i < _editModel.Fields.Count; i++)
            {
                ProtocolSchemaField field = _editModel.Fields[i];
                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.BeginHorizontal();
                GUILayout.Label("字段 " + (i + 1), EditorStyles.boldLabel, GUILayout.Width(70f));
                if (GUILayout.Button("上移", GUILayout.Width(52f)) && i > 0) SwapFields(i, i - 1);
                if (GUILayout.Button("下移", GUILayout.Width(52f)) && i < _editModel.Fields.Count - 1) SwapFields(i, i + 1);
                if (GUILayout.Button("删除", GUILayout.Width(52f))) { _editModel.Fields.RemoveAt(i); i--; EditorGUILayout.EndHorizontal(); EditorGUILayout.EndVertical(); continue; }
                GUILayout.FlexibleSpace();
                EditorGUILayout.EndHorizontal();
                field.Name = EditorGUILayout.TextField("字段名", field.Name);
                int typeIndex = Mathf.Max(0, typeOptions.IndexOf(field.Type));
                typeIndex = EditorGUILayout.Popup("字段类型", typeIndex, typeOptions.ToArray());
                field.Type = typeOptions.Count > 0 ? typeOptions[typeIndex] : field.Type;
                field.Comment = EditorGUILayout.TextField("中文说明", field.Comment);
                field.DefaultValue = EditorGUILayout.TextField("默认值", field.DefaultValue);
                field.Required = EditorGUILayout.ToggleLeft("必填", field.Required);
                field.Deprecated = EditorGUILayout.ToggleLeft("已废弃", field.Deprecated);
                field.FieldId = EditorGUILayout.IntField("FieldId", field.FieldId);
                field.SinceVersion = EditorGUILayout.TextField("引入版本", field.SinceVersion);
                field.Tags = EditorGUILayout.TextField("标签", field.Tags);
                field.Migration = EditorGUILayout.TextField("迁移说明", field.Migration);
                EditorGUILayout.EndVertical();
            }
            EditorGUILayout.EndScrollView();
            if (GUILayout.Button("添加字段", GUILayout.Height(28f))) _editModel.Fields.Add(new ProtocolSchemaField { Name = "NewField", Type = "string", Comment = "新字段" });
        });
    }

    private void DrawEnumEditor()
    {
        DrawSection("枚举值", () =>
        {
            for (int i = 0; i < _editModel.EnumValues.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                _editModel.EnumValues[i] = EditorGUILayout.TextField("Value " + i, _editModel.EnumValues[i]);
                if (GUILayout.Button("删除", GUILayout.Width(60f))) { _editModel.EnumValues.RemoveAt(i); i--; }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("添加枚举值", GUILayout.Height(28f))) _editModel.EnumValues.Add("NewValue");
        });
    }

    private void DrawExportTab()
    {
        DrawSection("正式协议产物", () =>
        {
            EditorGUILayout.HelpBox("正式客户端 DTO、ProtocolIds、ProtocolDictionary、兼容性报告等仍由 tools/protocols/Generate-ProtocolArtifacts.ps1 生成。", MessageType.Info);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("生成正式产物", GUILayout.Height(32f))) RunGenerate();
            if (GUILayout.Button("校验正式产物", GUILayout.Height(32f))) RunValidate();
            if (GUILayout.Button("打开生成目录", GUILayout.Height(32f))) EditorUtility.RevealInFinder(_service.GetArtifactPaths().GeneratedRoot);
            EditorGUILayout.EndHorizontal();
        });

        DrawSection("多语言/子集导出", () =>
        {
            _exportRoot = EditorGUILayout.TextField("导出目录", _exportRoot);
            _exportLanguages = (ProtocolExportLanguage)EditorGUILayout.EnumFlagsField("导出语言", _exportLanguages);
            _exportOptions.CSharpNamespace = EditorGUILayout.TextField("C# Namespace", _exportOptions.CSharpNamespace);
            _exportOptions.TypeScriptPackageName = EditorGUILayout.TextField("TypeScript Package", _exportOptions.TypeScriptPackageName);
            _exportOptions.JavaPackageName = EditorGUILayout.TextField("Java Package", _exportOptions.JavaPackageName);
            _exportOptions.KotlinPackageName = EditorGUILayout.TextField("Kotlin Package", _exportOptions.KotlinPackageName);
            _exportOptions.GoPackageName = EditorGUILayout.TextField("Go Package", _exportOptions.GoPackageName);
            _exportOptions.GenerateManifest = EditorGUILayout.ToggleLeft("生成 Manifest", _exportOptions.GenerateManifest);
            EditorGUILayout.LabelField("导出选择数量", _selectedForExport.Count == 0 ? "0（将导出全部）" : _selectedForExport.Count.ToString());
            if (GUILayout.Button("导出选中/全部协议", GUILayout.Height(32f))) RunManualExport();
        });
    }

    private void DrawProtocolTestTab()
    {
        DrawSection("前端协议测试模拟", () =>
        {
            if (_selectedEntry == null)
            {
                EditorGUILayout.HelpBox("请先在左侧选择协议。", MessageType.Info);
                return;
            }

            EditorGUILayout.LabelField("当前协议", _selectedEntry.Name + "  #" + _selectedEntry.MessageId);
            _testRequestJson = EditorGUILayout.TextArea(_testRequestJson, GUILayout.MinHeight(140f));
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("生成 Mock 请求", GUILayout.Height(30f))) _testRequestJson = BuildMockJson(_selectedEntry);
            if (GUILayout.Button("本地校验请求", GUILayout.Height(30f))) ValidateTestPayload();
            if (GUILayout.Button("模拟发送", GUILayout.Height(30f))) SimulateSend();
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.TextArea(_testResult, GUILayout.MinHeight(160f));
        });
    }

    private void DrawNetworkConfigTab()
    {
        DrawSection("网络通信配置", () =>
        {
            EditorGUILayout.HelpBox("该配置保存到 Resources/Protocol/ProtocolNetworkSettings.asset，运行时可通过 ProtocolNetworkSettingsRuntime.LoadDefault() 读取并应用到 NetworkManager。", MessageType.Info);
            if (_networkSettings == null)
            {
                if (GUILayout.Button("创建网络配置资产")) LoadOrCreateNetworkSettings();
                return;
            }

            if (_networkSerializedObject == null) _networkSerializedObject = new SerializedObject(_networkSettings);
            _networkSerializedObject.Update();
            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("项目身份配置", EditorStyles.boldLabel);
            DrawProperty("ProjectId", "ProjectId");
            DrawProperty("GameId", "GameId");
            DrawProperty("CredentialLocalVersion", "本地版本戳");
            DrawProperty("CredentialRemoteVersion", "内网版本戳");
            DrawProperty("CredentialLastSyncAtUtc", "最后同步时间(UTC)");
            string gmBaseUrl = EditorPrefs.GetString("GMOps.BaseUrl", "http://127.0.0.1:5000");
            string gmToken = EditorPrefs.GetString("GMOps.CiToken", string.Empty);
            string newBaseUrl = EditorGUILayout.TextField("内网接口地址", gmBaseUrl);
            string newToken = EditorGUILayout.TextField("内网同步Token", gmToken);
            if (!string.Equals(newBaseUrl, gmBaseUrl, StringComparison.Ordinal)) EditorPrefs.SetString("GMOps.BaseUrl", newBaseUrl);
            if (!string.Equals(newToken, gmToken, StringComparison.Ordinal)) EditorPrefs.SetString("GMOps.CiToken", newToken);
            string plain = string.Empty;
            try { plain = ProtocolCredentialCrypto.Decrypt(_networkSettings.EncryptedGameKey, _networkSettings.ProjectId); } catch { plain = string.Empty; }
            string masked = ProtocolCredentialCrypto.Mask(plain);
            EditorGUILayout.LabelField("GameKey(掩码)", string.IsNullOrEmpty(masked) ? "未配置" : masked);
            _showCredentialPlainText = EditorGUILayout.ToggleLeft("临时显示明文（本次会话）", _showCredentialPlainText);
            _credentialPlainInput = EditorGUILayout.TextField("GameKey输入", _showCredentialPlainText ? plain : _credentialPlainInput);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("写入本地加密", GUILayout.Height(24f)))
            {
                string input = string.IsNullOrEmpty(_credentialPlainInput) ? plain : _credentialPlainInput;
                _networkSettings.EncryptedGameKey = ProtocolCredentialCrypto.Encrypt(input, _networkSettings.ProjectId);
                _networkSettings.CredentialLocalVersion = DateTime.UtcNow.Ticks.ToString();
                _networkSettings.CredentialLastSyncAtUtc = DateTime.UtcNow.ToString("O");
                EditorUtility.SetDirty(_networkSettings);
                AddLog("已写入本地加密凭据。");
            }
            if (GUILayout.Button("从内网拉取", GUILayout.Height(24f))) PullCredentialsFromIntranet();
            if (GUILayout.Button("推送到内网", GUILayout.Height(24f))) PushCredentialsToIntranet();
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.Space(6f);

            DrawProperty("TransportKind", "通信方式");
            DrawProperty("PayloadEncoding", "序列化协议");
            DrawProperty("CommunicationMode", "通信模式");
            DrawProperty("CustomSerializerName", "自定义序列化器");
            DrawProperty("EndpointUrl", "默认地址");
            DrawProperty("ActiveEnvironmentId", "当前环境");
            DrawProperty("EnableRollingServerMode", "是否滚服模式");
            DrawProperty("SingleServerId", "单服ServerId");
            DrawProperty("EnvironmentPresets", "环境列表", true);
            DrawProperty("ConnectTimeoutMs", "连接超时(ms)");
            DrawProperty("RequestTimeoutMs", "请求超时(ms)");
            DrawProperty("HeartbeatIntervalMs", "心跳间隔(ms)");
            DrawProperty("HeartbeatTimeoutMs", "心跳超时(ms)");
            DrawProperty("MaxReconnectAttempts", "最大重连次数");
            DrawProperty("ReconnectBaseDelayMs", "重连基础延迟(ms)");
            DrawProperty("EnableReliableDelivery", "可靠投递");
            DrawProperty("AckTimeoutMs", "Ack 超时(ms)");
            DrawProperty("MaxRetryCount", "最大重试次数");
            DrawProperty("EnableCompression", "启用压缩");
            DrawProperty("EnableEncryption", "启用加密");
            DrawProperty("ClientFrameRate", "客户端帧率");
            DrawProperty("SnapshotIntervalMs", "快照间隔(ms)");
            _networkSerializedObject.ApplyModifiedProperties();
            EditorGUILayout.HelpBox(ProtocolNetworkSettingsRuntime.BuildTransportCapabilityMatrix(), MessageType.Info);
            if (GUILayout.Button("保存网络配置", GUILayout.Height(30f))) SaveNetworkSettings();
        });
    }

    private void DrawNetworkSimulationTab()
    {
        DrawSection("弱网模拟参数", () =>
        {
            if (_networkSettings == null)
            {
                EditorGUILayout.HelpBox("请先创建网络配置资产。", MessageType.Warning);
                return;
            }

            if (_networkSerializedObject == null) _networkSerializedObject = new SerializedObject(_networkSettings);
            _networkSerializedObject.Update();
            DrawProperty("EnableSimulation", "启用弱网模拟");
            DrawProperty("SimulatedLatencyMs", "基础延迟(ms)");
            DrawProperty("SimulatedJitterMs", "延迟抖动(ms)");
            DrawProperty("SimulatedPacketLossPercent", "丢包率(%)");
            DrawProperty("SimulatedDuplicatePercent", "重复包率(%)");
            DrawProperty("SimulatedReorderPercent", "乱序率(%)");
            DrawProperty("SimulatedBandwidthKbps", "带宽限制(Kbps)");
            DrawProperty("SimulatedDisconnectAfterSeconds", "断线时间(s)");
            DrawProperty("SimulationSeed", "随机种子");
            _networkSerializedObject.ApplyModifiedProperties();
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("保存模拟配置", GUILayout.Height(30f))) SaveNetworkSettings();
            if (GUILayout.Button("生成模拟报告", GUILayout.Height(30f))) _testResult = ProtocolGovernanceAndTestService.BuildNetworkSimulationReport(_networkSettings, 100, 2048);
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.TextArea(_testResult, GUILayout.MinHeight(140f));
        });
    }

    private void ReloadDocument()
    {
        _document = ProtocolSchemaDocument.Load(_service.GetArtifactPaths().SourceSchemaPath);
        RebuildProtocolCaches();
        if (_document.Entries.Count > 0)
        {
            ProtocolSchemaEntry next = _selectedEntry != null ? _document.Find(_selectedEntry.Name) : null;
            SelectEntry(next ?? _document.Entries.FirstOrDefault(entry => entry.Kind == ProtocolSchemaEntryKind.Message) ?? _document.Entries[0]);
        }
        AddLog("已加载协议：" + _document.Entries.Count + " 条。");
    }

    private void SelectEntry(ProtocolSchemaEntry entry)
    {
        _selectedEntry = entry;
        _editModel = GetModel(entry);
    }

    private void AddNewEntry(ProtocolSchemaEntryKind kind, int nextId)
    {
        if (_document == null) return;
        string safeName = string.IsNullOrWhiteSpace(_newProtocolName) ? "NewProtocol_c2s" : _newProtocolName.Trim();
        if (kind == ProtocolSchemaEntryKind.Message && !safeName.EndsWith("_c2s", StringComparison.Ordinal) && !safeName.EndsWith("_s2c", StringComparison.Ordinal))
        {
            safeName += _newProtocolIsS2c ? "_s2c" : "_c2s";
        }

        if (_document.Find(safeName) != null)
        {
            EditorUtility.DisplayDialog("新增失败", "协议名已存在：" + safeName, "OK");
            return;
        }

        ProtocolSchemaEntry entry = ProtocolSchemaDocument.CreateTemplate(safeName, kind, nextId);
        _document.Add(entry);
        RebuildProtocolCaches();
        SelectEntry(entry);
        AddLog("已新增：" + safeName);
    }

    private void SaveCurrentEntryAndDocument()
    {
        if (_document == null || _selectedEntry == null || _editModel == null) return;
        string oldName = _selectedEntry.Name;
        var replacement = new ProtocolSchemaEntry
        {
            Name = _editModel.Name,
            Kind = _editModel.Kind,
            MessageId = _editModel.MessageId,
            Json = ProtocolSchemaStructuredCodec.ToJson(_editModel)
        };
        ProtocolSchemaValidationResult validation = _document.ValidateRawEntry(replacement.Name, replacement.Json);
        if (!validation.IsValid)
        {
            EditorUtility.DisplayDialog("保存失败", string.Join("\n", validation.Errors), "OK");
            return;
        }

        _document.Replace(oldName, replacement);
        _document.Save();
        AssetDatabase.Refresh();
        RebuildProtocolCaches();
        SelectEntry(_document.Find(replacement.Name));
        AddLog("已保存协议源：" + replacement.Name);
    }

    private void DeleteCurrentEntry()
    {
        if (_document == null || _selectedEntry == null) return;
        if (!EditorUtility.DisplayDialog("删除确认", "确定删除 " + _selectedEntry.Name + " 吗？", "删除", "取消")) return;
        string oldName = _selectedEntry.Name;
        _document.Remove(oldName);
        _document.Save();
        _selectedEntry = null;
        _editModel = null;
        ReloadDocument();
        AddLog("已删除：" + oldName);
    }

    private void RunGenerate()
    {
        RunWithProgress("生成协议产物", "正在执行协议生成脚本...", () =>
        {
            bool ok = _service.GenerateAll(out string output);
            AssetDatabase.Refresh();
            AddLog((ok ? "[通过] " : "[失败] ") + output);
        });
    }

    private void RunValidate()
    {
        RunWithProgress("校验协议产物", "正在执行协议校验脚本...", () =>
        {
            bool ok = _service.Validate(out string output);
            AddLog((ok ? "[通过] " : "[失败] ") + output);
        });
    }

    private void RunManualExport()
    {
        RunWithProgress("导出协议", "正在导出选中协议到多语言文件...", () =>
        {
            IEnumerable<ProtocolSchemaEntry> entries = _selectedForExport.Count == 0 ? _document.Entries : _document.Entries.Where(entry => _selectedForExport.Contains(entry.Name));
            string absoluteRoot = Path.IsPathRooted(_exportRoot) ? _exportRoot : Path.GetFullPath(Path.Combine(RepoRoot, _exportRoot));
            ProtocolExportResult result = ProtocolMultiLanguageExporter.Export(_document, entries, _exportLanguages, absoluteRoot, _exportOptions);
            AssetDatabase.Refresh();
            AddLog(result.Success
                ? "导出成功：" + result.Files.Count + " 个文件 -> " + absoluteRoot
                : "导出失败：" + string.Join("\n", result.Errors));
        });
    }

    private void ValidateTestPayload()
    {
        bool ok = ProtocolJson.TryParse(_testRequestJson, out _, out string error);
        _testResult = ok ? "请求 JSON 格式正确。" : "请求 JSON 格式错误：" + error;
        AddLog(_testResult);
    }

    private void SimulateSend()
    {
        if (_selectedEntry == null)
        {
            _testResult = "请先选择协议。";
            return;
        }

        bool jsonOk = ProtocolJson.TryParse(_testRequestJson, out _, out string error);
        if (!jsonOk)
        {
            _testResult = "请求 JSON 格式错误：" + error;
            return;
        }

        string endpoint = _networkSettings != null ? ProtocolNetworkSettingsRuntime.ResolveEndpoint(_networkSettings) : "未配置";
        int latency = _networkSettings != null && _networkSettings.EnableSimulation ? _networkSettings.SimulatedLatencyMs : 0;
        _testResult = "模拟发送完成\n协议：" + _selectedEntry.Name + "\nMessageID：" + _selectedEntry.MessageId + "\nEndpoint：" + endpoint + "\n模拟延迟：" + latency + "ms\n说明：当前为编辑器侧模拟，不直接连接真实服务器。";
        AddLog("已模拟发送：" + _selectedEntry.Name);
    }

    private string BuildMockJson(ProtocolSchemaEntry entry)
    {
        ProtocolStructuredEntry model = GetModel(entry);
        var root = new ProtocolJsonObject();
        foreach (ProtocolSchemaField field in model.Fields)
        {
            root.Properties[field.Name] = BuildMockValue(field.Type);
        }
        return root.ToJson(0);
    }

    private ProtocolJsonValue BuildMockValue(string type)
    {
        string name = ProtocolTypeReference.Parse(type).Name.ToLowerInvariant();
        if (name == "int" || name == "int32" || name == "short" || name == "byte") return new ProtocolJsonNumber("1");
        if (name == "long" || name == "int64") return new ProtocolJsonNumber("1001");
        if (name == "float" || name == "double") return new ProtocolJsonNumber("1.0");
        if (name == "bool" || name == "boolean") return new ProtocolJsonBoolean(true);
        return new ProtocolJsonString("mock");
    }

    private void LoadOrCreateNetworkSettings()
    {
        _networkSettings = AssetDatabase.LoadAssetAtPath<ProtocolNetworkSettings>(NetworkSettingsAssetPath);
        if (_networkSettings == null)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(NetworkSettingsAssetPath) ?? string.Empty);
            _networkSettings = CreateInstance<ProtocolNetworkSettings>();
            AssetDatabase.CreateAsset(_networkSettings, NetworkSettingsAssetPath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }
        _networkSerializedObject = new SerializedObject(_networkSettings);
    }

    private void SaveNetworkSettings()
    {
        if (_networkSettings == null) return;
        EditorUtility.SetDirty(_networkSettings);
        AssetDatabase.SaveAssets();
        AddLog("已保存网络配置：" + NetworkSettingsAssetPath);
    }

    private void PullCredentialsFromIntranet()
    {
        if (_networkSettings == null) return;
        if (string.IsNullOrWhiteSpace(_networkSettings.ProjectId))
        {
            EditorUtility.DisplayDialog("提示", "请先填写 ProjectId。", "确定");
            return;
        }

        string baseUrl = EditorPrefs.GetString("GMOps.BaseUrl", "http://127.0.0.1:5000").TrimEnd('/');
        string token = EditorPrefs.GetString("GMOps.CiToken", string.Empty);
        string url = baseUrl + "/api/gm-ops/projects/credentials/sync-token?project_id=" + Uri.EscapeDataString(_networkSettings.ProjectId) + "&ci_token=" + Uri.EscapeDataString(token);
        using (var client = new HttpClient())
        {
            try
            {
                string json = client.GetStringAsync(url).GetAwaiter().GetResult();
                var data = JsonUtility.FromJson<CredentialSyncPullResponse>(json);
                if (data == null || !data.ok || data.data == null)
                {
                    AddLog("拉取凭据失败：" + json);
                    return;
                }

                _networkSettings.GameId = data.data.game_id ?? string.Empty;
                string plainKey = data.data.game_key ?? string.Empty;
                _networkSettings.EncryptedGameKey = ProtocolCredentialCrypto.Encrypt(plainKey, _networkSettings.ProjectId);
                _networkSettings.CredentialRemoteVersion = data.data.remote_version ?? string.Empty;
                _networkSettings.CredentialLocalVersion = DateTime.UtcNow.Ticks.ToString();
                _networkSettings.CredentialLastSyncAtUtc = DateTime.UtcNow.ToString("O");
                EditorUtility.SetDirty(_networkSettings);
                AssetDatabase.SaveAssets();
                AddLog("已从内网拉取并加密保存 gameId/gameKey。");
            }
            catch (Exception ex)
            {
                AddLog("拉取凭据异常：" + ex.Message);
            }
        }
    }

    private void PushCredentialsToIntranet()
    {
        if (_networkSettings == null) return;
        if (string.IsNullOrWhiteSpace(_networkSettings.ProjectId))
        {
            EditorUtility.DisplayDialog("提示", "请先填写 ProjectId。", "确定");
            return;
        }

        string plainKey = string.Empty;
        try { plainKey = ProtocolCredentialCrypto.Decrypt(_networkSettings.EncryptedGameKey, _networkSettings.ProjectId); } catch { plainKey = string.Empty; }
        if (string.IsNullOrWhiteSpace(_networkSettings.GameId) || string.IsNullOrWhiteSpace(plainKey))
        {
            EditorUtility.DisplayDialog("提示", "请先配置 GameId 和 GameKey。", "确定");
            return;
        }

        string baseUrl = EditorPrefs.GetString("GMOps.BaseUrl", "http://127.0.0.1:5000").TrimEnd('/');
        string token = EditorPrefs.GetString("GMOps.CiToken", string.Empty);
        string url = baseUrl + "/api/gm-ops/projects/credentials/sync-token?ci_token=" + Uri.EscapeDataString(token);
        var req = new CredentialSyncPushRequest
        {
            project_id = _networkSettings.ProjectId,
            mode = "push",
            game_id = _networkSettings.GameId,
            game_key = plainKey,
            local_version = _networkSettings.CredentialLocalVersion,
        };
        using (var client = new HttpClient())
        {
            try
            {
                string body = JsonUtility.ToJson(req);
                var response = client.PostAsync(url, new StringContent(body, Encoding.UTF8, "application/json")).GetAwaiter().GetResult();
                string json = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                var data = JsonUtility.FromJson<CredentialSyncPushResponse>(json);
                if (data != null && data.ok)
                {
                    _networkSettings.CredentialRemoteVersion = data.remote_version ?? _networkSettings.CredentialRemoteVersion;
                    _networkSettings.CredentialLastSyncAtUtc = DateTime.UtcNow.ToString("O");
                    EditorUtility.SetDirty(_networkSettings);
                    AssetDatabase.SaveAssets();
                    AddLog("已推送凭据到内网。");
                }
                else
                {
                    AddLog("推送凭据失败：" + json);
                }
            }
            catch (Exception ex)
            {
                AddLog("推送凭据异常：" + ex.Message);
            }
        }
    }

    [Serializable]
    private sealed class CredentialSyncPullResponse
    {
        public bool ok;
        public CredentialSyncData data;
    }

    [Serializable]
    private sealed class CredentialSyncData
    {
        public string project_id;
        public string game_id;
        public string game_key;
        public string remote_version;
    }

    [Serializable]
    private sealed class CredentialSyncPushRequest
    {
        public string project_id;
        public string mode;
        public string game_id;
        public string game_key;
        public string local_version;
    }

    [Serializable]
    private sealed class CredentialSyncPushResponse
    {
        public bool ok;
        public string remote_version;
    }

    private void DrawProperty(string propertyName, string displayName, bool includeChildren = false)
    {
        SerializedProperty property = _networkSerializedObject.FindProperty(propertyName);
        if (property == null)
        {
            EditorGUILayout.HelpBox("找不到配置字段：" + propertyName, MessageType.Warning);
            return;
        }
        EditorGUILayout.PropertyField(property, new GUIContent(displayName), includeChildren);
    }

    private void RebuildProtocolCaches()
    {
        _modelCache.Clear();
        _moduleCache.Clear();
        _moduleFoldouts.Clear();
        if (_document == null)
        {
            _summary = null;
            _basicValidation = null;
            _deepIssues = new List<ProtocolDeepValidationIssue>();
            _moduleOptions = new[] { "全部" };
            _visibleEntries.Clear();
            return;
        }

        foreach (ProtocolSchemaEntry entry in _document.Entries)
        {
            ProtocolStructuredEntry model = ProtocolSchemaStructuredCodec.FromEntry(entry);
            _modelCache[entry.Name] = model;
            _moduleCache[entry.Name] = InferModule(entry, model);
        }

        _summary = BuildSummary(_document);
        _basicValidation = _document.Validate();
        _deepIssues = ProtocolSchemaStructuredCodec.ValidateDeep(_document);
        _typeOptions = ProtocolSchemaStructuredCodec.GetTypeOptions(_document);
        _moduleOptions = new[] { "全部" }.Concat(_moduleCache.Values.Distinct(StringComparer.Ordinal).OrderBy(value => value, StringComparer.Ordinal)).ToArray();
        _lastSearch = null;
        RefreshVisibleEntriesIfNeeded();
    }

    private void RefreshVisibleEntriesIfNeeded()
    {
        if (_document == null)
        {
            _visibleEntries.Clear();
            return;
        }

        string search = (_search ?? string.Empty).Trim();
        if (string.Equals(search, _lastSearch, StringComparison.Ordinal)
            && string.Equals(_moduleFilter, _lastModuleFilter, StringComparison.Ordinal)
            && _kindFilter == _lastKindFilter)
        {
            return;
        }

        _visibleEntries.Clear();
        _visibleEntries.AddRange(GetFilteredEntries());
        _lastSearch = search;
        _lastModuleFilter = _moduleFilter;
        _lastKindFilter = _kindFilter;
    }

    private ProtocolStructuredEntry GetModel(ProtocolSchemaEntry entry)
    {
        if (entry == null) return new ProtocolStructuredEntry();
        if (_modelCache.TryGetValue(entry.Name, out ProtocolStructuredEntry model)) return model;
        model = ProtocolSchemaStructuredCodec.FromEntry(entry);
        _modelCache[entry.Name] = model;
        return model;
    }

    private static ProtocolSourceSummary BuildSummary(ProtocolSchemaDocument document)
    {
        var names = document.Entries.Select(entry => entry.Name ?? string.Empty).ToArray();
        var requestBases = new HashSet<string>(names.Where(name => name.EndsWith("_c2s", StringComparison.Ordinal)).Select(name => name.Substring(0, name.Length - 4)), StringComparer.Ordinal);
        return new ProtocolSourceSummary
        {
            SourcePath = document.SourcePath,
            SourceExists = File.Exists(document.SourcePath),
            TotalDefinitions = document.Entries.Count,
            MessageCount = document.Entries.Count(entry => entry.Kind == ProtocolSchemaEntryKind.Message),
            RequestCount = requestBases.Count,
            ResponseCount = names.Count(name => name.EndsWith("_s2c", StringComparison.Ordinal) && requestBases.Contains(name.Substring(0, name.Length - 4))),
            PushCount = names.Count(name => name.EndsWith("_s2c", StringComparison.Ordinal) && !requestBases.Contains(name.Substring(0, name.Length - 4))),
            CustomClassCount = document.Entries.Count(entry => entry.Kind == ProtocolSchemaEntryKind.Class),
            EnumCount = document.Entries.Count(entry => entry.Kind == ProtocolSchemaEntryKind.Enum),
            DuplicateIdCount = document.Entries.Where(entry => entry.Kind == ProtocolSchemaEntryKind.Message && entry.MessageId > 0).GroupBy(entry => entry.MessageId).Count(group => group.Count() > 1)
        };
    }

    private static string InferModule(ProtocolSchemaEntry entry, ProtocolStructuredEntry model)
    {
        if (!string.IsNullOrWhiteSpace(model?.Module)) return model.Module;
        string name = entry?.Name ?? string.Empty;
        if (name.EndsWith("_c2s", StringComparison.Ordinal) || name.EndsWith("_s2c", StringComparison.Ordinal)) name = name.Substring(0, name.Length - 4);
        int index = name.IndexOf('_');
        return index > 0 ? name.Substring(0, index) : "Common";
    }

    private IEnumerable<ProtocolSchemaEntry> GetFilteredEntries()
    {
        if (_document == null) return Enumerable.Empty<ProtocolSchemaEntry>();
        string search = (_search ?? string.Empty).Trim().ToLowerInvariant();
        return _document.Entries.Where(entry =>
        {
            if (_kindFilter != ProtocolSchemaEntryKind.All && entry.Kind != _kindFilter) return false;
            string module = GetModuleName(entry);
            if (!string.Equals(_moduleFilter, "全部", StringComparison.Ordinal) && !string.Equals(module, _moduleFilter, StringComparison.Ordinal)) return false;
            if (string.IsNullOrWhiteSpace(search)) return true;
            ProtocolStructuredEntry model = GetModel(entry);
            string haystack = (entry.Name + " " + entry.MessageId + " " + module + " " + model.Comment + " " + model.Status).ToLowerInvariant();
            return haystack.Contains(search);
        });
    }

    private string[] GetModuleOptions()
    {
        return _moduleOptions ?? new[] { "全部" };
    }

    private string GetModuleName(ProtocolSchemaEntry entry)
    {
        if (entry == null) return "Common";
        if (_moduleCache.TryGetValue(entry.Name, out string cachedModule)) return cachedModule;
        ProtocolStructuredEntry model = GetModel(entry);
        if (!string.IsNullOrWhiteSpace(model.Module)) return model.Module;
        string name = entry.Name ?? string.Empty;
        if (name.EndsWith("_c2s", StringComparison.Ordinal) || name.EndsWith("_s2c", StringComparison.Ordinal)) name = name.Substring(0, name.Length - 4);
        int index = name.IndexOf('_');
        return index > 0 ? name.Substring(0, index) : "Common";
    }

    private void SelectVisibleForExport()
    {
        RefreshVisibleEntriesIfNeeded();
        foreach (ProtocolSchemaEntry entry in _visibleEntries) _selectedForExport.Add(entry.Name);
        AddLog("已选择导出协议：" + _selectedForExport.Count);
    }

    private void SwapFields(int from, int to)
    {
        ProtocolSchemaField temp = _editModel.Fields[from];
        _editModel.Fields[from] = _editModel.Fields[to];
        _editModel.Fields[to] = temp;
    }

    private static string GetKindShort(ProtocolSchemaEntryKind kind)
    {
        switch (kind)
        {
            case ProtocolSchemaEntryKind.Message: return "MSG";
            case ProtocolSchemaEntryKind.Class: return "CLS";
            case ProtocolSchemaEntryKind.Enum: return "ENU";
            default: return "UNK";
        }
    }

    private void DrawLog()
    {
        EditorGUILayout.BeginVertical("box", GUILayout.Height(116f));
        EditorGUILayout.BeginHorizontal();
        GUILayout.Label("操作日志", EditorStyles.boldLabel);
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("复制", GUILayout.Width(70f))) EditorGUIUtility.systemCopyBuffer = _log;
        if (GUILayout.Button("清空", GUILayout.Width(70f))) _log = string.Empty;
        EditorGUILayout.EndHorizontal();
        _logScroll = EditorGUILayout.BeginScrollView(_logScroll);
        EditorGUILayout.TextArea(_log, GUILayout.ExpandHeight(true));
        EditorGUILayout.EndScrollView();
        EditorGUILayout.EndVertical();
    }

    private static void RunWithProgress(string title, string message, Action action)
    {
        try
        {
            EditorUtility.DisplayProgressBar(title, message, 0.25f);
            action?.Invoke();
            EditorUtility.DisplayProgressBar(title, "瀹屾垚", 1f);
        }
        finally
        {
            EditorUtility.ClearProgressBar();
        }
    }

    private static void DrawSection(string title, Action draw)
    {
        EditorGUILayout.BeginVertical("box");
        GUILayout.Label(title, EditorStyles.boldLabel);
        draw?.Invoke();
        EditorGUILayout.EndVertical();
        EditorGUILayout.Space(4f);
    }

    private void AddLog(string message)
    {
        _log += "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + message + "\n";
        _logScroll.y = float.MaxValue;
    }
}


