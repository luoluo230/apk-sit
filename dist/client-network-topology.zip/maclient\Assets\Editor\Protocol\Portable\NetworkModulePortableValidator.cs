using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

/// <summary>
/// 网络模块可移植验收器。
/// 用于导入到新项目后的一键完整性检查。
/// </summary>
public static class NetworkModulePortableValidator
{
    private static readonly string[] RequiredAssets =
    {
        "Assets/Src/HotUpdate/Framework/Network/NetworkManager.cs",
        "Assets/Src/HotUpdate/Framework/Network/ProtocolNetworkSettingsRuntime.cs",
        "Assets/Src/HotUpdate/Game/Network/GameNetworkClient.cs",
        "Assets/Src/HotUpdate/Game/Network/NetworkBootstrap.cs",
        "Assets/Src/HotUpdate/Game/Network/Modules/GameNetworkModules.cs",
        "Assets/Src/Protocols/protocols.json",
        "Assets/Src/Protocols/protocol-core-required-list.json",
        "Assets/Src/Protocols/protocol-business-extension-list.json",
        "Assets/Resources/Protocol/ProtocolNetworkSettings.asset",
        "Assets/Editor/Protocol/Workbench/ProtocolCodegenWorkbenchWindow.cs"
    };

    [MenuItem("Tools/MAClient/协议与网络/网络模块可移植验收", priority = 13)]
    public static void ValidatePortableReady()
    {
        var missing = new List<string>();
        foreach (string path in RequiredAssets)
        {
            if (AssetDatabase.IsValidFolder(path))
            {
                continue;
            }

            if (AssetDatabase.LoadMainAssetAtPath(path) == null)
            {
                missing.Add(path);
            }
        }

        if (missing.Count == 0)
        {
            EditorUtility.DisplayDialog(
                "验收通过",
                "网络模块关键资源完整，可直接复用到其他项目。",
                "确定");
            return;
        }

        string detail = string.Join("\n", missing);
        EditorUtility.DisplayDialog(
            "验收失败",
            "缺少以下关键资源：\n" + detail,
            "确定");
    }
}
