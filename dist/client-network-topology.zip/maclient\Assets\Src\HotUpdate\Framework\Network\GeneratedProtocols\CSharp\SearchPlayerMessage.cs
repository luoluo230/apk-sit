﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 搜索玩家(用于加好友)
/// </summary>
public class SearchPlayer_c2s
{
    /// <summary>
    /// 搜索关键字(昵称或ID)
    /// </summary>
    public string Keyword { get; set; }
}

/// <summary>
/// 搜索玩家结果
/// </summary>
public class SearchPlayer_s2c
{
    /// <summary>
    /// 符合条件的玩家列表
    /// </summary>
    public FriendInfo[] Players { get; set; }
}

