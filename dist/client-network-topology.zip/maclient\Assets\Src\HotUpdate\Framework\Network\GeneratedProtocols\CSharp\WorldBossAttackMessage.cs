﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 世界 Boss 攻击上报
/// </summary>
public class WorldBossAttack_c2s
{
    /// <summary>
    /// Boss ID
    /// </summary>
    public string BossId { get; set; }
    /// <summary>
    /// 伤害值
    /// </summary>
    public long Damage { get; set; }
}

/// <summary>
/// 世界 Boss 攻击结果
/// </summary>
public class WorldBossAttack_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// Boss 信息
    /// </summary>
    public WorldBossInfo Boss { get; set; }
}

