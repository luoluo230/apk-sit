using System;
using System.IO;
using System.Linq;

public sealed class ProtocolServerArchitectureProfile
{
    public string Summary = "No server project detected.";
    public string DbFramework = "Unknown";
    public string DbContextType = "Unknown";
    public string LoggerPattern = "Unknown";
    public string ErrorCodeType = "Unknown";
    public string TransactionPattern = "Unknown";
}

public static class ProtocolServerArchitectureScanner
{
    public static ProtocolServerArchitectureProfile Scan(string repoRoot)
    {
        var profile = new ProtocolServerArchitectureProfile();
        if (string.IsNullOrWhiteSpace(repoRoot) || !Directory.Exists(repoRoot)) return profile;

        string[] files = Directory.GetFiles(repoRoot, "*.*", SearchOption.AllDirectories)
            .Where(path => path.IndexOf("\\Library\\", StringComparison.OrdinalIgnoreCase) < 0
                && path.IndexOf("\\Temp\\", StringComparison.OrdinalIgnoreCase) < 0
                && (path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase)
                    || path.EndsWith(".ts", StringComparison.OrdinalIgnoreCase)
                    || path.EndsWith(".js", StringComparison.OrdinalIgnoreCase)
                    || path.EndsWith(".py", StringComparison.OrdinalIgnoreCase)
                    || path.EndsWith(".go", StringComparison.OrdinalIgnoreCase)))
            .Take(5000)
            .ToArray();

        string joinedNames = string.Join(" ", files.Select(Path.GetFileName));
        profile.DbFramework = Contains(joinedNames, "DbContext") ? "EntityFramework/DbContext"
            : Contains(joinedNames, "Dapper") ? "Dapper"
            : Contains(joinedNames, "Mongo") ? "Mongo"
            : Contains(joinedNames, "Redis") ? "Redis"
            : "Unknown";
        profile.LoggerPattern = Contains(joinedNames, "ILogger") ? "ILogger" : "Console/Unknown";
        profile.ErrorCodeType = Contains(joinedNames, "ErrorCode") ? "ErrorCode" : "Unknown";
        profile.TransactionPattern = Contains(joinedNames, "UnitOfWork") ? "UnitOfWork" : "Manual transaction adapter";
        profile.DbContextType = profile.DbFramework;
        profile.Summary = "Files scanned=" + files.Length + "; DB=" + profile.DbFramework + "; Logger=" + profile.LoggerPattern + "; Transaction=" + profile.TransactionPattern;
        return profile;
    }

    private static bool Contains(string value, string token)
    {
        return value.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0;
    }
}
