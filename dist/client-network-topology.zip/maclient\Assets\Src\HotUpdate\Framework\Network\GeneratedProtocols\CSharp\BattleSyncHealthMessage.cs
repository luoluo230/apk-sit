﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 上报或请求当前战斗同步健康信息
/// </summary>
public class BattleSyncHealth_c2s
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 客户端同步健康信息(可空)
    /// </summary>
    public BattleSyncHealth Health { get; set; }
    /// <summary>
    /// 客户端校验信息(可空)
    /// </summary>
    public BattleChecksumInfo Checksum { get; set; }
    /// <summary>
    /// 是否需要返回校验比对结果
    /// </summary>
    public bool NeedCompareResult { get; set; }
    /// <summary>
    /// 是否需要服务端返回健康状态
    /// </summary>
    public bool NeedServerHealth { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 战斗同步健康信息响应
/// </summary>
public class BattleSyncHealth_s2c
{
    /// <summary>
    /// 处理结果
    /// </summary>
    public BattleProtocolAck Ack { get; set; }
    /// <summary>
    /// 服务端同步健康信息
    /// </summary>
    public BattleSyncHealth ServerHealth { get; set; }
    /// <summary>
    /// 校验是否一致
    /// </summary>
    public bool Matched { get; set; }
    /// <summary>
    /// 服务端校验信息
    /// </summary>
    public BattleChecksumInfo ServerChecksum { get; set; }
    /// <summary>
    /// 是否需要重同步
    /// </summary>
    public bool NeedResync { get; set; }
    /// <summary>
    /// 建议重同步原因
    /// </summary>
    public BattleResyncReason ResyncReason { get; set; }
    /// <summary>
    /// 是否建议重同步
    /// </summary>
    public bool SuggestedResync { get; set; }
    /// <summary>
    /// 建议重同步起始帧
    /// </summary>
    public int SuggestedFromFrame { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

