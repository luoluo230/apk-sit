#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using System.Collections;
using System.Threading.Tasks;
using UnityEngine;

/// <summary>
/// 重构后网络模块全量演示（单脚本版，回调风格）。
/// 通过“回调 + 协程桥接”展示核心链路与系统业务调用。
/// </summary>
public sealed class NetworkModuleFullDemo : MonoBehaviour
{
    [Header("依赖")]
    [Tooltip("重构后的统一网络客户端（GameNetworkClient）。")]
    [SerializeField] private GameNetworkClient gameNetworkClient;

    [Header("演示账号")]
    [SerializeField] private string username = "demo_user";
    [SerializeField] private string password = "demo_pass";
    [SerializeField] private string roleNickname = "DemoRole";
    [SerializeField] private string roleAvatar = "default";
    [SerializeField] private bool createRoleAfterLogin;

    [Header("系统业务演示参数")]
    [SerializeField] private string boardType = "power";
    [SerializeField] private string chatContent = "hello network module";
    [SerializeField] private int dungeonId = 1001;
    [SerializeField] private string stageId = "stage_001";
    [SerializeField] private long friendTargetPlayerId = 10001;
    [SerializeField] private long teamTargetPlayerId = 10002;

    [Header("执行控制")]
    [SerializeField] private bool logoutWhenFinished = true;

    private void Awake()
    {
        if (gameNetworkClient == null)
        {
            gameNetworkClient = FindFirstObjectByType<GameNetworkClient>();
        }
    }

    /// <summary>
    /// 一键运行全量 Demo。
    /// </summary>
    [ContextMenu("Demo/Run Network Full Demo")]
    public void RunNetworkFullDemo()
    {
        if (!EnsureClientReady())
        {
            return;
        }

        RunCoreFlow(
            onSuccess: () => RunSystemBusinessFlow(
                onSuccess: () =>
                {
                    if (!logoutWhenFinished)
                    {
                        Logger.Log("[NetworkFullDemo] All demo flows finished.", LogLevel.Info);
                        return;
                    }

                    // 业务场景：玩家主动退出账号，清理 token 并断开连接。
                    RunTask(
                        () => gameNetworkClient.LogoutAsync(disconnect: true, clearToken: true),
                        logout =>
                        {
                            Logger.Log($"[NetworkFullDemo] Logout done. Success={logout?.Success}, HasToken={gameNetworkClient.HasToken}", LogLevel.Info);
                            Logger.Log("[NetworkFullDemo] All demo flows finished.", LogLevel.Info);
                        },
                        ex => Logger.Log("[NetworkFullDemo] Logout failed: " + ex.Message, LogLevel.Error));
                },
                onError: ex => Logger.Log("[NetworkFullDemo] System business flow failed: " + ex.Message, LogLevel.Error)),
            onError: ex => Logger.Log("[NetworkFullDemo] Core flow failed: " + ex.Message, LogLevel.Error));
    }

    /// <summary>
    /// 核心链路：登录、进服、创角(可选)、心跳、刷新 token、会话恢复。
    /// </summary>
    private void RunCoreFlow(Action onSuccess, Action<Exception> onError)
    {
        // 业务场景：账号登录，获取 token 与服务器列表。
        RunTask(
            () => gameNetworkClient.LoginAsync(username, password),
            login =>
            {
                Logger.Log($"[NetworkFullDemo][Core] Login success. LastServer={login?.LastServerId}, HasToken={gameNetworkClient.HasToken}", LogLevel.Info);

                // 业务场景：滚服模式选服；单服模式自动使用 SingleServerId。
                RunTask(
                    () => gameNetworkClient.EnsureServerEntryAsync(),
                    select =>
                    {
                        Logger.Log($"[NetworkFullDemo][Core] EnsureServerEntry success={select?.Success}, ServerId={select?.ServerId}", LogLevel.Info);

                        Action continueAfterRegister = () =>
                        {
                            // 业务场景：会话保活心跳。
                            RunTask(
                                () => gameNetworkClient.PingAsync(includeProfile: true),
                                heartbeat =>
                                {
                                    Logger.Log($"[NetworkFullDemo][Core] Heartbeat success={heartbeat?.Success}, ServerTime={heartbeat?.ServerTime}", LogLevel.Info);

                                    // 业务场景：token 临近过期刷新。
                                    RunTask(
                                        () => gameNetworkClient.RefreshTokenAsync(),
                                        refresh =>
                                        {
                                            Logger.Log($"[NetworkFullDemo][Core] RefreshToken success={refresh?.Success}, ExpireAt={refresh?.ExpireAt}", LogLevel.Info);

                                            // 业务场景：断线重连后的会话恢复。
                                            RunTask(
                                                () => gameNetworkClient.ResumeSessionAsync(includeProfile: true),
                                                resume =>
                                                {
                                                    Logger.Log($"[NetworkFullDemo][Core] SessionResume success={resume?.Success}, ServerId={resume?.ServerId}", LogLevel.Info);
                                                    onSuccess?.Invoke();
                                                },
                                                onError);
                                        },
                                        onError);
                                },
                                onError);
                        };

                        if (!createRoleAfterLogin)
                        {
                            continueAfterRegister();
                            return;
                        }

                        // 业务场景：首次进服无角色时创角。
                        RunTask(
                            () => gameNetworkClient.RegisterRoleAsync(roleNickname, roleAvatar),
                            createRole =>
                            {
                                Logger.Log($"[NetworkFullDemo][Core] RegisterRole success={createRole?.Success}", LogLevel.Info);
                                continueAfterRegister();
                            },
                            onError);
                    },
                    onError);
            },
            onError);
    }

    /// <summary>
    /// 系统业务链路：World/Social/Mail/Progression/Match/Team/GameplaySync。
    /// </summary>
    private void RunSystemBusinessFlow(Action onSuccess, Action<Exception> onError)
    {
        RunWorldDemo(
            () => RunSocialDemo(
                () => RunMailDemo(
                    () => RunProgressionDemo(
                        () => RunMatchAndBattleDemo(
                            () => RunTeamDemo(
                                () => RunGameplaySyncDemo(onSuccess, onError),
                                onError),
                            onError),
                        onError),
                    onError),
                onError),
            onError);
    }

    /// <summary>World 场景：大厅、公告、活动、排行榜。</summary>
    private void RunWorldDemo(Action onSuccess, Action<Exception> onError)
    {
        var world = gameNetworkClient.Modules.World;
        RunTask(() => world.GetLobbyInfoAsync(), lobby =>
        {
            RunTask(() => world.GetAnnouncementsAsync(), notices =>
            {
                RunTask(() => world.GetEventsAsync(), eventsResponse =>
                {
                    RunTask(() => world.GetLeaderboardAsync(boardType, 1, 20), leaderboard =>
                    {
                        Logger.Log($"[NetworkFullDemo][World] Scene={lobby?.Lobby?.CurrentScene}, Notices={notices?.Length ?? 0}, Events={eventsResponse?.Events?.Length ?? 0}, Board={leaderboard?.Leaderboard?.BoardType}", LogLevel.Info);
                        onSuccess?.Invoke();
                    }, onError);
                }, onError);
            }, onError);
        }, onError);
    }

    /// <summary>Social 场景：好友列表、聊天历史、发聊天、好友申请。</summary>
    private void RunSocialDemo(Action onSuccess, Action<Exception> onError)
    {
        var social = gameNetworkClient.Modules.Social;
        RunTask(() => social.GetFriendListAsync(), friends =>
        {
            RunTask(() => social.GetChatHistoryAsync(ChatChannel.World, 0, 0, 20), history =>
            {
                RunTask(() => social.SendChatMessageAsync(ChatChannel.World, chatContent), sendChat =>
                {
                    RunTask(() => social.ApplyFriendAsync(friendTargetPlayerId, "hi, let's play together"), applyFriend =>
                    {
                        Logger.Log($"[NetworkFullDemo][Social] Friends={friends?.Friends?.Length ?? 0}, History={history?.Chats?.Length ?? 0}, SendChat={sendChat?.Success}, ApplyFriend={applyFriend?.Success}", LogLevel.Info);
                        onSuccess?.Invoke();
                    }, onError);
                }, onError);
            }, onError);
        }, onError);
    }

    /// <summary>Mail 场景：邮件列表、读信、领取附件、删除邮件。</summary>
    private void RunMailDemo(Action onSuccess, Action<Exception> onError)
    {
        var mail = gameNetworkClient.Modules.Mail;
        RunTask(() => mail.GetMailListAsync(), list =>
        {
            long demoMailId = (list?.Mails != null && list.Mails.Length > 0) ? list.Mails[0].MailId : 0;
            if (demoMailId <= 0)
            {
                Logger.Log("[NetworkFullDemo][Mail] No mail available, skip read/claim/delete.", LogLevel.Warning);
                onSuccess?.Invoke();
                return;
            }

            RunTask(() => mail.ReadMailAsync(demoMailId), read =>
            {
                RunTask(() => mail.ClaimMailAttachmentAsync(demoMailId), claim =>
                {
                    RunTask(() => mail.DeleteMailAsync(demoMailId), delete =>
                    {
                        Logger.Log($"[NetworkFullDemo][Mail] MailId={demoMailId}, Read={read?.Success}, Claim={claim?.Success}, Delete={delete?.Success}", LogLevel.Info);
                        onSuccess?.Invoke();
                    }, onError);
                }, onError);
            }, onError);
        }, onError);
    }

    /// <summary>Progression 场景：背包、商店、任务、成就入口。</summary>
    private void RunProgressionDemo(Action onSuccess, Action<Exception> onError)
    {
        var progression = gameNetworkClient.Modules.Progression;
        RunTask(() => progression.GetInventoryAsync(true), inventory =>
        {
            RunTask(() => progression.GetShopInfoAsync(ShopType.Normal), shop =>
            {
                RunTask(() => progression.GetTaskListAsync(TaskType.Daily), tasks =>
                {
                    RunTask(() => progression.GetAchievementListAsync(), achievements =>
                    {
                        Logger.Log($"[NetworkFullDemo][Progression] Items={inventory?.Inventory?.Items?.Length ?? 0}, ShopItems={shop?.Items?.Length ?? 0}, Tasks={tasks?.Tasks?.Length ?? 0}, Achievements={achievements?.Achievements?.Length ?? 0}", LogLevel.Info);
                        onSuccess?.Invoke();
                    }, onError);
                }, onError);
            }, onError);
        }, onError);
    }

    /// <summary>Match 场景：匹配（1v1/NvN）+ 进战斗。</summary>
    private void RunMatchAndBattleDemo(Action onSuccess, Action<Exception> onError)
    {
        var match = gameNetworkClient.Modules.Match;
        RunTask(() => match.MatchAsync(dungeonId, "1v1"), matchResult =>
        {
            RunTask(() => match.EnterBattleAsync(stageId, "PVP", BattleSyncMode.ServerAuthoritative, null, "{}"), enter =>
            {
                Logger.Log($"[NetworkFullDemo][Match] Match={matchResult?.Success}, EnterBattle={enter?.Success}, BattleId={enter?.BattleId}", LogLevel.Info);
                onSuccess?.Invoke();
            }, onError);
        }, onError);
    }

    /// <summary>Team 场景：组队闭环（创建、邀请、响应、离队）。</summary>
    private void RunTeamDemo(Action onSuccess, Action<Exception> onError)
    {
        var team = gameNetworkClient.Modules.Team;
        RunTask(() => team.CreateTeamAsync(), create =>
        {
            RunTask(() => team.InviteToTeamAsync(teamTargetPlayerId), invite =>
            {
                RunTask(() => team.RespondTeamInviteAsync(invite?.Invite?.InviteId ?? string.Empty, true), respond =>
                {
                    RunTask(() => team.LeaveTeamAsync(), leave =>
                    {
                        Logger.Log($"[NetworkFullDemo][Team] Create={create?.Success}, Invite={invite?.Success}, Respond={respond?.Success}, Leave={leave?.Success}", LogLevel.Info);
                        onSuccess?.Invoke();
                    }, onError);
                }, onError);
            }, onError);
        }, onError);
    }

    /// <summary>GameplaySync 场景：资源/背包同步订阅 + 挂机进度同步。</summary>
    private void RunGameplaySyncDemo(Action onSuccess, Action<Exception> onError)
    {
        IDisposable resourceSub = null;
        IDisposable inventorySub = null;
        try
        {
            resourceSub = gameNetworkClient.GameplaySync.Session.ObserveResourceSync(_ =>
                Logger.Log("[NetworkFullDemo][GameplaySync] Resource sync arrived.", LogLevel.Info));
            inventorySub = gameNetworkClient.GameplaySync.Session.ObserveInventorySync(_ =>
                Logger.Log("[NetworkFullDemo][GameplaySync] Inventory sync arrived.", LogLevel.Info));

            RunTask(() => gameNetworkClient.GameplaySync.Idle.SyncDungeonProgressAsync(dungeonId, "{\"afk\":true,\"minutes\":30}"), idle =>
            {
                Logger.Log($"[NetworkFullDemo][GameplaySync] IdleProgress={idle?.Success}", LogLevel.Info);
                resourceSub?.Dispose();
                inventorySub?.Dispose();
                onSuccess?.Invoke();
            }, ex =>
            {
                resourceSub?.Dispose();
                inventorySub?.Dispose();
                onError?.Invoke(ex);
            });
        }
        catch (Exception ex)
        {
            resourceSub?.Dispose();
            inventorySub?.Dispose();
            onError?.Invoke(ex);
        }
    }

    /// <summary>
    /// 协程桥接：把 Task 结果转换成回调风格。
    /// </summary>
    private void RunTask<T>(Func<Task<T>> taskFactory, Action<T> onSuccess, Action<Exception> onError)
    {
        StartCoroutine(RunTaskCoroutine(taskFactory, onSuccess, onError));
    }

    /// <summary>
    /// 协程等待异步任务完成并分发回调。
    /// </summary>
    private IEnumerator RunTaskCoroutine<T>(Func<Task<T>> taskFactory, Action<T> onSuccess, Action<Exception> onError)
    {
        Task<T> task = null;
        try
        {
            task = taskFactory?.Invoke();
        }
        catch (Exception ex)
        {
            onError?.Invoke(ex);
            yield break;
        }

        if (task == null)
        {
            onError?.Invoke(new Exception("Task factory returned null."));
            yield break;
        }

        while (!task.IsCompleted)
        {
            yield return null;
        }

        if (task.IsFaulted)
        {
            onError?.Invoke(task.Exception?.InnerException ?? task.Exception ?? new Exception("Unknown task error."));
            yield break;
        }

        if (task.IsCanceled)
        {
            onError?.Invoke(new Exception("Task was canceled."));
            yield break;
        }

        onSuccess?.Invoke(task.Result);
    }

    private bool EnsureClientReady()
    {
        if (gameNetworkClient == null)
        {
            Logger.Log("[NetworkFullDemo] GameNetworkClient is null.", LogLevel.Error);
            return false;
        }

        if (!gameNetworkClient.IsReady)
        {
            Logger.Log("[NetworkFullDemo] GameNetworkClient is not ready.", LogLevel.Error);
            return false;
        }

        return true;
    }
}
#endif
