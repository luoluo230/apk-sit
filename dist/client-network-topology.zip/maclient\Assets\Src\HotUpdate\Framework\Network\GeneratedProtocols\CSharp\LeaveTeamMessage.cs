﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 离开队伍
/// </summary>
public class LeaveTeam_c2s
{
}

/// <summary>
/// 离开队伍结果
/// </summary>
public class LeaveTeam_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

