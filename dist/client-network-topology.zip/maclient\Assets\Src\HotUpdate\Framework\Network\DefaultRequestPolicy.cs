/// <summary>
/// 默认请求策略。
/// 约定响应消息 ID = 请求消息 ID + 1，并采用简单的时间差超时判断。
/// </summary>
public sealed class DefaultRequestPolicy : IRequestPolicy
{
    /// <summary>
    /// 计算响应消息 ID。
    /// </summary>
    public int GetResponseMessageId(int requestMessageId)
    {
        return requestMessageId + 1;
    }

    /// <summary>
    /// 判断请求是否超时。
    /// </summary>
    public bool IsTimedOut(float sendTime, float currentTime, float timeoutSeconds)
    {
        if (timeoutSeconds <= 0f)
        {
            return false;
        }

        return currentTime - sendTime >= timeoutSeconds;
    }
}
