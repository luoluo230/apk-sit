using System;
using System.IO;
using System.IO.Compression;
using UnityEditor;
using UnityEngine;

/// <summary>
/// Export topology or baas client network modules as standalone zip packages.
/// Base project keeps abstractions only; import zip to enable a module.
/// </summary>
public static class ClientNetworkModuleDualExporter
{
    [MenuItem("Tools/MAClient/协议与网络/导出拓扑网络模块ZIP", priority = 16)]
    public static void ExportTopologyModule()
    {
        ExportModule("topology", new[]
        {
            "Assets/Src/HotUpdate/Framework/Network",
            "Assets/Src/HotUpdate/Game/Network",
            "Assets/Editor/Protocol",
            "Assets/Src/Protocols",
            "Assets/Resources/Protocol/ProtocolNetworkSettings.asset",
            "Assets/Modules/TopologyNetwork"
        });
    }

    [MenuItem("Tools/MAClient/协议与网络/导出BaaS网络模块ZIP", priority = 17)]
    public static void ExportBaasModule()
    {
        ExportModule("baas", new[]
        {
            "Assets/Modules/BaasNetwork",
            "Assets/Src/HotUpdate/Framework/Network/Abstractions"
        });
    }

    static void ExportModule(string moduleKey, string[] roots)
    {
        string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        string outputPath = EditorUtility.SaveFilePanel(
            "导出 " + moduleKey + " 网络模块",
            projectRoot,
            "MAClient_" + moduleKey + "_network_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".zip",
            "zip");
        if (string.IsNullOrWhiteSpace(outputPath)) return;

        string tempRoot = Path.Combine(Path.GetTempPath(), "maclient_cn_export_" + Guid.NewGuid().ToString("N"));
        string bundleRoot = Path.Combine(tempRoot, moduleKey + "_client_network");
        try
        {
            Directory.CreateDirectory(bundleRoot);
            foreach (var rel in roots)
            {
                string source = Path.Combine(projectRoot, rel.Replace('/', Path.DirectorySeparatorChar));
                if (!Directory.Exists(source) && !File.Exists(source))
                {
                    Debug.LogWarning("[ClientNetworkModuleDualExporter] skip missing: " + rel);
                    continue;
                }
                string dest = Path.Combine(bundleRoot, rel.Replace('/', Path.DirectorySeparatorChar));
                if (Directory.Exists(source)) CopyDirectory(source, dest);
                else
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(dest) ?? bundleRoot);
                    File.Copy(source, dest, true);
                    if (File.Exists(source + ".meta")) File.Copy(source + ".meta", dest + ".meta", true);
                }
            }
            File.WriteAllText(
                Path.Combine(bundleRoot, "README_IMPORT.txt"),
                "Import via apk-site scripts/Import-ClientNetworkModule.ps1 -Module " + moduleKey + " -SourceDir <unzipped>\r\n");
            if (File.Exists(outputPath)) File.Delete(outputPath);
            ZipFile.CreateFromDirectory(bundleRoot, outputPath);
            EditorUtility.RevealInFinder(outputPath);
            Debug.Log("[ClientNetworkModuleDualExporter] exported " + outputPath);
        }
        catch (Exception ex)
        {
            Debug.LogError("[ClientNetworkModuleDualExporter] " + ex);
            EditorUtility.DisplayDialog("导出失败", ex.Message, "确定");
        }
        finally
        {
            try { if (Directory.Exists(tempRoot)) Directory.Delete(tempRoot, true); } catch { }
        }
    }

    static void CopyDirectory(string sourceDir, string destDir)
    {
        Directory.CreateDirectory(destDir);
        foreach (var file in Directory.GetFiles(sourceDir))
            File.Copy(file, Path.Combine(destDir, Path.GetFileName(file)), true);
        foreach (var dir in Directory.GetDirectories(sourceDir))
            CopyDirectory(dir, Path.Combine(destDir, Path.GetFileName(dir)));
    }
}
