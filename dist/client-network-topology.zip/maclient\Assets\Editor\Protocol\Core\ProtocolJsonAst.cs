using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

/// <summary>
/// Small JSON AST used by the editor tools.
/// It intentionally avoids third-party dependencies so the protocol tools compile in a fresh Unity project.
/// </summary>
public abstract class ProtocolJsonValue
{
    public abstract string ToJson(int indent = 0);
}

public sealed class ProtocolJsonObject : ProtocolJsonValue
{
    public readonly Dictionary<string, ProtocolJsonValue> Properties = new Dictionary<string, ProtocolJsonValue>(StringComparer.Ordinal);

    public ProtocolJsonValue Get(string key)
    {
        return key != null && Properties.TryGetValue(key, out ProtocolJsonValue value) ? value : null;
    }

    public string GetString(string key, string fallback = "")
    {
        return Get(key) is ProtocolJsonString value ? value.Value : fallback;
    }

    public int GetInt(string key, int fallback = 0)
    {
        if (Get(key) is ProtocolJsonNumber number && int.TryParse(number.Raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out int parsed))
        {
            return parsed;
        }

        return fallback;
    }

    public bool GetBool(string key, bool fallback = false)
    {
        return Get(key) is ProtocolJsonBoolean value ? value.Value : fallback;
    }

    public ProtocolJsonObject GetObject(string key)
    {
        return Get(key) as ProtocolJsonObject;
    }

    public ProtocolJsonArray GetArray(string key)
    {
        return Get(key) as ProtocolJsonArray;
    }

    public override string ToJson(int indent = 0)
    {
        var builder = new StringBuilder();
        string pad = new string(' ', indent);
        string childPad = new string(' ', indent + 4);
        builder.AppendLine("{");
        int index = 0;
        foreach (KeyValuePair<string, ProtocolJsonValue> pair in Properties)
        {
            builder.Append(childPad).Append('"').Append(ProtocolJson.Escape(pair.Key)).Append("\": ");
            builder.Append(pair.Value == null ? "null" : pair.Value.ToJson(indent + 4));
            if (++index < Properties.Count)
            {
                builder.Append(',');
            }

            builder.AppendLine();
        }

        builder.Append(pad).Append('}');
        return builder.ToString();
    }
}

public sealed class ProtocolJsonArray : ProtocolJsonValue
{
    public readonly List<ProtocolJsonValue> Items = new List<ProtocolJsonValue>();

    public override string ToJson(int indent = 0)
    {
        var builder = new StringBuilder();
        string pad = new string(' ', indent);
        string childPad = new string(' ', indent + 4);
        builder.AppendLine("[");
        for (int i = 0; i < Items.Count; i++)
        {
            builder.Append(childPad).Append(Items[i] == null ? "null" : Items[i].ToJson(indent + 4));
            if (i < Items.Count - 1)
            {
                builder.Append(',');
            }

            builder.AppendLine();
        }

        builder.Append(pad).Append(']');
        return builder.ToString();
    }
}

public sealed class ProtocolJsonString : ProtocolJsonValue
{
    public ProtocolJsonString(string value) { Value = value ?? string.Empty; }
    public string Value { get; }
    public override string ToJson(int indent = 0) { return "\"" + ProtocolJson.Escape(Value) + "\""; }
}

public sealed class ProtocolJsonNumber : ProtocolJsonValue
{
    public ProtocolJsonNumber(string raw) { Raw = string.IsNullOrWhiteSpace(raw) ? "0" : raw; }
    public string Raw { get; }
    public override string ToJson(int indent = 0) { return Raw; }
}

public sealed class ProtocolJsonBoolean : ProtocolJsonValue
{
    public ProtocolJsonBoolean(bool value) { Value = value; }
    public bool Value { get; }
    public override string ToJson(int indent = 0) { return Value ? "true" : "false"; }
}

public sealed class ProtocolJsonNull : ProtocolJsonValue
{
    public override string ToJson(int indent = 0) { return "null"; }
}

public static class ProtocolJson
{
    public static bool TryParse(string json, out ProtocolJsonValue value, out string error)
    {
        value = null;
        error = string.Empty;
        try
        {
            var parser = new Parser(json ?? string.Empty);
            value = parser.Parse();
            return true;
        }
        catch (Exception exception)
        {
            error = exception.Message;
            return false;
        }
    }

    public static string Escape(string value)
    {
        if (string.IsNullOrEmpty(value)) return string.Empty;
        var builder = new StringBuilder(value.Length + 8);
        foreach (char c in value)
        {
            switch (c)
            {
                case '\\': builder.Append("\\\\"); break;
                case '"': builder.Append("\\\""); break;
                case '\n': builder.Append("\\n"); break;
                case '\r': builder.Append("\\r"); break;
                case '\t': builder.Append("\\t"); break;
                default: builder.Append(c); break;
            }
        }

        return builder.ToString();
    }

    private sealed class Parser
    {
        private readonly string _json;
        private int _index;

        public Parser(string json) { _json = json; }

        public ProtocolJsonValue Parse()
        {
            SkipWhitespace();
            ProtocolJsonValue value = ParseValue();
            SkipWhitespace();
            if (_index != _json.Length)
            {
                throw Error("JSON has trailing content.");
            }

            return value;
        }

        private ProtocolJsonValue ParseValue()
        {
            SkipWhitespace();
            if (_index >= _json.Length) throw Error("Unexpected end of JSON.");
            char c = _json[_index];
            if (c == '{') return ParseObject();
            if (c == '[') return ParseArray();
            if (c == '"') return new ProtocolJsonString(ParseString());
            if (c == 't') { ExpectLiteral("true"); return new ProtocolJsonBoolean(true); }
            if (c == 'f') { ExpectLiteral("false"); return new ProtocolJsonBoolean(false); }
            if (c == 'n') { ExpectLiteral("null"); return new ProtocolJsonNull(); }
            if (c == '-' || char.IsDigit(c)) return ParseNumber();
            throw Error("Unexpected JSON token.");
        }

        private ProtocolJsonObject ParseObject()
        {
            Expect('{');
            var obj = new ProtocolJsonObject();
            SkipWhitespace();
            if (TryConsume('}')) return obj;
            while (true)
            {
                SkipWhitespace();
                string key = ParseString();
                SkipWhitespace();
                Expect(':');
                obj.Properties[key] = ParseValue();
                SkipWhitespace();
                if (TryConsume('}')) return obj;
                Expect(',');
            }
        }

        private ProtocolJsonArray ParseArray()
        {
            Expect('[');
            var array = new ProtocolJsonArray();
            SkipWhitespace();
            if (TryConsume(']')) return array;
            while (true)
            {
                array.Items.Add(ParseValue());
                SkipWhitespace();
                if (TryConsume(']')) return array;
                Expect(',');
            }
        }

        private string ParseString()
        {
            Expect('"');
            var builder = new StringBuilder();
            while (_index < _json.Length)
            {
                char c = _json[_index++];
                if (c == '"') return builder.ToString();
                if (c != '\\')
                {
                    builder.Append(c);
                    continue;
                }

                if (_index >= _json.Length) throw Error("Invalid escape sequence.");
                char escaped = _json[_index++];
                switch (escaped)
                {
                    case '"': builder.Append('"'); break;
                    case '\\': builder.Append('\\'); break;
                    case '/': builder.Append('/'); break;
                    case 'b': builder.Append('\b'); break;
                    case 'f': builder.Append('\f'); break;
                    case 'n': builder.Append('\n'); break;
                    case 'r': builder.Append('\r'); break;
                    case 't': builder.Append('\t'); break;
                    case 'u':
                        if (_index + 4 > _json.Length) throw Error("Invalid unicode escape.");
                        string hex = _json.Substring(_index, 4);
                        builder.Append((char)int.Parse(hex, NumberStyles.HexNumber, CultureInfo.InvariantCulture));
                        _index += 4;
                        break;
                    default:
                        throw Error("Unsupported escape sequence.");
                }
            }

            throw Error("String is not closed.");
        }

        private ProtocolJsonNumber ParseNumber()
        {
            int start = _index;
            if (_json[_index] == '-') _index++;
            while (_index < _json.Length && char.IsDigit(_json[_index])) _index++;
            if (_index < _json.Length && _json[_index] == '.')
            {
                _index++;
                while (_index < _json.Length && char.IsDigit(_json[_index])) _index++;
            }

            if (_index < _json.Length && (_json[_index] == 'e' || _json[_index] == 'E'))
            {
                _index++;
                if (_index < _json.Length && (_json[_index] == '+' || _json[_index] == '-')) _index++;
                while (_index < _json.Length && char.IsDigit(_json[_index])) _index++;
            }

            return new ProtocolJsonNumber(_json.Substring(start, _index - start));
        }

        private void SkipWhitespace()
        {
            while (_index < _json.Length && char.IsWhiteSpace(_json[_index])) _index++;
        }

        private void Expect(char expected)
        {
            SkipWhitespace();
            if (_index >= _json.Length || _json[_index] != expected)
            {
                throw Error("Expected '" + expected + "'.");
            }

            _index++;
        }

        private bool TryConsume(char expected)
        {
            SkipWhitespace();
            if (_index >= _json.Length || _json[_index] != expected) return false;
            _index++;
            return true;
        }

        private void ExpectLiteral(string literal)
        {
            if (_index + literal.Length > _json.Length || string.CompareOrdinal(_json, _index, literal, 0, literal.Length) != 0)
            {
                throw Error("Expected literal " + literal + ".");
            }

            _index += literal.Length;
        }

        private FormatException Error(string message)
        {
            return new FormatException(message + " Position: " + _index);
        }
    }
}
