// 自动生成的协议文件

// 定义协议类


// 获取装备列表
class GetEquipmentList_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 装备列表响应
class GetEquipmentList_s2c {
    constructor() {
        this.Equipments = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetEquipmentList_c2s,
    GetEquipmentList_s2c,
};
