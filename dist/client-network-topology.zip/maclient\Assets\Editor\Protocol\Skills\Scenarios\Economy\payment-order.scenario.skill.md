# 支付/订单场景 Skill

## 客户端生成要求

- 生成创建订单、拉起 SDK、等待支付、服务端确认、补单查询入口。
- 支付开始后默认禁止自动重试，除非存在 orderId/idempotencyKey。
- loading 必须区分“创建订单”“支付 SDK 中”“确认发货中”。
- 失败结果必须区分取消支付、SDK 失败、服务端校验失败、发货失败。

## 服务端生成要求

- 服务端权威校验商品、价格、货币、渠道、订单状态。
- receipt/transactionId/orderId 必须有幂等校验。
- 状态机至少包含 Created、Pending、Paid、Delivered、Closed、Failed。
- 发货和订单状态更新必须在事务或可恢复流程中。
- 生成审计日志、风控、补单、重复通知处理 hook。

## 禁止

- 禁止信任客户端价格、奖励、支付成功状态。
- 禁止记录 receipt/token/secret 明文。
