# 测试与质量 Skill

## Mock 数据

- 根据字段类型生成合法、边界、异常三类样例。
- required 字段必须出现在合法样例。
- deprecated 字段默认不出现在新样例，但要生成兼容性样例。

## 客户端测试

- 生成可无 UI 运行的 smoke test helper。
- 覆盖成功、协议错误、网络失败、超时、取消。
- 对 retry/loading 要验证 begin/end 平衡。

## 服务端测试

- 覆盖参数校验、权限失败、幂等重复、事务失败恢复、repository 异常。
- 没有真实测试框架时生成可迁移的 plain helper 和测试用例说明。

## 兼容性

- 新增 required 字段必须提示旧客户端兼容风险。
- 删除/重命名/改变类型必须生成 breaking-change 说明。
- MessageID 变化必须标记为高风险。
