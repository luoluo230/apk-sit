﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 处理好友申请(同意/拒绝)
/// </summary>
public class HandleFriendRequest_c2s
{
    /// <summary>
    /// 申请 ID
    /// </summary>
    public long RequestId { get; set; }
    /// <summary>
    /// 是否同意
    /// </summary>
    public bool Accept { get; set; }
}

/// <summary>
/// 处理好友申请结果
/// </summary>
public class HandleFriendRequest_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

