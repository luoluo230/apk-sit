﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取公会活动列表
/// </summary>
public class GetGuildActivities_c2s
{
}

/// <summary>
/// 获取公会活动列表结果
/// </summary>
public class GetGuildActivities_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 活动列表
    /// </summary>
    public GuildActivityInfo[] Activities { get; set; }
}

