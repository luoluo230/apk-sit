/// <summary>
/// 网络错误展示接口。
/// 业务层可接入自己的弹窗、Toast 或埋点方案。
/// </summary>
public interface INetworkErrorPresenter
{
    /// <summary>
    /// 展示一个网络错误。
    /// </summary>
    void ShowError(int code, string message);
}
