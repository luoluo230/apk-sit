// 自动生成的协议文件

// 定义协议类


// 删除邮件
class DeleteMail_c2s {
    constructor() {
        this.MailId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 删除邮件结果
class DeleteMail_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DeleteMail_c2s,
    DeleteMail_s2c,
};
