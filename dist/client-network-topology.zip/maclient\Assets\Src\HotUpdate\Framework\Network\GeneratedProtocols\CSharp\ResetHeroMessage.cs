﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 英雄重置(还原等级返还资源)
/// </summary>
public class ResetHero_c2s
{
    /// <summary>
    /// 英雄 ID
    /// </summary>
    public long HeroId { get; set; }
}

/// <summary>
/// 英雄重置结果
/// </summary>
public class ResetHero_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 重置后的英雄(等级/星级重置后状态)
    /// </summary>
    public HeroInfo Hero { get; set; }
    /// <summary>
    /// 返还的道具/资源
    /// </summary>
    public RewardItem[] RefundRewards { get; set; }
}

