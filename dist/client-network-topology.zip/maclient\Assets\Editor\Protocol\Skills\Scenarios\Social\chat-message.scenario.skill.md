# 聊天/通知场景 Skill

## 客户端生成要求

- 生成发送消息、拉取消息、未读刷新、通知回调、发送失败重试入口。
- UI 示例必须区分 sending、sent、failed、received、unread changed。
- 文本展示必须经过 sanitize/format hook。

## 服务端生成要求

- 校验关系、频道权限、频率限制、禁言、黑名单、敏感词/安全审核。
- 生成 messageId/traceId 防重复。
- 存储、推送分发、离线消息、未读计数要分层。

## 禁止

- 禁止直接回显未净化文本。
- 禁止泄露举报、封禁、私聊敏感信息到普通日志。
