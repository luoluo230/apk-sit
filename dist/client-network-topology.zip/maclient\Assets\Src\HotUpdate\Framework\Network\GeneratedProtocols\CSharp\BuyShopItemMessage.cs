﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 购买商店物品
/// </summary>
public class BuyShopItem_c2s
{
    /// <summary>
    /// 商店类型
    /// </summary>
    public ShopType ShopType { get; set; }
    /// <summary>
    /// 格子序号
    /// </summary>
    public int SlotIndex { get; set; }
    /// <summary>
    /// 购买数量(通常为1)
    /// </summary>
    public int BuyCount { get; set; }
}

/// <summary>
/// 购买商店物品结果
/// </summary>
public class BuyShopItem_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 更新后的商店格子
    /// </summary>
    public ShopItemInfo Item { get; set; }
    /// <summary>
    /// 获得物品(背包里新增)
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 货币消耗
    /// </summary>
    public ResourceChange[] ResourceChanges { get; set; }
}

