# Hero Domain Skill

- Client: generate hero upgrade/sync use cases with resource preview and result refresh hooks.
- Server: generate hero ownership validation, resource cost validation, level/star rule extension points, and hero repository mutation hooks.
- Never trust client-provided resulting hero stats.
