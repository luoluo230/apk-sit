// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 客户端主动登出请求
/// </summary>
public class Logout_c2s
{
    /// <summary>
    /// 客户端时间戳(Unix)
    /// </summary>
    public long ClientTime { get; set; }
    /// <summary>
    /// 登出原因（客户端描述）
    /// </summary>
    public string Reason { get; set; }
}

/// <summary>
/// 客户端主动登出响应
/// </summary>
public class Logout_s2c
{
    /// <summary>
    /// 登出是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
}

