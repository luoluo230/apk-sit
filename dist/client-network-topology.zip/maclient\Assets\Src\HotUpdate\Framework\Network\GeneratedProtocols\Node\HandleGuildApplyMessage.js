// 自动生成的协议文件

// 定义协议类


// 处理公会申请(会长/官员)
class HandleGuildApply_c2s {
    constructor() {
        this.ApplyId = null;
        this.Accept = false;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 处理公会申请结果
class HandleGuildApply_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    HandleGuildApply_c2s,
    HandleGuildApply_s2c,
};
