// 自动生成的协议文件

// 定义协议类


// 获取挂机收益预览
class GetAfkRewardInfo_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 挂机收益信息响应
class GetAfkRewardInfo_s2c {
    constructor() {
        this.Afk = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetAfkRewardInfo_c2s,
    GetAfkRewardInfo_s2c,
};
