using System;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// 协议工作台使用的本地凭据加密工具。
/// 仅用于降低明文泄露风险，不作为高强度密钥管理方案。
/// </summary>
internal static class ProtocolCredentialCrypto
{
    private const int IvSize = 16;

    public static string Encrypt(string plainText, string projectId)
    {
        if (string.IsNullOrEmpty(plainText)) return string.Empty;
        byte[] key = BuildKey(projectId);
        using (Aes aes = Aes.Create())
        {
            aes.Key = key;
            aes.GenerateIV();
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            byte[] plain = Encoding.UTF8.GetBytes(plainText);
            using (ICryptoTransform encryptor = aes.CreateEncryptor())
            {
                byte[] cipher = encryptor.TransformFinalBlock(plain, 0, plain.Length);
                byte[] payload = new byte[IvSize + cipher.Length];
                Buffer.BlockCopy(aes.IV, 0, payload, 0, IvSize);
                Buffer.BlockCopy(cipher, 0, payload, IvSize, cipher.Length);
                return Convert.ToBase64String(payload);
            }
        }
    }

    public static string Decrypt(string encryptedText, string projectId)
    {
        if (string.IsNullOrEmpty(encryptedText)) return string.Empty;
        byte[] payload = Convert.FromBase64String(encryptedText);
        if (payload.Length <= IvSize) return string.Empty;
        byte[] key = BuildKey(projectId);
        byte[] iv = new byte[IvSize];
        byte[] cipher = new byte[payload.Length - IvSize];
        Buffer.BlockCopy(payload, 0, iv, 0, IvSize);
        Buffer.BlockCopy(payload, IvSize, cipher, 0, cipher.Length);
        using (Aes aes = Aes.Create())
        {
            aes.Key = key;
            aes.IV = iv;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            using (ICryptoTransform decryptor = aes.CreateDecryptor())
            {
                byte[] plain = decryptor.TransformFinalBlock(cipher, 0, cipher.Length);
                return Encoding.UTF8.GetString(plain);
            }
        }
    }

    public static string Mask(string value)
    {
        if (string.IsNullOrEmpty(value)) return string.Empty;
        if (value.Length <= 8) return "****";
        return value.Substring(0, 4) + "****" + value.Substring(value.Length - 4);
    }

    private static byte[] BuildKey(string projectId)
    {
        string machine = Environment.MachineName ?? "LOCAL";
        string seed = "MAClient-Protocol-Credential|" + (projectId ?? string.Empty) + "|" + machine;
        using (SHA256 sha = SHA256.Create())
        {
            return sha.ComputeHash(Encoding.UTF8.GetBytes(seed));
        }
    }
}
