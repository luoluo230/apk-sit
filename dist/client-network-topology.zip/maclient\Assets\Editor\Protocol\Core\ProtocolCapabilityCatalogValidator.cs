﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace MAClient.Protocol.Editor
{
    /// <summary>
    /// 协议能力清单校验器。
    /// 在不改动 protocols.json 结构前提下，校验核心必需协议与业务扩展协议清单，避免协议膨胀与缺失。
    /// </summary>
    public static class ProtocolCapabilityCatalogValidator
    {
        private const string ProtocolSchemaPath = "Assets/Src/Protocols/protocols.json";
        private const string CoreRequiredPath = "Assets/Src/Protocols/protocol-core-required.json";
        private const string BusinessExtensionsPath = "Assets/Src/Protocols/protocol-business-extensions.json";
        private const string ReportOutputPath = "protocols/generated/reports/protocol-capability-validation-report.md";

        [MenuItem("Tools/MAClient/协议与网络/校验核心与扩展协议清单")]
        public static void RunFromMenu()
        {
            ValidationReport report = Validate();
            Directory.CreateDirectory(Path.GetDirectoryName(ReportOutputPath) ?? ".");
            File.WriteAllText(ReportOutputPath, report.ToMarkdown(), new UTF8Encoding(false));
            AssetDatabase.Refresh();

            if (report.Errors.Count > 0)
            {
                Debug.LogError("[ProtocolCapabilityCatalogValidator] FAIL\n" + report.SummaryText);
                EditorUtility.DisplayDialog("协议清单校验失败", report.SummaryText + "\n\n报告已输出到:\n" + ReportOutputPath, "确定");
                return;
            }

            Debug.Log("[ProtocolCapabilityCatalogValidator] PASS\n" + report.SummaryText);
            EditorUtility.DisplayDialog("协议清单校验通过", report.SummaryText + "\n\n报告已输出到:\n" + ReportOutputPath, "确定");
        }

        public static ValidationReport Validate()
        {
            var report = new ValidationReport();
            ProtocolSchemaDocument schema = ProtocolSchemaDocument.Load(ProtocolSchemaPath);
            if (schema.ParseErrors.Count > 0)
            {
                report.Errors.AddRange(schema.ParseErrors.Select(x => "协议源解析失败: " + x));
                return report;
            }

            HashSet<string> allNames = new HashSet<string>(schema.Entries.Select(e => e.Name), StringComparer.Ordinal);
            HashSet<string> coreRequired = LoadCatalogArray(CoreRequiredPath, "CoreRequired", report.Errors);
            HashSet<string> businessExtensions = LoadCatalogArray(BusinessExtensionsPath, "BusinessExtensions", report.Errors);
            if (report.Errors.Count > 0)
            {
                return report;
            }

            foreach (string name in coreRequired)
            {
                if (!allNames.Contains(name))
                {
                    report.Errors.Add("核心必需协议缺失: " + name);
                }
            }

            foreach (string name in businessExtensions)
            {
                if (!allNames.Contains(name))
                {
                    report.Warnings.Add("业务扩展清单中存在未定义协议: " + name);
                }
            }

            HashSet<string> covered = new HashSet<string>(coreRequired, StringComparer.Ordinal);
            covered.UnionWith(businessExtensions);
            List<string> orphanMessages = schema.Entries
                .Where(e => e.Kind == ProtocolSchemaEntryKind.Message)
                .Select(e => e.Name)
                .Where(n => !covered.Contains(n))
                .OrderBy(n => n, StringComparer.Ordinal)
                .ToList();

            report.OrphanProtocols.AddRange(orphanMessages);
            if (orphanMessages.Count > 0)
            {
                report.Warnings.Add("存在未纳入核心/扩展清单的消息协议: " + orphanMessages.Count + " 条。");
            }

            report.CoreCount = coreRequired.Count;
            report.BusinessCount = businessExtensions.Count;
            report.TotalMessageCount = schema.Entries.Count(e => e.Kind == ProtocolSchemaEntryKind.Message);
            return report;
        }

        private static HashSet<string> LoadCatalogArray(string filePath, string key, List<string> errors)
        {
            var result = new HashSet<string>(StringComparer.Ordinal);
            if (!File.Exists(filePath))
            {
                errors.Add("未找到协议清单文件: " + filePath);
                return result;
            }

            string json = File.ReadAllText(filePath, Encoding.UTF8);
            if (!ProtocolJson.TryParse(json, out ProtocolJsonValue value, out string parseError) || !(value is ProtocolJsonObject root))
            {
                errors.Add("协议清单 JSON 解析失败(" + filePath + "): " + parseError);
                return result;
            }

            if (!(root.Get(key) is ProtocolJsonArray array))
            {
                errors.Add("协议清单字段缺失: " + key + " in " + filePath);
                return result;
            }

            foreach (ProtocolJsonValue item in array.Items)
            {
                string name = item is ProtocolJsonString s ? s.Value : string.Empty;
                if (string.IsNullOrWhiteSpace(name))
                {
                    continue;
                }

                result.Add(name.Trim());
            }

            return result;
        }

        public sealed class ValidationReport
        {
            public readonly List<string> Errors = new List<string>();
            public readonly List<string> Warnings = new List<string>();
            public readonly List<string> OrphanProtocols = new List<string>();
            public int CoreCount;
            public int BusinessCount;
            public int TotalMessageCount;

            public string SummaryText
            {
                get
                {
                    return string.Format(
                        "核心:{0} 扩展:{1} 消息总数:{2} 错误:{3} 警告:{4} 孤儿:{5}",
                        CoreCount,
                        BusinessCount,
                        TotalMessageCount,
                        Errors.Count,
                        Warnings.Count,
                        OrphanProtocols.Count);
                }
            }

            public string ToMarkdown()
            {
                var builder = new StringBuilder();
                builder.AppendLine("# 协议能力清单校验报告");
                builder.AppendLine();
                builder.AppendLine("- 生成时间: " + DateTime.UtcNow.ToString("O"));
                builder.AppendLine("- " + SummaryText);
                builder.AppendLine();

                WriteList(builder, "错误", Errors);
                WriteList(builder, "警告", Warnings);
                WriteList(builder, "未纳入清单的消息协议（孤儿）", OrphanProtocols);
                return builder.ToString();
            }

            private static void WriteList(StringBuilder builder, string title, List<string> items)
            {
                builder.AppendLine("## " + title);
                if (items.Count == 0)
                {
                    builder.AppendLine("- 无");
                    builder.AppendLine();
                    return;
                }

                foreach (string item in items)
                {
                    builder.AppendLine("- " + item);
                }

                builder.AppendLine();
            }
        }
    }
}
