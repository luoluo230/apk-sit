﻿using System;
using System.Collections.Generic;

public sealed class KcpPeer
{
    private const int IKCP_RTO_NDL = 30;
    private const int IKCP_RTO_MIN = 100;
    private const int IKCP_RTO_DEF = 200;
    private const int IKCP_RTO_MAX = 60000;
    private const int IKCP_CMD_PUSH = 81;
    private const int IKCP_CMD_ACK = 82;
    private const int IKCP_OVERHEAD = 24;

    private readonly List<KcpSegment> _sndQueue = new List<KcpSegment>();
    private readonly List<KcpSegment> _rcvQueue = new List<KcpSegment>();
    private readonly List<KcpSegment> _sndBuf = new List<KcpSegment>();
    private readonly List<KcpSegment> _rcvBuf = new List<KcpSegment>();
    private readonly List<AckItem> _ackList = new List<AckItem>();

    private uint _conv;
    private uint _mtu = 1400;
    private uint _mss = 1400 - IKCP_OVERHEAD;
    private uint _sndUna;
    private uint _sndNxt;
    private uint _rcvNxt;
    private uint _rxRttval;
    private uint _rxSrtt;
    private uint _rxRto = IKCP_RTO_DEF;
    private uint _rxMinRto = IKCP_RTO_MIN;
    private uint _sndWnd = 32;
    private uint _rcvWnd = 32;
    private uint _rmtWnd = 32;
    private uint _interval = 100;
    private uint _tsFlush;
    private uint _current;
    private uint _updated;

    private int _nodelay;
    private int _fastresend;
    private int _nocwnd;

    private readonly byte[] _buffer;
    private readonly Action<byte[], int> _output;

    public KcpPeer(uint conv, Action<byte[], int> output)
    {
        _conv = conv;
        _output = output;
        _buffer = new byte[_mtu];
    }

    public void SetMtu(uint mtu)
    {
        if (mtu < 50)
        {
            return;
        }
        _mtu = mtu;
        _mss = mtu - IKCP_OVERHEAD;
    }

    public void SetWindowSize(uint sndWnd, uint rcvWnd)
    {
        if (sndWnd > 0) _sndWnd = sndWnd;
        if (rcvWnd > 0) _rcvWnd = rcvWnd;
    }

    public void SetNoDelay(int nodelay, int interval, int resend, int nc)
    {
        _nodelay = nodelay;
        if (nodelay > 0)
        {
            _rxMinRto = IKCP_RTO_NDL;
        }
        if (interval >= 10)
        {
            _interval = (uint)interval;
        }
        if (resend >= 0)
        {
            _fastresend = resend;
        }
        _nocwnd = nc;
    }

    public int Send(byte[] buffer, int offset, int len)
    {
        if (buffer == null || len <= 0)
        {
            return -1;
        }

        int count = len <= _mss ? 1 : (int)((len + _mss - 1) / _mss);
        if (count > 255)
        {
            return -2;
        }

        for (int i = 0; i < count; i++)
        {
            int size = (int)Min(_mss, (uint)(len - i * _mss));
            KcpSegment seg = new KcpSegment(size);
            Buffer.BlockCopy(buffer, offset + i * (int)_mss, seg.Data, 0, size);
            seg.Frg = (byte)(count - i - 1);
            _sndQueue.Add(seg);
        }

        return 0;
    }

    public int PeekSize()
    {
        if (_rcvQueue.Count == 0)
        {
            return -1;
        }

        KcpSegment seg = _rcvQueue[0];
        if (seg.Frg == 0)
        {
            return seg.Data.Length;
        }

        if (_rcvQueue.Count < seg.Frg + 1)
        {
            return -1;
        }

        int length = 0;
        for (int i = 0; i < seg.Frg + 1; i++)
        {
            length += _rcvQueue[i].Data.Length;
        }

        return length;
    }

    public int Receive(byte[] buffer, int len)
    {
        int peekSize = PeekSize();
        if (peekSize < 0)
        {
            return -1;
        }

        if (len < peekSize)
        {
            return -2;
        }

        int n = 0;
        int count = 0;
        foreach (var seg in _rcvQueue)
        {
            Buffer.BlockCopy(seg.Data, 0, buffer, n, seg.Data.Length);
            n += seg.Data.Length;
            count++;
            if (seg.Frg == 0)
            {
                break;
            }
        }

        _rcvQueue.RemoveRange(0, count);

        return n;
    }

    public void Input(byte[] data, int length)
    {
        if (data == null || length < IKCP_OVERHEAD)
        {
            return;
        }

        int offset = 0;
        while (true)
        {
            if (length - offset < IKCP_OVERHEAD)
            {
                break;
            }

            uint conv = Decode32u(data, ref offset);
            if (conv != _conv)
            {
                return;
            }

            int cmd = data[offset++];
            byte frg = data[offset++];
            uint wnd = Decode16u(data, ref offset);
            uint ts = Decode32u(data, ref offset);
            uint sn = Decode32u(data, ref offset);
            uint una = Decode32u(data, ref offset);
            uint len = Decode32u(data, ref offset);

            if (length - offset < len)
            {
                return;
            }

            _rmtWnd = wnd;

            if (cmd == IKCP_CMD_ACK)
            {
                ParseUna(una);
                ParseAck(sn);
                ShrinkBuf();
                UpdateAck(_current - ts);
            }
            else if (cmd == IKCP_CMD_PUSH)
            {
                if (sn < _rcvNxt + _rcvWnd)
                {
                    AckPush(sn, ts);
                    if (sn >= _rcvNxt)
                    {
                        InsertSegment(new KcpSegment(data, offset, (int)len)
                        {
                            Sn = sn,
                            Ts = ts,
                            Frg = frg
                        }, _rcvBuf);
                    }
                }
            }

            offset += (int)len;
        }

        MoveRcvBufToQueue();
        if (_rcvQueue.Count > _rcvWnd)
        {
            _rcvQueue.RemoveRange((int)_rcvWnd, _rcvQueue.Count - (int)_rcvWnd);
        }
    }

    public void Update(uint current)
    {
        _current = current;
        if (_updated == 0)
        {
            _updated = 1;
            _tsFlush = _current;
        }

        int slap = (int)(_current - _tsFlush);
        if (slap >= 10000 || slap < -10000)
        {
            _tsFlush = _current;
            slap = 0;
        }

        if (slap >= 0)
        {
            _tsFlush += _interval;
            if (_current >= _tsFlush)
            {
                _tsFlush = _current + _interval;
            }
            Flush();
        }
    }

    public void SetCurrent(uint current)
    {
        _current = current;
    }

    private void Flush()
    {
        int offset = 0;
        foreach (var ack in _ackList)
        {
            if (offset + IKCP_OVERHEAD > _buffer.Length)
            {
                OutputBuffer(offset);
                offset = 0;
            }
            offset = EncodeAck(_buffer, offset, ack.Sn, ack.Ts);
        }
        _ackList.Clear();

        uint cwnd = _sndWnd;
        if (_nocwnd == 0)
        {
            cwnd = Min(_sndWnd, _rmtWnd);
        }

        while (_sndNxt < _sndUna + cwnd && _sndQueue.Count > 0)
        {
            var seg = _sndQueue[0];
            _sndQueue.RemoveAt(0);

            seg.Conv = _conv;
            seg.Cmd = IKCP_CMD_PUSH;
            seg.Wnd = (ushort)_rcvWnd;
            seg.Ts = _current;
            seg.Sn = _sndNxt;
            seg.Una = _rcvNxt;
            seg.Resendts = _current;
            seg.Rto = _rxRto;
            seg.Fastack = 0;
            seg.Xmit = 0;
            _sndBuf.Add(seg);
            _sndNxt++;
        }

        foreach (var seg in _sndBuf)
        {
            bool needsend = false;
            if (seg.Xmit == 0)
            {
                needsend = true;
                seg.Xmit++;
                seg.Rto = _rxRto;
                seg.Resendts = _current + seg.Rto;
            }
            else if (_current >= seg.Resendts)
            {
                needsend = true;
                seg.Xmit++;
                seg.Rto += _rxRto / 2;
                seg.Resendts = _current + seg.Rto;
            }
            else if (_fastresend > 0 && seg.Fastack >= _fastresend)
            {
                needsend = true;
                seg.Xmit++;
                seg.Fastack = 0;
                seg.Resendts = _current + seg.Rto;
            }

            if (!needsend)
            {
                continue;
            }

            if (offset + IKCP_OVERHEAD + seg.Data.Length > _buffer.Length)
            {
                OutputBuffer(offset);
                offset = 0;
            }
            offset = EncodeData(_buffer, offset, seg);
        }

        if (offset > 0)
        {
            OutputBuffer(offset);
        }
    }

    private void OutputBuffer(int length)
    {
        if (length <= 0 || _output == null)
        {
            return;
        }
        _output(_buffer, length);
    }

    private void AckPush(uint sn, uint ts)
    {
        _ackList.Add(new AckItem(sn, ts));
    }

    private int EncodeAck(byte[] buffer, int offset, uint sn, uint ts)
    {
        offset = Encode32u(buffer, offset, _conv);
        buffer[offset++] = (byte)IKCP_CMD_ACK;
        buffer[offset++] = 0;
        offset = Encode16u(buffer, offset, (ushort)_rcvWnd);
        offset = Encode32u(buffer, offset, ts);
        offset = Encode32u(buffer, offset, sn);
        offset = Encode32u(buffer, offset, _rcvNxt);
        offset = Encode32u(buffer, offset, 0);
        return offset;
    }

    private int EncodeData(byte[] buffer, int offset, KcpSegment seg)
    {
        offset = Encode32u(buffer, offset, seg.Conv);
        buffer[offset++] = (byte)seg.Cmd;
        buffer[offset++] = seg.Frg;
        offset = Encode16u(buffer, offset, seg.Wnd);
        offset = Encode32u(buffer, offset, seg.Ts);
        offset = Encode32u(buffer, offset, seg.Sn);
        offset = Encode32u(buffer, offset, seg.Una);
        offset = Encode32u(buffer, offset, (uint)seg.Data.Length);
        Buffer.BlockCopy(seg.Data, 0, buffer, offset, seg.Data.Length);
        return offset + seg.Data.Length;
    }

    private void ParseAck(uint sn)
    {
        for (int i = 0; i < _sndBuf.Count; i++)
        {
            if (sn == _sndBuf[i].Sn)
            {
                _sndBuf.RemoveAt(i);
                return;
            }
            if (sn < _sndBuf[i].Sn)
            {
                break;
            }
            _sndBuf[i].Fastack++;
        }
    }

    private void ParseUna(uint una)
    {
        int count = 0;
        foreach (var seg in _sndBuf)
        {
            if (una > seg.Sn)
            {
                count++;
            }
            else
            {
                break;
            }
        }

        if (count > 0)
        {
            _sndBuf.RemoveRange(0, count);
        }
    }

    private void ShrinkBuf()
    {
        if (_sndBuf.Count > 0)
        {
            _sndUna = _sndBuf[0].Sn;
        }
        else
        {
            _sndUna = _sndNxt;
        }
    }

    private void UpdateAck(uint rtt)
    {
        if (_rxSrtt == 0)
        {
            _rxSrtt = rtt;
            _rxRttval = rtt / 2;
        }
        else
        {
            int delta = (int)rtt - (int)_rxSrtt;
            if (delta < 0) delta = -delta;
            _rxRttval = (3 * _rxRttval + (uint)delta) / 4;
            _rxSrtt = (7 * _rxSrtt + rtt) / 8;
            if (_rxSrtt < 1) _rxSrtt = 1;
        }

        uint rto = _rxSrtt + Max(_interval, 4 * _rxRttval);
        _rxRto = Clamp(rto, _rxMinRto, IKCP_RTO_MAX);
    }

    private void InsertSegment(KcpSegment seg, List<KcpSegment> buf)
    {
        int i = buf.Count - 1;
        if (i < 0)
        {
            buf.Add(seg);
            return;
        }

        for (; i >= 0; i--)
        {
            if (seg.Sn == buf[i].Sn)
            {
                return;
            }
            if (seg.Sn > buf[i].Sn)
            {
                break;
            }
        }
        buf.Insert(i + 1, seg);
    }

    private void MoveRcvBufToQueue()
    {
        int count = 0;
        foreach (var seg in _rcvBuf)
        {
            if (seg.Sn == _rcvNxt && _rcvQueue.Count < _rcvWnd)
            {
                _rcvQueue.Add(seg);
                _rcvNxt++;
                count++;
            }
            else
            {
                break;
            }
        }

        if (count > 0)
        {
            _rcvBuf.RemoveRange(0, count);
        }
    }

    private static int Encode16u(byte[] buffer, int offset, ushort value)
    {
        buffer[offset++] = (byte)(value & 0xFF);
        buffer[offset++] = (byte)((value >> 8) & 0xFF);
        return offset;
    }

    private static int Encode32u(byte[] buffer, int offset, uint value)
    {
        buffer[offset++] = (byte)(value & 0xFF);
        buffer[offset++] = (byte)((value >> 8) & 0xFF);
        buffer[offset++] = (byte)((value >> 16) & 0xFF);
        buffer[offset++] = (byte)((value >> 24) & 0xFF);
        return offset;
    }

    private static uint Decode16u(byte[] buffer, ref int offset)
    {
        uint value = (uint)(buffer[offset] | (buffer[offset + 1] << 8));
        offset += 2;
        return value;
    }

    private static uint Decode32u(byte[] buffer, ref int offset)
    {
        uint value = (uint)(buffer[offset] |
                            (buffer[offset + 1] << 8) |
                            (buffer[offset + 2] << 16) |
                            (buffer[offset + 3] << 24));
        offset += 4;
        return value;
    }

    private static uint Clamp(uint value, uint min, uint max)
    {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    private static uint Max(uint left, uint right)
    {
        return left > right ? left : right;
    }

    private static uint Min(uint left, uint right)
    {
        return left < right ? left : right;
    }

    private sealed class KcpSegment
    {
        public uint Conv;
        public int Cmd;
        public byte Frg;
        public ushort Wnd;
        public uint Ts;
        public uint Sn;
        public uint Una;
        public uint Resendts;
        public uint Rto;
        public uint Fastack;
        public uint Xmit;
        public byte[] Data;

        public KcpSegment(int size)
        {
            Data = new byte[size];
        }

        public KcpSegment(byte[] source, int offset, int len)
        {
            Data = new byte[len];
            Buffer.BlockCopy(source, offset, Data, 0, len);
        }
    }

    private readonly struct AckItem
    {
        public readonly uint Sn;
        public readonly uint Ts;

        public AckItem(uint sn, uint ts)
        {
            Sn = sn;
            Ts = ts;
        }
    }
}
