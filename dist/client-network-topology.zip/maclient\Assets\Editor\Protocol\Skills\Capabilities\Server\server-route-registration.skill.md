# 服务端路由注册/分发 Skill

## 目标

根据协议上下文中的 `_c2s` 请求名、`_s2c` 响应名、MessageID 和 handler 类型，生成服务端网络层可挂接的路由注册代码。

## 必须生成

- 每个 `_c2s` 协议必须有独立的 `RouteRegistration` 文件。
- 注册入口必须包含 `RequestMessageId`、`ResponseMessageId`、`RequestName`、`ResponseName` 常量，便于接入日志、抓包、埋点和运维排查。
- 注册入口必须通过 `IServerProtocolRouteRegistry.Register<TRequest, TResponse>` 绑定 `handler.HandleAsync`。
- 分发入口必须通过 `IServerProtocolDispatcher.DispatchAsync` 按 MessageID 调用已注册 handler。
- 如果是纯 `_s2c` 推送协议，没有 `_c2s` 请求，必须只生成推送说明和空注册保护，不要伪造客户端请求。

## 接入约束

- 只生成路由适配层，不重写网络 socket、包体编码、session 管理。
- 如果项目已有路由接口，优先在生成代码中保留 adapter 位置，人工只需要把 `IServerProtocolRouteRegistry` 对接到现有路由表。
- 注册必须是幂等的，重复注册同一个 MessageID 时由宿主路由表决定覆盖、拒绝或报警。
- 生成代码不能吞掉 handler 异常，异常映射仍走 handler/service/guard 层。

