# Support

这里放全局硬约束，所有 Protocol Skill AI Payload 都会读取。

## 当前规则包

- `00-global-codegen-contract`：全局代码生成契约。
- `10-client-network-policy`：客户端 loading/retry/error/cancel/cache 策略。
- `20-server-security-transaction`：服务端权限、事务、错误码、安全日志。
- `30-database-model-migration`：数据库模型、迁移、索引、review gate。
- `40-observability`：日志、埋点、trace、指标。
- `50-testing-quality`：mock、smoke test、兼容性测试。

## 规则

- 使用数字前缀控制读取顺序。
- 只写跨所有协议都成立的硬约束。
- 不写具体业务流程，具体流程放到 `Scenarios`。
