// 自动生成的协议文件

// 定义协议类


// 世界 Boss 状态广播
class WorldBossStatusNotify_s2c {
    constructor() {
        this.Boss = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    WorldBossStatusNotify_s2c,
};
