// 自动生成的协议文件

// 定义协议类


// 会话心跳请求，轻量校验 Token 并可选返回档案
class Heartbeat_c2s {
    constructor() {
        this.IncludeProfile = false;
        this.ClientTime = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 会话心跳响应，返回会话有效性与服务器时间
class Heartbeat_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.ServerTime = null;
        this.TokenExpireAt = null;
        this.Profile = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    Heartbeat_c2s,
    Heartbeat_s2c,
};
