﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取召唤/抽卡池信息
/// </summary>
public class GetGachaInfo_c2s
{
}

/// <summary>
/// 召唤/抽卡池信息响应
/// </summary>
public class GetGachaInfo_s2c
{
    /// <summary>
    /// 所有可用池子
    /// </summary>
    public GachaPoolInfo[] Pools { get; set; }
}

