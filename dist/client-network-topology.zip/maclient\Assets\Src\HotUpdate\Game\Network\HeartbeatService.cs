using System.Collections;
using UnityEngine;

/// <summary>
/// 轻量心跳服务：依附 NetworkFacade，按固定间隔发送 Heartbeat_c2s。
/// </summary>
public sealed class HeartbeatService
{
    private readonly NetworkFacade _facade;
    private Coroutine _loop;
    private float _intervalSeconds = 10f;

    public HeartbeatService(NetworkFacade facade)
    {
        _facade = facade;
    }

    public void StartHeartbeat(float intervalSeconds = 10f, bool includeProfile = false)
    {
        _intervalSeconds = Mathf.Max(1f, intervalSeconds);
        StopHeartbeat();
        if (_facade == null)
        {
            return;
        }

        if (_facade.Manager != null)
        {
            if (_loop != null)
            {
                _facade.StopCoroutine(_loop);
                _loop = null;
            }

            _facade.Manager.heartBeatInterval = _intervalSeconds;
            _facade.Manager.enableHeartbeatRequest = true;
            return;
        }

        _loop = _facade.StartCoroutine(HeartbeatLoop(includeProfile));
    }

    public void StopHeartbeat()
    {
        if (_facade != null && _facade.Manager != null)
        {
            _facade.Manager.enableHeartbeatRequest = false;
        }

        if (_facade != null && _loop != null)
        {
            _facade.StopCoroutine(_loop);
        }

        _loop = null;
    }

    private IEnumerator HeartbeatLoop(bool includeProfile)
    {
        var wait = new WaitForSeconds(_intervalSeconds);
        while (true)
        {
            if (_facade != null && _facade.IsConnected)
            {
                _facade.Send<Heartbeat_s2c>(
                    new Heartbeat_c2s
                    {
                        IncludeProfile = includeProfile,
                        ClientTime = System.DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                    },
                    _ => { },
                    _facade.CurrentTransportType,
                    _facade.CurrentServerUri,
                    reliable: false,
                    priority: 1);
            }

            yield return wait;
        }
    }
}
