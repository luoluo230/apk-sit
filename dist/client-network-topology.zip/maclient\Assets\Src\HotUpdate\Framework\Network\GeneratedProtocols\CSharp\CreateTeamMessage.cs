﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 创建队伍
/// </summary>
public class CreateTeam_c2s
{
}

/// <summary>
/// 创建队伍结果
/// </summary>
public class CreateTeam_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 队伍信息
    /// </summary>
    public TeamInfo Team { get; set; }
}

