// 自动生成的协议文件

// 定义协议类


// 登录请求协议
class Login_c2s {
    constructor() {
        this.Username = '';
        this.Password = '';
        this.Device = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 登录响应协议
class Login_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Token = null;
        this.Profile = null;
        this.AutoLogin = false;
        this.LastServerId = '';
        this.ServerList = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    Login_c2s,
    Login_s2c,
};
