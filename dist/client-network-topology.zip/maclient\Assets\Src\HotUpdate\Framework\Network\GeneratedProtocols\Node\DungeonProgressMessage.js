// 自动生成的协议文件

// 定义协议类


// 副本内进度同步
class DungeonProgress_c2s {
    constructor() {
        this.DungeonId = 0;
        this.Progress = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 副本进度同步结果
class DungeonProgress_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DungeonProgress_c2s,
    DungeonProgress_s2c,
};
