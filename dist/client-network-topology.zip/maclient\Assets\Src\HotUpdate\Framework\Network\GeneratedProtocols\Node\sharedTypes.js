// 自动生成的共享类型文件


// 客户端设备信息
class DeviceInfo {
    constructor() {
        this.Platform = '';
        this.DeviceId = '';
        this.ClientVersion = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 认证 Token 信息
class AuthToken {
    constructor() {
        this.Token = '';
        this.ExpireAt = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 可登录的游戏服信息
class ServerInfo {
    constructor() {
        this.ServerId = '';
        this.Name = '';
        this.Region = '';
        this.Status = '';
        this.IsRecommended = false;
        this.OnlinePlayers = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 玩家基础信息
class PlayerProfile {
    constructor() {
        this.PlayerId = null;
        this.Nickname = '';
        this.Level = 0;
        this.Experience = null;
        this.Gold = null;
        this.Diamonds = null;
        this.ClearedStage = 0;
        this.VipLevel = 0;
        this.CombatPower = 0;
        this.GuildName = '';
        this.CurrentStage = 0;
        this.ArenaRank = 0;
        this.AvatarUrl = '';
        this.Country = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 背包物品类别
const ItemCategory = {
    Equipment: 0,
    Consumable: 1,
    Material: 2,
    Quest: 3,
    Currency: 4,
    Other: 5,
};
// 背包物品数据
class InventoryItem {
    constructor() {
        this.ItemId = null;
        this.ItemName = '';
        this.Category = null;
        this.Quantity = 0;
        this.IsBound = false;
        this.ExpireAt = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 背包整体信息
class InventoryInfo {
    constructor() {
        this.Items = [];
        this.LastRefreshTime = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 大厅公告信息
class NoticeMessage {
    constructor() {
        this.Title = '';
        this.Content = '';
        this.StartAt = null;
        this.EndAt = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 大厅概览信息
class LobbyInfo {
    constructor() {
        this.CurrentScene = '';
        this.OnlinePlayerCount = 0;
        this.FeatureEntries = [];
        this.Notices = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 排行榜条目
class LeaderboardEntry {
    constructor() {
        this.Rank = 0;
        this.PlayerId = null;
        this.Nickname = '';
        this.Score = 0;
        this.Level = 0;
        this.CombatPower = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 排行榜整体数据
class LeaderboardInfo {
    constructor() {
        this.BoardType = '';
        this.Entries = [];
        this.RefreshAt = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 奖励物品信息
class RewardItem {
    constructor() {
        this.ItemId = null;
        this.ItemName = '';
        this.Quantity = 0;
        this.RewardType = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 活动信息
class EventInfo {
    constructor() {
        this.EventId = 0;
        this.EventName = '';
        this.Description = '';
        this.StartTime = null;
        this.EndTime = null;
        this.IsLimitedTime = false;
        this.PreviewRewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 阵容槽位信息
class FormationSlot {
    constructor() {
        this.Position = 0;
        this.HeroId = '';
        this.HeroLevel = 0;
        this.StarLevel = 0;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 战斗同步模式（预留实时/回放/权威服务器）
const BattleSyncMode = {
    ServerAuthoritative: 0,
    LockstepInput: 1,
    PlaybackOnly: 2,
};
// 战斗阶段
const BattlePhase = {
    Preparing: 0,
    Running: 1,
    Completed: 2,
    Failed: 3,
};
// 战斗参与方信息
class BattleParticipant {
    constructor() {
        this.PlayerId = null;
        this.Nickname = '';
        this.Level = 0;
        this.CombatPower = 0;
        this.Side = '';
        this.LatencyMs = 0;
        this.Formation = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 简化的战斗玩家信息(兼容客户端缓存字段)
class BattlePlayerInfo {
    constructor() {
        this.PlayerId = null;
        this.Nickname = '';
        this.Level = 0;
        this.CombatPower = 0;
        this.Side = '';
        this.Formation = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 战斗场景信息
class BattleSceneInfo {
    constructor() {
        this.StageId = '';
        this.SceneName = '';
        this.Background = '';
        this.Seed = null;
        this.Weather = '';
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 战斗同步参数/性能调优
class BattleServerTuning {
    constructor() {
        this.TickRate = 0;
        this.FrameDurationMs = 0;
        this.InputDelayFrames = 0;
        this.MaxRollbackFrames = 0;
        this.SyncMode = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 单位快照（权威状态与回放用）
class BattleUnitSnapshot {
    constructor() {
        this.UnitId = '';
        this.TemplateId = '';
        this.Level = 0;
        this.MaxHp = 0;
        this.Hp = 0;
        this.Attack = 0;
        this.Defense = 0;
        this.Speed = 0;
        this.Position = '';
        this.Side = '';
        this.Tags = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 战斗操作指令(用于实时/预测)
class BattleOperation {
    constructor() {
        this.OperationId = '';
        this.ActorId = '';
        this.OperationType = '';
        this.TargetId = '';
        this.Parameters = '';
        this.ClientFrame = 0;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 服务器下发的帧事件/日志
class BattleFrameEvent {
    constructor() {
        this.Frame = 0;
        this.EventType = '';
        this.SourceId = '';
        this.TargetId = '';
        this.Payload = '';
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 一组帧事件与状态快照，用于回放/追帧
class BattleFrameBundle {
    constructor() {
        this.StartFrame = 0;
        this.EndFrame = 0;
        this.Events = [];
        this.StateHash = '';
        this.AuthoritativeSnapshot = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 状态锚点/重连点
class BattleTimelineAnchor {
    constructor() {
        this.Frame = 0;
        this.StateHash = '';
        this.ServerTime = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 战斗结果类型
const BattleResultType = {
    Win: 0,
    Lose: 1,
    Draw: 2,
    Abort: 3,
};
// 战斗统计数据
class BattleStatistic {
    constructor() {
        this.DamageDealt = 0;
        this.DamageTaken = 0;
        this.HealDone = 0;
        this.ShieldProvided = 0;
        this.ComboMax = 0;
        this.Interrupts = 0;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 组队成员信息
class TeamMemberInfo {
    constructor() {
        this.PlayerId = null;
        this.Nickname = '';
        this.Level = 0;
        this.Role = '';
        this.CombatPower = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 通用错误码
const ErrorCode = {
    OK: 0,
    Unknown: 1,
    InvalidRequest: 2,
    InvalidToken: 3,
    InsufficientResource: 4,
    ConfigNotFound: 5,
    FeatureLocked: 6,
    Cooldown: 7,
    Duplicate: 8,
    NotFound: 9,
    AlreadyOwned: 10,
    BagFull: 11,
};
// 通用货币/资源类型
const ResourceType = {
    Gold: 0,
    Diamond: 1,
    PlayerExp: 2,
    HeroExp: 3,
    Dust: 4,
    ArenaTicket: 5,
    GuildCoin: 6,
    FriendCoin: 7,
    Energy: 8,
    TowerTicket: 9,
    EventCurrency: 10,
    Other: 11,
};
// 资源变更信息（用于结算、同步）
class ResourceChange {
    constructor() {
        this.Type = null;
        this.Delta = null;
        this.NewValue = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 背包增量更新（避免每次全量下发）
class InventoryDelta {
    constructor() {
        this.UpdatedItems = [];
        this.RemovedItemIds = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 消耗物品信息（强化/升级等使用）
class ItemCost {
    constructor() {
        this.ItemId = null;
        this.Quantity = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 英雄品质
const HeroQuality = {
    Common: 0,
    Rare: 1,
    Elite: 2,
    Legendary: 3,
    Mythic: 4,
    Ascended: 5,
};
// 英雄职业/定位
const HeroClass = {
    Tank: 0,
    Warrior: 1,
    Mage: 2,
    Ranger: 3,
    Support: 4,
    Assassin: 5,
    Other: 6,
};
// 英雄阵营（具体与策划表对应）
const HeroFaction = {
    Faction1: 0,
    Faction2: 1,
    Faction3: 2,
    Faction4: 3,
    Faction5: 4,
    Faction6: 5,
    Other: 6,
};
// 英雄技能信息
class HeroSkillInfo {
    constructor() {
        this.SkillId = '';
        this.Level = 0;
        this.IsUnlocked = false;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 英雄装备槽位
class HeroEquipSlot {
    constructor() {
        this.SlotType = '';
        this.EquipmentId = null;
        this.IsLocked = false;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 英雄完整数据
class HeroInfo {
    constructor() {
        this.HeroId = null;
        this.TemplateId = '';
        this.Level = 0;
        this.StarLevel = 0;
        this.Quality = null;
        this.Faction = null;
        this.Class = null;
        this.CombatPower = 0;
        this.Exp = null;
        this.IsLocked = false;
        this.IsInFormation = false;
        this.Skills = [];
        this.EquipSlots = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 装备品质
const EquipmentQuality = {
    Common: 0,
    Rare: 1,
    Elite: 2,
    Legendary: 3,
    Mythic: 4,
    Ascended: 5,
};
// 属性键值对
class StatPair {
    constructor() {
        this.Key = '';
        this.Value = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 装备详细信息（与 InventoryItem.ItemId 对应）
class EquipmentInfo {
    constructor() {
        this.EquipmentId = null;
        this.TemplateId = '';
        this.Level = 0;
        this.Rank = 0;
        this.Quality = null;
        this.MainStat = null;
        this.SubStats = [];
        this.Locked = false;
        this.EquippedHeroId = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 主线关卡信息
class StageInfo {
    constructor() {
        this.StageId = '';
        this.ChapterId = 0;
        this.Index = 0;
        this.Stars = 0;
        this.IsUnlocked = false;
        this.IsPassed = false;
        this.FirstPassRewardClaimed = false;
        this.MaxStarRewardClaimed = false;
        this.BestDurationFrames = 0;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 主线/推图整体进度
class CampaignInfo {
    constructor() {
        this.CurrentStageId = '';
        this.MaxUnlockedStageId = '';
        this.Stages = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 挂机收益信息
class AfkRewardInfo {
    constructor() {
        this.LastCalcTime = null;
        this.LastClaimTime = null;
        this.AccumulateSeconds = 0;
        this.MaxAccumulateSeconds = 0;
        this.IsFull = false;
        this.PreviewRewards = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 商店类型
const ShopType = {
    Normal: 0,
    Arena: 1,
    Guild: 2,
    Friend: 3,
    BlackMarket: 4,
    Event: 5,
    Daily: 6,
    Weekly: 7,
};
// 单个商店格子信息
class ShopItemInfo {
    constructor() {
        this.ShopId = 0;
        this.ShopType = null;
        this.SlotIndex = 0;
        this.Goods = null;
        this.PriceType = null;
        this.PriceValue = 0;
        this.BuyLimit = 0;
        this.BoughtCount = 0;
        this.RefreshAt = null;
        this.IsSoldOut = false;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 召唤池类型
const GachaPoolType = {
    Normal: 0,
    Advanced: 1,
    Faction: 2,
    Friend: 3,
    Limited: 4,
    Beginner: 5,
};
// 抽卡池信息
class GachaPoolInfo {
    constructor() {
        this.PoolId = 0;
        this.Name = '';
        this.PoolType = null;
        this.SingleCostType = null;
        this.SingleCostValue = 0;
        this.TenCostType = null;
        this.TenCostValue = 0;
        this.FreeCdSeconds = 0;
        this.FreeAvailable = false;
        this.TodayUsedTimes = 0;
        this.PityCount = 0;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 抽卡结果
class GachaResult {
    constructor() {
        this.PoolId = 0;
        this.Times = 0;
        this.Rewards = [];
        this.NewHeroes = [];
        this.ResourceChanges = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 任务类型
const TaskType = {
    Daily: 0,
    Weekly: 1,
    Main: 2,
    Guide: 3,
    Event: 4,
};
// 任务状态/成就状态通用
const TaskStatus = {
    InProgress: 0,
    Completed: 1,
    RewardTaken: 2,
    Expired: 3,
};
// 任务信息
class TaskInfo {
    constructor() {
        this.TaskId = 0;
        this.Type = null;
        this.Name = '';
        this.Description = '';
        this.Progress = 0;
        this.Target = 0;
        this.Status = null;
        this.ExpireAt = null;
        this.Rewards = [];
        this.NextTaskId = 0;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 成就信息
class AchievementInfo {
    constructor() {
        this.AchievementId = 0;
        this.Name = '';
        this.Description = '';
        this.Progress = 0;
        this.Target = 0;
        this.Status = null;
        this.Rewards = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 好友状态
const FriendStatus = {
    Normal: 0,
    Blacklisted: 1,
    Blocked: 2,
};
// 好友基础信息
class FriendInfo {
    constructor() {
        this.PlayerId = null;
        this.Nickname = '';
        this.Level = 0;
        this.VipLevel = 0;
        this.CombatPower = 0;
        this.AvatarUrl = '';
        this.Signature = '';
        this.Country = '';
        this.IsOnline = false;
        this.LastOnlineTime = null;
        this.FriendshipPoint = 0;
        this.Status = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 好友申请信息
class FriendRequestInfo {
    constructor() {
        this.RequestId = null;
        this.FromPlayer = null;
        this.ToPlayerId = null;
        this.Message = '';
        this.CreatedAt = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 聊天频道
const ChatChannel = {
    World: 0,
    Guild: 1,
    Team: 2,
    Private: 3,
    System: 4,
};
// 聊天消息
class ChatMessage {
    constructor() {
        this.MessageId = null;
        this.Channel = null;
        this.FromPlayerId = null;
        this.FromNickname = '';
        this.FromLevel = 0;
        this.FromVipLevel = 0;
        this.FromAvatarUrl = '';
        this.ToPlayerId = null;
        this.Content = '';
        this.SendTime = null;
        this.Extra = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 邮件状态
const MailStatus = {
    Unread: 0,
    Read: 1,
    Received: 2,
    Deleted: 3,
};
// 邮件信息
class MailInfo {
    constructor() {
        this.MailId = null;
        this.Title = '';
        this.Content = '';
        this.SenderName = '';
        this.SenderId = null;
        this.SendTime = null;
        this.ExpireAt = null;
        this.Status = null;
        this.Category = '';
        this.Attachments = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 公会成员职位
const GuildRole = {
    Member: 0,
    Elder: 1,
    Officer: 2,
    Leader: 3,
};
// 公会基础信息
class GuildInfo {
    constructor() {
        this.GuildId = null;
        this.Name = '';
        this.Badge = '';
        this.Level = 0;
        this.MemberCount = 0;
        this.MemberLimit = 0;
        this.LeaderName = '';
        this.Power = null;
        this.Notice = '';
        this.RequirePower = 0;
        this.RequireVerify = false;
        this.Country = '';
        this.CreateTime = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 公会成员信息
class GuildMemberInfo {
    constructor() {
        this.PlayerId = null;
        this.Nickname = '';
        this.Level = 0;
        this.VipLevel = 0;
        this.CombatPower = 0;
        this.Role = null;
        this.JoinTime = null;
        this.LastOnlineTime = null;
        this.Contribution = 0;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 公会申请
class GuildApplyInfo {
    constructor() {
        this.ApplyId = null;
        this.Player = null;
        this.ApplyTime = null;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 竞技场对手信息
class ArenaOpponentInfo {
    constructor() {
        this.PlayerId = null;
        this.Nickname = '';
        this.Level = 0;
        this.VipLevel = 0;
        this.CombatPower = 0;
        this.Rank = 0;
        this.AvatarUrl = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 竞技场信息
class ArenaInfo {
    constructor() {
        this.Rank = 0;
        this.BestRank = 0;
        this.Score = 0;
        this.TodayFightCount = 0;
        this.TodayBuyCount = 0;
        this.Tickets = 0;
        this.RefreshAt = null;
        this.Rivals = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 竞技场战报
class ArenaBattleRecord {
    constructor() {
        this.RecordId = null;
        this.Time = null;
        this.Attacker = null;
        this.Defender = null;
        this.Result = null;
        this.ReplayId = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 爬塔层数信息
class TowerFloorInfo {
    constructor() {
        this.Floor = 0;
        this.IsPassed = false;
        this.Stars = 0;
        this.RewardTaken = false;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 爬塔/试炼信息
class TowerInfo {
    constructor() {
        this.TowerId = 0;
        this.Name = '';
        this.CurrentFloor = 0;
        this.MaxFloor = 0;
        this.ResetCount = 0;
        this.LastResetTime = null;
        this.Floors = [];
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 红点提示数据
class RedPointInfo {
    constructor() {
        this.Module = '';
        this.SubModule = '';
        this.Count = 0;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// GM 命令执行结果
class GMCommandResult {
    constructor() {
        this.Command = '';
        this.Success = false;
        this.Message = '';
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 队伍信息
class TeamInfo {
    constructor() {
        this.TeamId = '';
        this.LeaderId = null;
        this.Members = [];
        this.CreateTime = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 组队邀请信息
class TeamInviteInfo {
    constructor() {
        this.InviteId = '';
        this.TeamId = '';
        this.FromPlayerId = null;
        this.ToPlayerId = null;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 世界 Boss 信息
class WorldBossInfo {
    constructor() {
        this.BossId = '';
        this.BossName = '';
        this.Hp = null;
        this.MaxHp = null;
        this.StartAt = null;
        this.EndAt = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 公会活动信息
class GuildActivityInfo {
    constructor() {
        this.ActivityId = '';
        this.Name = '';
        this.StartAt = null;
        this.EndAt = null;
        this.Status = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

module.exports = {
    DeviceInfo,
    AuthToken,
    ServerInfo,
    PlayerProfile,
    ItemCategory,
    InventoryItem,
    InventoryInfo,
    NoticeMessage,
    LobbyInfo,
    LeaderboardEntry,
    LeaderboardInfo,
    RewardItem,
    EventInfo,
    FormationSlot,
    BattleSyncMode,
    BattlePhase,
    BattleParticipant,
    BattlePlayerInfo,
    BattleSceneInfo,
    BattleServerTuning,
    BattleUnitSnapshot,
    BattleOperation,
    BattleFrameEvent,
    BattleFrameBundle,
    BattleTimelineAnchor,
    BattleResultType,
    BattleStatistic,
    TeamMemberInfo,
    ErrorCode,
    ResourceType,
    ResourceChange,
    InventoryDelta,
    ItemCost,
    HeroQuality,
    HeroClass,
    HeroFaction,
    HeroSkillInfo,
    HeroEquipSlot,
    HeroInfo,
    EquipmentQuality,
    StatPair,
    EquipmentInfo,
    StageInfo,
    CampaignInfo,
    AfkRewardInfo,
    ShopType,
    ShopItemInfo,
    GachaPoolType,
    GachaPoolInfo,
    GachaResult,
    TaskType,
    TaskStatus,
    TaskInfo,
    AchievementInfo,
    FriendStatus,
    FriendInfo,
    FriendRequestInfo,
    ChatChannel,
    ChatMessage,
    MailStatus,
    MailInfo,
    GuildRole,
    GuildInfo,
    GuildMemberInfo,
    GuildApplyInfo,
    ArenaOpponentInfo,
    ArenaInfo,
    ArenaBattleRecord,
    TowerFloorInfo,
    TowerInfo,
    RedPointInfo,
    GMCommandResult,
    TeamInfo,
    TeamInviteInfo,
    WorldBossInfo,
    GuildActivityInfo,
};
