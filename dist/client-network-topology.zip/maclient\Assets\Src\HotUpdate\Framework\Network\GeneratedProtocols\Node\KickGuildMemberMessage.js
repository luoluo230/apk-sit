// 自动生成的协议文件

// 定义协议类


// 踢出公会成员
class KickGuildMember_c2s {
    constructor() {
        this.TargetPlayerId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 踢出成员结果
class KickGuildMember_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    KickGuildMember_c2s,
    KickGuildMember_s2c,
};
