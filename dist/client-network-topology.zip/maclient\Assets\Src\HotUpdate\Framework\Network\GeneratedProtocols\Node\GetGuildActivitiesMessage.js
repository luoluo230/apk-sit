// 自动生成的协议文件

// 定义协议类


// 获取公会活动列表
class GetGuildActivities_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 获取公会活动列表结果
class GetGuildActivities_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Activities = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetGuildActivities_c2s,
    GetGuildActivities_s2c,
};
