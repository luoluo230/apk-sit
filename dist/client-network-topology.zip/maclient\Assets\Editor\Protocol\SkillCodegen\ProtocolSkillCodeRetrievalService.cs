using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public sealed class ProtocolSkillCodeRetrievalService
{
    private readonly string _repoRoot;

    public ProtocolSkillCodeRetrievalService(string repoRoot)
    {
        _repoRoot = repoRoot;
    }

    public void Enrich(ProtocolSkillContext context)
    {
        if (context == null || string.IsNullOrWhiteSpace(_repoRoot) || !Directory.Exists(_repoRoot))
        {
            return;
        }

        string[] keywords = new[] { context.ProtocolName, context.Module, context.RequestName, context.ResponseName }
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();
        var hits = new List<string>();
        foreach (string file in Directory.GetFiles(_repoRoot, "*.cs", SearchOption.AllDirectories).Take(4000))
        {
            if (IsIgnored(file)) continue;
            string name = Path.GetFileNameWithoutExtension(file);
            if (keywords.Any(keyword => name.IndexOf(keyword.Replace("_c2s", string.Empty).Replace("_s2c", string.Empty), StringComparison.OrdinalIgnoreCase) >= 0))
            {
                hits.Add(Relative(file));
            }
            if (hits.Count >= 12) break;
        }

        context.RetrievedCodeSummary = hits.Count == 0 ? "No strong code reference was found." : string.Join("\n", hits);
        context.ClientReferencePaths.AddRange(hits.Where(path => path.IndexOf("Assets/", StringComparison.OrdinalIgnoreCase) >= 0));
        context.ServerReferencePaths.AddRange(hits.Where(path => path.IndexOf("game-server", StringComparison.OrdinalIgnoreCase) >= 0));
    }

    private bool IsIgnored(string path)
    {
        return path.IndexOf("\\Library\\", StringComparison.OrdinalIgnoreCase) >= 0
            || path.IndexOf("\\Temp\\", StringComparison.OrdinalIgnoreCase) >= 0
            || path.IndexOf("\\obj\\", StringComparison.OrdinalIgnoreCase) >= 0;
    }

    private string Relative(string path)
    {
        return path.StartsWith(_repoRoot, StringComparison.OrdinalIgnoreCase) ? path.Substring(_repoRoot.Length).TrimStart('\\', '/') : path;
    }
}
