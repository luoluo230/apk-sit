// 自动生成的协议文件

// 定义协议类


// 获取任务列表(包含每日/每周/主线等)
class GetTaskList_c2s {
    constructor() {
        this.TaskType = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 任务列表响应
class GetTaskList_s2c {
    constructor() {
        this.Tasks = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetTaskList_c2s,
    GetTaskList_s2c,
};
