// 自动生成的协议文件

// 定义协议类


// 获取自身公会信息及成员列表
class GetGuildInfo_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 公会信息响应
class GetGuildInfo_s2c {
    constructor() {
        this.Guild = null;
        this.Members = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetGuildInfo_c2s,
    GetGuildInfo_s2c,
};
