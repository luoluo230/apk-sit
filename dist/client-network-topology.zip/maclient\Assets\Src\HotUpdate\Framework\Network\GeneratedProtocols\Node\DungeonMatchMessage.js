// 自动生成的协议文件

// 定义协议类


// 副本匹配请求
class DungeonMatch_c2s {
    constructor() {
        this.DungeonId = 0;
        this.Difficulty = '';
        this.Formation = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 副本匹配响应
class DungeonMatch_s2c {
    constructor() {
        this.Success = false;
        this.MatchId = '';
        this.EstimatedWaitSeconds = 0;
        this.Team = [];
        this.ServerAddress = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DungeonMatch_c2s,
    DungeonMatch_s2c,
};
