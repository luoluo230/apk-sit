﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 成就信息
/// </summary>
public class AchievementInfo
{
    /// <summary>
    /// 成就 ID
    /// </summary>
    public int AchievementId { get; set; }
    /// <summary>
    /// 名称
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// 描述
    /// </summary>
    public string Description { get; set; }
    /// <summary>
    /// 当前进度
    /// </summary>
    public int Progress { get; set; }
    /// <summary>
    /// 完成目标
    /// </summary>
    public int Target { get; set; }
    /// <summary>
    /// 状态
    /// </summary>
    public TaskStatus Status { get; set; }
    /// <summary>
    /// 奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 挂机收益信息
/// </summary>
public class AfkRewardInfo
{
    /// <summary>
    /// 服务器上次结算时间
    /// </summary>
    public long LastCalcTime { get; set; }
    /// <summary>
    /// 上次领取时间
    /// </summary>
    public long LastClaimTime { get; set; }
    /// <summary>
    /// 累计离线/挂机秒数(用于展示)
    /// </summary>
    public int AccumulateSeconds { get; set; }
    /// <summary>
    /// 可累计的最大秒数(溢出封顶)
    /// </summary>
    public int MaxAccumulateSeconds { get; set; }
    /// <summary>
    /// 是否已达上限
    /// </summary>
    public bool IsFull { get; set; }
    /// <summary>
    /// 当前未领的预览奖励
    /// </summary>
    public RewardItem[] PreviewRewards { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 竞技场战报
/// </summary>
public class ArenaBattleRecord
{
    /// <summary>
    /// 战报 ID
    /// </summary>
    public long RecordId { get; set; }
    /// <summary>
    /// 战斗时间
    /// </summary>
    public long Time { get; set; }
    /// <summary>
    /// 进攻方
    /// </summary>
    public FriendInfo Attacker { get; set; }
    /// <summary>
    /// 防守方
    /// </summary>
    public FriendInfo Defender { get; set; }
    /// <summary>
    /// 战斗结果(相对进攻方)
    /// </summary>
    public BattleResultType Result { get; set; }
    /// <summary>
    /// 回放 ID(可复用 BattleId 或自定义)
    /// </summary>
    public string ReplayId { get; set; }
}


/// <summary>
/// 竞技场信息
/// </summary>
public class ArenaInfo
{
    /// <summary>
    /// 当前排名(0表示未上榜)
    /// </summary>
    public int Rank { get; set; }
    /// <summary>
    /// 历史最高排名
    /// </summary>
    public int BestRank { get; set; }
    /// <summary>
    /// 积分(如有天梯)
    /// </summary>
    public int Score { get; set; }
    /// <summary>
    /// 今日已挑战次数
    /// </summary>
    public int TodayFightCount { get; set; }
    /// <summary>
    /// 今日已购买次数
    /// </summary>
    public int TodayBuyCount { get; set; }
    /// <summary>
    /// 剩余挑战券/次数
    /// </summary>
    public int Tickets { get; set; }
    /// <summary>
    /// 对手刷新时间
    /// </summary>
    public long RefreshAt { get; set; }
    /// <summary>
    /// 可挑战对手列表
    /// </summary>
    public ArenaOpponentInfo[] Rivals { get; set; }
}


/// <summary>
/// 竞技场对手信息
/// </summary>
public class ArenaOpponentInfo
{
    /// <summary>
    /// 玩家 ID
    /// </summary>
    public long PlayerId { get; set; }
    /// <summary>
    /// 昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// VIP 等级
    /// </summary>
    public int VipLevel { get; set; }
    /// <summary>
    /// 战力
    /// </summary>
    public int CombatPower { get; set; }
    /// <summary>
    /// 当前排名
    /// </summary>
    public int Rank { get; set; }
    /// <summary>
    /// 头像
    /// </summary>
    public string AvatarUrl { get; set; }
}


/// <summary>
/// 认证 Token 信息
/// </summary>
public class AuthToken
{
    /// <summary>
    /// Token 字符串
    /// </summary>
    public string Token { get; set; }
    /// <summary>
    /// 过期时间(Unix 时间戳)
    /// </summary>
    public long ExpireAt { get; set; }
}


/// <summary>
/// 战斗一致性校验信息
/// </summary>
public class BattleChecksumInfo
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 校验 Tick
    /// </summary>
    public int Tick { get; set; }
    /// <summary>
    /// 校验帧号
    /// </summary>
    public int Frame { get; set; }
    /// <summary>
    /// 状态哈希
    /// </summary>
    public string StateHash { get; set; }
    /// <summary>
    /// 规则版本
    /// </summary>
    public string RuleVersion { get; set; }
    /// <summary>
    /// 配置版本
    /// </summary>
    public string ConfigVersion { get; set; }
    /// <summary>
    /// 随机调用计数
    /// </summary>
    public long RandomCounter { get; set; }
    /// <summary>
    /// 客户端时间戳
    /// </summary>
    public long ClientTime { get; set; }
    /// <summary>
    /// 服务器时间戳
    /// </summary>
    public long ServerTime { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 一组帧事件与状态快照，用于回放/追帧
/// </summary>
public class BattleFrameBundle
{
    /// <summary>
    /// 起始帧
    /// </summary>
    public int StartFrame { get; set; }
    /// <summary>
    /// 结束帧
    /// </summary>
    public int EndFrame { get; set; }
    /// <summary>
    /// 事件列表
    /// </summary>
    public BattleFrameEvent[] Events { get; set; }
    /// <summary>
    /// 状态哈希(客户端校验)
    /// </summary>
    public string StateHash { get; set; }
    /// <summary>
    /// 权威单位状态
    /// </summary>
    public BattleUnitSnapshot[] AuthoritativeSnapshot { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 服务器下发的帧事件/日志
/// </summary>
public class BattleFrameEvent
{
    /// <summary>
    /// 帧索引
    /// </summary>
    public int Frame { get; set; }
    /// <summary>
    /// 事件类型(技能/死亡等)
    /// </summary>
    public string EventType { get; set; }
    /// <summary>
    /// 来源单位
    /// </summary>
    public string SourceId { get; set; }
    /// <summary>
    /// 目标单位/阵营
    /// </summary>
    public string TargetId { get; set; }
    /// <summary>
    /// 事件数据(JSON)
    /// </summary>
    public string Payload { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗操作指令(用于实时/预测)
/// </summary>
public class BattleOperation
{
    /// <summary>
    /// 客户端操作唯一 ID
    /// </summary>
    public string OperationId { get; set; }
    /// <summary>
    /// 操作单位 ID
    /// </summary>
    public string ActorId { get; set; }
    /// <summary>
    /// 操作类型(技能/移动等)
    /// </summary>
    public string OperationType { get; set; }
    /// <summary>
    /// 目标 ID
    /// </summary>
    public string TargetId { get; set; }
    /// <summary>
    /// 参数(JSON)
    /// </summary>
    public string Parameters { get; set; }
    /// <summary>
    /// 客户端帧号(用于lockstep)
    /// </summary>
    public int ClientFrame { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗参与方信息
/// </summary>
public class BattleParticipant
{
    /// <summary>
    /// 玩家 ID
    /// </summary>
    public long PlayerId { get; set; }
    /// <summary>
    /// 玩家昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 玩家等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 战斗力
    /// </summary>
    public int CombatPower { get; set; }
    /// <summary>
    /// 阵营(Ally/Enemy等)
    /// </summary>
    public string Side { get; set; }
    /// <summary>
    /// 网络延迟预估
    /// </summary>
    public int LatencyMs { get; set; }
    /// <summary>
    /// 阵容配置
    /// </summary>
    public FormationSlot[] Formation { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗阶段
/// </summary>
public enum BattlePhase
{
    Preparing,
    Running,
    Completed,
    Failed,
}


/// <summary>
/// 简化的战斗玩家信息(兼容客户端缓存字段)
/// </summary>
public class BattlePlayerInfo
{
    /// <summary>
    /// 玩家 ID
    /// </summary>
    public long PlayerId { get; set; }
    /// <summary>
    /// 玩家昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 玩家等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 战斗力
    /// </summary>
    public int CombatPower { get; set; }
    /// <summary>
    /// 阵营(Ally/Enemy等)
    /// </summary>
    public string Side { get; set; }
    /// <summary>
    /// 出战阵容
    /// </summary>
    public FormationSlot[] Formation { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗协议通用 ACK
/// </summary>
public class BattleProtocolAck
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 错误码
    /// </summary>
    public BattleProtocolErrorCode ErrorCode { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 战斗 ID(可选)
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗专用协议错误码
/// </summary>
public enum BattleProtocolErrorCode
{
    OK,
    InvalidBattleId,
    FrameTooOld,
    FrameTooNew,
    ChecksumMismatch,
    ResyncDenied,
    ReplayNotFound,
    ReplayCorrupted,
    SpectatorDenied,
    PermissionDenied,
    UnsupportedSyncMode,
    Unknown,
}


/// <summary>
/// 战斗回放分片数据
/// </summary>
public class BattleReplayChunk
{
    /// <summary>
    /// 回放 ID
    /// </summary>
    public string ReplayId { get; set; }
    /// <summary>
    /// 分片序号(0开始)
    /// </summary>
    public int ChunkIndex { get; set; }
    /// <summary>
    /// 总分片数
    /// </summary>
    public int TotalChunks { get; set; }
    /// <summary>
    /// 分片起始帧
    /// </summary>
    public int StartFrame { get; set; }
    /// <summary>
    /// 分片结束帧
    /// </summary>
    public int EndFrame { get; set; }
    /// <summary>
    /// 是否压缩
    /// </summary>
    public bool Compressed { get; set; }
    /// <summary>
    /// 分片载荷(Base64)
    /// </summary>
    public string PayloadBase64 { get; set; }
    /// <summary>
    /// 分片哈希
    /// </summary>
    public string PayloadHash { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗回放定位信息
/// </summary>
public class BattleReplayLocator
{
    /// <summary>
    /// 回放 ID
    /// </summary>
    public string ReplayId { get; set; }
    /// <summary>
    /// 对象存储键
    /// </summary>
    public string StorageKey { get; set; }
    /// <summary>
    /// 下载地址(可选)
    /// </summary>
    public string SignedUrl { get; set; }
    /// <summary>
    /// 地址过期时间
    /// </summary>
    public long ExpireAt { get; set; }
    /// <summary>
    /// 分片总数
    /// </summary>
    public int ChunkCount { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗回放元数据
/// </summary>
public class BattleReplayMeta
{
    /// <summary>
    /// 回放 ID
    /// </summary>
    public string ReplayId { get; set; }
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 所属玩家 ID
    /// </summary>
    public long OwnerPlayerId { get; set; }
    /// <summary>
    /// 规则版本
    /// </summary>
    public string RuleVersion { get; set; }
    /// <summary>
    /// 配置版本
    /// </summary>
    public string ConfigVersion { get; set; }
    /// <summary>
    /// 协议版本
    /// </summary>
    public string ProtocolVersion { get; set; }
    /// <summary>
    /// 同步模式
    /// </summary>
    public BattleSyncMode SyncMode { get; set; }
    /// <summary>
    /// 开始时间
    /// </summary>
    public long StartAt { get; set; }
    /// <summary>
    /// 结束时间
    /// </summary>
    public long EndAt { get; set; }
    /// <summary>
    /// 持续帧数
    /// </summary>
    public int DurationFrames { get; set; }
    /// <summary>
    /// 最终结果
    /// </summary>
    public BattleResultType FinalResult { get; set; }
    /// <summary>
    /// 最终状态哈希
    /// </summary>
    public string FinalStateHash { get; set; }
    /// <summary>
    /// 存储对象键
    /// </summary>
    public string StorageKey { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗结果类型
/// </summary>
public enum BattleResultType
{
    Win,
    Lose,
    Draw,
    Abort,
}


/// <summary>
/// 战斗重同步原因
/// </summary>
public enum BattleResyncReason
{
    ChecksumMismatch,
    FrameGapTooLarge,
    Reconnect,
    ManualRequest,
    ServerForceResync,
    Unknown,
}


/// <summary>
/// 战斗重同步请求数据
/// </summary>
public class BattleResyncRequestData
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 请求起始帧
    /// </summary>
    public int FromFrame { get; set; }
    /// <summary>
    /// 请求结束帧(可为0表示由服务端决定)
    /// </summary>
    public int ToFrame { get; set; }
    /// <summary>
    /// 重同步原因
    /// </summary>
    public BattleResyncReason Reason { get; set; }
    /// <summary>
    /// 客户端当前校验信息
    /// </summary>
    public BattleChecksumInfo ClientChecksum { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗重同步响应数据
/// </summary>
public class BattleResyncResponseData
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 错误码
    /// </summary>
    public BattleProtocolErrorCode ErrorCode { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 返回起始帧
    /// </summary>
    public int FromFrame { get; set; }
    /// <summary>
    /// 返回结束帧
    /// </summary>
    public int ToFrame { get; set; }
    /// <summary>
    /// 补帧数据
    /// </summary>
    public BattleFrameBundle[] Frames { get; set; }
    /// <summary>
    /// 最新锚点
    /// </summary>
    public BattleTimelineAnchor Anchor { get; set; }
    /// <summary>
    /// 服务器校验信息
    /// </summary>
    public BattleChecksumInfo ServerChecksum { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗场景信息
/// </summary>
public class BattleSceneInfo
{
    /// <summary>
    /// 关卡 ID
    /// </summary>
    public string StageId { get; set; }
    /// <summary>
    /// 场景名称
    /// </summary>
    public string SceneName { get; set; }
    /// <summary>
    /// 背景资源
    /// </summary>
    public string Background { get; set; }
    /// <summary>
    /// 随机种子
    /// </summary>
    public long Seed { get; set; }
    /// <summary>
    /// 天气/光照等表现
    /// </summary>
    public string Weather { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗同步参数/性能调优
/// </summary>
public class BattleServerTuning
{
    /// <summary>
    /// 每秒 tick 数
    /// </summary>
    public int TickRate { get; set; }
    /// <summary>
    /// 一帧时长(毫秒)
    /// </summary>
    public int FrameDurationMs { get; set; }
    /// <summary>
    /// 输入延迟缓存帧数
    /// </summary>
    public int InputDelayFrames { get; set; }
    /// <summary>
    /// 最大回滚帧数(实时模式预留)
    /// </summary>
    public int MaxRollbackFrames { get; set; }
    /// <summary>
    /// 同步模式
    /// </summary>
    public BattleSyncMode SyncMode { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 观战会话信息
/// </summary>
public class BattleSpectatorSession
{
    /// <summary>
    /// 观战会话 ID
    /// </summary>
    public string SessionId { get; set; }
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 观战玩家 ID
    /// </summary>
    public long ViewerPlayerId { get; set; }
    /// <summary>
    /// 主机时间
    /// </summary>
    public long HostServerTime { get; set; }
    /// <summary>
    /// 接入起始帧
    /// </summary>
    public int StartFrame { get; set; }
    /// <summary>
    /// 延迟模式(LowLatency/Stable)
    /// </summary>
    public string LatencyMode { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗统计数据
/// </summary>
public class BattleStatistic
{
    /// <summary>
    /// 造成伤害
    /// </summary>
    public int DamageDealt { get; set; }
    /// <summary>
    /// 承受伤害
    /// </summary>
    public int DamageTaken { get; set; }
    /// <summary>
    /// 治疗量
    /// </summary>
    public int HealDone { get; set; }
    /// <summary>
    /// 护盾值
    /// </summary>
    public int ShieldProvided { get; set; }
    /// <summary>
    /// 最高连击
    /// </summary>
    public int ComboMax { get; set; }
    /// <summary>
    /// 打断次数
    /// </summary>
    public int Interrupts { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗同步健康度信息
/// </summary>
public class BattleSyncHealth
{
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 最后确认帧
    /// </summary>
    public int LastConfirmedFrame { get; set; }
    /// <summary>
    /// 客户端当前帧
    /// </summary>
    public int ClientFrame { get; set; }
    /// <summary>
    /// 服务器当前帧
    /// </summary>
    public int ServerFrame { get; set; }
    /// <summary>
    /// 输入队列深度
    /// </summary>
    public int InputQueueDepth { get; set; }
    /// <summary>
    /// 是否待重同步
    /// </summary>
    public bool PendingResync { get; set; }
    /// <summary>
    /// 网络 RTT 毫秒
    /// </summary>
    public int NetworkRttMs { get; set; }
    /// <summary>
    /// 丢包率(0~1)
    /// </summary>
    public float PacketLossRate { get; set; }
    /// <summary>
    /// 网络抖动毫秒
    /// </summary>
    public int JitterMs { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 战斗同步模式（预留实时/回放/权威服务器）
/// </summary>
public enum BattleSyncMode
{
    ServerAuthoritative,
    LockstepInput,
    PlaybackOnly,
}


/// <summary>
/// 状态锚点/重连点
/// </summary>
public class BattleTimelineAnchor
{
    /// <summary>
    /// 锚点帧
    /// </summary>
    public int Frame { get; set; }
    /// <summary>
    /// 状态哈希
    /// </summary>
    public string StateHash { get; set; }
    /// <summary>
    /// 服务器时间戳(ms)
    /// </summary>
    public long ServerTime { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 单位快照（权威状态与回放用）
/// </summary>
public class BattleUnitSnapshot
{
    /// <summary>
    /// 单位唯一标识
    /// </summary>
    public string UnitId { get; set; }
    /// <summary>
    /// 美术/策划模板 ID
    /// </summary>
    public string TemplateId { get; set; }
    /// <summary>
    /// 等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 最大生命
    /// </summary>
    public int MaxHp { get; set; }
    /// <summary>
    /// 当前生命
    /// </summary>
    public int Hp { get; set; }
    /// <summary>
    /// 攻击
    /// </summary>
    public int Attack { get; set; }
    /// <summary>
    /// 防御
    /// </summary>
    public int Defense { get; set; }
    /// <summary>
    /// 速度
    /// </summary>
    public int Speed { get; set; }
    /// <summary>
    /// 站位/坐标
    /// </summary>
    public string Position { get; set; }
    /// <summary>
    /// 阵营
    /// </summary>
    public string Side { get; set; }
    /// <summary>
    /// 标签(如boss/dps)
    /// </summary>
    public string[] Tags { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 主线/推图整体进度
/// </summary>
public class CampaignInfo
{
    /// <summary>
    /// 当前正在推进的关卡 ID
    /// </summary>
    public string CurrentStageId { get; set; }
    /// <summary>
    /// 已解锁的最高关卡 ID
    /// </summary>
    public string MaxUnlockedStageId { get; set; }
    /// <summary>
    /// 关卡进度列表
    /// </summary>
    public StageInfo[] Stages { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 聊天频道
/// </summary>
public enum ChatChannel
{
    World,
    Guild,
    Team,
    Private,
    System,
}


/// <summary>
/// 聊天消息
/// </summary>
public class ChatMessage
{
    /// <summary>
    /// 消息 ID
    /// </summary>
    public long MessageId { get; set; }
    /// <summary>
    /// 频道
    /// </summary>
    public ChatChannel Channel { get; set; }
    /// <summary>
    /// 发送者 ID
    /// </summary>
    public long FromPlayerId { get; set; }
    /// <summary>
    /// 发送者昵称
    /// </summary>
    public string FromNickname { get; set; }
    /// <summary>
    /// 发送者等级
    /// </summary>
    public int FromLevel { get; set; }
    /// <summary>
    /// 发送者 VIP
    /// </summary>
    public int FromVipLevel { get; set; }
    /// <summary>
    /// 发送者头像
    /// </summary>
    public string FromAvatarUrl { get; set; }
    /// <summary>
    /// 私聊目标 ID(其它频道为0)
    /// </summary>
    public long ToPlayerId { get; set; }
    /// <summary>
    /// 文本内容
    /// </summary>
    public string Content { get; set; }
    /// <summary>
    /// 发送时间戳
    /// </summary>
    public long SendTime { get; set; }
    /// <summary>
    /// 额外数据(JSON，表情/跑马灯等)
    /// </summary>
    public string Extra { get; set; }
}


/// <summary>
/// 客户端设备信息
/// </summary>
public class DeviceInfo
{
    /// <summary>
    /// 平台(例如 iOS/Android/PC)
    /// </summary>
    public string Platform { get; set; }
    /// <summary>
    /// 设备唯一标识
    /// </summary>
    public string DeviceId { get; set; }
    /// <summary>
    /// 客户端版本号
    /// </summary>
    public string ClientVersion { get; set; }
}


/// <summary>
/// 装备详细信息（与 InventoryItem.ItemId 对应）
/// </summary>
public class EquipmentInfo
{
    /// <summary>
    /// 装备唯一 ID，对应背包物品 ID
    /// </summary>
    public long EquipmentId { get; set; }
    /// <summary>
    /// 装备配置 ID
    /// </summary>
    public string TemplateId { get; set; }
    /// <summary>
    /// 强化等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 阶级/锻造等级
    /// </summary>
    public int Rank { get; set; }
    /// <summary>
    /// 品质
    /// </summary>
    public EquipmentQuality Quality { get; set; }
    /// <summary>
    /// 主属性
    /// </summary>
    public StatPair MainStat { get; set; }
    /// <summary>
    /// 副属性
    /// </summary>
    public StatPair[] SubStats { get; set; }
    /// <summary>
    /// 是否锁定
    /// </summary>
    public bool Locked { get; set; }
    /// <summary>
    /// 当前佩戴该装备的英雄 ID (0表示未佩戴)
    /// </summary>
    public long EquippedHeroId { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 装备品质
/// </summary>
public enum EquipmentQuality
{
    Common,
    Rare,
    Elite,
    Legendary,
    Mythic,
    Ascended,
}


/// <summary>
/// 通用错误码
/// </summary>
public enum ErrorCode
{
    OK,
    Unknown,
    InvalidRequest,
    InvalidToken,
    InsufficientResource,
    ConfigNotFound,
    FeatureLocked,
    Cooldown,
    Duplicate,
    NotFound,
    AlreadyOwned,
    BagFull,
}


/// <summary>
/// 活动信息
/// </summary>
public class EventInfo
{
    /// <summary>
    /// 活动 ID
    /// </summary>
    public int EventId { get; set; }
    /// <summary>
    /// 活动名称
    /// </summary>
    public string EventName { get; set; }
    /// <summary>
    /// 活动描述
    /// </summary>
    public string Description { get; set; }
    /// <summary>
    /// 开始时间
    /// </summary>
    public long StartTime { get; set; }
    /// <summary>
    /// 结束时间
    /// </summary>
    public long EndTime { get; set; }
    /// <summary>
    /// 是否限时活动
    /// </summary>
    public bool IsLimitedTime { get; set; }
    /// <summary>
    /// 预览奖励
    /// </summary>
    public RewardItem[] PreviewRewards { get; set; }
}


/// <summary>
/// 阵容槽位信息
/// </summary>
public class FormationSlot
{
    /// <summary>
    /// 站位索引
    /// </summary>
    public int Position { get; set; }
    /// <summary>
    /// 英雄 ID
    /// </summary>
    public string HeroId { get; set; }
    /// <summary>
    /// 英雄等级
    /// </summary>
    public int HeroLevel { get; set; }
    /// <summary>
    /// 星级
    /// </summary>
    public int StarLevel { get; set; }
    /// <summary>
    /// 自定义扩展(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 好友基础信息
/// </summary>
public class FriendInfo
{
    /// <summary>
    /// 玩家 ID
    /// </summary>
    public long PlayerId { get; set; }
    /// <summary>
    /// 昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// VIP 等级
    /// </summary>
    public int VipLevel { get; set; }
    /// <summary>
    /// 战力
    /// </summary>
    public int CombatPower { get; set; }
    /// <summary>
    /// 头像
    /// </summary>
    public string AvatarUrl { get; set; }
    /// <summary>
    /// 个性签名
    /// </summary>
    public string Signature { get; set; }
    /// <summary>
    /// 地区
    /// </summary>
    public string Country { get; set; }
    /// <summary>
    /// 是否在线
    /// </summary>
    public bool IsOnline { get; set; }
    /// <summary>
    /// 最后在线时间
    /// </summary>
    public long LastOnlineTime { get; set; }
    /// <summary>
    /// 友情点
    /// </summary>
    public int FriendshipPoint { get; set; }
    /// <summary>
    /// 状态
    /// </summary>
    public FriendStatus Status { get; set; }
}


/// <summary>
/// 好友申请信息
/// </summary>
public class FriendRequestInfo
{
    /// <summary>
    /// 申请 ID
    /// </summary>
    public long RequestId { get; set; }
    /// <summary>
    /// 申请人信息
    /// </summary>
    public FriendInfo FromPlayer { get; set; }
    /// <summary>
    /// 被申请人 ID
    /// </summary>
    public long ToPlayerId { get; set; }
    /// <summary>
    /// 申请附言
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 申请时间
    /// </summary>
    public long CreatedAt { get; set; }
}


/// <summary>
/// 好友状态
/// </summary>
public enum FriendStatus
{
    Normal,
    Blacklisted,
    Blocked,
}


/// <summary>
/// 抽卡池信息
/// </summary>
public class GachaPoolInfo
{
    /// <summary>
    /// 池子 ID
    /// </summary>
    public int PoolId { get; set; }
    /// <summary>
    /// 池子名称
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// 类型
    /// </summary>
    public GachaPoolType PoolType { get; set; }
    /// <summary>
    /// 单抽货币类型
    /// </summary>
    public ResourceType SingleCostType { get; set; }
    /// <summary>
    /// 单抽价格
    /// </summary>
    public int SingleCostValue { get; set; }
    /// <summary>
    /// 十连货币类型
    /// </summary>
    public ResourceType TenCostType { get; set; }
    /// <summary>
    /// 十连价格
    /// </summary>
    public int TenCostValue { get; set; }
    /// <summary>
    /// 免费CD秒数(0表示无免费)
    /// </summary>
    public int FreeCdSeconds { get; set; }
    /// <summary>
    /// 是否当前可免费一次
    /// </summary>
    public bool FreeAvailable { get; set; }
    /// <summary>
    /// 今日已抽次数
    /// </summary>
    public int TodayUsedTimes { get; set; }
    /// <summary>
    /// 保底计数
    /// </summary>
    public int PityCount { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 召唤池类型
/// </summary>
public enum GachaPoolType
{
    Normal,
    Advanced,
    Faction,
    Friend,
    Limited,
    Beginner,
}


/// <summary>
/// 抽卡结果
/// </summary>
public class GachaResult
{
    /// <summary>
    /// 抽卡池 ID
    /// </summary>
    public int PoolId { get; set; }
    /// <summary>
    /// 抽卡次数(1或10等)
    /// </summary>
    public int Times { get; set; }
    /// <summary>
    /// 抽到的所有奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 新获得的英雄(用于展示)
    /// </summary>
    public HeroInfo[] NewHeroes { get; set; }
    /// <summary>
    /// 涉及到的资源变动
    /// </summary>
    public ResourceChange[] ResourceChanges { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// GM 命令执行结果
/// </summary>
public class GMCommandResult
{
    /// <summary>
    /// 执行的命令字符串
    /// </summary>
    public string Command { get; set; }
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 结果描述
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 扩展(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 公会活动信息
/// </summary>
public class GuildActivityInfo
{
    /// <summary>
    /// 活动 ID
    /// </summary>
    public string ActivityId { get; set; }
    /// <summary>
    /// 活动名称
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// 开始时间
    /// </summary>
    public long StartAt { get; set; }
    /// <summary>
    /// 结束时间
    /// </summary>
    public long EndAt { get; set; }
    /// <summary>
    /// 活动状态
    /// </summary>
    public string Status { get; set; }
}


/// <summary>
/// 公会申请
/// </summary>
public class GuildApplyInfo
{
    /// <summary>
    /// 申请 ID
    /// </summary>
    public long ApplyId { get; set; }
    /// <summary>
    /// 申请人信息
    /// </summary>
    public FriendInfo Player { get; set; }
    /// <summary>
    /// 申请时间
    /// </summary>
    public long ApplyTime { get; set; }
    /// <summary>
    /// 申请留言
    /// </summary>
    public string Message { get; set; }
}


/// <summary>
/// 公会基础信息
/// </summary>
public class GuildInfo
{
    /// <summary>
    /// 公会 ID
    /// </summary>
    public long GuildId { get; set; }
    /// <summary>
    /// 公会名
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// 公会标志/旗帜
    /// </summary>
    public string Badge { get; set; }
    /// <summary>
    /// 公会等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 当前人数
    /// </summary>
    public int MemberCount { get; set; }
    /// <summary>
    /// 人数上限
    /// </summary>
    public int MemberLimit { get; set; }
    /// <summary>
    /// 会长名字
    /// </summary>
    public string LeaderName { get; set; }
    /// <summary>
    /// 公会总战力
    /// </summary>
    public long Power { get; set; }
    /// <summary>
    /// 公告
    /// </summary>
    public string Notice { get; set; }
    /// <summary>
    /// 加入最低战力要求
    /// </summary>
    public int RequirePower { get; set; }
    /// <summary>
    /// 是否需要审核
    /// </summary>
    public bool RequireVerify { get; set; }
    /// <summary>
    /// 地区/阵营
    /// </summary>
    public string Country { get; set; }
    /// <summary>
    /// 创建时间
    /// </summary>
    public long CreateTime { get; set; }
    /// <summary>
    /// 扩展(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 公会成员信息
/// </summary>
public class GuildMemberInfo
{
    /// <summary>
    /// 玩家 ID
    /// </summary>
    public long PlayerId { get; set; }
    /// <summary>
    /// 昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// VIP 等级
    /// </summary>
    public int VipLevel { get; set; }
    /// <summary>
    /// 战力
    /// </summary>
    public int CombatPower { get; set; }
    /// <summary>
    /// 职位
    /// </summary>
    public GuildRole Role { get; set; }
    /// <summary>
    /// 加入时间
    /// </summary>
    public long JoinTime { get; set; }
    /// <summary>
    /// 最后在线
    /// </summary>
    public long LastOnlineTime { get; set; }
    /// <summary>
    /// 历史贡献值
    /// </summary>
    public int Contribution { get; set; }
    /// <summary>
    /// 扩展(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 公会成员职位
/// </summary>
public enum GuildRole
{
    Member,
    Elder,
    Officer,
    Leader,
}


/// <summary>
/// 英雄职业/定位
/// </summary>
public enum HeroClass
{
    Tank,
    Warrior,
    Mage,
    Ranger,
    Support,
    Assassin,
    Other,
}


/// <summary>
/// 英雄装备槽位
/// </summary>
public class HeroEquipSlot
{
    /// <summary>
    /// 槽位类型(Weapon/Helmet/Armor/Boots等)
    /// </summary>
    public string SlotType { get; set; }
    /// <summary>
    /// 当前装备的装备 ID(可为0表示空)
    /// </summary>
    public long EquipmentId { get; set; }
    /// <summary>
    /// 槽位是否锁定
    /// </summary>
    public bool IsLocked { get; set; }
}


/// <summary>
/// 英雄阵营（具体与策划表对应）
/// </summary>
public enum HeroFaction
{
    Faction1,
    Faction2,
    Faction3,
    Faction4,
    Faction5,
    Faction6,
    Other,
}


/// <summary>
/// 英雄完整数据
/// </summary>
public class HeroInfo
{
    /// <summary>
    /// 英雄唯一 ID
    /// </summary>
    public long HeroId { get; set; }
    /// <summary>
    /// 英雄配置 ID
    /// </summary>
    public string TemplateId { get; set; }
    /// <summary>
    /// 等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 星级
    /// </summary>
    public int StarLevel { get; set; }
    /// <summary>
    /// 品质
    /// </summary>
    public HeroQuality Quality { get; set; }
    /// <summary>
    /// 阵营
    /// </summary>
    public HeroFaction Faction { get; set; }
    /// <summary>
    /// 职业
    /// </summary>
    public HeroClass Class { get; set; }
    /// <summary>
    /// 英雄个人战力
    /// </summary>
    public int CombatPower { get; set; }
    /// <summary>
    /// 当前英雄经验
    /// </summary>
    public long Exp { get; set; }
    /// <summary>
    /// 是否锁定(防止一键分解)
    /// </summary>
    public bool IsLocked { get; set; }
    /// <summary>
    /// 是否在任意阵容中
    /// </summary>
    public bool IsInFormation { get; set; }
    /// <summary>
    /// 技能列表
    /// </summary>
    public HeroSkillInfo[] Skills { get; set; }
    /// <summary>
    /// 装备槽位
    /// </summary>
    public HeroEquipSlot[] EquipSlots { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 英雄品质
/// </summary>
public enum HeroQuality
{
    Common,
    Rare,
    Elite,
    Legendary,
    Mythic,
    Ascended,
}


/// <summary>
/// 英雄技能信息
/// </summary>
public class HeroSkillInfo
{
    /// <summary>
    /// 技能配置 ID
    /// </summary>
    public string SkillId { get; set; }
    /// <summary>
    /// 技能等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 是否已解锁
    /// </summary>
    public bool IsUnlocked { get; set; }
}


/// <summary>
/// 背包增量更新（避免每次全量下发）
/// </summary>
public class InventoryDelta
{
    /// <summary>
    /// 新增或变更的物品
    /// </summary>
    public InventoryItem[] UpdatedItems { get; set; }
    /// <summary>
    /// 被删除的物品 ID 列表
    /// </summary>
    public long[] RemovedItemIds { get; set; }
}


/// <summary>
/// 背包整体信息
/// </summary>
public class InventoryInfo
{
    /// <summary>
    /// 物品列表
    /// </summary>
    public InventoryItem[] Items { get; set; }
    /// <summary>
    /// 上次刷新时间
    /// </summary>
    public long LastRefreshTime { get; set; }
}


/// <summary>
/// 背包物品数据
/// </summary>
public class InventoryItem
{
    /// <summary>
    /// 物品唯一 ID
    /// </summary>
    public long ItemId { get; set; }
    /// <summary>
    /// 物品名称
    /// </summary>
    public string ItemName { get; set; }
    /// <summary>
    /// 物品类别
    /// </summary>
    public ItemCategory Category { get; set; }
    /// <summary>
    /// 数量
    /// </summary>
    public int Quantity { get; set; }
    /// <summary>
    /// 是否为绑定物品
    /// </summary>
    public bool IsBound { get; set; }
    /// <summary>
    /// 过期时间(0 表示永久)
    /// </summary>
    public long ExpireAt { get; set; }
}


/// <summary>
/// 背包物品类别
/// </summary>
public enum ItemCategory
{
    Equipment,
    Consumable,
    Material,
    Quest,
    Currency,
    Other,
}


/// <summary>
/// 消耗物品信息（强化/升级等使用）
/// </summary>
public class ItemCost
{
    /// <summary>
    /// 物品 ID
    /// </summary>
    public long ItemId { get; set; }
    /// <summary>
    /// 消耗数量
    /// </summary>
    public int Quantity { get; set; }
}


/// <summary>
/// 排行榜条目
/// </summary>
public class LeaderboardEntry
{
    /// <summary>
    /// 排名
    /// </summary>
    public int Rank { get; set; }
    /// <summary>
    /// 玩家 ID
    /// </summary>
    public long PlayerId { get; set; }
    /// <summary>
    /// 玩家昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 积分或分数
    /// </summary>
    public int Score { get; set; }
    /// <summary>
    /// 玩家等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 战力
    /// </summary>
    public int CombatPower { get; set; }
}


/// <summary>
/// 排行榜整体数据
/// </summary>
public class LeaderboardInfo
{
    /// <summary>
    /// 排行榜类型
    /// </summary>
    public string BoardType { get; set; }
    /// <summary>
    /// 排行榜条目
    /// </summary>
    public LeaderboardEntry[] Entries { get; set; }
    /// <summary>
    /// 下次刷新时间
    /// </summary>
    public long RefreshAt { get; set; }
}


/// <summary>
/// 大厅概览信息
/// </summary>
public class LobbyInfo
{
    /// <summary>
    /// 当前场景
    /// </summary>
    public string CurrentScene { get; set; }
    /// <summary>
    /// 在线人数
    /// </summary>
    public int OnlinePlayerCount { get; set; }
    /// <summary>
    /// 功能入口列表
    /// </summary>
    public string[] FeatureEntries { get; set; }
    /// <summary>
    /// 公告列表
    /// </summary>
    public NoticeMessage[] Notices { get; set; }
}


/// <summary>
/// 邮件信息
/// </summary>
public class MailInfo
{
    /// <summary>
    /// 邮件 ID
    /// </summary>
    public long MailId { get; set; }
    /// <summary>
    /// 标题
    /// </summary>
    public string Title { get; set; }
    /// <summary>
    /// 内容
    /// </summary>
    public string Content { get; set; }
    /// <summary>
    /// 发件人名称
    /// </summary>
    public string SenderName { get; set; }
    /// <summary>
    /// 发件人 ID(系统为0)
    /// </summary>
    public long SenderId { get; set; }
    /// <summary>
    /// 发送时间
    /// </summary>
    public long SendTime { get; set; }
    /// <summary>
    /// 过期时间
    /// </summary>
    public long ExpireAt { get; set; }
    /// <summary>
    /// 状态
    /// </summary>
    public MailStatus Status { get; set; }
    /// <summary>
    /// 邮件类型(系统/活动/补偿等)
    /// </summary>
    public string Category { get; set; }
    /// <summary>
    /// 附件奖励
    /// </summary>
    public RewardItem[] Attachments { get; set; }
    /// <summary>
    /// 扩展(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 邮件状态
/// </summary>
public enum MailStatus
{
    Unread,
    Read,
    Received,
    Deleted,
}


/// <summary>
/// 大厅公告信息
/// </summary>
public class NoticeMessage
{
    /// <summary>
    /// 公告标题
    /// </summary>
    public string Title { get; set; }
    /// <summary>
    /// 公告内容
    /// </summary>
    public string Content { get; set; }
    /// <summary>
    /// 开始时间
    /// </summary>
    public long StartAt { get; set; }
    /// <summary>
    /// 结束时间
    /// </summary>
    public long EndAt { get; set; }
}


/// <summary>
/// 玩家基础信息
/// </summary>
public class PlayerProfile
{
    /// <summary>
    /// 玩家唯一 ID
    /// </summary>
    public long PlayerId { get; set; }
    /// <summary>
    /// 玩家昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 玩家等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 当前经验
    /// </summary>
    public long Experience { get; set; }
    /// <summary>
    /// 金币
    /// </summary>
    public long Gold { get; set; }
    /// <summary>
    /// 钻石
    /// </summary>
    public long Diamonds { get; set; }
    /// <summary>
    /// 已通关到的关卡
    /// </summary>
    public int ClearedStage { get; set; }
    /// <summary>
    /// VIP 等级
    /// </summary>
    public int VipLevel { get; set; }
    /// <summary>
    /// 战力
    /// </summary>
    public int CombatPower { get; set; }
    /// <summary>
    /// 公会名称
    /// </summary>
    public string GuildName { get; set; }
    /// <summary>
    /// 当前进度关卡
    /// </summary>
    public int CurrentStage { get; set; }
    /// <summary>
    /// 当前竞技场排名
    /// </summary>
    public int ArenaRank { get; set; }
    /// <summary>
    /// 头像地址
    /// </summary>
    public string AvatarUrl { get; set; }
    /// <summary>
    /// 地区信息
    /// </summary>
    public string Country { get; set; }
}


/// <summary>
/// 红点提示数据
/// </summary>
public class RedPointInfo
{
    /// <summary>
    /// 模块名(例如 Task/Gacha/Guild)
    /// </summary>
    public string Module { get; set; }
    /// <summary>
    /// 子模块，可为空
    /// </summary>
    public string SubModule { get; set; }
    /// <summary>
    /// 红点计数(>0显示红点)
    /// </summary>
    public int Count { get; set; }
    /// <summary>
    /// 扩展(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 资源变更信息（用于结算、同步）
/// </summary>
public class ResourceChange
{
    /// <summary>
    /// 资源类型
    /// </summary>
    public ResourceType Type { get; set; }
    /// <summary>
    /// 变化值，正为增加，负为消耗
    /// </summary>
    public long Delta { get; set; }
    /// <summary>
    /// 变化后的最终值
    /// </summary>
    public long NewValue { get; set; }
}


/// <summary>
/// 通用货币/资源类型
/// </summary>
public enum ResourceType
{
    Gold,
    Diamond,
    PlayerExp,
    HeroExp,
    Dust,
    ArenaTicket,
    GuildCoin,
    FriendCoin,
    Energy,
    TowerTicket,
    EventCurrency,
    Other,
}


/// <summary>
/// 奖励物品信息
/// </summary>
public class RewardItem
{
    /// <summary>
    /// 物品 ID
    /// </summary>
    public long ItemId { get; set; }
    /// <summary>
    /// 物品名称
    /// </summary>
    public string ItemName { get; set; }
    /// <summary>
    /// 数量
    /// </summary>
    public int Quantity { get; set; }
    /// <summary>
    /// 奖励类别
    /// </summary>
    public string RewardType { get; set; }
}


/// <summary>
/// 可登录的游戏服信息
/// </summary>
public class ServerInfo
{
    /// <summary>
    /// 服务器唯一 ID
    /// </summary>
    public string ServerId { get; set; }
    /// <summary>
    /// 服务器显示名称
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// 大区/分区
    /// </summary>
    public string Region { get; set; }
    /// <summary>
    /// 当前状态(Online/Busy/Maintenance)
    /// </summary>
    public string Status { get; set; }
    /// <summary>
    /// 是否推荐
    /// </summary>
    public bool IsRecommended { get; set; }
    /// <summary>
    /// 在线人数估算
    /// </summary>
    public int OnlinePlayers { get; set; }
}


/// <summary>
/// 单个商店格子信息
/// </summary>
public class ShopItemInfo
{
    /// <summary>
    /// 商店 ID
    /// </summary>
    public int ShopId { get; set; }
    /// <summary>
    /// 商店类型
    /// </summary>
    public ShopType ShopType { get; set; }
    /// <summary>
    /// 格子序号
    /// </summary>
    public int SlotIndex { get; set; }
    /// <summary>
    /// 售卖的物品/奖励
    /// </summary>
    public RewardItem Goods { get; set; }
    /// <summary>
    /// 价格货币类型
    /// </summary>
    public ResourceType PriceType { get; set; }
    /// <summary>
    /// 价格数量
    /// </summary>
    public int PriceValue { get; set; }
    /// <summary>
    /// 购买上限(0表示无限)
    /// </summary>
    public int BuyLimit { get; set; }
    /// <summary>
    /// 当前已买次数
    /// </summary>
    public int BoughtCount { get; set; }
    /// <summary>
    /// 下次刷新时间
    /// </summary>
    public long RefreshAt { get; set; }
    /// <summary>
    /// 是否已售罄
    /// </summary>
    public bool IsSoldOut { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 商店类型
/// </summary>
public enum ShopType
{
    Normal,
    Arena,
    Guild,
    Friend,
    BlackMarket,
    Event,
    Daily,
    Weekly,
}


/// <summary>
/// 主线关卡信息
/// </summary>
public class StageInfo
{
    /// <summary>
    /// 关卡 ID
    /// </summary>
    public string StageId { get; set; }
    /// <summary>
    /// 章节 ID
    /// </summary>
    public int ChapterId { get; set; }
    /// <summary>
    /// 该章节内序号
    /// </summary>
    public int Index { get; set; }
    /// <summary>
    /// 星级(0~3)
    /// </summary>
    public int Stars { get; set; }
    /// <summary>
    /// 是否解锁
    /// </summary>
    public bool IsUnlocked { get; set; }
    /// <summary>
    /// 是否通关
    /// </summary>
    public bool IsPassed { get; set; }
    /// <summary>
    /// 首通奖励是否已领取
    /// </summary>
    public bool FirstPassRewardClaimed { get; set; }
    /// <summary>
    /// 满星宝箱是否已领取
    /// </summary>
    public bool MaxStarRewardClaimed { get; set; }
    /// <summary>
    /// 最快通关帧数
    /// </summary>
    public int BestDurationFrames { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 属性键值对
/// </summary>
public class StatPair
{
    /// <summary>
    /// 属性名(Attack/HP等)
    /// </summary>
    public string Key { get; set; }
    /// <summary>
    /// 属性值
    /// </summary>
    public int Value { get; set; }
}


/// <summary>
/// 任务信息
/// </summary>
public class TaskInfo
{
    /// <summary>
    /// 任务 ID
    /// </summary>
    public int TaskId { get; set; }
    /// <summary>
    /// 任务类型
    /// </summary>
    public TaskType Type { get; set; }
    /// <summary>
    /// 任务名称
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// 描述
    /// </summary>
    public string Description { get; set; }
    /// <summary>
    /// 当前进度值
    /// </summary>
    public int Progress { get; set; }
    /// <summary>
    /// 目标值
    /// </summary>
    public int Target { get; set; }
    /// <summary>
    /// 状态
    /// </summary>
    public TaskStatus Status { get; set; }
    /// <summary>
    /// 过期时间(0表示永久)
    /// </summary>
    public long ExpireAt { get; set; }
    /// <summary>
    /// 完成奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 后续任务 ID(用于引导链)
    /// </summary>
    public int NextTaskId { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 任务状态/成就状态通用
/// </summary>
public enum TaskStatus
{
    InProgress,
    Completed,
    RewardTaken,
    Expired,
}


/// <summary>
/// 任务类型
/// </summary>
public enum TaskType
{
    Daily,
    Weekly,
    Main,
    Guide,
    Event,
}


/// <summary>
/// 队伍信息
/// </summary>
public class TeamInfo
{
    /// <summary>
    /// 队伍 ID
    /// </summary>
    public string TeamId { get; set; }
    /// <summary>
    /// 队长玩家 ID
    /// </summary>
    public long LeaderId { get; set; }
    /// <summary>
    /// 队伍成员
    /// </summary>
    public TeamMemberInfo[] Members { get; set; }
    /// <summary>
    /// 创建时间
    /// </summary>
    public long CreateTime { get; set; }
}


/// <summary>
/// 组队邀请信息
/// </summary>
public class TeamInviteInfo
{
    /// <summary>
    /// 邀请 ID
    /// </summary>
    public string InviteId { get; set; }
    /// <summary>
    /// 队伍 ID
    /// </summary>
    public string TeamId { get; set; }
    /// <summary>
    /// 邀请人 ID
    /// </summary>
    public long FromPlayerId { get; set; }
    /// <summary>
    /// 被邀请人 ID
    /// </summary>
    public long ToPlayerId { get; set; }
    /// <summary>
    /// 邀请附言
    /// </summary>
    public string Message { get; set; }
}


/// <summary>
/// 组队成员信息
/// </summary>
public class TeamMemberInfo
{
    /// <summary>
    /// 玩家 ID
    /// </summary>
    public long PlayerId { get; set; }
    /// <summary>
    /// 玩家昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 玩家等级
    /// </summary>
    public int Level { get; set; }
    /// <summary>
    /// 定位(输出/坦克/治疗等)
    /// </summary>
    public string Role { get; set; }
    /// <summary>
    /// 战力
    /// </summary>
    public int CombatPower { get; set; }
}


/// <summary>
/// 爬塔层数信息
/// </summary>
public class TowerFloorInfo
{
    /// <summary>
    /// 层数
    /// </summary>
    public int Floor { get; set; }
    /// <summary>
    /// 是否通关
    /// </summary>
    public bool IsPassed { get; set; }
    /// <summary>
    /// 星级
    /// </summary>
    public int Stars { get; set; }
    /// <summary>
    /// 层数奖励是否已领
    /// </summary>
    public bool RewardTaken { get; set; }
}


/// <summary>
/// 爬塔/试炼信息
/// </summary>
public class TowerInfo
{
    /// <summary>
    /// 塔 ID
    /// </summary>
    public int TowerId { get; set; }
    /// <summary>
    /// 名称
    /// </summary>
    public string Name { get; set; }
    /// <summary>
    /// 当前挑战到的层数
    /// </summary>
    public int CurrentFloor { get; set; }
    /// <summary>
    /// 开放的最大层数
    /// </summary>
    public int MaxFloor { get; set; }
    /// <summary>
    /// 今日已重置次数
    /// </summary>
    public int ResetCount { get; set; }
    /// <summary>
    /// 上次重置时间
    /// </summary>
    public long LastResetTime { get; set; }
    /// <summary>
    /// 层数信息
    /// </summary>
    public TowerFloorInfo[] Floors { get; set; }
    /// <summary>
    /// 扩展(JSON)
    /// </summary>
    public string Custom { get; set; }
}


/// <summary>
/// 世界 Boss 信息
/// </summary>
public class WorldBossInfo
{
    /// <summary>
    /// Boss ID
    /// </summary>
    public string BossId { get; set; }
    /// <summary>
    /// Boss 名称
    /// </summary>
    public string BossName { get; set; }
    /// <summary>
    /// 当前 HP
    /// </summary>
    public long Hp { get; set; }
    /// <summary>
    /// 最大 HP
    /// </summary>
    public long MaxHp { get; set; }
    /// <summary>
    /// 开始时间
    /// </summary>
    public long StartAt { get; set; }
    /// <summary>
    /// 结束时间
    /// </summary>
    public long EndAt { get; set; }
}

