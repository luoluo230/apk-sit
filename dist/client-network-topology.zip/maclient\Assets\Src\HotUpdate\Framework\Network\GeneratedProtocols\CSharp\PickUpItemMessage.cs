﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 拾取物品
/// </summary>
public class PickUpItem_c2s
{
    /// <summary>
    /// 物品 ID
    /// </summary>
    public long ItemId { get; set; }
    /// <summary>
    /// 数量
    /// </summary>
    public int Quantity { get; set; }
}

/// <summary>
/// 拾取物品结果
/// </summary>
public class PickUpItem_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 背包变化
    /// </summary>
    public InventoryDelta Inventory { get; set; }
}

