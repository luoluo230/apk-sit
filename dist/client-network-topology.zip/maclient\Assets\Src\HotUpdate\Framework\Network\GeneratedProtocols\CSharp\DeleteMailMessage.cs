﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 删除邮件
/// </summary>
public class DeleteMail_c2s
{
    /// <summary>
    /// 邮件 ID
    /// </summary>
    public long MailId { get; set; }
}

/// <summary>
/// 删除邮件结果
/// </summary>
public class DeleteMail_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

