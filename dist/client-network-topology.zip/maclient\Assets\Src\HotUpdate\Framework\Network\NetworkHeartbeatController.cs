﻿using System;
using UnityEngine;

public sealed class NetworkHeartbeatController : IHeartbeatController
{
    public int HeartbeatRequestId { get; private set; }
    public int HeartbeatResponseId { get; private set; }
    public float LastHeartbeatRtt { get; private set; }

    private float _lastReceiveTime;
    private float _lastSendTime;
    private float _lastHeartbeatSentAt;

    public void Configure(int heartbeatRequestId, int heartbeatResponseId, float currentTime)
    {
        HeartbeatRequestId = heartbeatRequestId;
        HeartbeatResponseId = heartbeatResponseId;
        _lastReceiveTime = currentTime;
        _lastSendTime = currentTime;
        _lastHeartbeatSentAt = currentTime;
        LastHeartbeatRtt = 0f;
    }

    public void OnConnected(float currentTime)
    {
        _lastReceiveTime = currentTime;
        _lastSendTime = currentTime;
        _lastHeartbeatSentAt = currentTime;
    }

    public void OnDisconnected()
    {
        LastHeartbeatRtt = 0f;
    }

    public void OnDataReceived(float currentTime)
    {
        _lastReceiveTime = currentTime;
    }

    public void MarkHeartbeatSent(float currentTime)
    {
        _lastSendTime = currentTime;
        _lastHeartbeatSentAt = currentTime;
    }

    public void Tick(
        float currentTime,
        bool isLongConnection,
        bool isConnected,
        NetworkManager.TransportType transportType,
        float heartbeatInterval,
        float heartbeatTimeoutSeconds,
        bool enableHeartbeatRequest,
        float kcpDisconnectTimeout,
        Action sendHeartbeatRequest,
        Action onHeartbeatTimeout)
    {
        if (!isLongConnection || !isConnected || heartbeatInterval <= 0f)
        {
            return;
        }

        if (enableHeartbeatRequest && currentTime - _lastSendTime >= heartbeatInterval)
        {
            _lastSendTime = currentTime;
            sendHeartbeatRequest?.Invoke();
        }

        if (transportType == NetworkManager.TransportType.Kcp && kcpDisconnectTimeout > 0f)
        {
            if (currentTime - _lastReceiveTime >= kcpDisconnectTimeout)
            {
                onHeartbeatTimeout?.Invoke();
            }

            return;
        }

        float timeout = heartbeatTimeoutSeconds > 0f ? heartbeatTimeoutSeconds : heartbeatInterval * 2f;
        if (currentTime - _lastReceiveTime >= timeout)
        {
            onHeartbeatTimeout?.Invoke();
        }
    }

    public bool TryHandleHeartbeatResponse(
        NetMessage message,
        bool enableHeartbeatRequest,
        bool swallowHeartbeatResponse,
        float currentTime,
        NetworkManager.TransportType transportType,
        float kcpDisconnectBaseTimeout,
        float kcpDisconnectMinTimeout,
        float kcpDisconnectMaxTimeout,
        float kcpDisconnectRttMultiplier,
        Action<float> setKcpDisconnectTimeout)
    {
        if (!enableHeartbeatRequest || message == null || HeartbeatResponseId <= 0 || message.MessageID != HeartbeatResponseId)
        {
            return false;
        }

        var response = NetMessage.DeserializeData<Heartbeat_s2c>(message.Data);
        if (response == null)
        {
            return swallowHeartbeatResponse;
        }

        if (response.TokenExpireAt > 0 && NetMessage.HasCachedToken)
        {
            NetMessage.CacheToken(NetMessage.CachedToken, response.TokenExpireAt);
        }

        if (transportType == NetworkManager.TransportType.Kcp)
        {
            float rtt = Mathf.Max(0f, currentTime - _lastHeartbeatSentAt);
            LastHeartbeatRtt = rtt;
            float nextTimeout = Mathf.Max(kcpDisconnectBaseTimeout, rtt * kcpDisconnectRttMultiplier);
            setKcpDisconnectTimeout?.Invoke(Mathf.Clamp(nextTimeout, kcpDisconnectMinTimeout, kcpDisconnectMaxTimeout));
        }

        return swallowHeartbeatResponse;
    }
}
