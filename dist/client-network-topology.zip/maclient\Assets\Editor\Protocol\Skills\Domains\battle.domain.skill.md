# Battle Domain Skill

- Client: generate battle request wrapper with frame/tick context, timeout handling, and replay/mock hooks.
- Server: generate battle session validation, anti-cheat validation hook, deterministic frame processing extension points, and result persistence hooks.
- Avoid heavy DB writes per frame unless explicitly required.
