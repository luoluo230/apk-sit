﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 发送好友申请
/// </summary>
public class ApplyFriend_c2s
{
    /// <summary>
    /// 目标玩家 ID
    /// </summary>
    public long TargetPlayerId { get; set; }
    /// <summary>
    /// 申请附言
    /// </summary>
    public string Message { get; set; }
}

/// <summary>
/// 好友申请发送结果
/// </summary>
public class ApplyFriend_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 申请信息(成功时返回)
    /// </summary>
    public FriendRequestInfo Request { get; set; }
}

