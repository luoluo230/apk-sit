// 自动生成的协议文件

// 定义协议类


// 进入塔层战斗(走通用EnterBattle)
class EnterTower_c2s {
    constructor() {
        this.TowerId = 0;
        this.Floor = 0;
        this.Formation = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 进入塔战斗结果
class EnterTower_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.BattleId = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    EnterTower_c2s,
    EnterTower_s2c,
};
