# 日志埋点与可观测性 Skill

## 客户端

- API wrapper 记录协议名、MessageID、耗时、结果类型，不记录敏感字段。
- UseCase 暴露业务埋点 hook，如 begin/success/fail/cancel。
- Presenter 示例只展示 hook，不强依赖具体埋点 SDK。

## 服务端

- Handler 记录 request received、validation failed、service success、service failed。
- Service 记录关键业务分支、事务提交/回滚、领域事件。
- Repository 记录慢查询/写入失败 hook。

## Trace

- 如果上下文存在 traceId/requestId/sessionId，必须透传。
- 不存在时生成可替换的 trace accessor。

## 指标

- 每个协议至少提供耗时、成功率、错误码分布三个指标接入点。
- 支付、广告、登录、战斗等高风险领域要额外提供业务关键指标 hook。
