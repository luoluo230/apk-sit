// 自动生成的协议文件

// 定义协议类


// 发送聊天消息
class SendChatMessage_c2s {
    constructor() {
        this.Channel = null;
        this.ToPlayerId = null;
        this.Content = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 发送聊天消息结果(本地回显)
class SendChatMessage_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Chat = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SendChatMessage_c2s,
    SendChatMessage_s2c,
};
