// 自动生成的协议文件

// 定义协议类


// 背包变化推送(掉落/消耗等)
class SyncInventory_s2c {
    constructor() {
        this.Full = false;
        this.Inventory = null;
        this.Delta = null;
        this.Reason = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SyncInventory_s2c,
};
