# Inventory Domain Skill

- Client: generate inventory refresh/use-item/equipment operation use cases with local optimistic update hooks disabled by default.
- Server: generate item ownership validation, quantity checks, idempotency hook, inventory repository operations, and change-log/mutation result structure.
- Persist only authoritative inventory changes; response-only delta fields should not be stored directly without review.
