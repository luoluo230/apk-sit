# 客户端网络策略 Skill

## 适用范围

客户端 API wrapper、UseCase、Presenter 示例都必须遵守本策略。

## Loading 策略

- API wrapper 不直接操作 UI，只暴露 loading policy 或回调点。
- UseCase 可以触发 loading begin/end，但必须保证异常、取消、失败都会关闭 loading。
- Presenter 示例只能演示调用，不绑定具体 UI 框架路径。

## Retry 策略

- 只对网络超时、连接断开、临时服务不可用做有限重试。
- 登录、支付、消耗、领奖、购买、提交战斗结果等非幂等协议默认不自动重试，除非上下文存在 idempotency key。
- 每次重试必须保留最大次数、退避间隔、最终失败回调。

## Error Mapping

- 必须把网络错误、协议错误码、业务失败拆分成不同分支。
- 不能只暴露字符串；至少要有 code/message/raw response 或 exception。
- 业务层必须可以订阅成功、失败、取消、超时。

## 并发与取消

- 同一请求是否允许并发由 policy 控制。
- 支持取消 token 或等价取消入口；如果项目没有取消框架，生成可替换接口。

## 缓存刷新

- response 只驱动客户端缓存刷新，不得信任客户端本地计算作为服务端事实。
- 对 inventory/profile/mail/shop 等领域要提供 after-success refresh hook。
