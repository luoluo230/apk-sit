// 自动生成的协议工具模块

const {
    DeviceInfo,
    AuthToken,
    ServerInfo,
    PlayerProfile,
    ItemCategory,
    InventoryItem,
    InventoryInfo,
    NoticeMessage,
    LobbyInfo,
    LeaderboardEntry,
    LeaderboardInfo,
    RewardItem,
    EventInfo,
    FormationSlot,
    BattleSyncMode,
    BattlePhase,
    BattleParticipant,
    BattlePlayerInfo,
    BattleSceneInfo,
    BattleServerTuning,
    BattleUnitSnapshot,
    BattleOperation,
    BattleFrameEvent,
    BattleFrameBundle,
    BattleTimelineAnchor,
    BattleResultType,
    BattleStatistic,
    TeamMemberInfo,
    ErrorCode,
    ResourceType,
    ResourceChange,
    InventoryDelta,
    ItemCost,
    HeroQuality,
    HeroClass,
    HeroFaction,
    HeroSkillInfo,
    HeroEquipSlot,
    HeroInfo,
    EquipmentQuality,
    StatPair,
    EquipmentInfo,
    StageInfo,
    CampaignInfo,
    AfkRewardInfo,
    ShopType,
    ShopItemInfo,
    GachaPoolType,
    GachaPoolInfo,
    GachaResult,
    TaskType,
    TaskStatus,
    TaskInfo,
    AchievementInfo,
    FriendStatus,
    FriendInfo,
    FriendRequestInfo,
    ChatChannel,
    ChatMessage,
    MailStatus,
    MailInfo,
    GuildRole,
    GuildInfo,
    GuildMemberInfo,
    GuildApplyInfo,
    ArenaOpponentInfo,
    ArenaInfo,
    ArenaBattleRecord,
    TowerFloorInfo,
    TowerInfo,
    RedPointInfo,
    GMCommandResult,
    TeamInfo,
    TeamInviteInfo,
    WorldBossInfo,
    GuildActivityInfo,
} = require('./sharedTypes');
const { getProtocolClass } = require('./MessageRegistry');

// 自动导入 sharedTypes 中的所有类
const sharedTypes = {
    DeviceInfo,
    AuthToken,
    ServerInfo,
    PlayerProfile,
    ItemCategory,
    InventoryItem,
    InventoryInfo,
    NoticeMessage,
    LobbyInfo,
    LeaderboardEntry,
    LeaderboardInfo,
    RewardItem,
    EventInfo,
    FormationSlot,
    BattleSyncMode,
    BattlePhase,
    BattleParticipant,
    BattlePlayerInfo,
    BattleSceneInfo,
    BattleServerTuning,
    BattleUnitSnapshot,
    BattleOperation,
    BattleFrameEvent,
    BattleFrameBundle,
    BattleTimelineAnchor,
    BattleResultType,
    BattleStatistic,
    TeamMemberInfo,
    ErrorCode,
    ResourceType,
    ResourceChange,
    InventoryDelta,
    ItemCost,
    HeroQuality,
    HeroClass,
    HeroFaction,
    HeroSkillInfo,
    HeroEquipSlot,
    HeroInfo,
    EquipmentQuality,
    StatPair,
    EquipmentInfo,
    StageInfo,
    CampaignInfo,
    AfkRewardInfo,
    ShopType,
    ShopItemInfo,
    GachaPoolType,
    GachaPoolInfo,
    GachaResult,
    TaskType,
    TaskStatus,
    TaskInfo,
    AchievementInfo,
    FriendStatus,
    FriendInfo,
    FriendRequestInfo,
    ChatChannel,
    ChatMessage,
    MailStatus,
    MailInfo,
    GuildRole,
    GuildInfo,
    GuildMemberInfo,
    GuildApplyInfo,
    ArenaOpponentInfo,
    ArenaInfo,
    ArenaBattleRecord,
    TowerFloorInfo,
    TowerInfo,
    RedPointInfo,
    GMCommandResult,
    TeamInfo,
    TeamInviteInfo,
    WorldBossInfo,
    GuildActivityInfo,
};


/**
 * 动态解析消息，支持多层嵌套
 * @param {Object} message - 原始消息对象
 * @param {Object} protocolClass - 协议类
 * @returns {Object} - 解析后的协议实例
 */
function parseMessage(message, protocolClass) {
    // 确保 message 是对象
    const data = typeof message === 'string' ? JSON.parse(message) : message;

    // 创建协议类实例
    const instance = new protocolClass();

    console.log('Parsing message:', data, 'with class:', protocolClass.name);

    for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(instance, key)) {
            const value = data[key];

            // 如果字段是嵌套对象
            if (value && typeof value === 'object' && instance[key] !== null) {
                // 自动推断嵌套对象的类型
                const nestedClass = sharedTypes[instance[key]?.constructor?.name];
                if (nestedClass) {
                    instance[key] = parseMessage(value, nestedClass); // 递归解析嵌套对象
                } else {
                    instance[key] = value; // 非嵌套对象直接赋值
                }
            } else {
                // 直接赋值基础类型
                instance[key] = value;
            }
        }
    }

    console.log('Parsed instance:', instance);
    return instance;
}


/**
 * 将协议类实例转换为字符串，用于发送协议。
 * @param {Object} instance - 协议类实例。
 * @returns {string} - JSON 格式的字符串。
 */
function serializeMessage(instance) {
    return JSON.stringify(instance);
}


module.exports = {
    parseMessage,
    serializeMessage,
};

