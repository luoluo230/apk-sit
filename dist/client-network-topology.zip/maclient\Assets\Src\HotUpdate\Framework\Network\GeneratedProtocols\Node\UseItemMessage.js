// 自动生成的协议文件

// 定义协议类


// 使用物品
class UseItem_c2s {
    constructor() {
        this.ItemId = null;
        this.Quantity = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 使用物品结果
class UseItem_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Inventory = null;
        this.Rewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    UseItem_c2s,
    UseItem_s2c,
};
