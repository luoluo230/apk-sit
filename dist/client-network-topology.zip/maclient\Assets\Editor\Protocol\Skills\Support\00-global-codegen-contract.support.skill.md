# 全局代码生成契约

## 目标

所有 Protocol Skill 都只生成“协议业务接入层”，让开发者直接调用封装后的客户端 API 或服务端 handler/service/repository 骨架，不重复生成 DTO、ProtocolIds、ProtocolDictionary，不修改协议源。

## 强制输入

- 使用 `ProtocolSkillContext` 中的协议名、MessageID、request/response pair、字段类型、必填、默认值、废弃状态、DTO 路径、ProtocolIds 路径、ProtocolDictionary 路径。
- 使用 `Planned Files` 中给出的文件路径和 skill 名称。
- 使用 `Business Constraints`、`Retrieved Code References`、`Domain Skills` 作为优先约束。

## 输出规则

- 每个输出文件必须能独立解释用途、依赖、人工接入点。
- C# 文件必须放入正确 namespace，类名与协议名稳定对应。
- 生成代码必须保留 `auto-generated-protocol-skill` 区域，不覆盖手写业务块。
- 不确定项目真实框架时，生成接口/适配层和清晰 TODO，不要臆造不存在的类。
- 生成代码必须是“可接入闭环”，不能只写孤立类。必须补齐 using/namespace、构造依赖、事件注册/注销、客户端 Feature 入口、服务端 route registration、handler/service/repository/db model 调用链。
- 客户端生成结果要让业务只需要调用 Feature/UseCase，并在 UI/Presenter 中补具体表现；服务端生成结果要让启动流程只需要调用 RegisterRoutes，并在 Service 中补具体业务规则。
- 所有生成的业务代码必须有详细中文注释，说明类职责、生命周期、依赖、事件流、错误处理、重试/缓存/事务边界和人工 TODO 点。

## 禁止事项

- 禁止重新定义 DTO、ProtocolIds、ProtocolDictionary。
- 禁止在客户端生成服务端权威逻辑。
- 禁止吞掉异常或返回不透明 bool。
- 禁止把 token、password、deviceId、secret、订单号等敏感字段写入日志。
- 禁止生成不可审查的数据库迁移直接执行逻辑。

## 质量门禁

- 代码必须表达 loading、retry、error mapping、timeout、cancel、日志、埋点、鉴权、事务、DB review gate 中与当前 skill 相关的接入点。
- 如果某项能力因缺少项目框架无法完整接入，必须在文件注释中写清“缺什么、在哪里接、接入后如何替换”。
- 生成完成后的验收标准：开发者不需要再手动补基础 wiring、引用、事件绑定、路由注册或依赖装配，只补真实业务逻辑和具体 UI 表现。
