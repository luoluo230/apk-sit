﻿using System;
using UnityEngine;
using UnityWebSocket;

/// <summary>
/// WebSocket 传输实现。
/// 当前基于 UnityWebSocket 库实现，适合跨平台长连接场景，尤其是 WebGL 或网关统一接入。
/// </summary>
public class WebSocketTransport : MonoBehaviour, ITransportClient
{
    private WebSocket _ws;
    private string _currentUrl;

    public bool IsConnected { get; private set; }

    public event Action OnConnected;
    public event Action<string> OnDisconnected;
    public event Action<string> OnError;
    public event Action<byte[]> OnDataReceived;

    /// <summary>
    /// 建立 WebSocket 连接。
    /// </summary>
    public void Connect(string url)
    {
        if (IsConnected)
        {
            Disconnect();
        }

        if (string.IsNullOrWhiteSpace(url))
        {
            Logger.Log("WebSocket url is empty.", LogLevel.Error);
            OnError?.Invoke("WebSocket url is empty.");
            return;
        }

        try
        {
            _currentUrl = url;
            Logger.Log($"[UnityWebSocket] connecting: {_currentUrl}");
            _ws = new WebSocket(_currentUrl);
            _ws.OnOpen += HandleOpen;
            _ws.OnClose += HandleClose;
            _ws.OnMessage += HandleMessage;
            _ws.OnError += HandleError;

            _ws.ConnectAsync();
        }
        catch (Exception ex)
        {
            Logger.Log($"WebSocket init failed: {ex.Message}", LogLevel.Error);
            OnError?.Invoke(ex.Message);
        }
    }

    /// <summary>
    /// 断开 WebSocket 连接。
    /// </summary>
    public void Disconnect()
    {
        if (_ws != null)
        {
            UnbindEvents(_ws);
            var closingSocket = _ws;
            _ws = null;
            closingSocket.CloseAsync();
        }

        IsConnected = false;
    }

    /// <summary>
    /// 发送原始字节数据。
    /// </summary>
    public void Send(byte[] data)
    {
        if (IsConnected && _ws != null)
        {
            _ws.SendAsync(data);
        }
    }

    /// <summary>
    /// 连接建立回调。
    /// </summary>
    private void HandleOpen(object sender, EventArgs e)
    {
        if (!ReferenceEquals(sender, _ws))
        {
            return;
        }

        IsConnected = true;
        OnConnected?.Invoke();
    }

    /// <summary>
    /// 连接关闭回调。
    /// </summary>
    private void HandleClose(object sender, CloseEventArgs e)
    {
        if (!ReferenceEquals(sender, _ws))
        {
            return;
        }

        UnbindEvents(_ws);
        _ws = null;
        IsConnected = false;
        var reason = string.IsNullOrWhiteSpace(e.Reason) ? "Unknown" : e.Reason;
        Logger.Log($"[UnityWebSocket] Connection closed ({reason}), url={_currentUrl}", LogLevel.Warning);
        OnDisconnected?.Invoke(reason);
    }

    /// <summary>
    /// 连接错误回调。
    /// </summary>
    private void HandleError(object sender, ErrorEventArgs e)
    {
        if (!ReferenceEquals(sender, _ws))
        {
            return;
        }

        var detail = string.IsNullOrEmpty(e.Message) ? "Unknown error" : e.Message;
        if (e.Exception != null)
        {
            detail += $" | Exception: {e.Exception.GetType().Name} - {e.Exception.Message}";
        }

        Logger.Log($"UnityWebSocket transport error: {detail}, Url={_currentUrl}", LogLevel.Error);
        OnError?.Invoke(detail);
    }

    /// <summary>
    /// 收包回调。
    /// </summary>
    private void HandleMessage(object sender, MessageEventArgs e)
    {
        if (!ReferenceEquals(sender, _ws))
        {
            return;
        }

        OnDataReceived?.Invoke(e.RawData);
    }

    private void UnbindEvents(WebSocket socket)
    {
        if (socket == null)
        {
            return;
        }

        socket.OnOpen -= HandleOpen;
        socket.OnClose -= HandleClose;
        socket.OnMessage -= HandleMessage;
        socket.OnError -= HandleError;
    }

    private void OnDestroy()
    {
        Disconnect();
    }
}
