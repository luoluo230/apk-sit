using System;
using System.Threading.Tasks;

/// <summary>
/// 端点解析器接口。
/// 负责把“滚服/单服/环境路由”决策为最终可连接地址与服务器标识。
/// </summary>
public interface IEndpointResolver
{
    /// <summary>
    /// 解析指定通道的最终连接地址。
    /// </summary>
    /// <param name="channel">网络通道。</param>
    /// <returns>最终 endpoint。</returns>
    string ResolveEndpoint(NetworkChannel channel);

    /// <summary>
    /// 解析最终 serverId（滚服/单服统一入口）。
    /// </summary>
    /// <param name="preferredServerId">优先 serverId。</param>
    /// <returns>最终 serverId。</returns>
    string ResolveServerId(string preferredServerId = null);
}

/// <summary>
/// 认证与会话传输接口。
/// 负责注册、登录、选服、心跳、token 刷新、会话恢复、登出等账号生命周期能力。
/// </summary>
public interface IAuthTransport
{
    Task<Login_s2c> LoginAsync(string username, string password, DeviceInfo device = null);
    Task<SelectServer_s2c> SelectServerAsync(string serverId);
    Task<CreateRole_s2c> RegisterRoleAsync(string nickname, string avatar = "default", string serverId = null);
    Task<Heartbeat_s2c> PingAsync(bool includeProfile = false);
    Task<TokenRefresh_s2c> RefreshTokenAsync(string refreshToken = null);
    Task<SessionResume_s2c> ResumeSessionAsync(string serverId = null, bool includeProfile = true);
    Task<Logout_s2c> LogoutAsync(bool disconnect = true, bool clearToken = true);
}

/// <summary>
/// 连接生命周期接口。
/// 负责连接、断线、重连生命周期回调与控制。
/// </summary>
public interface IConnectionLifecycle
{
    bool IsConnected { get; }
    event Action OnDisconnected;
    event Action OnReconnected;
    void Connect(NetworkChannel channel = NetworkChannel.Login);
    void Disconnect(bool clearToken = false);
}

/// <summary>
/// 心跳服务接口。
/// 负责保活策略的启停与主动 ping。
/// </summary>
public interface IHeartbeatService
{
    void StartHeartbeat();
    void StopHeartbeat();
    Task<Heartbeat_s2c> PingAsync(bool includeProfile = false);
}

/// <summary>
/// 通用消息通道接口。
/// 提供请求-响应与推送订阅能力。
/// </summary>
public interface IMessageChannel
{
    Task<TResponse> RequestAsync<TResponse>(
        object request,
        NetworkChannel channel = NetworkChannel.Game,
        bool requireToken = true,
        bool? reliable = null,
        int? priority = null,
        float? timeoutSeconds = null) where TResponse : class;

    Task<GameNetworkCallResult<TResponse>> RequestResultAsync<TResponse>(
        object request,
        NetworkChannel channel = NetworkChannel.Game,
        bool requireToken = true,
        bool? reliable = null,
        int? priority = null,
        float? timeoutSeconds = null) where TResponse : class;

    IDisposable Subscribe<TNotify>(Action<TNotify> handler) where TNotify : class;
}

/// <summary>
/// 会话存储接口。
/// 统一 token 读写与清理，避免业务直接依赖底层静态实现。
/// </summary>
public interface ISessionStore
{
    bool HasToken { get; }
    string GetToken();
    long GetTokenExpireAt();
    void SaveToken(string token, long expireAt = 0);
    void ClearToken(bool clearPersistent = true);
}

/// <summary>
/// 登出接口。
/// 统一退出与会话清理行为。
/// </summary>
public interface ILogoutService
{
    Task<Logout_s2c> LogoutAsync(bool disconnect = true, bool clearToken = true);
}
