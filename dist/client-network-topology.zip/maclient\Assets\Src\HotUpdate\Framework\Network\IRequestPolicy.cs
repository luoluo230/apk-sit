/// <summary>
/// 请求策略接口。
/// 负责定义 requestId 与 responseId 的映射规则，以及超时判断方式。
/// </summary>
public interface IRequestPolicy
{
    /// <summary>
    /// 根据请求消息 ID 计算响应消息 ID。
    /// </summary>
    int GetResponseMessageId(int requestMessageId);

    /// <summary>
    /// 判断一个请求是否超时。
    /// </summary>
    bool IsTimedOut(float sendTime, float currentTime, float timeoutSeconds);
}
