# Profile Domain Skill

- Client: generate profile query/update wrappers and cache refresh callback hooks.
- Server: generate player existence validation, profile repository hooks, privacy/sensitive-field filtering, and safe public profile DTO mapping.
- Avoid returning private account fields.
