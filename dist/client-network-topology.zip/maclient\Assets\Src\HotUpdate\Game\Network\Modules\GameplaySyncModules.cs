﻿using System;
using System.Threading.Tasks;

/// <summary>
/// 通用会话同步接口。
/// 用于订阅账号维度的资源/背包/角色等增量推送，适配战斗外与战斗内的统一状态刷新。
/// </summary>
public interface ISessionSyncNetworkModule
{
    /// <summary>
    /// 订阅资源同步推送。
    /// </summary>
    /// <param name="handler">资源同步消息处理器。</param>
    /// <returns>取消订阅句柄。</returns>
    IDisposable ObserveResourceSync(Action<SyncResource_s2c> handler);

    /// <summary>
    /// 订阅背包同步推送。
    /// </summary>
    /// <param name="handler">背包同步消息处理器。</param>
    /// <returns>取消订阅句柄。</returns>
    IDisposable ObserveInventorySync(Action<SyncInventory_s2c> handler);

    /// <summary>
    /// 订阅英雄/角色同步推送。
    /// </summary>
    /// <param name="handler">角色同步消息处理器。</param>
    /// <returns>取消订阅句柄。</returns>
    IDisposable ObserveHeroSync(Action<SyncHero_s2c> handler);
}

/// <summary>
/// 对局同步模块接口。
/// 用于实时玩法（PVP/PVE对局、竞技、休闲实时玩法）的逐帧/指令/结果同步。
/// </summary>
public interface IGameplayBattleSyncModule
{
    Task<BattleFrame_s2c> SendFrameAsync(string battleId, int frame, BattleOperation[] operations);
    Task<BattleCommand_s2c> SendCommandAsync(string battleId, string commandType, string payloadJson, long actorId = 0, int tickIndex = 0, int frame = 0);
    Task<BattleResult_s2c> ReportResultAsync(string battleId, BattleResultType result, BattleStatistic statistic = null, int elapsedFrames = 0);
    Task<BattleSyncHealth_s2c> ReportSyncHealthAsync(string battleId, BattleSyncHealth health = null, BattleChecksumInfo checksum = null, bool needServerHealth = true);
    Task<BattleResync_s2c> RequestResyncAsync(BattleResyncRequestData requestData);
}

/// <summary>
/// 挂机/进度同步模块接口。
/// 用于非实时玩法的状态推进与离线收益类同步。
/// </summary>
public interface IIdleProgressSyncModule
{
    /// <summary>
    /// 同步副本进度（可用于挂机进度、扫荡进度、阶段推进等业务）。
    /// </summary>
    /// <param name="dungeonId">副本或玩法实例ID。</param>
    /// <param name="progressJson">进度JSON，建议由业务定义稳定结构。</param>
    /// <returns>同步响应。</returns>
    Task<DungeonProgress_s2c> SyncDungeonProgressAsync(int dungeonId, string progressJson);
}

/// <summary>
/// 玩法同步模块容器。
/// 按“会话同步 / 对局同步 / 进度同步”拆分，便于不同游戏品类复用。
/// </summary>
public sealed class GameplaySyncModules
{
    /// <summary>会话同步模块。</summary>
    public ISessionSyncNetworkModule Session { get; }

    /// <summary>对局同步模块。</summary>
    public IGameplayBattleSyncModule Battle { get; }

    /// <summary>PVP 实时帧同步（jitter buffer + spectator notify）。</summary>
    public BattlePvpRealtimeSync Pvp { get; }

    /// <summary>挂机与进度同步模块。</summary>
    public IIdleProgressSyncModule Idle { get; }

    /// <summary>
    /// 构造玩法同步模块容器。
    /// </summary>
    /// <param name="requester">统一请求器。</param>
    public GameplaySyncModules(IGameNetworkRequester requester)
    {
        Session = new SessionSyncNetworkModule(requester);
        Battle = new GameplayBattleSyncModule(requester);
        Pvp = new BattlePvpRealtimeSync(requester, Battle);
        Idle = new IdleProgressSyncModule(requester);
    }

    /// <summary>
    /// 会话同步模块实现。
    /// </summary>
    private sealed class SessionSyncNetworkModule : ISessionSyncNetworkModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public SessionSyncNetworkModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public IDisposable ObserveResourceSync(Action<SyncResource_s2c> handler) => _requester.Subscribe(handler);
        public IDisposable ObserveInventorySync(Action<SyncInventory_s2c> handler) => _requester.Subscribe(handler);
        public IDisposable ObserveHeroSync(Action<SyncHero_s2c> handler) => _requester.Subscribe(handler);
    }

    /// <summary>
    /// 对局同步模块实现。
    /// </summary>
    private sealed class GameplayBattleSyncModule : IGameplayBattleSyncModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public GameplayBattleSyncModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public Task<BattleFrame_s2c> SendFrameAsync(string battleId, int frame, BattleOperation[] operations)
        {
            if (string.IsNullOrWhiteSpace(battleId))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "BattleId is empty.");
            }

            return _requester.RequestAsync<BattleFrame_s2c>(
                new BattleFrame_c2s
                {
                    BattleId = battleId,
                    Frame = Math.Max(0, frame),
                    Operations = operations ?? Array.Empty<BattleOperation>()
                },
                NetworkChannel.Battle,
                requireToken: true,
                reliable: true,
                priority: 0);
        }

        public Task<BattleCommand_s2c> SendCommandAsync(string battleId, string commandType, string payloadJson, long actorId = 0, int tickIndex = 0, int frame = 0)
        {
            if (string.IsNullOrWhiteSpace(battleId))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "BattleId is empty.");
            }

            return _requester.RequestAsync<BattleCommand_s2c>(
                new BattleCommand_c2s
                {
                    BattleId = battleId,
                    CommandId = Guid.NewGuid().ToString("N"),
                    ActorId = actorId,
                    CommandType = string.IsNullOrWhiteSpace(commandType) ? "custom" : commandType,
                    TickIndex = Math.Max(0, tickIndex),
                    Frame = Math.Max(0, frame),
                    ClientTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    IdempotencyKey = Guid.NewGuid().ToString("N"),
                    PayloadJson = string.IsNullOrWhiteSpace(payloadJson) ? "{}" : payloadJson
                },
                NetworkChannel.Battle,
                requireToken: true,
                reliable: true,
                priority: 0);
        }

        public Task<BattleResult_s2c> ReportResultAsync(string battleId, BattleResultType result, BattleStatistic statistic = null, int elapsedFrames = 0)
        {
            if (string.IsNullOrWhiteSpace(battleId))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "BattleId is empty.");
            }

            return _requester.RequestAsync<BattleResult_s2c>(
                new BattleResult_c2s
                {
                    BattleId = battleId,
                    Result = result,
                    ElapsedFrames = Math.Max(0, elapsedFrames),
                    Statistic = statistic ?? new BattleStatistic()
                },
                NetworkChannel.Battle,
                requireToken: true,
                reliable: true,
                priority: 0);
        }

        public Task<BattleSyncHealth_s2c> ReportSyncHealthAsync(string battleId, BattleSyncHealth health = null, BattleChecksumInfo checksum = null, bool needServerHealth = true)
        {
            if (string.IsNullOrWhiteSpace(battleId))
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "BattleId is empty.");
            }

            return _requester.RequestAsync<BattleSyncHealth_s2c>(
                new BattleSyncHealth_c2s
                {
                    BattleId = battleId,
                    Health = health,
                    Checksum = checksum,
                    NeedServerHealth = needServerHealth
                },
                NetworkChannel.Battle,
                requireToken: true,
                reliable: false,
                priority: 1);
        }

        public Task<BattleResync_s2c> RequestResyncAsync(BattleResyncRequestData requestData)
        {
            if (requestData == null)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "RequestData is null.");
            }

            return _requester.RequestAsync<BattleResync_s2c>(
                new BattleResync_c2s { Request = requestData },
                NetworkChannel.Battle,
                requireToken: true,
                reliable: true,
                priority: 0);
        }
    }

    /// <summary>
    /// 挂机与进度同步模块实现。
    /// </summary>
    private sealed class IdleProgressSyncModule : IIdleProgressSyncModule
    {
        /// <summary>底层请求器。</summary>
        private readonly IGameNetworkRequester _requester;

        public IdleProgressSyncModule(IGameNetworkRequester requester)
        {
            _requester = requester;
        }

        public Task<DungeonProgress_s2c> SyncDungeonProgressAsync(int dungeonId, string progressJson)
        {
            if (dungeonId <= 0)
            {
                throw new GameNetworkException(GameNetworkErrorCodes.InvalidArgument, "DungeonId must be > 0.");
            }

            return _requester.RequestAsync<DungeonProgress_s2c>(
                new DungeonProgress_c2s
                {
                    DungeonId = dungeonId,
                    Progress = string.IsNullOrWhiteSpace(progressJson) ? "{}" : progressJson
                },
                NetworkChannel.Game,
                requireToken: true,
                reliable: true,
                priority: 1);
        }
    }
}
