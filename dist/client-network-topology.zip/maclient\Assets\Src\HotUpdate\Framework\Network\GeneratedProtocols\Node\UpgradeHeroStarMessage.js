// 自动生成的协议文件

// 定义协议类


// 英雄升星(消耗同名卡/素材)
class UpgradeHeroStar_c2s {
    constructor() {
        this.HeroId = null;
        this.ConsumeHeroes = [];
        this.ConsumeItems = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 英雄升星结果
class UpgradeHeroStar_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Hero = null;
        this.RemovedHeroIds = [];
        this.InventoryDelta = null;
        this.ResourceChanges = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    UpgradeHeroStar_c2s,
    UpgradeHeroStar_s2c,
};
