using System;
using System.Collections.Generic;

/// <summary>
/// 快照同步通道默认实现。
/// 适合“最新状态覆盖旧状态”的同步消息处理模式。
/// </summary>
public sealed class SnapshotSyncChannel : ISnapshotSyncChannel
{
    private readonly Dictionary<int, Action<NetMessage>> _handlers = new Dictionary<int, Action<NetMessage>>();

    public string Name => "SnapshotSync";

    public bool CanHandle(NetMessage message)
    {
        return message != null && _handlers.ContainsKey(message.MessageID);
    }

    public void Handle(NetMessage message)
    {
        if (message == null)
        {
            return;
        }

        if (_handlers.TryGetValue(message.MessageID, out var handler))
        {
            handler?.Invoke(message);
        }
    }

    public void RegisterSnapshotHandler(int messageId, Action<NetMessage> handler)
    {
        if (handler == null)
        {
            _handlers.Remove(messageId);
            return;
        }

        _handlers[messageId] = handler;
    }
}

/// <summary>
/// 帧同步通道默认实现。
/// 适合“按顺序逐帧消费”的同步消息处理模式。
/// </summary>
public sealed class FrameSyncChannel : IFrameSyncChannel
{
    private readonly Dictionary<int, Action<NetMessage>> _handlers = new Dictionary<int, Action<NetMessage>>();

    public string Name => "FrameSync";

    public bool CanHandle(NetMessage message)
    {
        return message != null && _handlers.ContainsKey(message.MessageID);
    }

    public void Handle(NetMessage message)
    {
        if (message == null)
        {
            return;
        }

        if (_handlers.TryGetValue(message.MessageID, out var handler))
        {
            handler?.Invoke(message);
        }
    }

    public void RegisterFrameHandler(int messageId, Action<NetMessage> handler)
    {
        if (handler == null)
        {
            _handlers.Remove(messageId);
            return;
        }

        _handlers[messageId] = handler;
    }
}
