﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 赠送好友体力/友情点
/// </summary>
public class SendFriendEnergy_c2s
{
    /// <summary>
    /// 要赠送的好友 ID 列表(可多选)
    /// </summary>
    public long[] TargetPlayerIds { get; set; }
}

/// <summary>
/// 赠送好友体力结果
/// </summary>
public class SendFriendEnergy_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

