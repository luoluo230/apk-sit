// 自动生成的协议文件

// 定义协议类


// 创建队伍
class CreateTeam_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 创建队伍结果
class CreateTeam_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Team = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    CreateTeam_c2s,
    CreateTeam_s2c,
};
