using System;
using System.Collections.Generic;

/// <summary>
/// 请求分发器默认实现。
/// 负责维护等待中的响应回调，并在消息到达时按顺序匹配派发。
/// </summary>
public sealed class NetworkRequestDispatcher : IRequestDispatcher
{
    private readonly MessageRouter _messageRouter;
    private readonly IRequestPolicy _requestPolicy;
    private readonly Dictionary<int, List<PendingResponseEntry>> _responseCallbacks = new Dictionary<int, List<PendingResponseEntry>>();

    private struct PendingResponseEntry
    {
        public string RequestInstanceId;
        public Action<object> Callback;
        public float SendTime;
        public int ResponseMessageId;
        public Type ExpectedType;
    }

    /// <summary>
    /// 创建请求分发器。
    /// </summary>
    public NetworkRequestDispatcher(MessageRouter messageRouter, IRequestPolicy requestPolicy)
    {
        _messageRouter = messageRouter ?? throw new ArgumentNullException(nameof(messageRouter));
        _requestPolicy = requestPolicy ?? throw new ArgumentNullException(nameof(requestPolicy));
    }

    /// <summary>
    /// 注册一个请求对应的响应回调。
    /// </summary>
    public string RegisterResponseCallback<T>(int requestMessageId, Action<T> callback, float currentTime) where T : class
    {
        if (callback == null)
        {
            return string.Empty;
        }

        var responseMessageId = _requestPolicy.GetResponseMessageId(requestMessageId);
        if (!_responseCallbacks.TryGetValue(responseMessageId, out var list))
        {
            list = new List<PendingResponseEntry>();
            _responseCallbacks[responseMessageId] = list;
        }

        var requestInstanceId = Guid.NewGuid().ToString("N");
        list.Add(new PendingResponseEntry
        {
            RequestInstanceId = requestInstanceId,
            Callback = obj => callback(obj as T),
            SendTime = currentTime,
            ResponseMessageId = responseMessageId,
            ExpectedType = typeof(T)
        });
        return requestInstanceId;
    }

    public void CancelResponseCallback(int requestMessageId, string reason, Action<int, string, string> onRequestFailed)
    {
        var responseMessageId = _requestPolicy.GetResponseMessageId(requestMessageId);
        if (!_responseCallbacks.TryGetValue(responseMessageId, out var list) || list.Count == 0)
        {
            return;
        }

        var entry = list[0];
        list.RemoveAt(0);
        if (list.Count == 0)
        {
            _responseCallbacks.Remove(responseMessageId);
        }

        entry.Callback?.Invoke(null);
        onRequestFailed?.Invoke(responseMessageId, entry.RequestInstanceId, string.IsNullOrWhiteSpace(reason) ? "Request cancelled." : reason);
    }

    /// <summary>
    /// 清理超时请求，并通过回调通知调用方失败原因。
    /// </summary>
    public void CheckTimeouts(float currentTime, float timeoutSeconds, Action<int, string, string> onRequestFailed)
    {
        if (timeoutSeconds <= 0f || _responseCallbacks.Count == 0)
        {
            return;
        }

        var emptyKeys = new List<int>();
        var timedOutEntries = new List<PendingResponseEntry>();
        foreach (var pair in _responseCallbacks)
        {
            var list = pair.Value;
            for (var index = list.Count - 1; index >= 0; index--)
            {
                if (!_requestPolicy.IsTimedOut(list[index].SendTime, currentTime, timeoutSeconds))
                {
                    continue;
                }

                var entry = list[index];
                list.RemoveAt(index);
                timedOutEntries.Add(entry);
            }

            if (list.Count == 0)
            {
                emptyKeys.Add(pair.Key);
            }
        }

        foreach (var key in emptyKeys)
        {
            _responseCallbacks.Remove(key);
        }

        for (var i = 0; i < timedOutEntries.Count; i++)
        {
            var entry = timedOutEntries[i];
            entry.Callback?.Invoke(null);
            onRequestFailed?.Invoke(entry.ResponseMessageId, entry.RequestInstanceId, "Request timed out.");
        }
    }

    /// <summary>
    /// 派发消息。
    /// 优先走待响应回调链，未命中时再交给普通消息路由器。
    /// </summary>
    public void Dispatch(NetMessage message)
    {
        if (message == null)
        {
            return;
        }

        var responseMessageId = message.MessageID;
        if (_responseCallbacks.TryGetValue(responseMessageId, out var list) && list.Count > 0)
        {
            for (var i = 0; i < list.Count; i++)
            {
                var entry = list[i];
                object responseData = TryDeserializeForEntry(message, entry);
                if (responseData == null)
                {
                    // Keep pending entry when payload cannot be decoded for this instance.
                    continue;
                }

                list.RemoveAt(i);
                if (list.Count == 0)
                {
                    _responseCallbacks.Remove(responseMessageId);
                }

                entry.Callback?.Invoke(responseData);
                return;
            }

            // Message did not match any pending instance decode; fall through to normal router.
        }

        _messageRouter.Dispatch(message);
    }

    private static object TryDeserializeForEntry(NetMessage message, PendingResponseEntry entry)
    {
        if (message == null)
        {
            return null;
        }

        object responseData = NetMessage.DeserializeData(message);
        if (responseData != null)
        {
            return responseData;
        }

        if (message.Data != null && entry.ExpectedType != null)
        {
            try
            {
                responseData = NetworkPayloadPipeline.Decode(message.Data.ToString(), entry.ExpectedType);
                if (responseData != null)
                {
                    return responseData;
                }
            }
            catch
            {
                // ignore and continue fallback
            }
        }

        if (message.Data != null)
        {
            return NetMessage.DeserializeData<object>(message.Data);
        }

        return null;
    }

    /// <summary>
    /// 以统一原因清空所有待处理请求。
    /// </summary>
    public void Clear(string reason, Action<int, string, string> onRequestFailed)
    {
        var pendingEntries = new List<PendingResponseEntry>();
        foreach (var pair in _responseCallbacks)
        {
            foreach (var entry in pair.Value)
            {
                pendingEntries.Add(entry);
            }
        }

        _responseCallbacks.Clear();

        for (var i = 0; i < pendingEntries.Count; i++)
        {
            var entry = pendingEntries[i];
            entry.Callback?.Invoke(null);
            onRequestFailed?.Invoke(entry.ResponseMessageId, entry.RequestInstanceId, reason);
        }
    }
}
