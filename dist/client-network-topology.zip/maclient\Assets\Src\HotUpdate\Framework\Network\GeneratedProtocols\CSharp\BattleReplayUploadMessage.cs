﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 上传战斗回放元数据/分片
/// </summary>
public class BattleReplayUpload_c2s
{
    /// <summary>
    /// 回放元数据
    /// </summary>
    public BattleReplayMeta Meta { get; set; }
    /// <summary>
    /// 回放分片(可空，先上报元数据时可空)
    /// </summary>
    public BattleReplayChunk Chunk { get; set; }
    /// <summary>
    /// 是否上传完成
    /// </summary>
    public bool Complete { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 战斗回放上传响应
/// </summary>
public class BattleReplayUpload_s2c
{
    /// <summary>
    /// 处理结果
    /// </summary>
    public BattleProtocolAck Ack { get; set; }
    /// <summary>
    /// 回放 ID
    /// </summary>
    public string ReplayId { get; set; }
    /// <summary>
    /// 已接收分片序号
    /// </summary>
    public int AcceptedChunkIndex { get; set; }
    /// <summary>
    /// 服务端期望下一分片序号
    /// </summary>
    public int NeedNextChunkIndex { get; set; }
    /// <summary>
    /// 上传完成时返回定位信息
    /// </summary>
    public BattleReplayLocator Locator { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

