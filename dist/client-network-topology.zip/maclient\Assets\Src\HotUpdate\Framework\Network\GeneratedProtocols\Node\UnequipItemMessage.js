// 自动生成的协议文件

// 定义协议类


// 卸下装备
class UnequipItem_c2s {
    constructor() {
        this.HeroId = null;
        this.SlotType = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 卸下装备结果
class UnequipItem_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Hero = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    UnequipItem_c2s,
    UnequipItem_s2c,
};
