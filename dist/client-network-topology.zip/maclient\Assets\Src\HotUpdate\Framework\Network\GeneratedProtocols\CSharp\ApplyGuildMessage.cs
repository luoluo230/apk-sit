﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 申请加入公会
/// </summary>
public class ApplyGuild_c2s
{
    /// <summary>
    /// 公会 ID
    /// </summary>
    public long GuildId { get; set; }
    /// <summary>
    /// 申请附言
    /// </summary>
    public string Message { get; set; }
}

/// <summary>
/// 申请加入公会结果
/// </summary>
public class ApplyGuild_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

