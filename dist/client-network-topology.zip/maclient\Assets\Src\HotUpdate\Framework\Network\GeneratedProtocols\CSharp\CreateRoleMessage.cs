﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 创建角色请求
/// </summary>
public class CreateRole_c2s
{
    /// <summary>
    /// 服务器 ID
    /// </summary>
    public string ServerId { get; set; }
    /// <summary>
    /// 角色昵称
    /// </summary>
    public string Nickname { get; set; }
    /// <summary>
    /// 头像/职业选择
    /// </summary>
    public string Avatar { get; set; }
}

/// <summary>
/// 创建角色响应
/// </summary>
public class CreateRole_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 创建好的角色信息
    /// </summary>
    public PlayerProfile Profile { get; set; }
}

