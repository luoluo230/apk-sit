﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 背包变化推送(掉落/消耗等)
/// </summary>
public class SyncInventory_s2c
{
    /// <summary>
    /// 是否为全量同步
    /// </summary>
    public bool Full { get; set; }
    /// <summary>
    /// 当Full=true时为完整背包
    /// </summary>
    public InventoryInfo Inventory { get; set; }
    /// <summary>
    /// 增量更新数据
    /// </summary>
    public InventoryDelta Delta { get; set; }
    /// <summary>
    /// 变更原因
    /// </summary>
    public string Reason { get; set; }
}

