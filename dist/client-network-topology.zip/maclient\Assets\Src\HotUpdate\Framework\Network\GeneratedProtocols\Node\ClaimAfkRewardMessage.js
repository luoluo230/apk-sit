// 自动生成的协议文件

// 定义协议类


// 领取挂机收益/快速战斗奖励
class ClaimAfkReward_c2s {
    constructor() {
        this.UseQuickReward = false;
        this.QuickRewardTimes = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 挂机收益领取结果
class ClaimAfkReward_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Rewards = [];
        this.ResourceChanges = [];
        this.Afk = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ClaimAfkReward_c2s,
    ClaimAfkReward_s2c,
};
