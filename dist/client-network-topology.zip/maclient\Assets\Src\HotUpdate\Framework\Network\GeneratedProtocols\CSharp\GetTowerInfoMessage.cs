﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取爬塔信息
/// </summary>
public class GetTowerInfo_c2s
{
    /// <summary>
    /// 塔 ID
    /// </summary>
    public int TowerId { get; set; }
}

/// <summary>
/// 爬塔信息响应
/// </summary>
public class GetTowerInfo_s2c
{
    /// <summary>
    /// 塔信息
    /// </summary>
    public TowerInfo Tower { get; set; }
}

