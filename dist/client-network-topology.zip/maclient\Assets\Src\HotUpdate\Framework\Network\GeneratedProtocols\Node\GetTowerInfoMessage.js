// 自动生成的协议文件

// 定义协议类


// 获取爬塔信息
class GetTowerInfo_c2s {
    constructor() {
        this.TowerId = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 爬塔信息响应
class GetTowerInfo_s2c {
    constructor() {
        this.Tower = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetTowerInfo_c2s,
    GetTowerInfo_s2c,
};
