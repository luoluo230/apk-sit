﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 踢出队伍成员
/// </summary>
public class KickTeamMember_c2s
{
    /// <summary>
    /// 成员玩家 ID
    /// </summary>
    public long TargetPlayerId { get; set; }
}

/// <summary>
/// 踢出队伍成员结果
/// </summary>
public class KickTeamMember_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 队伍信息
    /// </summary>
    public TeamInfo Team { get; set; }
}

