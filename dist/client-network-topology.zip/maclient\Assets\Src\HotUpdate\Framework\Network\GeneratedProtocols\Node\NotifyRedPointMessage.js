// 自动生成的协议文件

// 定义协议类


// 红点变化推送
class NotifyRedPoint_s2c {
    constructor() {
        this.RedPoints = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    NotifyRedPoint_s2c,
};
