# Capabilities

这里放“标准生成能力”，只描述要生成哪一层代码。

## 分类

- `Client`：客户端 C# 调用层，如 API wrapper、UseCase、Presenter 示例。
- `Server`：服务端入口和数据层，如 Handler、Service、Repository/DB。
- `Shared`：双端通用辅助能力，如 Mock/Test、Migration。

## 规则

- 不写具体业务闭环，具体业务放到 `Scenarios`。
- 不写全局质量门禁，通用约束放到 `Support`。
- 新增文件后必须在 `ProtocolSkillRegistry` 注册，否则工作台不会读取。
