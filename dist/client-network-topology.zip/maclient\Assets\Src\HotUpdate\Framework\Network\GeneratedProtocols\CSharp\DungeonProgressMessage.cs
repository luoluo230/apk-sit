﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 副本内进度同步
/// </summary>
public class DungeonProgress_c2s
{
    /// <summary>
    /// 副本 ID
    /// </summary>
    public int DungeonId { get; set; }
    /// <summary>
    /// 进度数据(JSON)
    /// </summary>
    public string Progress { get; set; }
}

/// <summary>
/// 副本进度同步结果
/// </summary>
public class DungeonProgress_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

