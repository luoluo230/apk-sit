using System;
using System.Collections.Generic;
using System.Linq;

public sealed class ProtocolTypeReference
{
    private static readonly HashSet<string> PrimitiveTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "int", "int32", "long", "int64", "float", "double", "bool", "boolean", "string", "byte", "short"
    };

    public string Name { get; private set; }
    public bool IsArray { get; private set; }
    public bool IsNullable { get; private set; }
    public readonly List<ProtocolTypeReference> GenericArguments = new List<ProtocolTypeReference>();

    public static ProtocolTypeReference Parse(string raw)
    {
        string value = (raw ?? "string").Trim();
        var result = new ProtocolTypeReference();
        if (value.EndsWith("?", StringComparison.Ordinal))
        {
            result.IsNullable = true;
            value = value.Substring(0, value.Length - 1);
        }

        if (value.EndsWith("[]", StringComparison.Ordinal))
        {
            result.IsArray = true;
            value = value.Substring(0, value.Length - 2);
        }

        int genericStart = value.IndexOf('<');
        if (genericStart > 0 && value.EndsWith(">", StringComparison.Ordinal))
        {
            result.Name = value.Substring(0, genericStart).Trim();
            string inner = value.Substring(genericStart + 1, value.Length - genericStart - 2);
            foreach (string part in SplitGenericArguments(inner))
            {
                result.GenericArguments.Add(Parse(part));
            }
        }
        else
        {
            result.Name = string.IsNullOrWhiteSpace(value) ? "string" : value;
        }

        return result;
    }

    public IEnumerable<string> GetNamedDependencies()
    {
        if (!PrimitiveTypes.Contains(Name) && !string.Equals(Name, "List", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(Name, "Map", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(Name, "Dictionary", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(Name, "OneOf", StringComparison.OrdinalIgnoreCase))
        {
            yield return Name;
        }

        foreach (ProtocolTypeReference child in GenericArguments)
        {
            foreach (string dependency in child.GetNamedDependencies())
            {
                yield return dependency;
            }
        }
    }

    public override string ToString()
    {
        string value = Name;
        if (GenericArguments.Count > 0) value += "<" + string.Join(",", GenericArguments.Select(arg => arg.ToString())) + ">";
        if (IsArray) value += "[]";
        if (IsNullable) value += "?";
        return value;
    }

    private static IEnumerable<string> SplitGenericArguments(string value)
    {
        int depth = 0;
        int start = 0;
        for (int i = 0; i < value.Length; i++)
        {
            if (value[i] == '<') depth++;
            else if (value[i] == '>') depth--;
            else if (value[i] == ',' && depth == 0)
            {
                yield return value.Substring(start, i - start).Trim();
                start = i + 1;
            }
        }

        yield return value.Substring(start).Trim();
    }
}
