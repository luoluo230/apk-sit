﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取单个活动详情/进度
/// </summary>
public class GetEventDetail_c2s
{
    /// <summary>
    /// 活动 ID
    /// </summary>
    public int EventId { get; set; }
}

/// <summary>
/// 活动详情响应(按具体活动自定义Custom)
/// </summary>
public class GetEventDetail_s2c
{
    /// <summary>
    /// 活动基础信息
    /// </summary>
    public EventInfo Event { get; set; }
    /// <summary>
    /// 活动进度数据(JSON)
    /// </summary>
    public string Progress { get; set; }
}

