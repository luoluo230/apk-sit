using System.Collections.Generic;

/// <summary>
/// 网络诊断服务默认实现。
/// 用于按配置输出网络流量日志和关键调试信息。
/// </summary>
public sealed class NetworkDiagnosticsService : INetworkDiagnosticsService
{
    private readonly bool _enableDebugTrafficLog;
    private readonly int _debugPayloadPreviewLength;
    private readonly Dictionary<int, string> _protocolNames;

    /// <summary>
    /// 创建诊断服务。
    /// </summary>
    public NetworkDiagnosticsService(bool enableDebugTrafficLog, int debugPayloadPreviewLength, Dictionary<int, string> protocolNames)
    {
        _enableDebugTrafficLog = enableDebugTrafficLog;
        _debugPayloadPreviewLength = debugPayloadPreviewLength;
        _protocolNames = protocolNames ?? new Dictionary<int, string>();
    }

    /// <summary>
    /// 输出一条网络消息的调试日志。
    /// </summary>
    public void LogTraffic(string direction, NetMessage message)
    {
        if (!_enableDebugTrafficLog || message == null)
        {
            return;
        }

        var name = _protocolNames.TryGetValue(message.MessageID, out var value) ? value : "Unknown";
        var payloadPreview = BuildPayloadPreview(message.Data);
        var chunkInfo = message.IsChunk ? $" chunk {message.ChunkIndex + 1}/{message.ChunkTotal}" : string.Empty;
        Logger.Log($"[NetDebug] {direction} ID={message.MessageID} ({name}) Seq={message.SequenceId} Ack={message.RequiresAck} Priority={message.Priority}{chunkInfo} Type={message.DataType} Payload={payloadPreview}");
    }

    /// <summary>
    /// 输出通用网络日志。
    /// </summary>
    public void Log(string message, LogLevel level = LogLevel.Info)
    {
        if (!_enableDebugTrafficLog && level == LogLevel.Info)
        {
            return;
        }

        Logger.Log(message, level);
    }

    /// <summary>
    /// 构造消息载荷预览字符串。
    /// </summary>
    private string BuildPayloadPreview(object payload)
    {
        if (payload == null)
        {
            return "<null>";
        }

        var text = payload as string ?? payload.ToString();
        if (string.IsNullOrEmpty(text))
        {
            return "<empty>";
        }

        if (_debugPayloadPreviewLength > 0 && text.Length > _debugPayloadPreviewLength)
        {
            text = text.Substring(0, _debugPayloadPreviewLength) + "...";
        }

        return text;
    }
}
