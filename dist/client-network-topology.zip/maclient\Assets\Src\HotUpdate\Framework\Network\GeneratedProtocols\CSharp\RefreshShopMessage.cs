﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 手动刷新商店
/// </summary>
public class RefreshShop_c2s
{
    /// <summary>
    /// 商店类型
    /// </summary>
    public ShopType ShopType { get; set; }
}

/// <summary>
/// 商店刷新结果
/// </summary>
public class RefreshShop_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 刷新后的商店数据
    /// </summary>
    public ShopItemInfo[] Items { get; set; }
    /// <summary>
    /// 刷新花费
    /// </summary>
    public ResourceChange[] ResourceChanges { get; set; }
}

