// 自动生成的协议文件

// 定义协议类


// 公会列表(用于查找加入)
class GetGuildList_c2s {
    constructor() {
        this.PageIndex = 0;
        this.PageSize = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 公会列表响应
class GetGuildList_s2c {
    constructor() {
        this.Guilds = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetGuildList_c2s,
    GetGuildList_s2c,
};
