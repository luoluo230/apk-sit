// 自动生成的协议文件

// 定义协议类


// 参与活动行为(翻牌/转盘/签到等统一入口)
class DoEventAction_c2s {
    constructor() {
        this.EventId = 0;
        this.Action = '';
        this.Params = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 活动行为结果
class DoEventAction_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Rewards = [];
        this.Progress = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    DoEventAction_c2s,
    DoEventAction_s2c,
};
