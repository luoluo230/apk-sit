// 自动生成的协议文件

// 定义协议类


// 申请加入公会
class ApplyGuild_c2s {
    constructor() {
        this.GuildId = null;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 申请加入公会结果
class ApplyGuild_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ApplyGuild_c2s,
    ApplyGuild_s2c,
};
