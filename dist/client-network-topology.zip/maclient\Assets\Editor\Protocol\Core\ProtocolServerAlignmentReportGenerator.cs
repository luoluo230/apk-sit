﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;

/// <summary>
/// 导出“协议与网络治理报告”：
/// 链路矩阵、协议映射、孤儿协议、传输能力矩阵。
/// </summary>
public static class ProtocolServerAlignmentReportGenerator
{
    private const string ReportRoot = "protocols/generated/reports";

    [MenuItem("Tools/MAClient/协议与网络/导出协议与网络治理报告")]
    public static void ExportReports()
    {
        Directory.CreateDirectory(ReportRoot);

        WriteLifecycleMatrixReport();
        WriteProtocolMappingReport();
        WriteOrphanProtocolReport();
        WriteTransportCapabilityReport();

        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("导出完成", "协议与网络治理报告已输出到:\n" + ReportRoot, "确定");
    }

    private static void WriteLifecycleMatrixReport()
    {
        var builder = new StringBuilder();
        builder.AppendLine("# 底层通用链路矩阵（客户端/服务端对齐）");
        builder.AppendLine();
        builder.AppendLine("| 阶段 | 输入 | 输出 | 关键日志键 |");
        builder.AppendLine("| --- | --- | --- | --- |");
        builder.AppendLine("| Bootstrap | 网络配置资产 | 生效配置快照 | ConfigApplied |");
        builder.AppendLine("| EndpointResolve | 滚服开关/单服ID | 最终 endpoint 与 serverId | LoginModeDecision |");
        builder.AppendLine("| AuthSession | 注册/登录/token | 可用会话 | SerializerResolved |");
        builder.AppendLine("| KeepAlive | 心跳请求 | 连接健康状态 | KeepAlive |");
        builder.AppendLine("| ConnectionResilience | 断线事件 | 重连/恢复结果 | Reconnect |");
        builder.AppendLine("| Messaging | 通用请求/推送 | 业务响应/通知 | MessageRoute |");
        builder.AppendLine("| LogoutTeardown | 登出请求 | 会话清理完成 | Logout |");
        File.WriteAllText(Path.Combine(ReportRoot, "network-lifecycle-matrix.md"), builder.ToString(), new UTF8Encoding(false));
    }

    private static void WriteProtocolMappingReport()
    {
        ProtocolSchemaDocument schema = ProtocolSchemaDocument.Load("Assets/Src/Protocols/protocols.json");
        HashSet<string> all = new HashSet<string>(schema.Entries.Select(e => e.Name), StringComparer.Ordinal);
        HashSet<string> core = LoadArray("Assets/Src/Protocols/protocol-core-required.json", "CoreRequired");
        HashSet<string> ext = LoadArray("Assets/Src/Protocols/protocol-business-extensions.json", "BusinessExtensions");

        var builder = new StringBuilder();
        builder.AppendLine("# 协议映射报告");
        builder.AppendLine();
        builder.AppendLine("## 核心必需协议");
        foreach (string item in core.OrderBy(x => x, StringComparer.Ordinal))
        {
            builder.AppendLine("- " + item + (all.Contains(item) ? " ✅" : " ❌缺失"));
        }

        builder.AppendLine();
        builder.AppendLine("## 业务扩展协议");
        foreach (string item in ext.OrderBy(x => x, StringComparer.Ordinal))
        {
            builder.AppendLine("- " + item + (all.Contains(item) ? " ✅" : " ⚠未定义"));
        }

        File.WriteAllText(Path.Combine(ReportRoot, "protocol-mapping-report.md"), builder.ToString(), new UTF8Encoding(false));
    }

    private static void WriteOrphanProtocolReport()
    {
        ProtocolSchemaDocument schema = ProtocolSchemaDocument.Load("Assets/Src/Protocols/protocols.json");
        HashSet<string> core = LoadArray("Assets/Src/Protocols/protocol-core-required.json", "CoreRequired");
        HashSet<string> ext = LoadArray("Assets/Src/Protocols/protocol-business-extensions.json", "BusinessExtensions");
        core.UnionWith(ext);

        List<string> orphan = schema.Entries
            .Where(e => e.Kind == ProtocolSchemaEntryKind.Message)
            .Select(e => e.Name)
            .Where(name => !core.Contains(name))
            .OrderBy(x => x, StringComparer.Ordinal)
            .ToList();

        var builder = new StringBuilder();
        builder.AppendLine("# 孤儿协议报告");
        builder.AppendLine();
        builder.AppendLine("- 总数: " + orphan.Count);
        builder.AppendLine();
        foreach (string item in orphan)
        {
            builder.AppendLine("- " + item);
        }

        File.WriteAllText(Path.Combine(ReportRoot, "orphan-protocol-report.md"), builder.ToString(), new UTF8Encoding(false));
    }

    private static void WriteTransportCapabilityReport()
    {
        var builder = new StringBuilder();
        builder.AppendLine("# 传输能力报告");
        builder.AppendLine();
        builder.AppendLine("## 客户端矩阵");
        builder.AppendLine("```");
        builder.AppendLine(BuildTransportCapabilityMatrixFallback());
        builder.AppendLine("```");
        builder.AppendLine();
        builder.AppendLine("## 预期服务端对齐");
        builder.AppendLine("- Http: 短连接请求-响应");
        builder.AppendLine("- WebSocket: 长连接推送与实时消息");
        builder.AppendLine("- Tcp: 长连接业务通道");
        builder.AppendLine("- Kcp(Udp): 长连接低延迟通道");

        File.WriteAllText(Path.Combine(ReportRoot, "transport-capability-report.md"), builder.ToString(), new UTF8Encoding(false));
    }

    private static string BuildTransportCapabilityMatrixFallback()
    {
        return string.Join("\n", new[]
        {
            "Transport | 连接形态 | 典型用途",
            "Http      | 短连接   | 登录、配置、一次性请求",
            "WebSocket | 长连接   | 实时推送、大厅消息",
            "Tcp       | 长连接   | 稳定业务通道",
            "Kcp(Udp)  | 长连接   | 战斗/低延迟同步"
        });
    }

    private static HashSet<string> LoadArray(string path, string key)
    {
        var result = new HashSet<string>(StringComparer.Ordinal);
        if (!File.Exists(path))
        {
            return result;
        }

        string json = File.ReadAllText(path, Encoding.UTF8);
        if (!ProtocolJson.TryParse(json, out ProtocolJsonValue value, out _) || !(value is ProtocolJsonObject root))
        {
            return result;
        }

        if (!(root.Get(key) is ProtocolJsonArray array))
        {
            return result;
        }

        foreach (ProtocolJsonValue item in array.Items)
        {
            if (item is ProtocolJsonString s && !string.IsNullOrWhiteSpace(s.Value))
            {
                result.Add(s.Value.Trim());
            }
        }

        return result;
    }
}
