﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 领取关卡奖励(首通/星级/章节宝箱等)
/// </summary>
public class ClaimStageReward_c2s
{
    /// <summary>
    /// 关卡 ID
    /// </summary>
    public string StageId { get; set; }
    /// <summary>
    /// 奖励类型(FirstPass/Star/Chapter等)
    /// </summary>
    public string RewardType { get; set; }
}

/// <summary>
/// 关卡奖励领取结果
/// </summary>
public class ClaimStageReward_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 失败原因或提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 关卡 ID
    /// </summary>
    public string StageId { get; set; }
    /// <summary>
    /// 奖励类型
    /// </summary>
    public string RewardType { get; set; }
    /// <summary>
    /// 获得奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
    /// <summary>
    /// 资源变化
    /// </summary>
    public ResourceChange[] ResourceChanges { get; set; }
}

