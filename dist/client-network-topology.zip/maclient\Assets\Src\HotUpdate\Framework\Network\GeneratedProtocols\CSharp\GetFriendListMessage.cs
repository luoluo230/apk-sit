﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取好友列表及申请列表
/// </summary>
public class GetFriendList_c2s
{
}

/// <summary>
/// 好友列表响应
/// </summary>
public class GetFriendList_s2c
{
    /// <summary>
    /// 好友列表
    /// </summary>
    public FriendInfo[] Friends { get; set; }
    /// <summary>
    /// 好友申请列表
    /// </summary>
    public FriendRequestInfo[] Requests { get; set; }
}

