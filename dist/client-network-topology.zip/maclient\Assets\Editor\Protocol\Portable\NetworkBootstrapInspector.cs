using UnityEditor;
using UnityEngine;

/// <summary>
/// NetworkBootstrap 专用检查器。
/// 只展示单组件壳需要的配置与快捷操作，避免底层组件参数分散暴露。
/// </summary>
[CustomEditor(typeof(NetworkBootstrap))]
public sealed class NetworkBootstrapInspector : Editor
{
    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        EditorGUILayout.HelpBox(
            "推荐只使用 NetworkBootstrap 作为网络入口。底层 NetworkManager / NetworkFacade / GameNetworkClient 由该壳自动托管。",
            MessageType.Info);

        DrawProperty("protocolNetworkSettings", "协议网络配置资产");
        DrawProperty("autoLoadSettingsFromResources", "配置为空时自动从 Resources 加载");
        DrawProperty("dontDestroyOnLoad", "跨场景保留");
        DrawProperty("autoConnect", "启动自动连接");
        DrawProperty("autoCleanupLegacyNetworkComponents", "自动清理旧网络组件");
        DrawProperty("hideRuntimeNodeInHierarchy", "在层级面板隐藏内部运行时节点");

        EditorGUILayout.Space(8f);
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("打开协议与网络工作台", GUILayout.Height(24f)))
        {
            EditorApplication.ExecuteMenuItem("Tools/MAClient/协议与网络/协议与代码生成工作台");
        }

        if (GUILayout.Button("应用当前协议配置", GUILayout.Height(24f)))
        {
            foreach (Object obj in targets)
            {
                var bootstrap = obj as NetworkBootstrap;
                bootstrap?.ApplySettings();
                EditorUtility.SetDirty(obj);
            }
        }
        EditorGUILayout.EndHorizontal();

        if (GUILayout.Button("清理旧网络组件", GUILayout.Height(24f)))
        {
            foreach (Object obj in targets)
            {
                var bootstrap = obj as NetworkBootstrap;
                bootstrap?.CleanupLegacyNetworkComponents();
                EditorUtility.SetDirty(obj);
            }
        }

        serializedObject.ApplyModifiedProperties();
    }

    private void DrawProperty(string propertyName, string label)
    {
        SerializedProperty property = serializedObject.FindProperty(propertyName);
        if (property == null)
        {
            return;
        }

        EditorGUILayout.PropertyField(property, new GUIContent(label), true);
    }
}
