# Server Handler Skill

## 职责

生成服务端协议入口 Handler，负责接收请求、基础校验、session/权限入口、错误包装和调用 Service。

## 必须生成

- Handler 类和入口方法。
- request null 校验、required 字段校验、枚举/范围/长度校验。
- session/player/account 获取接入点。
- permission guard、rate limit、idempotency guard 接入点。
- try/catch，统一错误码返回。
- 调用 Service 并返回 response。

## 禁止事项

- 不在 Handler 直接写数据库。
- 不在 Handler 实现复杂领域规则。
- 不记录敏感字段。
- 不把 exception 原文直接返回客户端。

## 质量门禁

- 参数错误、未登录、无权限、业务失败、系统错误分支清晰。
- Handler 可被 mock request 单独测试。
