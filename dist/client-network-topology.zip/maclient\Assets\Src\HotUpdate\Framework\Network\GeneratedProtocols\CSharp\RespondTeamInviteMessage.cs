﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 响应组队邀请(同意/拒绝)
/// </summary>
public class RespondTeamInvite_c2s
{
    /// <summary>
    /// 邀请 ID
    /// </summary>
    public string InviteId { get; set; }
    /// <summary>
    /// 是否同意
    /// </summary>
    public bool Accept { get; set; }
}

/// <summary>
/// 响应组队邀请结果
/// </summary>
public class RespondTeamInvite_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 队伍信息
    /// </summary>
    public TeamInfo Team { get; set; }
}

