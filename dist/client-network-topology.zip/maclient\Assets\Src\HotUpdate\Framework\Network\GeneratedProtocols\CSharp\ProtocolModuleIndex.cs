﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System.Collections.Generic;

public static class ProtocolModuleIndex
{
    public static readonly Dictionary<string, string[]> ModuleToProtocols = new Dictionary<string, string[]>
    {
        { "Achievement", new[] { "ClaimAchievementReward", "GetAchievementList" } },
        { "Afk", new[] { "ClaimAfkReward", "GetAfkRewardInfo" } },
        { "Arena", new[] { "ArenaChallenge", "GetArenaInfo", "GetArenaRecords", "SetArenaDefense" } },
        { "Auth", new[] { "CreateRole", "Login", "SelectServer" } },
        { "Battle", new[] { "BattleCommand", "BattleErrorNotify", "BattleFrame", "BattleReplayQuery", "BattleReplayUpload", "BattleResult", "BattleResync", "BattleSpectatorFrameNotify", "BattleSpectatorJoin", "BattleSpectatorLeave", "BattleSyncHealth", "EnterBattle", "LeaveBattle" } },
        { "Campaign", new[] { "GetCampaignInfo" } },
        { "Chat", new[] { "ChatMessageNotify", "GetChatHistory", "SendChatMessage" } },
        { "Core", new[] { "NotifyRedPoint" } },
        { "Dungeon", new[] { "DungeonMatch", "DungeonProgress", "DungeonProgressNotify", "EnterDungeon" } },
        { "Event", new[] { "DoEventAction", "GetEventDetail", "GetEvents" } },
        { "Friend", new[] { "ApplyFriend", "DeleteFriend", "FriendOnlineStatusNotify", "FriendRequestNotify", "GetFriendList", "HandleFriendRequest", "ReceiveFriendEnergy", "SendFriendEnergy" } },
        { "Gacha", new[] { "DoGacha", "GetGachaInfo" } },
        { "General", new[] { "ClaimStageReward", "Logout", "SearchPlayer", "SessionResume", "SetFormation", "TokenRefresh" } },
        { "Guild", new[] { "ApplyGuild", "ChangeGuildSettings", "CreateGuild", "DonateGuild", "GetGuildActivities", "GetGuildInfo", "GetGuildList", "GuildApplyNotify", "GuildMemberUpdateNotify", "HandleGuildApply", "JoinGuildActivity", "KickGuildMember", "LeaveGuild" } },
        { "Hero", new[] { "GetHeroList", "ResetHero", "SyncHero", "UpgradeHeroLevel", "UpgradeHeroStar" } },
        { "Inventory", new[] { "BuyShopItem", "DecomposeEquipment", "EquipItem", "GetEquipmentList", "GetInventory", "PickUpItem", "SyncInventory", "SyncResource", "UnequipItem", "UpgradeEquipment", "UseItem" } },
        { "Lobby", new[] { "GetLeaderboard", "GetLobbyInfo" } },
        { "Mail", new[] { "ClaimMailAttachment", "DeleteMail", "GetMailList", "NewMailNotify", "ReadMail", "SendMail" } },
        { "Profile", new[] { "GetPlayerProfile" } },
        { "Session", new[] { "Heartbeat", "NotifyKickOff" } },
        { "Shop", new[] { "GetShopInfo", "RefreshShop" } },
        { "Task", new[] { "ClaimTaskReward", "GetTaskList" } },
        { "Team", new[] { "CreateTeam", "InviteToTeam", "KickTeamMember", "LeaveTeam", "RespondTeamInvite", "TeamUpdateNotify" } },
        { "Tower", new[] { "EnterTower", "GetTowerInfo", "SweepTower" } },
        { "WorldBoss", new[] { "EnterWorldBoss", "WorldBossAttack", "WorldBossStatusNotify" } },
    };
}

