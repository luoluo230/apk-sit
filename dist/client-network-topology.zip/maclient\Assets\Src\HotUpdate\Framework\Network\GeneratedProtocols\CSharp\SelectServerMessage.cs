﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 选择服务器请求
/// </summary>
public class SelectServer_c2s
{
    /// <summary>
    /// 目标服务器 ID
    /// </summary>
    public string ServerId { get; set; }
}

/// <summary>
/// 选择服务器响应
/// </summary>
public class SelectServer_s2c
{
    /// <summary>
    /// 是否成功进入服务器
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 服务器 ID
    /// </summary>
    public string ServerId { get; set; }
    /// <summary>
    /// 已有角色信息
    /// </summary>
    public PlayerProfile Profile { get; set; }
}

