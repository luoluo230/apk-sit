﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取任务列表(包含每日/每周/主线等)
/// </summary>
public class GetTaskList_c2s
{
    /// <summary>
    /// 任务类型(可选,为空则全部)
    /// </summary>
    public TaskType TaskType { get; set; }
}

/// <summary>
/// 任务列表响应
/// </summary>
public class GetTaskList_s2c
{
    /// <summary>
    /// 任务列表
    /// </summary>
    public TaskInfo[] Tasks { get; set; }
}

