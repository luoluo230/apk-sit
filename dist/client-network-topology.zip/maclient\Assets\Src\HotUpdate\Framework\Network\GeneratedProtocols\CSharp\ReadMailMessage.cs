﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 标记邮件为已读
/// </summary>
public class ReadMail_c2s
{
    /// <summary>
    /// 邮件 ID
    /// </summary>
    public long MailId { get; set; }
}

/// <summary>
/// 邮件已读操作结果
/// </summary>
public class ReadMail_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
}

