using System;
using System.Collections.Generic;
using System.Threading.Tasks;

/// <summary>
/// PVP 实时对战同步：订阅 BattleSpectatorFrameNotify，经 jitter buffer 平滑追帧并支持 resync。
/// </summary>
public sealed class BattlePvpRealtimeSync : IDisposable
{
    private readonly IGameplayBattleSyncModule _battleSync;
    private readonly IGameNetworkRequester _requester;
    private BattleSyncJitterBuffer _jitterBuffer;
    private IDisposable _frameSubscription;
    private string _battleId;

    public event Action<IReadOnlyList<BattleFrameBundle>> OnFramesReady;

    public BattlePvpRealtimeSync(IGameNetworkRequester requester, IGameplayBattleSyncModule battleSync)
    {
        _requester = requester ?? throw new ArgumentNullException(nameof(requester));
        _battleSync = battleSync ?? throw new ArgumentNullException(nameof(battleSync));
    }

    public string BattleId => _battleId;
    public BattleSyncJitterBuffer JitterBuffer => _jitterBuffer;
    public bool IsActive => !string.IsNullOrWhiteSpace(_battleId);

    public void Start(string battleId, int targetBufferMs = 80)
    {
        Stop();
        _battleId = string.IsNullOrWhiteSpace(battleId) ? throw new ArgumentException("battleId required") : battleId;
        _jitterBuffer = new BattleSyncJitterBuffer(_battleSync, _battleId, targetBufferMs);
        _jitterBuffer.StartHealthLoop();
        _frameSubscription = _requester.Subscribe<BattleSpectatorFrameNotify_s2c>(OnFrameNotify);
    }

    public void Stop()
    {
        _frameSubscription?.Dispose();
        _frameSubscription = null;
        _jitterBuffer?.Dispose();
        _jitterBuffer = null;
        _battleId = null;
    }

    public Task<BattleCommand_s2c> SendCommandAsync(string commandType, string payloadJson, long actorId = 0, int frame = 0)
    {
        if (!IsActive)
        {
            throw new InvalidOperationException("PVP sync session is not started.");
        }

        return _battleSync.SendCommandAsync(_battleId, commandType, payloadJson, actorId, frame, frame);
    }

    public Task<bool> ReportHealthAsync(int clientFrame, string stateHash, int rttMs, int jitterMs, float packetLoss)
    {
        if (_jitterBuffer == null)
        {
            return Task.FromResult(false);
        }

        return _jitterBuffer.ReportHealthAndResyncIfNeededAsync(clientFrame, stateHash, rttMs, jitterMs, packetLoss);
    }

    private void OnFrameNotify(BattleSpectatorFrameNotify_s2c notify)
    {
        if (notify == null || string.IsNullOrWhiteSpace(_battleId))
        {
            return;
        }

        if (!string.Equals(notify.BattleId, _battleId, StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        _jitterBuffer?.PushRemoteFrame(notify);
        var ready = _jitterBuffer?.ConsumeReadyFrames(notify.Frame) ?? Array.Empty<BattleFrameBundle>();
        if (ready.Count > 0)
        {
            OnFramesReady?.Invoke(ready);
        }
    }

    public void Dispose()
    {
        Stop();
    }
}
