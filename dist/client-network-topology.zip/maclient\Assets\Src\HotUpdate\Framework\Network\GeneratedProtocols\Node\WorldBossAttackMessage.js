// 自动生成的协议文件

// 定义协议类


// 世界 Boss 攻击上报
class WorldBossAttack_c2s {
    constructor() {
        this.BossId = '';
        this.Damage = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 世界 Boss 攻击结果
class WorldBossAttack_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Boss = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    WorldBossAttack_c2s,
    WorldBossAttack_s2c,
};
