// 自动生成的协议文件

// 定义协议类


// 发送邮件(玩家对玩家)
class SendMail_c2s {
    constructor() {
        this.ToPlayerId = null;
        this.Title = '';
        this.Content = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 发送邮件结果
class SendMail_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.MailId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SendMail_c2s,
    SendMail_s2c,
};
