// 自动生成的协议文件

// 定义协议类


// 英雄数据同步(升级/升星/获取/分解等)
class SyncHero_s2c {
    constructor() {
        this.UpdatedHeroes = [];
        this.RemovedHeroIds = [];
        this.Reason = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SyncHero_s2c,
};
