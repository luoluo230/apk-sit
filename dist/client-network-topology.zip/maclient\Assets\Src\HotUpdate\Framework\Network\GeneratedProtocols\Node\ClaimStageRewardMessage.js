// 自动生成的协议文件

// 定义协议类


// 领取关卡奖励(首通/星级/章节宝箱等)
class ClaimStageReward_c2s {
    constructor() {
        this.StageId = '';
        this.RewardType = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 关卡奖励领取结果
class ClaimStageReward_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.StageId = '';
        this.RewardType = '';
        this.Rewards = [];
        this.ResourceChanges = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ClaimStageReward_c2s,
    ClaimStageReward_s2c,
};
