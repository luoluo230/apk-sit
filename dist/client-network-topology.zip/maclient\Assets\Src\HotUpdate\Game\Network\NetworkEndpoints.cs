using System;
using System.Collections.Generic;

public static class NetworkEndpoints
{
    public enum Environment
    {
        Dev,
        QA,
        Prod
    }

    public enum Channel
    {
        Login,
        Game,
        Battle,
        Report
    }

    public static Environment CurrentEnvironment = Environment.Dev;

    // 本地联调默认指向 game-server 网关：ws://127.0.0.1:5050/ws
    public const string LoginWebSocket = "ws://127.0.0.1:5050/ws";
    // 目前游戏内业务也走同一条 WebSocket 网关连接，保留字段名以便未来拆分
    public const string GameTcp = "ws://127.0.0.1:5050/ws";
    public const string BattleKcp = "ws://127.0.0.1:5050/ws";
    public const string ReportHttp = "http://127.0.0.1:8080/api";

    private static readonly Dictionary<Environment, Dictionary<Channel, string>> Endpoints =
        new Dictionary<Environment, Dictionary<Channel, string>>
        {
            {
                Environment.Dev,
                new Dictionary<Channel, string>
                {
                    { Channel.Login, LoginWebSocket },
                    { Channel.Game, GameTcp },
                    { Channel.Battle, BattleKcp },
                    { Channel.Report, ReportHttp }
                }
            },
            {
                Environment.QA,
                new Dictionary<Channel, string>
                {
                    { Channel.Login, "ws://qa.example.com:9001" },
                    { Channel.Game, "tcp://qa.example.com:9002" },
                    { Channel.Battle, "kcp://qa.example.com:9003" },
                    { Channel.Report, "http://qa.example.com:8080/api" }
                }
            },
            {
                Environment.Prod,
                new Dictionary<Channel, string>
                {
                    { Channel.Login, "wss://prod.example.com:9001" },
                    { Channel.Game, "tcp://prod.example.com:9002" },
                    { Channel.Battle, "kcp://prod.example.com:9003" },
                    { Channel.Report, "https://prod.example.com/api" }
                }
            }
        };

    public static string GetEndpoint(Environment env, Channel channel)
    {
        if (Endpoints.TryGetValue(env, out var byChannel) && byChannel.TryGetValue(channel, out var url))
        {
            return url;
        }

        throw new ArgumentOutOfRangeException(nameof(channel), $"未配置端点: {env}.{channel}");
    }

    public static string GetEndpoint(Channel channel)
    {
        return GetEndpoint(CurrentEnvironment, channel);
    }
}
