// 自动生成的协议文件

// 定义协议类


// 服务器权威战斗启动请求(兼容旧版 EnterBattle)
class EnterBattle_c2s {
    constructor() {
        this.StageId = '';
        this.BattleMode = '';
        this.SyncMode = null;
        this.Formation = [];
        this.ClientTime = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 战斗启动响应(兼容客户端表演字段)
class EnterBattle_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.BattleId = '';
        this.Phase = null;
        this.ServerTime = null;
        this.Scene = null;
        this.Sync = null;
        this.Participants = [];
        this.Self = null;
        this.Allies = [];
        this.Enemies = [];
        this.InitialUnits = [];
        this.Warmup = [];
        this.Anchor = null;
        this.Custom = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    EnterBattle_c2s,
    EnterBattle_s2c,
};
