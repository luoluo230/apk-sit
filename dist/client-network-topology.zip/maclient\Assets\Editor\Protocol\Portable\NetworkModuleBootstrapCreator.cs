using UnityEditor;
using UnityEngine;

/// <summary>
/// 网络模块运行时一键引导创建器。
/// 在当前场景创建单组件壳 NetworkBootstrap，由其自动托管底层网络组件。
/// </summary>
public static class NetworkModuleBootstrapCreator
{
    [MenuItem("Tools/MAClient/协议与网络/创建网络模块运行时引导", priority = 14)]
    public static void CreateBootstrapInCurrentScene()
    {
        var root = new GameObject("NetworkModuleBootstrap");
        Undo.RegisterCreatedObjectUndo(root, "Create NetworkModuleBootstrap");
        root.AddComponent<NetworkBootstrap>();

        Selection.activeGameObject = root;
        EditorGUIUtility.PingObject(root);

        EditorUtility.DisplayDialog(
            "创建完成",
            "已创建 NetworkBootstrap 单组件壳。\n请配置 ProtocolNetworkSettings 后运行。",
            "确定");
    }
}
