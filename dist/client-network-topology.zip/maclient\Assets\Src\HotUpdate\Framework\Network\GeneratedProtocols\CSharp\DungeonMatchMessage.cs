﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 副本匹配请求
/// </summary>
public class DungeonMatch_c2s
{
    /// <summary>
    /// 副本 ID
    /// </summary>
    public int DungeonId { get; set; }
    /// <summary>
    /// 难度
    /// </summary>
    public string Difficulty { get; set; }
    /// <summary>
    /// 阵容
    /// </summary>
    public FormationSlot[] Formation { get; set; }
}

/// <summary>
/// 副本匹配响应
/// </summary>
public class DungeonMatch_s2c
{
    /// <summary>
    /// 是否成功进入匹配
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 匹配 ID
    /// </summary>
    public string MatchId { get; set; }
    /// <summary>
    /// 预计等待时间
    /// </summary>
    public int EstimatedWaitSeconds { get; set; }
    /// <summary>
    /// 组队成员信息
    /// </summary>
    public TeamMemberInfo[] Team { get; set; }
    /// <summary>
    /// 战斗服地址
    /// </summary>
    public string ServerAddress { get; set; }
}

