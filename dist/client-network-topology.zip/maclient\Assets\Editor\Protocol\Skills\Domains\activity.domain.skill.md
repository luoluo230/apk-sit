# Activity Domain Skill

- Client: generate activity/campaign/task use cases with time-window refresh hooks and red-point update callback.
- Server: generate activity open-time validation, reward claim idempotency, progress query/update repository hooks, and audit log placeholders.
- Reward claims must guard against duplicate claim.
