// 自动生成的协议文件

// 定义协议类


// 获取活动列表请求
class GetEvents_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 获取活动列表响应
class GetEvents_s2c {
    constructor() {
        this.Events = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetEvents_c2s,
    GetEvents_s2c,
};
