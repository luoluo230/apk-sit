// 自动生成的协议文件

// 定义协议类


// 选择服务器请求
class SelectServer_c2s {
    constructor() {
        this.ServerId = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 选择服务器响应
class SelectServer_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.ServerId = '';
        this.Profile = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    SelectServer_c2s,
    SelectServer_s2c,
};
