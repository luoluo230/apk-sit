﻿// Framework: endpoint config interface. Business layer implements and injects for portability.

/// <summary>
/// Network channel enum. Framework defines; business maps to URLs.
/// </summary>
public enum NetworkChannel
{
    Login = 0,
    Game = 1,
    Battle = 2,
    Report = 3
}

/// <summary>
/// Endpoint provider. Business implements (e.g. from config/ScriptableObject/RemoteConfig)
/// and uses NetworkFacade/GameNetworkClient routing for framework/business decoupling.
/// </summary>
public interface INetworkEndpointProvider
{
    string GetEndpoint(NetworkChannel channel);
}

