﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 登录请求协议
/// </summary>
public class Login_c2s
{
    /// <summary>
    /// 账号
    /// </summary>
    public string Username { get; set; }
    /// <summary>
    /// 密码
    /// </summary>
    public string Password { get; set; }
    /// <summary>
    /// 设备信息
    /// </summary>
    public DeviceInfo Device { get; set; }
}

/// <summary>
/// 登录响应协议
/// </summary>
public class Login_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示信息
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 登录 Token
    /// </summary>
    public AuthToken Token { get; set; }
    /// <summary>
    /// 玩家基础信息
    /// </summary>
    public PlayerProfile Profile { get; set; }
    /// <summary>
    /// 是否自动登录到上次服务器
    /// </summary>
    public bool AutoLogin { get; set; }
    /// <summary>
    /// 上次登录的服务器 ID
    /// </summary>
    public string LastServerId { get; set; }
    /// <summary>
    /// 需要手动选择时的服务器列表
    /// </summary>
    public ServerInfo[] ServerList { get; set; }
}

