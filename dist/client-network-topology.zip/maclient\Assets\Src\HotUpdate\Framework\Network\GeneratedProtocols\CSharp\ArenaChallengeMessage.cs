﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 发起竞技场挑战
/// </summary>
public class ArenaChallenge_c2s
{
    /// <summary>
    /// 挑战目标 ID
    /// </summary>
    public long TargetPlayerId { get; set; }
    /// <summary>
    /// 进攻阵容
    /// </summary>
    public FormationSlot[] Formation { get; set; }
}

/// <summary>
/// 竞技场挑战结果(简单结算, 详细战斗走 BattleResult)
/// </summary>
public class ArenaChallenge_s2c
{
    /// <summary>
    /// 是否挑战成功(请求合法)
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 对应战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 新排名
    /// </summary>
    public int NewRank { get; set; }
    /// <summary>
    /// 排名变化(负数为下降)
    /// </summary>
    public int RankChange { get; set; }
    /// <summary>
    /// 挑战奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
}

