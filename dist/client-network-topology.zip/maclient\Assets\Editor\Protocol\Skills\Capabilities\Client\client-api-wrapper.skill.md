# Client API Wrapper Skill

## 职责

生成客户端协议 API 封装层，让业务代码只调用稳定方法，不直接拼 DTO、不直接依赖底层网络细节。

## 必须读取的上下文

- request/response 类型名、MessageID、字段表、required/default/deprecated。
- Client DTO 路径、Client ProtocolIds 路径、Client ProtocolDictionary 路径。
- `networkFacadeType` 和 `networkSendMethod`。
- `codeStyle`：Callback / TaskAsync / UniTask / Coroutine。

## 必须生成

- 一个以协议名命名的 API 类或静态方法集合。
- request DTO 构造入口，参数名来自协议字段。
- callback / async / coroutine 对应的发送方法。
- 成功、协议错误、网络错误、取消、超时分支。
- `ClientPolicy` 或等价策略对象，包含 timeout、retry、loading、并发保护、错误映射。

## 约束

- 不重新声明 DTO、ProtocolIds、ProtocolDictionary。
- 不直接操作 UI。
- 不把服务端权威计算放到客户端。
- 非幂等协议默认不自动重试。
- 敏感字段不得写入日志。

## 质量门禁

- 业务层能用一行调用发起请求。
- 错误信息能被业务层区分和展示。
- loading begin/end 在所有路径上成对出现。
- 没有项目真实取消/日志/埋点框架时，生成可替换接口。
