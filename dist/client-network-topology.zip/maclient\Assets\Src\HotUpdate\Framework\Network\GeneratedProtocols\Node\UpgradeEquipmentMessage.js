// 自动生成的协议文件

// 定义协议类


// 装备强化/升阶
class UpgradeEquipment_c2s {
    constructor() {
        this.EquipmentId = null;
        this.UseItems = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 装备强化/升阶结果
class UpgradeEquipment_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Equipment = null;
        this.InventoryDelta = null;
        this.ResourceChanges = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    UpgradeEquipment_c2s,
    UpgradeEquipment_s2c,
};
