using System;

/// <summary>
/// 快照同步通道接口。
/// 用于处理按状态快照覆盖的同步消息。
/// </summary>
public interface ISnapshotSyncChannel : ISyncChannel
{
    /// <summary>
    /// 注册某个消息 ID 的快照处理函数。
    /// </summary>
    void RegisterSnapshotHandler(int messageId, Action<NetMessage> handler);
}
