﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 进入世界 Boss
/// </summary>
public class EnterWorldBoss_c2s
{
    /// <summary>
    /// Boss ID
    /// </summary>
    public string BossId { get; set; }
}

/// <summary>
/// 进入世界 Boss 结果
/// </summary>
public class EnterWorldBoss_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// Boss 信息
    /// </summary>
    public WorldBossInfo Boss { get; set; }
}

