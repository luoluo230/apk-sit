﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 离开战斗观战会话
/// </summary>
public class BattleSpectatorLeave_c2s
{
    /// <summary>
    /// 观战会话 ID
    /// </summary>
    public string SessionId { get; set; }
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
    /// <summary>
    /// 扩展字段(JSON)
    /// </summary>
    public string Custom { get; set; }
}

/// <summary>
/// 离开战斗观战会话响应
/// </summary>
public class BattleSpectatorLeave_s2c
{
    /// <summary>
    /// 处理结果
    /// </summary>
    public BattleProtocolAck Ack { get; set; }
}

