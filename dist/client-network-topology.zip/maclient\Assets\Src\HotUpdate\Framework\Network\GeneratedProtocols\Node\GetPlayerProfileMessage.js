// 自动生成的协议文件

// 定义协议类


// 获取玩家信息请求
class GetPlayerProfile_c2s {
    constructor() {
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 获取玩家信息响应
class GetPlayerProfile_s2c {
    constructor() {
        this.Profile = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetPlayerProfile_c2s,
    GetPlayerProfile_s2c,
};
