using System.IO;
using UnityEditor;
using UnityEngine;

public static class ProtocolGenerationMenu
{
    private static readonly string RepoRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
    private static readonly string GenerateScriptPath = Path.Combine(RepoRoot, "tools", "protocols", "Generate-ProtocolArtifacts.ps1");
    private static readonly string ValidateScriptPath = Path.Combine(RepoRoot, "tools", "protocols", "Validate-ProtocolArtifacts.ps1");
    private static readonly string GeneratedRoot = Path.Combine(RepoRoot, "protocols", "generated");

    [MenuItem("Tools/MAClient/协议与网络/协议与代码生成工作台", priority = 10)]
    public static void OpenWorkbench()
    {
        ProtocolCodegenWorkbenchWindow.Open();
    }

    [MenuItem("Tools/MAClient/协议与网络/协议业务逻辑AI工作台", priority = 11)]
    public static void OpenBusinessLogicStudio()
    {
        ProtocolBusinessLogicStudioWindow.Open();
    }

    public static void GenerateArtifacts()
    {
        var service = new PowerShellProtocolArtifactService(GenerateScriptPath, ValidateScriptPath);
        bool ok = service.GenerateAll(out string output);
        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog(ok ? "Protocol generation completed" : "Protocol generation failed", string.IsNullOrWhiteSpace(output) ? "No output." : output, "OK");
    }

    public static void ValidateArtifacts()
    {
        var service = new PowerShellProtocolArtifactService(GenerateScriptPath, ValidateScriptPath);
        bool ok = service.Validate(out string output);
        EditorUtility.DisplayDialog(ok ? "Protocol validation passed" : "Protocol validation failed", string.IsNullOrWhiteSpace(output) ? "No output." : output, "OK");
    }

    public static void OpenGeneratedFolder()
    {
        EditorUtility.RevealInFinder(GeneratedRoot);
    }
}
