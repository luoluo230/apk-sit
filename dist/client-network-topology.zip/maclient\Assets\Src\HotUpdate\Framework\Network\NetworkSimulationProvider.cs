using System;
using UnityEngine;

public interface INetworkSimulationProvider
{
    void Configure(bool enabled, int latencyMs, int jitterMs, float lossPercent, float duplicatePercent, float reorderPercent, int bandwidthKbps, float disconnectAfterSeconds, int seed);
    bool Enabled { get; }
    bool ShouldDrop();
    int GetDuplicateCount();
    float GetDelaySeconds(int payloadBytes);
    bool ShouldDisconnect(float connectedDurationSeconds);
}

public sealed class NetworkSimulationProvider : INetworkSimulationProvider
{
    private System.Random _random = new System.Random(9527);
    private bool _enabled;
    private int _latencyMs;
    private int _jitterMs;
    private float _lossPercent;
    private float _duplicatePercent;
    private float _reorderPercent;
    private int _bandwidthKbps;
    private float _disconnectAfterSeconds;

    public bool Enabled => _enabled;

    public void Configure(bool enabled, int latencyMs, int jitterMs, float lossPercent, float duplicatePercent, float reorderPercent, int bandwidthKbps, float disconnectAfterSeconds, int seed)
    {
        _enabled = enabled;
        _latencyMs = Math.Max(0, latencyMs);
        _jitterMs = Math.Max(0, jitterMs);
        _lossPercent = Mathf.Clamp(lossPercent, 0f, 100f);
        _duplicatePercent = Mathf.Clamp(duplicatePercent, 0f, 100f);
        _reorderPercent = Mathf.Clamp(reorderPercent, 0f, 100f);
        _bandwidthKbps = Math.Max(0, bandwidthKbps);
        _disconnectAfterSeconds = Mathf.Max(0f, disconnectAfterSeconds);
        _random = new System.Random(seed <= 0 ? 9527 : seed);
    }

    public bool ShouldDrop()
    {
        if (!_enabled || _lossPercent <= 0f)
        {
            return false;
        }

        return NextPercent() < _lossPercent;
    }

    public int GetDuplicateCount()
    {
        if (!_enabled || _duplicatePercent <= 0f)
        {
            return 1;
        }

        return NextPercent() < _duplicatePercent ? 2 : 1;
    }

    public float GetDelaySeconds(int payloadBytes)
    {
        if (!_enabled)
        {
            return 0f;
        }

        float delayMs = _latencyMs;
        if (_jitterMs > 0)
        {
            delayMs += (float)((_random.NextDouble() * 2d - 1d) * _jitterMs);
        }

        if (_bandwidthKbps > 0 && payloadBytes > 0)
        {
            float bits = payloadBytes * 8f;
            float seconds = bits / (_bandwidthKbps * 1000f);
            delayMs += seconds * 1000f;
        }

        if (_reorderPercent > 0f && NextPercent() < _reorderPercent)
        {
            delayMs += Math.Max(5f, _jitterMs * 0.5f);
        }

        return Mathf.Max(0f, delayMs / 1000f);
    }

    public bool ShouldDisconnect(float connectedDurationSeconds)
    {
        if (!_enabled || _disconnectAfterSeconds <= 0f)
        {
            return false;
        }

        return connectedDurationSeconds >= _disconnectAfterSeconds;
    }

    private float NextPercent()
    {
        return (float)_random.NextDouble() * 100f;
    }
}

