# Client UseCase Skill

## 职责

生成面向业务流程的客户端 UseCase，把协议 API 封装成“页面/系统可以直接调用”的业务入口。

## 必须生成

- UseCase 类，依赖 API wrapper 和 policy。
- 输入参数校验与默认值处理。
- loading 策略接入点。
- retry 策略接入点。
- error mapping 到业务错误对象。
- success callback / result wrapper。
- after-success refresh hook，用于刷新背包、角色、邮件、资料等本地缓存。

## 禁止事项

- 不直接访问 Unity UI 组件。
- 不直接 new 具体页面。
- 不直接写本地缓存，除非生成可替换 cache interface。
- 不吞异常。

## 质量门禁

- Presenter 或业务系统可以只依赖 UseCase。
- 所有失败路径都有业务可感知结果。
- 支持取消或保留取消接入点。
