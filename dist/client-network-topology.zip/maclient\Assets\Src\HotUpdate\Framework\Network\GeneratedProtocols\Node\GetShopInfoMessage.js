// 自动生成的协议文件

// 定义协议类


// 获取商店信息
class GetShopInfo_c2s {
    constructor() {
        this.ShopType = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 商店信息响应
class GetShopInfo_s2c {
    constructor() {
        this.ShopType = null;
        this.Items = [];
        this.RefreshAt = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetShopInfo_c2s,
    GetShopInfo_s2c,
};
