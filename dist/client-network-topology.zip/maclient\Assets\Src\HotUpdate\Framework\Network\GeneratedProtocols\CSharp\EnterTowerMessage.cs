﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 进入塔层战斗(走通用EnterBattle)
/// </summary>
public class EnterTower_c2s
{
    /// <summary>
    /// 塔 ID
    /// </summary>
    public int TowerId { get; set; }
    /// <summary>
    /// 层数
    /// </summary>
    public int Floor { get; set; }
    /// <summary>
    /// 阵容
    /// </summary>
    public FormationSlot[] Formation { get; set; }
}

/// <summary>
/// 进入塔战斗结果
/// </summary>
public class EnterTower_s2c
{
    /// <summary>
    /// 请求是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 战斗 ID
    /// </summary>
    public string BattleId { get; set; }
}

