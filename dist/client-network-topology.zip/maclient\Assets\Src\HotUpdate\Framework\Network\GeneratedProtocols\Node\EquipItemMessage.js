// 自动生成的协议文件

// 定义协议类


// 穿戴装备
class EquipItem_c2s {
    constructor() {
        this.HeroId = null;
        this.SlotType = '';
        this.EquipmentId = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 穿戴装备结果
class EquipItem_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Hero = null;
        this.Equipment = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    EquipItem_c2s,
    EquipItem_s2c,
};
