// 自动生成的协议文件

// 定义协议类


// 领取任务奖励
class ClaimTaskReward_c2s {
    constructor() {
        this.TaskId = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 领取任务奖励结果
class ClaimTaskReward_s2c {
    constructor() {
        this.Success = false;
        this.Message = '';
        this.Task = null;
        this.Rewards = [];
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    ClaimTaskReward_c2s,
    ClaimTaskReward_s2c,
};
