﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 获取英雄列表
/// </summary>
public class GetHeroList_c2s
{
}

/// <summary>
/// 英雄列表响应
/// </summary>
public class GetHeroList_s2c
{
    /// <summary>
    /// 所有英雄列表
    /// </summary>
    public HeroInfo[] Heroes { get; set; }
}

