// 自动生成的协议文件

// 定义协议类


// 获取单个活动详情/进度
class GetEventDetail_c2s {
    constructor() {
        this.EventId = 0;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 活动详情响应(按具体活动自定义Custom)
class GetEventDetail_s2c {
    constructor() {
        this.Event = null;
        this.Progress = '';
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetEventDetail_c2s,
    GetEventDetail_s2c,
};
