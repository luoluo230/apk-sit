// 自动生成的协议文件

// 定义协议类


// 获取背包信息请求
class GetInventory_c2s {
    constructor() {
        this.ForceRefresh = false;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 获取背包信息响应
class GetInventory_s2c {
    constructor() {
        this.Inventory = null;
    }

    toJSON() {
        return JSON.stringify(this);
    }
}

// 导出协议类
module.exports = {
    GetInventory_c2s,
    GetInventory_s2c,
};
