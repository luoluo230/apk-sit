using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using UnityEditor;
using UnityEngine;

/// <summary>
/// 网络模块可移植 ZIP 导出器。
/// 一键导出完整便携包（包含 Assets 与协议工具脚本）。
/// </summary>
public static class NetworkModulePortableZipExporter
{
    private static readonly string[] AssetRoots =
    {
        "Assets/Src/HotUpdate/Framework/Network",
        "Assets/Src/HotUpdate/Game/Network",
        "Assets/Editor/Protocol",
        "Assets/Src/Protocols",
        "Assets/Resources/Protocol/ProtocolNetworkSettings.asset"
    };

    private static readonly string[] ToolRoots =
    {
        "tools/protocols"
    };

    [MenuItem("Tools/MAClient/协议与网络/导出网络模块ZIP便携包", priority = 15)]
    public static void ExportPortableZipBundle()
    {
        string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        string outputPath = EditorUtility.SaveFilePanel(
            "导出网络模块ZIP便携包",
            projectRoot,
            "MAClient_NetworkModule_Portable_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"),
            "zip");

        if (string.IsNullOrWhiteSpace(outputPath))
        {
            return;
        }

        string tempRoot = Path.Combine(Path.GetTempPath(), "maclient_network_portable_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(tempRoot);
            string bundleRoot = Path.Combine(tempRoot, "NetworkModulePortable");
            Directory.CreateDirectory(bundleRoot);

            CopyRoots(projectRoot, bundleRoot, AssetRoots);
            CopyRoots(projectRoot, bundleRoot, ToolRoots);
            WriteReadme(bundleRoot);

            if (File.Exists(outputPath))
            {
                File.Delete(outputPath);
            }

            ZipFile.CreateFromDirectory(bundleRoot, outputPath, System.IO.Compression.CompressionLevel.Optimal, false);
            EditorUtility.RevealInFinder(outputPath);
            Debug.Log("[NetworkModulePortableZipExporter] 导出成功: " + outputPath);
        }
        catch (Exception ex)
        {
            Debug.LogError("[NetworkModulePortableZipExporter] 导出失败: " + ex);
            EditorUtility.DisplayDialog("导出失败", ex.Message, "确定");
        }
        finally
        {
            try
            {
                if (Directory.Exists(tempRoot))
                {
                    Directory.Delete(tempRoot, true);
                }
            }
            catch
            {
            }
        }
    }

    private static void CopyRoots(string projectRoot, string bundleRoot, IEnumerable<string> roots)
    {
        foreach (var relative in roots)
        {
            string source = Path.Combine(projectRoot, relative.Replace('/', Path.DirectorySeparatorChar));
            if (!Directory.Exists(source) && !File.Exists(source))
            {
                Debug.LogWarning("[NetworkModulePortableZipExporter] 跳过不存在路径: " + relative);
                continue;
            }

            string dest = Path.Combine(bundleRoot, relative.Replace('/', Path.DirectorySeparatorChar));
            if (Directory.Exists(source))
            {
                CopyDirectory(source, dest);
            }
            else
            {
                Directory.CreateDirectory(Path.GetDirectoryName(dest) ?? bundleRoot);
                File.Copy(source, dest, true);
                string meta = source + ".meta";
                if (File.Exists(meta))
                {
                    File.Copy(meta, dest + ".meta", true);
                }
            }
        }
    }

    private static void CopyDirectory(string sourceDir, string destDir)
    {
        Directory.CreateDirectory(destDir);

        foreach (var file in Directory.GetFiles(sourceDir))
        {
            string fileName = Path.GetFileName(file);
            string destFile = Path.Combine(destDir, fileName);
            File.Copy(file, destFile, true);
        }

        foreach (var dir in Directory.GetDirectories(sourceDir))
        {
            string dirName = Path.GetFileName(dir);
            CopyDirectory(dir, Path.Combine(destDir, dirName));
        }
    }

    private static void WriteReadme(string bundleRoot)
    {
        string readmePath = Path.Combine(bundleRoot, "README_IMPORT.txt");
        string content =
            "Network Module Portable Bundle\n" +
            "1) 将 Assets/* 拷贝到目标 Unity 项目 Assets 目录。\n" +
            "2) 将 tools/protocols/* 拷贝到目标项目 tools/protocols 目录。\n" +
            "3) 在 Unity 执行：Tools/MAClient/协议与网络/网络模块可移植验收。\n" +
            "4) 按需从协议工作台执行协议生成/校验。\n" +
            "5) 执行：Tools/MAClient/协议与网络/创建网络模块运行时引导。\n";

        File.WriteAllText(readmePath, content);
    }
}
