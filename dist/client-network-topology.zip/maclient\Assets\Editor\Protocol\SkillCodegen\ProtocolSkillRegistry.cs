using System.Collections.Generic;
using System.IO;
using UnityEngine;

public static class ProtocolSkillRegistry
{
    private static readonly string CapabilityRoot = Path.Combine(Application.dataPath, "Editor", "Protocol", "Skills", "Capabilities");

    public static IReadOnlyList<ProtocolSkillDefinition> GetAll()
    {
        return new[]
        {
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.ClientApiWrapper, Target = ProtocolSkillTarget.Client, DisplayName = "Client API Wrapper", Description = "Generate protocol API wrappers for business code.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Client", "client-api-wrapper.skill.md"), WritesRuntimeCode = true },
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.ClientUseCase, Target = ProtocolSkillTarget.Client, DisplayName = "Client UseCase", Description = "Generate client use case layer with loading, retry, cancel and error hooks.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Client", "client-usecase.skill.md"), WritesRuntimeCode = true },
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.ClientPresenterBinding, Target = ProtocolSkillTarget.Client, DisplayName = "Client Presenter Sample", Description = "Generate UI or presenter usage sample.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Client", "client-presenter-binding.skill.md"), WritesRuntimeCode = true },
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.ServerHandler, Target = ProtocolSkillTarget.Server, DisplayName = "Server Handler", Description = "Generate server handler entry with validation, auth, transaction and service call.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Server", "server-handler.skill.md"), WritesRuntimeCode = true },
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.ServerService, Target = ProtocolSkillTarget.Server, DisplayName = "Server Service", Description = "Generate domain service skeleton.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Server", "server-service.skill.md"), WritesRuntimeCode = true },
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.ServerRepository, Target = ProtocolSkillTarget.Server, DisplayName = "Server Repository/DB", Description = "Generate repository, db model and migration drafts.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Server", "server-repository.skill.md"), WritesRuntimeCode = true, RequiresDatabaseReview = true },
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.ServerRouteRegistration, Target = ProtocolSkillTarget.Server, DisplayName = "Server Route Registration", Description = "Generate server route registration by _c2s MessageID.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Server", "server-route-registration.skill.md"), WritesRuntimeCode = true },
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.MockAndTest, Target = ProtocolSkillTarget.Both, DisplayName = "Mock And Test", Description = "Generate mock data and smoke test helpers.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Shared", "mock-and-test.skill.md"), WritesRuntimeCode = true },
            new ProtocolSkillDefinition { Kind = ProtocolSkillKind.Migration, Target = ProtocolSkillTarget.Both, DisplayName = "Migration Notes", Description = "Generate compatibility, migration, backfill and rollback notes.", PromptTemplatePath = Path.Combine(CapabilityRoot, "Shared", "migration.skill.md"), WritesRuntimeCode = false }
        };
    }
}
