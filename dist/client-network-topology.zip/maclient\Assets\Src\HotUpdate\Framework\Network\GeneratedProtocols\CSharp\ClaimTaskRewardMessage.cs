﻿// Generated from Assets/Src/Protocols/protocols.json. Do not edit by hand.
using System;

/// <summary>
/// 领取任务奖励
/// </summary>
public class ClaimTaskReward_c2s
{
    /// <summary>
    /// 任务 ID
    /// </summary>
    public int TaskId { get; set; }
}

/// <summary>
/// 领取任务奖励结果
/// </summary>
public class ClaimTaskReward_s2c
{
    /// <summary>
    /// 是否成功
    /// </summary>
    public bool Success { get; set; }
    /// <summary>
    /// 提示
    /// </summary>
    public string Message { get; set; }
    /// <summary>
    /// 更新后的任务状态
    /// </summary>
    public TaskInfo Task { get; set; }
    /// <summary>
    /// 获得奖励
    /// </summary>
    public RewardItem[] Rewards { get; set; }
}

